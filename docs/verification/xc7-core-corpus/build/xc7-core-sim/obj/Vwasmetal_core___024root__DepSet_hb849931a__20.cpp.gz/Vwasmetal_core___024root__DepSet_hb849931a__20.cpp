#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__26(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__26\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013839_;
    wasmetal_core__DOT___013839_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017856_;
    wasmetal_core__DOT___017856_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022709_;
    wasmetal_core__DOT___022709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045276_;
    wasmetal_core__DOT___045276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045277_;
    wasmetal_core__DOT___045277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045278_;
    wasmetal_core__DOT___045278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045300_;
    wasmetal_core__DOT___045300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045301_;
    wasmetal_core__DOT___045301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045302_;
    wasmetal_core__DOT___045302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045480_;
    wasmetal_core__DOT___045480_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045481_;
    wasmetal_core__DOT___045481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045482_;
    wasmetal_core__DOT___045482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045504_;
    wasmetal_core__DOT___045504_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045505_;
    wasmetal_core__DOT___045505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045506_;
    wasmetal_core__DOT___045506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054468_;
    wasmetal_core__DOT___054468_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054472_;
    wasmetal_core__DOT___054472_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059177_;
    wasmetal_core__DOT___059177_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059184_;
    wasmetal_core__DOT___059184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062975_;
    wasmetal_core__DOT___062975_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062985_;
    wasmetal_core__DOT___062985_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062998_;
    wasmetal_core__DOT___062998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062999_;
    wasmetal_core__DOT___062999_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070582_;
    wasmetal_core__DOT___070582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070583_;
    wasmetal_core__DOT___070583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070585_;
    wasmetal_core__DOT___070585_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___072264_;
    wasmetal_core__DOT___072264_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127440___O;
    wasmetal_core__DOT____Vcellout___127440___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127485___O;
    wasmetal_core__DOT____Vcellout___127485___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127614___O;
    wasmetal_core__DOT____Vcellout___127614___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hf7f66e14__0;
    __VdfgTmp_hf7f66e14__0 = 0;
    CData/*1:0*/ __VdfgTmp_h103fe912__0;
    __VdfgTmp_h103fe912__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0996db4e__0;
    __VdfgTmp_h0996db4e__0 = 0;
    CData/*1:0*/ __VdfgTmp_he5f9d86a__0;
    __VdfgTmp_he5f9d86a__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___039641_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039648_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039646_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039645_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039644_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039643_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039653_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039654_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039655_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039668_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039662_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039670_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039672_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039664_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___040056_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039656_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039642_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039683_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039671_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039669_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039661_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039657_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039667_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039659_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039666_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039660_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039673_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039674_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039675_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039689_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039682_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039691_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039698_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039684_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___040055_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039676_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039665_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039681_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039692_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039690_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039685_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039688_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039677_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039687_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039679_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039686_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039693_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039694_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___039695_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d)))))));
    vlSelf->wasmetal_core__DOT___039696_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d)))))));
    vlSelf->wasmetal_core__DOT___039697_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___039678_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT___039680_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d)))))));
    vlSelf->wasmetal_core__DOT___039700_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d)))))));
    vlSelf->wasmetal_core__DOT___039701_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d)))))));
    vlSelf->wasmetal_core__DOT___039702_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d)))))));
    vlSelf->wasmetal_core__DOT___039703_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d)))))));
    vlSelf->wasmetal_core__DOT___039704_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___039705_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d)))))));
    vlSelf->wasmetal_core__DOT___039706_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d)))))));
    vlSelf->wasmetal_core__DOT___039707_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d)))))));
    vlSelf->wasmetal_core__DOT___039727_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b77__05d)))))));
    vlSelf->wasmetal_core__DOT___039719_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d)))))));
    vlSelf->wasmetal_core__DOT___039718_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b79__05d)))))));
    vlSelf->wasmetal_core__DOT___039717_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d)))))));
    vlSelf->wasmetal_core__DOT___039716_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d)))))));
    vlSelf->wasmetal_core__DOT___039699_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b82__05d)))))));
    vlSelf->wasmetal_core__DOT___039708_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b83__05d)))))));
    vlSelf->wasmetal_core__DOT___039715_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b84__05d)))))));
    vlSelf->wasmetal_core__DOT___039713_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___039712_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b86__05d)))))));
    vlSelf->wasmetal_core__DOT___039711_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d)))))));
    vlSelf->wasmetal_core__DOT___039710_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))))));
    vlSelf->wasmetal_core__DOT___039720_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___039742_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d)))))));
    vlSelf->wasmetal_core__DOT___039731_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___039730_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d)))))));
    vlSelf->wasmetal_core__DOT___039728_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d)))))));
    vlSelf->wasmetal_core__DOT___040050_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___039721_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___039709_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039725_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___039729_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT___039724_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d)))))));
    vlSelf->wasmetal_core__DOT___039723_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT___039732_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d)))))));
    vlSelf->wasmetal_core__DOT___039733_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT___039734_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___039752_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d)))))));
    vlSelf->wasmetal_core__DOT___039746_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT___039745_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT___039744_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT___039743_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d)))))));
    vlSelf->wasmetal_core__DOT___039726_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT___039735_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT___039722_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d)))))));
    vlSelf->wasmetal_core__DOT___039740_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d)))))));
    vlSelf->wasmetal_core__DOT___039739_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d)))))));
    vlSelf->wasmetal_core__DOT___039738_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d)))))));
    vlSelf->wasmetal_core__DOT___039737_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d)))))));
    vlSelf->wasmetal_core__DOT___039747_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d)))))));
    vlSelf->wasmetal_core__DOT___039748_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d)))))));
    vlSelf->wasmetal_core__DOT___039749_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d)))))));
    vlSelf->wasmetal_core__DOT___039759_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d)))))));
    vlSelf->wasmetal_core__DOT___039757_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d)))))));
    vlSelf->wasmetal_core__DOT___039756_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d)))))));
    vlSelf->wasmetal_core__DOT___039754_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d)))))));
    vlSelf->wasmetal_core__DOT___039753_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d)))))));
    vlSelf->wasmetal_core__DOT___040047_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d)))))));
    vlSelf->wasmetal_core__DOT___039750_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d)))))));
    vlSelf->wasmetal_core__DOT___039736_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d)))))));
    vlSelf->wasmetal_core__DOT___039751_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d)))))));
    vlSelf->wasmetal_core__DOT___040104_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053923_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039592_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053924_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039564_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053925_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039571_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039569_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053927_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_y) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039568_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053928_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039567_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053929_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039566_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053930_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039573_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053931_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039574_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053932_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039591_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053933_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039585_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053934_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039584_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039583_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053936_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039582_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039570_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053938_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039575_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053939_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xcU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039565_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053940_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039580_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053941_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039579_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053942_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039578_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053943_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039577_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053944_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039586_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053945_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039587_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053946_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039588_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053947_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039597_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039595_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039594_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053950_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039593_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053951_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039576_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039581_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039589_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053954_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039627_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039601_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039600_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039599_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039603_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039604_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039619_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039615_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039614_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039613_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039612_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039602_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039605_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039598_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039610_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039609_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039608_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039607_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039616_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039620_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039611_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039617_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039606_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039618_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039621_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039622_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039623_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039624_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039625_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039626_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039630_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039628_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026492_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026520_)));
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127959___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027361_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027360_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027359_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027358_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027292_)))));
    vlSelf->wasmetal_core__DOT___027296_ = ((IData)(vlSelf->wasmetal_core__DOT___027361_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b35__05d));
    vlSelf->wasmetal_core__DOT___057372_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___057236_ = (1U & (0x3fafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff33330f0f5555ULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054929_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0ccccff00aaaaULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O))))))))))))))));
    vlSelf->wasmetal_core__DOT___057670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 2U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033443_));
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030251_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d));
    wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d));
    vlSelf->__VdfgTmp_h276f18a3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->__VdfgTmp_h8ddb6508__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->__VdfgTmp_hf2c31503__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_h87705c6a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023886_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d) {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024013_;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT____Vcellout___127440___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h419b9e2f__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022523_)))));
    vlSelf->wasmetal_core__DOT___022528_ = ((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022795_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0))));
    vlSelf->__VdfgTmp_hcc8c0380__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->__VdfgTmp_h747f7a26__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->__VdfgTmp_h1eb7369a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_h183d05b4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022876_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022939_;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022699_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022699_));
    wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___043056_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057806_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017910_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057790_))))))))))));
    vlSelf->wasmetal_core__DOT___017888_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf64b2678__0)))));
    vlSelf->wasmetal_core__DOT___057838_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006933_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha11b0f77__0))));
    vlSelf->wasmetal_core__DOT___043062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017811_))));
    vlSelf->wasmetal_core__DOT___043059_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057923_)))));
    vlSelf->wasmetal_core__DOT___043051_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016297_)))))))));
    wasmetal_core__DOT___070585_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0))));
    vlSelf->wasmetal_core__DOT___017831_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0faccffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_)))));
    wasmetal_core__DOT___070583_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017874_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057817_))));
    wasmetal_core__DOT___017856_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017874_)
                                           ? ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xb0bbULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xf0ff4044ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))
                                           : ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xbbbb00000b00ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xffff44440f000400ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))));
    vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))));
    vlSelf->wasmetal_core__DOT___043036_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043040_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))))))));
    vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))));
    vlSelf->__VdfgTmp_h96af251d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)));
    vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022628_)
            ? (IData)(vlSelf->wasmetal_core__DOT___022635_)
            : (IData)(vlSelf->wasmetal_core__DOT___022628_));
    vlSelf->wasmetal_core__DOT___063683_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063681_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063691_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063690_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063689_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063699_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063698_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063697_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063707_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063706_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063705_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    wasmetal_core__DOT___045482_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045506_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045278_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045302_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045480_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071374_))))))));
    wasmetal_core__DOT___045504_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071374_)))))))));
    wasmetal_core__DOT___045481_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071377_))))))));
    wasmetal_core__DOT___045505_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071377_)))))))));
    wasmetal_core__DOT___045276_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071437_))))))));
    wasmetal_core__DOT___045300_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071437_)))))))));
    wasmetal_core__DOT___045277_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071440_))))))));
    wasmetal_core__DOT___045301_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071440_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127975___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           ^ (((IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027422_)))));
    vlSelf->wasmetal_core__DOT___027427_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063296_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063298_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027296_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b36__05d));
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030252_)
            ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d;
        wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127595___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023751_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023750_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023749_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023748_)))) 
           ^ (((IData)(wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023684_)))));
    vlSelf->wasmetal_core__DOT___023688_ = ((IData)(vlSelf->wasmetal_core__DOT___023751_)
                                             ? (IData)(wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d));
    vlSelf->wasmetal_core__DOT___023756_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058901_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058708_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0))))))));
    vlSelf->wasmetal_core__DOT___023755_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d))));
    vlSelf->wasmetal_core__DOT___058871_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d))))));
    vlSelf->wasmetal_core__DOT___023754_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d))));
    vlSelf->wasmetal_core__DOT___023753_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d))));
    vlSelf->__VdfgTmp_hb47c9e11__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hb48e3438__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127440___O)))))));
    vlSelf->__VdfgTmp_h2914f84f__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->__VdfgTmp_hd5e33f95__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127440___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_h584814f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h5b56c921__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_));
    vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022528_));
    vlSelf->wasmetal_core__DOT____Vcellout___127580___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002193_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h80016717__0))) 
           ^ (((IData)(wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023587_)))));
    vlSelf->wasmetal_core__DOT___023592_ = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                            & (IData)(wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d;
        wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127473___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022796_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022795_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022794_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022793_)))) 
           ^ (((IData)(wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022761_)))));
    vlSelf->wasmetal_core__DOT___022765_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022796_)
                                                   ? (IData)(wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))));
    vlSelf->wasmetal_core__DOT___022801_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))))));
    vlSelf->wasmetal_core__DOT___059193_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h7e209046__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)))))))))));
    vlSelf->wasmetal_core__DOT___022800_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0))))));
    vlSelf->wasmetal_core__DOT___059088_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O)))))));
    vlSelf->wasmetal_core__DOT___059170_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059165_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)))))))))));
    vlSelf->wasmetal_core__DOT___022799_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0))))));
    vlSelf->wasmetal_core__DOT___059178_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059172_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)))))))))));
    vlSelf->wasmetal_core__DOT___022798_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))))));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022700_));
    vlSelf->wasmetal_core__DOT____Vcellout___127563___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003806_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005868_)))) 
           ^ (((IData)(wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023466_)))));
    vlSelf->wasmetal_core__DOT___023471_ = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                            & (IData)(wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___070582_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017888_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057871_))));
    vlSelf->wasmetal_core__DOT___017858_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017888_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))));
    vlSelf->wasmetal_core__DOT___043053_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057843_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057835_)))))))));
    vlSelf->wasmetal_core__DOT___017861_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057843_)))))))));
    vlSelf->wasmetal_core__DOT___043063_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))));
    vlSelf->wasmetal_core__DOT___043057_ = (1U & (IData)(
                                                         (0xffff40ff40ff4040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017849_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057781_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___070585_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017828_)))))))));
    vlSelf->wasmetal_core__DOT___043055_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057812_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(wasmetal_core__DOT___017856_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057858_)))))))));
    vlSelf->__VdfgTmp_hb36cd122__0 = ((2U & ((IData)(
                                                     (0xf8ffffff0700ULL 
                                                      >> 
                                                      ((0x20U 
                                                        & ((0xefU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                           << 5U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017848_)))))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___017856_));
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                  >> 2U) | (IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022629_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022629_));
    vlSelf->wasmetal_core__DOT___045469_ = ((IData)(vlSelf->wasmetal_core__DOT___045515_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045514_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045512_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045511_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045510_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045509_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045508_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045507_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045506_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045505_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045504_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045503_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045523_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045522_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045521_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045520_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045519_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045518_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045517_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045516_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045513_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045502_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045478_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045489_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045492_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045493_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045494_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045495_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045496_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045497_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045498_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045499_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045479_))
                                                          : (IData)(wasmetal_core__DOT___045480_))
                                                         : (IData)(wasmetal_core__DOT___045481_))
                                                        : (IData)(wasmetal_core__DOT___045482_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045483_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045484_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045485_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045486_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045487_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045488_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045490_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045491_));
    vlSelf->wasmetal_core__DOT___045265_ = ((IData)(vlSelf->wasmetal_core__DOT___045311_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045310_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045308_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045307_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045306_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045305_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045304_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045303_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045302_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045301_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045300_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045299_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045319_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045318_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045317_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045316_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045315_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045314_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045313_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045312_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045309_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045298_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045274_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045285_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045288_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045289_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045290_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045291_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045292_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045293_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045294_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045295_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045275_))
                                                          : (IData)(wasmetal_core__DOT___045276_))
                                                         : (IData)(wasmetal_core__DOT___045277_))
                                                        : (IData)(wasmetal_core__DOT___045278_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045279_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045280_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045281_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045282_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045283_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045284_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045286_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045287_));
    vlSelf->wasmetal_core__DOT___044867_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)))))))))));
    vlSelf->wasmetal_core__DOT___044891_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d))))))));
    vlSelf->__VdfgTmp_h93b91d72__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027427_));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027363_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b37__05d));
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
           & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128254___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030253_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030252_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030251_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030250_)))) 
           ^ (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030185_)))));
    vlSelf->wasmetal_core__DOT___030189_ = ((IData)(vlSelf->wasmetal_core__DOT___030253_)
                                             ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___023890_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023890_ = wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058907_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058901_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058900_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023688_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d));
    vlSelf->wasmetal_core__DOT___023208_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))));
    vlSelf->wasmetal_core__DOT___023207_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))));
    vlSelf->wasmetal_core__DOT___023206_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006215_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))));
    vlSelf->wasmetal_core__DOT___023205_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))));
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022473_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013822_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))))));
    __VdfgTmp_h0996db4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___013764_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002631_)))))))));
    vlSelf->wasmetal_core__DOT___013763_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002630_))))));
    vlSelf->wasmetal_core__DOT___013813_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002629_))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023592_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___022880_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022880_ = wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___059177_ = (1U & (IData)((0x700000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059170_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059169_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059168_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022798_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022765_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))));
    wasmetal_core__DOT___022709_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022713_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___022713_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127460___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022713_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022700_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022699_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022698_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022705_)))));
    vlSelf->wasmetal_core__DOT___006673_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h276936c0__0)))));
    vlSelf->wasmetal_core__DOT___050105_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___050092_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006022_))))));
    vlSelf->wasmetal_core__DOT___006676_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005770_))))));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023471_));
    vlSelf->wasmetal_core__DOT___043060_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017858_))));
    vlSelf->wasmetal_core__DOT___043054_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017887_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057865_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070582_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057876_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134185___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036988_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022630_)
            ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022630_));
    vlSelf->__VdfgTmp_hf5578d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___045469_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045321_));
    vlSelf->wasmetal_core__DOT___062972_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___062970_)))))));
    __VdfgTmp_h103fe912__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044280_));
    __VdfgTmp_hf7f66e14__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)));
    vlSelf->wasmetal_core__DOT___052691_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052644_))));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128555___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033443_)))));
    vlSelf->wasmetal_core__DOT___033447_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                                            & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030255_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030189_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127630___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024013_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___024017_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024017_ = wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023890_;
    }
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d));
    wasmetal_core__DOT____Vcellout___127614___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023886_)))));
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022474_) 
           & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013814_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h0996db4e__0))))))));
    wasmetal_core__DOT___013839_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h0996db4e__0))))))));
    vlSelf->wasmetal_core__DOT___013742_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013813_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___002633_)))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127493___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022939_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___022943_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022943_ = wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022880_;
    }
    vlSelf->wasmetal_core__DOT___059187_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059178_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059177_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059176_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))))))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022799_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0))));
    wasmetal_core__DOT____Vcellout___127485___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022876_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127461___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                 ? (IData)(wasmetal_core__DOT___022709_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)) 
               << 1U) | (IData)(wasmetal_core__DOT___022709_)));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___022639_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022643_)
                                                   ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___022643_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127451___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022643_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022630_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022629_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022628_)))) 
           ^ (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022635_)))));
    vlSelf->wasmetal_core__DOT___052862_ = (1U & (IData)(
                                                         (0xefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052855_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052703_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf5578d4c__0))))))));
    vlSelf->wasmetal_core__DOT___053595_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052578_)))))))));
    vlSelf->wasmetal_core__DOT___052707_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052703_))));
    wasmetal_core__DOT___062975_ = (1U & (IData)((0xf7000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062964_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062963_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062972_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__decoded_table)))))))));
    vlSelf->wasmetal_core__DOT___019774_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    vlSelf->wasmetal_core__DOT___054475_ = (1U & (IData)(
                                                         (0x3000a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->done) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_h103fe912__0)))))))))));
    wasmetal_core__DOT___062998_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((1U 
                                                         >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))));
    vlSelf->wasmetal_core__DOT___053593_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    wasmetal_core__DOT___054468_ = (1U & (0x10U >> 
                                          ((4U & ((1U 
                                                   >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052644_)))));
    vlSelf->wasmetal_core__DOT___063009_ = (1U & (IData)(
                                                         (0x8fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((IData)(
                                                                                (0x1f1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128899___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___044897_)))))))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___062992_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062990_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062979_)))))))));
    vlSelf->wasmetal_core__DOT___053594_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))))));
    vlSelf->wasmetal_core__DOT___052692_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))));
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127960___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027365_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027364_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027363_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027362_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027296_)))));
    vlSelf->wasmetal_core__DOT___027300_ = ((IData)(vlSelf->wasmetal_core__DOT___027365_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b39__05d));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033447_));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030256_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024017_;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023755_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d));
    vlSelf->__VdfgTmp_hea953bdf__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h8fda36d2__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h9c2e8d35__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127614___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_hc450b1a0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT____Vcellout___127441___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022475_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022473_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022472_)))) 
           ^ (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022528_)))));
    vlSelf->wasmetal_core__DOT___022532_ = ((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                            & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___013825_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                & (IData)(wasmetal_core__DOT___013839_))
                                             : (IData)(wasmetal_core__DOT___013839_));
    vlSelf->__VdfgTmp_he2ae9361__0 = (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013672_));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) {
        vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d;
        wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022943_;
        wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022800_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0))));
    vlSelf->__VdfgTmp_h0ecf04e3__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h3e9bda10__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h601f88f8__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127485___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_h36468d91__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT___051266_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))))));
    vlSelf->wasmetal_core__DOT___024134_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___002961_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127452___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                 ? (IData)(vlSelf->wasmetal_core__DOT___022639_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022639_)));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036988_)));
    vlSelf->wasmetal_core__DOT___016473_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058528_))))));
    vlSelf->wasmetal_core__DOT___036393_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___043037_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043041_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128860___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_h29bb7b8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h7b6ee7cc__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 2U)));
    vlSelf->wasmetal_core__DOT___053101_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052862_)))));
    vlSelf->wasmetal_core__DOT___053509_ = (1U & (IData)(
                                                         (0xefff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052707_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hf7f66e14__0))))));
    wasmetal_core__DOT___062985_ = (1U & (IData)((0xbfbfbf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062981_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050438_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->insn_valid) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x40ff0000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062979_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((0xd0000U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___062975_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062974_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062970_)))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (0xb00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045321_))))))))))))))))))));
    wasmetal_core__DOT___062999_ = (1U & (IData)((0xf100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062966_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___062998_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))))));
    vlSelf->wasmetal_core__DOT___053597_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053593_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052695_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052700_)))))));
    wasmetal_core__DOT___072264_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053593_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hca0be130__0))))))));
    vlSelf->wasmetal_core__DOT___063435_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052849_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___054468_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->wasmetal_core__DOT___054469_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___054468_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053592_))));
    vlSelf->wasmetal_core__DOT___053251_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052692_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052708_))));
    vlSelf->wasmetal_core__DOT___052697_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052692_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hf7f66e14__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127976___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           ^ (((IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027427_)))));
    vlSelf->wasmetal_core__DOT___027431_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063300_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063302_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063304_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063306_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027367_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027300_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b40__05d));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030257_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127596___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023756_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023755_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023754_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023753_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023688_)))));
    vlSelf->wasmetal_core__DOT___023693_ = ((IData)(vlSelf->wasmetal_core__DOT___023756_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d));
    vlSelf->wasmetal_core__DOT___058722_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0))))));
    vlSelf->wasmetal_core__DOT___023760_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))));
    vlSelf->wasmetal_core__DOT___058741_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0))))));
    vlSelf->wasmetal_core__DOT___023759_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d))));
    vlSelf->wasmetal_core__DOT___023758_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))));
    vlSelf->wasmetal_core__DOT___058884_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___058921_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))));
    vlSelf->wasmetal_core__DOT___058723_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058706_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___023757_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d))));
    vlSelf->__VdfgTmp_he6ade5b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_he6a1153d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_he5c4f457__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)));
    vlSelf->wasmetal_core__DOT___023204_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022472_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O))))));
    vlSelf->wasmetal_core__DOT___023201_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023200_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 3U))))));
    __VdfgTmp_he5f9d86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022476_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022532_));
    vlSelf->wasmetal_core__DOT____Vcellout___127581___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h62ff3be8__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023592_)))));
    vlSelf->wasmetal_core__DOT___023596_ = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127474___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022799_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022798_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022765_)))));
    vlSelf->wasmetal_core__DOT___022770_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022801_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))));
    vlSelf->wasmetal_core__DOT___022805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___059179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___022804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    wasmetal_core__DOT___059184_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    vlSelf->wasmetal_core__DOT___022803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))));
    vlSelf->wasmetal_core__DOT___059182_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___059126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT___022802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127635___O 
        = ((6U | (IData)(vlSelf->wasmetal_core__DOT___024134_)) 
           ^ (0xeU & ((- (IData)((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___024134_))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___014610_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___002961_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))))));
    vlSelf->wasmetal_core__DOT___000132_ = ((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                            & (IData)(
                                                      (0x7fffffffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127564___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003805_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023471_)))));
    vlSelf->wasmetal_core__DOT___023475_ = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006829_ = (1U & (0xbf000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___017895_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))))));
    vlSelf->wasmetal_core__DOT___048705_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                  >> 1U) | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___051511_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))));
    vlSelf->__VdfgTmp_h04da727f__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0));
    vlSelf->wasmetal_core__DOT___062988_ = (1U & (IData)(
                                                         (0xf0f0fdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___062985_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf00bb00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->mem_fault) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___063001_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063000_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053019_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___062999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)))))))))));
    vlSelf->wasmetal_core__DOT___019792_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053590_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053589_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053594_)))))))));
    vlSelf->wasmetal_core__DOT___019794_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___072264_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053594_)))));
    vlSelf->wasmetal_core__DOT___039561_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039533_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039535_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039554_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039545_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039544_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039543_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039542_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039869_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040088_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039523_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039540_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039539_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039538_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039537_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039546_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039547_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039548_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039562_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039558_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039557_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039556_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039555_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039870_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039549_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039536_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039553_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039552_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039551_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039550_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039559_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xcaU 
                                                                >> (IData)(vlSelf->__VdfgTmp_he7cea807__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039560_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___046425_ = (1U & (IData)(
                                                         (0xaafff3f0f3f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063441_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063417_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xef0f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063428_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063439_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbfffffff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063398_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x700U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xffffffffffff00feULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052577_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045469_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052578_)))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063369_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053095_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063435_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053568_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053592_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052848_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063364_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063418_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063380_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___063012_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128900___Q)))))))));
    vlSelf->wasmetal_core__DOT___063015_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128901___Q)))))))));
    vlSelf->wasmetal_core__DOT___063017_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128902___Q)))))))));
    vlSelf->wasmetal_core__DOT___063019_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063011_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128903___Q)))))))));
    vlSelf->wasmetal_core__DOT___062997_ = (1U & (IData)(
                                                         (0xff000f00ff00ee00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062996_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4f4f000000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->insn_valid) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062992_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062991_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062990_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052700_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128897___Q)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062994_)))))))));
    wasmetal_core__DOT___054472_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___054469_))));
    vlSelf->wasmetal_core__DOT___053510_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052690_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052689_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053250_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053249_)))))))));
    vlSelf->wasmetal_core__DOT___072265_ = (1U & (IData)(
                                                         (0x1f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053509_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca0be130__0))))))));
    vlSelf->wasmetal_core__DOT___072278_ = (1U & (0xbf00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072276_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053491_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053422_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051228_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053499_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053014_))))));
    vlSelf->wasmetal_core__DOT___052710_ = (1U & (IData)(
                                                         (0x1f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052695_)))))))));
    vlSelf->wasmetal_core__DOT___044847_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)))))))))));
    vlSelf->wasmetal_core__DOT___044871_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    vlSelf->__VdfgTmp_h8c284b8e__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027431_));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b41__05d));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128240___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030258_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030257_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030256_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030255_)))) 
           ^ (((IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030189_)))));
    vlSelf->wasmetal_core__DOT___030194_ = ((IData)(vlSelf->wasmetal_core__DOT___030258_)
                                             ? (IData)(wasmetal_core__DOT___128240___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d));
    vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023693_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d));
    vlSelf->__VdfgTmp_h098b01ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he5f9d86a__0)));
    vlSelf->__VdfgTmp_h1ea78a97__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he5f9d86a__0)))));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022477_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hb00ae252__0 = (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023596_));
    vlSelf->wasmetal_core__DOT____Vcellout___127494___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022943_)))));
    vlSelf->wasmetal_core__DOT___059186_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059184_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022802_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022770_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127486___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 : (IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022880_)))));
    vlSelf->wasmetal_core__DOT___060213_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013805_)))));
    vlSelf->wasmetal_core__DOT___057769_ = (1U & (0xccdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005683_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005681_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005677_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000132_)) 
                                                  & (IData)(
                                                            (0xfff3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___051268_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000131_))))));
    vlSelf->wasmetal_core__DOT___050098_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    vlSelf->wasmetal_core__DOT___050094_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->__VdfgTmp_h27384d82__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023475_));
    vlSelf->wasmetal_core__DOT___058425_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006829_))));
    vlSelf->wasmetal_core__DOT___016219_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006933_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    if (vlSelf->wasmetal_core__DOT___006829_) {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb02141c6__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006916_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006917_)))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006915_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006914_)))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006896_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006897_)))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006899_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006895_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006894_)))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006932_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006899_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006933_)) 
                                                   & (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha11b0f77__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hf64b2678__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016206_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h63494727__0))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h4068d69c__0))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016197_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h42a31070__0))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h3bcc9f30__0))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016206_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016197_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & (0xefU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb02141c6__0)))));
    }
    vlSelf->wasmetal_core__DOT___016188_ = (1U & (0xff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8599270c__0))));
    vlSelf->wasmetal_core__DOT___006887_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))));
    vlSelf->wasmetal_core__DOT___058424_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he163c644__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he163c644__0))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf053300U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    }
    vlSelf->wasmetal_core__DOT___016233_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedae78d9__0))));
    vlSelf->wasmetal_core__DOT___016257_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf053300U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___016375_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h934029c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051557_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haa0d8025__0)))));
    vlSelf->wasmetal_core__DOT___048950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___017896_ = (1U & (0xf0d5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))));
    vlSelf->wasmetal_core__DOT___006821_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051510_))));
    vlSelf->wasmetal_core__DOT___058470_ = (1U & (0x1000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x4fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))))));
    vlSelf->__VdfgTmp_h363b6dc6__0 = ((4U & ((0x4fU 
                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h96af251d__0));
    vlSelf->wasmetal_core__DOT___016377_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006819_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006820_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006818_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006891_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127634___O 
        = ((6U | (1U & (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))) 
           ^ (0xeU & ((- (IData)((1U & (~ (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___022439_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128904___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022450_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128905___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022461_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128906___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128907___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022465_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128908___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022466_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128909___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022467_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128910___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022468_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128911___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022469_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128912___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022470_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128913___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022440_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128914___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022441_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128915___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022442_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128916___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022443_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128917___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022444_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128918___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022445_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128919___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022446_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128920___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022447_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128921___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022448_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128922___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022449_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128923___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022451_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128924___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022452_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128925___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022453_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128926___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022454_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128927___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022455_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128928___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022456_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128929___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022457_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128930___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022458_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128931___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022459_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128932___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022460_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128933___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022462_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128934___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022463_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128935___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___019796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072265_))));
    vlSelf->wasmetal_core__DOT___039477_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054250_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039446_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054252_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039445_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054254_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039448_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054256_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039449_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054258_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039450_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054260_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039467_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054262_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039460_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054264_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039459_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054266_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039458_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054268_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039457_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054270_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039861_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054272_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039451_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054274_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039444_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054280_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039456_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054282_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039455_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054284_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039454_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054286_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039453_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054288_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039461_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054290_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039462_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054292_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039463_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054294_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039469_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054296_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039863_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054298_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039471_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039473_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054302_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039468_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054304_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039862_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054306_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039464_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054308_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039452_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054310_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039474_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054312_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039472_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054314_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039470_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054316_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039466_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054318_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___039465_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054319_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d)))))))));
}
