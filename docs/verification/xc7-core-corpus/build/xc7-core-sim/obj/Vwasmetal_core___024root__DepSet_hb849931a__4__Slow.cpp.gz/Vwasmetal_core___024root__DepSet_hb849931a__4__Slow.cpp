#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__3(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__3\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___000357_;
    wasmetal_core__DOT___000357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___001235_;
    wasmetal_core__DOT___001235_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043138_;
    wasmetal_core__DOT___043138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043582_;
    wasmetal_core__DOT___043582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044115_;
    wasmetal_core__DOT___044115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044157_;
    wasmetal_core__DOT___044157_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044224_;
    wasmetal_core__DOT___044224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044616_;
    wasmetal_core__DOT___044616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044636_;
    wasmetal_core__DOT___044636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044645_;
    wasmetal_core__DOT___044645_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044655_;
    wasmetal_core__DOT___044655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045615_;
    wasmetal_core__DOT___045615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045666_;
    wasmetal_core__DOT___045666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045709_;
    wasmetal_core__DOT___045709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045726_;
    wasmetal_core__DOT___045726_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045738_;
    wasmetal_core__DOT___045738_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048375_;
    wasmetal_core__DOT___048375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051191_;
    wasmetal_core__DOT___051191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052838_;
    wasmetal_core__DOT___052838_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053756_;
    wasmetal_core__DOT___053756_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053760_;
    wasmetal_core__DOT___053760_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065578_;
    wasmetal_core__DOT___065578_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128704___O;
    wasmetal_core__DOT____Vcellout___128704___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_hcc483c10__0;
    __VdfgTmp_hcc483c10__0 = 0;
    CData/*1:0*/ __VdfgTmp_he81561f4__0;
    __VdfgTmp_he81561f4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf2823744__0;
    __VdfgTmp_hf2823744__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9205a979__0;
    __VdfgTmp_h9205a979__0 = 0;
    CData/*4:0*/ __VdfgTmp_h5fe12ba6__0;
    __VdfgTmp_h5fe12ba6__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___048417_ = (1U & (0xedf3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h752c22b4__0))))));
    vlSelf->wasmetal_core__DOT___048376_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048319_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010006_)))));
    vlSelf->wasmetal_core__DOT___048440_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___048418_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___048446_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x100U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->wasmetal_core__DOT___048304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___050357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc416787b__0))))));
    vlSelf->wasmetal_core__DOT___051531_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc416787b__0))))));
    vlSelf->wasmetal_core__DOT___048270_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc416787b__0))));
    vlSelf->wasmetal_core__DOT___048407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___063775_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_hc62a6006__0 = (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000354_));
    vlSelf->wasmetal_core__DOT___052904_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_hb92dbfd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000378_));
    vlSelf->wasmetal_core__DOT___007190_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_h4a5b8c23__0 = ((4U & ((1U >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000353_)));
    vlSelf->wasmetal_core__DOT___048475_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047786_)))));
    vlSelf->wasmetal_core__DOT___007058_ = (1U & (0xbfU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048461_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x100U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->wasmetal_core__DOT___048460_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->wasmetal_core__DOT___048490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->wasmetal_core__DOT___048455_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047781_)))));
    vlSelf->wasmetal_core__DOT___048324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->wasmetal_core__DOT___048316_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->__VdfgTmp_hc8342b84__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010006_));
    vlSelf->wasmetal_core__DOT___053769_ = (1U & (IData)(
                                                         (0xfff1f1f1f1ffffffULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->insn_op 
                                                               >> 2U)) 
                                                           | ((2U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___048326_))))));
    vlSelf->__VdfgTmp_h6d3657d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))));
    vlSelf->__VdfgTmp_haa5fc240__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___002988_));
    vlSelf->wasmetal_core__DOT___048368_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))))));
    vlSelf->wasmetal_core__DOT___048399_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))));
    vlSelf->wasmetal_core__DOT___048462_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)))))));
    vlSelf->wasmetal_core__DOT___048400_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))))));
    vlSelf->wasmetal_core__DOT___048378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048363_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048283_)))));
    vlSelf->wasmetal_core__DOT___048334_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048326_))))));
    vlSelf->wasmetal_core__DOT___025061_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048444_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048438_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048313_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))))));
    vlSelf->wasmetal_core__DOT___048364_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0))))));
    vlSelf->wasmetal_core__DOT___019304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0))))));
    vlSelf->__VdfgTmp_haf8eec33__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048320_));
    vlSelf->wasmetal_core__DOT___050447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___053764_ = (1U & (0x1110fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047781_)))))));
    vlSelf->wasmetal_core__DOT___052878_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048333_ = (1U & (IData)(
                                                         (0x1ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048327_)))))))));
    __VdfgTmp_hf2823744__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048328_));
    vlSelf->wasmetal_core__DOT___048402_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048412_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048472_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048327_)))));
    vlSelf->wasmetal_core__DOT___048385_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    wasmetal_core__DOT___053760_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    vlSelf->wasmetal_core__DOT___048287_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048283_))))));
    vlSelf->wasmetal_core__DOT___048413_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    vlSelf->wasmetal_core__DOT___048405_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    __VdfgTmp_he81561f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048284_));
    vlSelf->wasmetal_core__DOT___047790_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h84a34a18__0)))));
    vlSelf->wasmetal_core__DOT___002964_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h84a34a18__0)))));
    vlSelf->wasmetal_core__DOT___053780_ = (1U & (IData)(
                                                         (0xfff1f1f1f1ffffffULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->insn_op 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___010007_))))));
    vlSelf->wasmetal_core__DOT___053765_ = (1U & (0x1110fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010006_)))))));
    wasmetal_core__DOT___048375_ = (1U & (0xf8880000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))));
    vlSelf->wasmetal_core__DOT___048318_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    vlSelf->wasmetal_core__DOT___048437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    __VdfgTmp_h9205a979__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048314_));
    vlSelf->wasmetal_core__DOT___048466_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048326_)))));
    vlSelf->wasmetal_core__DOT___048473_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))));
    vlSelf->wasmetal_core__DOT___048325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    vlSelf->wasmetal_core__DOT___060712_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))));
    wasmetal_core__DOT___053756_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    vlSelf->wasmetal_core__DOT___048341_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))));
    vlSelf->wasmetal_core__DOT___048347_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    vlSelf->wasmetal_core__DOT___048360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    __VdfgTmp_hcc483c10__0 = (((IData)(vlSelf->wasmetal_core__DOT___048320_) 
                               << 2U) | ((2U & ((8U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))));
    if (vlSelf->wasmetal_core__DOT___001233_) {
        vlSelf->wasmetal_core__DOT___002977_ = (1U 
                                                & (IData)(
                                                          (0xfffffff01111111ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((0xfffeU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((0x8000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hec761a3f__0))))))));
        vlSelf->wasmetal_core__DOT___003039_ = (1U 
                                                & ((1U 
                                                    & (0xfffeU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___001246_)
                                                    : (IData)(
                                                              (0x1111111111111ULL 
                                                               >> 
                                                               ((0x20U 
                                                                 & ((0x8000U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                    << 5U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___001240_))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___002977_ = (1U 
                                                & (0x7fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000366_)))));
        vlSelf->wasmetal_core__DOT___003039_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001246_));
    }
    vlSelf->wasmetal_core__DOT___002963_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hec761a3f__0)))));
    wasmetal_core__DOT___045666_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070629_))));
    vlSelf->wasmetal_core__DOT___053778_ = (1U & (IData)(
                                                         (0x10101ffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___048361_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h755be032__0))));
    vlSelf->wasmetal_core__DOT___048382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h755be032__0))))));
    vlSelf->wasmetal_core__DOT___048362_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h755be032__0))))));
    vlSelf->wasmetal_core__DOT___048269_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h755be032__0))));
    wasmetal_core__DOT___044224_ = (1U & (4U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h94b1bf18__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)))));
    wasmetal_core__DOT___045738_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h94b1bf18__0))))));
    vlSelf->wasmetal_core__DOT___047963_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((1U 
                                                      & (8U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U))))
                                                      ? (IData)(
                                                                (0xafaf000fffff33ffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & (vlSelf->insn_op 
                                                                         << 2U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h94b1bf18__0)))))))
                                                      : 
                                                     (0xf7U 
                                                      >> 
                                                      ((4U 
                                                        & vlSelf->insn_op) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))));
    vlSelf->__VdfgTmp_h88a73cb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003009_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002965_));
    vlSelf->wasmetal_core__DOT___053017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053009_))));
    vlSelf->wasmetal_core__DOT___051565_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048005_)))));
    vlSelf->wasmetal_core__DOT___005571_ = (1U & (0x7fd5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048005_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    vlSelf->wasmetal_core__DOT___052889_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___047979_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047793_)))))));
    vlSelf->wasmetal_core__DOT___048419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    wasmetal_core__DOT___001235_ = (1U & (0x1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001231_)))));
    vlSelf->__VdfgTmp_h9fdaf630__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048424_));
    vlSelf->wasmetal_core__DOT___051564_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___054457_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051563_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048328_)))))));
    vlSelf->wasmetal_core__DOT___000125_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x1000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdd61004f__0)))));
    vlSelf->wasmetal_core__DOT___051253_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdd61004f__0)))));
    vlSelf->wasmetal_core__DOT___052643_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___052838_ = (1U & (0x40U >> 
                                          ((4U & ((0x1000U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048445_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048433_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___000357_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___051191_ = (1U & (0x40U >> 
                                          ((4U & ((0x1000U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048425_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___052647_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___044115_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h323e8784__0))))));
    wasmetal_core__DOT___045709_ = (1U & (4U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h323e8784__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)))));
    if (vlSelf->wasmetal_core__DOT___044627_) {
        if (vlSelf->wasmetal_core__DOT___044626_) {
            if (vlSelf->wasmetal_core__DOT___044625_) {
                if (vlSelf->wasmetal_core__DOT___044630_) {
                    wasmetal_core__DOT___044655_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                    if (vlSelf->wasmetal_core__DOT___044624_) {
                        wasmetal_core__DOT___044645_ 
                            = (1U & ((~ (4U >> (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0))) 
                                     & (8U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0))));
                        wasmetal_core__DOT___044636_ 
                            = (1U & ((~ (4U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0))) 
                                     & (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)));
                    } else {
                        wasmetal_core__DOT___044645_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                        wasmetal_core__DOT___044636_ 
                            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044624_)));
                    }
                    wasmetal_core__DOT___044616_ = 
                        (1U & (IData)(vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__));
                } else {
                    wasmetal_core__DOT___044655_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044645_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044636_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                    wasmetal_core__DOT___044616_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044630_)));
                }
                vlSelf->wasmetal_core__DOT___044819_ 
                    = (1U & ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))
                              ? (IData)(vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__)
                              : (4U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0))));
            } else {
                wasmetal_core__DOT___044655_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044645_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044636_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                wasmetal_core__DOT___044616_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
                vlSelf->wasmetal_core__DOT___044819_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044625_)));
            }
        } else {
            wasmetal_core__DOT___044655_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044645_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044636_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            wasmetal_core__DOT___044616_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
            vlSelf->wasmetal_core__DOT___044819_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044626_)));
        }
    } else {
        wasmetal_core__DOT___044655_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044645_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044636_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        wasmetal_core__DOT___044616_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
        vlSelf->wasmetal_core__DOT___044819_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044627_)));
    }
    vlSelf->wasmetal_core__DOT___048286_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___044626_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___044627_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044624_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044625_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))))))))));
    wasmetal_core__DOT___045615_ = ((IData)(vlSelf->wasmetal_core__DOT___044627_) 
                                    & ((IData)(vlSelf->wasmetal_core__DOT___044626_) 
                                       & ((IData)(vlSelf->wasmetal_core__DOT___044625_) 
                                          & ((1U & 
                                              (8U >> (IData)(vlSelf->__VdfgTmp_h73c641ae__0)))
                                              ? ((IData)(vlSelf->wasmetal_core__DOT___044624_) 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))
                                              : (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))))));
    if (vlSelf->wasmetal_core__DOT__sp__05b4__05d) {
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033933_;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032955_;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b5__05d) {
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032633_;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x78U >> (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) 
                 | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                    >> 2U)));
    vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__ 
        = (1U & ((6U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                               >> 1U))) | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                           >> 2U)));
    vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x1eU >> (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) 
                 | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                    >> 2U)));
    vlSelf->wasmetal_core__DOT___021739_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17767d6e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052014_))));
    vlSelf->wasmetal_core__DOT___052015_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052014_))));
    vlSelf->wasmetal_core__DOT___000189_ = (1U & ((IData)(
                                                          (0x9009000000009009ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b26__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b24__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b22__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d)))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000214_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000213_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000212_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x9009U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b5__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b4__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((9U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000209_))))))))));
    vlSelf->wasmetal_core__DOT___000263_ = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b19__05d)
                                              ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000348_))
                                              : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000348_))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b29__05d)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000344_))
                                                 : 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000344_))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000313_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000311_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b24__05d)
                                                                       ? 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT___000329_))
                                                                       : 
                                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d)) 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT___000329_))) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b28__05d)
                                                                          ? 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000325_))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000325_))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b18__05d)
                                                                           ? 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000321_))
                                                                           : 
                                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d)) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000321_))))))))))));
    vlSelf->wasmetal_core__DOT___000187_ = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b19__05d)
                                              ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000258_))
                                              : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000258_))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b29__05d)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000254_))
                                                 : 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000254_))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000222_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000221_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000220_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b24__05d)
                                                                       ? 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT___000238_))
                                                                       : 
                                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d)) 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT___000238_))) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b28__05d)
                                                                          ? 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000234_))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000234_))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b18__05d)
                                                                           ? 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000230_))
                                                                           : 
                                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d)) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000230_))))))))))));
    vlSelf->wasmetal_core__DOT___003092_ = (1U & (0xf1ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047787_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xfffeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___002985_)))))));
    vlSelf->wasmetal_core__DOT___054736_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___054737_ = (1U & (0x75U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlSelf->insn_op)))));
    vlSelf->wasmetal_core__DOT___054729_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->__VdfgTmp_hbec427aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048307_));
    vlSelf->wasmetal_core__DOT___048453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___048305_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))));
    vlSelf->wasmetal_core__DOT___047953_ = (1U & ((4U 
                                                   & vlSelf->insn_op)
                                                   ? 
                                                  ((2U 
                                                    & vlSelf->insn_op)
                                                    ? (IData)(
                                                              (0xffffffffb0bbbbbbULL 
                                                               >> 
                                                               ((0x20U 
                                                                 & (vlSelf->insn_op 
                                                                    << 5U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((0x4000U 
                                                                           >> 
                                                                           (0xfU 
                                                                            & (vlSelf->insn_op 
                                                                               >> 4U))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & (vlSelf->insn_op 
                                                                             >> 1U)) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0)))))))
                                                    : 
                                                   (0xbfU 
                                                    >> 
                                                    ((4U 
                                                      & (vlSelf->insn_op 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))))
                                                   : 
                                                  ((vlSelf->insn_op 
                                                    >> 1U) 
                                                   | (0x7fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x4000U 
                                                               >> 
                                                               (0xfU 
                                                                & (vlSelf->insn_op 
                                                                   >> 4U))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (vlSelf->insn_op 
                                                                >> 3U))))))));
    if (vlSelf->wasmetal_core__DOT___043133_) {
        wasmetal_core__DOT___043138_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___043141_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                               : (IData)(vlSelf->wasmetal_core__DOT___043139_)));
        vlSelf->wasmetal_core__DOT___043283_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___043286_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043284_)));
        vlSelf->wasmetal_core__DOT___043129_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___043135_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043131_)));
        wasmetal_core__DOT___043582_ = ((IData)(vlSelf->wasmetal_core__DOT___043141_) 
                                        | (IData)(vlSelf->wasmetal_core__DOT___043583_));
        vlSelf->wasmetal_core__DOT___043673_ = ((IData)(vlSelf->wasmetal_core__DOT___043286_) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___043674_));
    } else {
        wasmetal_core__DOT___043138_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        vlSelf->wasmetal_core__DOT___043283_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        vlSelf->wasmetal_core__DOT___043129_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        wasmetal_core__DOT___043582_ = 0U;
        vlSelf->wasmetal_core__DOT___043673_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___045642_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045646_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045643_))))));
    vlSelf->wasmetal_core__DOT___045652_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___044076_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___045654_))))));
    vlSelf->wasmetal_core__DOT___045682_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045687_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__)
                                                         : 
                                                        (~ 
                                                         (vlSelf->insn_op 
                                                          >> 7U)))))));
    vlSelf->wasmetal_core__DOT___045672_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045676_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045673_))))));
    vlSelf->wasmetal_core__DOT___042536_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044061_))));
    vlSelf->wasmetal_core__DOT___045693_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045697_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045694_))))));
    vlSelf->wasmetal_core__DOT___053282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052953_))));
    vlSelf->wasmetal_core__DOT___052955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))));
    vlSelf->wasmetal_core__DOT___003011_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11a2e1d4__0)))));
    vlSelf->wasmetal_core__DOT___047982_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haec53eda__0))))));
    vlSelf->wasmetal_core__DOT___002969_ = (1U & (0x53fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_haec53eda__0))))));
    vlSelf->wasmetal_core__DOT___048379_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048315_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->wasmetal_core__DOT___048317_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048315_))));
    vlSelf->wasmetal_core__DOT___044194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070609_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___045719_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070609_))));
    wasmetal_core__DOT___045726_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070609_))));
    if ((1U & (IData)((1ULL >> (vlSelf->insn_op >> 0x1aU))))) {
        if (vlSelf->wasmetal_core__DOT___044063_) {
            if (vlSelf->wasmetal_core__DOT___044062_) {
                if (vlSelf->wasmetal_core__DOT___044061_) {
                    vlSelf->wasmetal_core__DOT___044055_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044066_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045643_))));
                    vlSelf->wasmetal_core__DOT___044082_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044086_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___044083_)));
                    vlSelf->wasmetal_core__DOT__divider__02ewide 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044104_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (vlSelf->insn_op 
                                     >> 7U)));
                    vlSelf->wasmetal_core__DOT___044092_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044096_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045673_))));
                    vlSelf->wasmetal_core__DOT___044230_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044234_) 
                                 | (IData)(vlSelf->wasmetal_core__DOT___044231_)));
                    wasmetal_core__DOT___044157_ = 
                        (1U & ((IData)(vlSelf->wasmetal_core__DOT___044162_)
                                ? ((4U >> (3U & vlSelf->insn_op)) 
                                   | (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)))
                                : (IData)(vlSelf->wasmetal_core__DOT___044158_)));
                    vlSelf->wasmetal_core__DOT___044072_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044076_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (IData)(vlSelf->wasmetal_core__DOT___044073_)));
                    vlSelf->wasmetal_core__DOT___044220_ 
                        = (1U & ((IData)(wasmetal_core__DOT___044224_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045735_))));
                } else {
                    vlSelf->wasmetal_core__DOT___044055_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044082_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT__divider__02ewide 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044092_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044230_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    wasmetal_core__DOT___044157_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044072_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044220_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                }
            } else {
                vlSelf->wasmetal_core__DOT___044055_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044082_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT__divider__02ewide 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044092_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044230_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                wasmetal_core__DOT___044157_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044072_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044220_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___044055_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044082_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT__divider__02ewide 
                = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044092_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044230_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            wasmetal_core__DOT___044157_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044072_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044220_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
        }
        if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))) {
            vlSelf->wasmetal_core__DOT__decoded_table 
                = (1U & ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_he33f1ed5__0)))
                          ? ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                              ? ((IData)(wasmetal_core__DOT___044115_) 
                                 | (0xfffeU >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                          : (IData)(vlSelf->wasmetal_core__DOT___044111_)));
            vlSelf->wasmetal_core__DOT___044180_ = 
                (1U & ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                        ? ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                            ? ((~ (IData)(wasmetal_core__DOT___045726_)) 
                               | (IData)(vlSelf->wasmetal_core__DOT___044184_))
                            : (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                        : (IData)(vlSelf->wasmetal_core__DOT___044170_)));
        } else {
            vlSelf->wasmetal_core__DOT__decoded_table 
                = (1U & (0xeU >> (3U & (vlSelf->insn_op 
                                        >> 0x18U))));
            vlSelf->wasmetal_core__DOT___044180_ = 
                (1U & (0xeU >> (3U & (vlSelf->insn_op 
                                      >> 0x18U))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___044055_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044082_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT__divider__02ewide 
            = (1U & (~ (IData)((1ULL >> (vlSelf->insn_op 
                                         >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044092_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044230_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        wasmetal_core__DOT___044157_ = (1U & (~ (IData)(
                                                        (1ULL 
                                                         >> 
                                                         (vlSelf->insn_op 
                                                          >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044072_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044220_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT__decoded_table = 
            (1U & (~ (IData)((1ULL >> (vlSelf->insn_op 
                                       >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044180_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128794___O 
        = (((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)) 
                   << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)))) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)
                  ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)
                  : (IData)(vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035884_)));
    wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 5U) & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 5U) : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063422_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048478_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_fault)))))));
    vlSelf->wasmetal_core__DOT___063441_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063377_)))))));
    vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063382_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00f1f100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052985_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->mem_fault))))))))))));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128213___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029939_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029936_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029925_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029914_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029907_ = ((IData)(vlSelf->wasmetal_core__DOT___029939_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128482___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032891_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032888_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032877_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032866_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032859_ = ((IData)(vlSelf->wasmetal_core__DOT___032891_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128196___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029767_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029756_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029745_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029738_ = ((IData)(vlSelf->wasmetal_core__DOT___029770_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128163___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029407_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029404_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029393_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029382_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029375_ = ((IData)(vlSelf->wasmetal_core__DOT___029407_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128010___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027826_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027823_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027801_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027794_ = ((IData)(vlSelf->wasmetal_core__DOT___027826_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 5U) & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128147___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029246_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029243_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029221_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029214_ = ((IData)(vlSelf->wasmetal_core__DOT___029246_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d));
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 5U)) & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h891b440b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   >> 2U)))));
    vlSelf->__VdfgTmp_h91551c13__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->wasmetal_core__DOT___019577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (3U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                             >> 1U)))))));
    vlSelf->__VdfgTmp_h5035dc07__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___019418_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x5ffffffffffffff3ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (~ 
                                                                                (- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_)))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (~ 
                                                                                (- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_)))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf123769f__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf123769f__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f508139__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (~ 
                                                                                (3U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 2U))))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 1U))) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 1U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f508139__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & (~ 
                                                                                (3U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034222_))) 
                                                                                >> 2U)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128426___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032219_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032216_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h58222fb0__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032187_ = ((IData)(vlSelf->wasmetal_core__DOT___032219_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___052871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->function_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044693_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128466___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032699_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032667_ = ((IData)(vlSelf->wasmetal_core__DOT___032699_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___065590_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065582_))));
    vlSelf->wasmetal_core__DOT___019392_ = (1U & (0xf800U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065582_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065584_))))));
    __VdfgTmp_h5fe12ba6__0 = (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                            << 1U) 
                                           | (1U & 
                                              (0x40U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___065562_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065563_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___067563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065556_))));
    vlSelf->wasmetal_core__DOT___065560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065556_))));
    vlSelf->wasmetal_core__DOT___064247_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___064093_))))));
    vlSelf->__VdfgTmp_hd2f701d9__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064093_));
    vlSelf->wasmetal_core__DOT___066372_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066365_))));
    vlSelf->wasmetal_core__DOT___070190_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067556_))));
    vlSelf->wasmetal_core__DOT___069258_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065553_))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066367_))));
    vlSelf->wasmetal_core__DOT___066368_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066367_)))));
    vlSelf->wasmetal_core__DOT___064453_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    vlSelf->wasmetal_core__DOT___065566_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065558_))));
    vlSelf->wasmetal_core__DOT___064993_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    vlSelf->wasmetal_core__DOT___067561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065558_))));
    vlSelf->wasmetal_core__DOT___067557_ = (1U & (0x7fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065558_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064992_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))))));
    vlSelf->wasmetal_core__DOT___067565_ = (1U & (IData)(
                                                         (0x7f7f7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064973_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065559_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064091_)))))))));
    vlSelf->wasmetal_core__DOT___064976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064973_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064093_))));
    wasmetal_core__DOT___065578_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064973_))));
    vlSelf->wasmetal_core__DOT___071553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071506_))));
    vlSelf->wasmetal_core__DOT___071507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071526_))));
    vlSelf->wasmetal_core__DOT___071527_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071480_))));
    vlSelf->wasmetal_core__DOT___071481_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071480_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___134208___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037209_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037206_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037195_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2d9d1f69__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__) 
               << 3U) | ((IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__) 
                         << 2U)));
    vlSelf->wasmetal_core__DOT___037178_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037209_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h60140cd4__0))));
    wasmetal_core__DOT____Vcellout___128704___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035117_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035106_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((9U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035084_)))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__) 
                                                             << 1U)))));
    vlSelf->wasmetal_core__DOT___035053_ = ((IData)(vlSelf->wasmetal_core__DOT___035117_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d));
    wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___026254_ = ((IData)(vlSelf->wasmetal_core__DOT___026286_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127834___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026286_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026283_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026272_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026261_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026158_ = ((IData)(vlSelf->wasmetal_core__DOT___026190_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127826___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026187_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026176_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026165_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026350_ = ((IData)(vlSelf->wasmetal_core__DOT___026382_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127842___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026382_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026379_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026357_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___071555_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071512_))));
    vlSelf->wasmetal_core__DOT___071513_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071530_))));
    vlSelf->wasmetal_core__DOT___071531_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071530_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071548_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071488_))));
    vlSelf->wasmetal_core__DOT___071489_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071554_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071509_))));
    vlSelf->wasmetal_core__DOT___071510_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071509_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071839_ = (1U & (IData)(
                                                         (0xffff0077ffff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he775e720__0))))))));
    vlSelf->wasmetal_core__DOT___071547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071484_))));
    vlSelf->wasmetal_core__DOT___071485_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071552_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071503_))));
    vlSelf->wasmetal_core__DOT___071504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071559_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071524_))));
    vlSelf->wasmetal_core__DOT___071525_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071476_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071550_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071497_))));
    vlSelf->wasmetal_core__DOT___071498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071557_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071519_))));
    vlSelf->wasmetal_core__DOT___071520_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070573_))));
    vlSelf->wasmetal_core__DOT___070574_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032802_) 
                 | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___031214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046933_))));
    vlSelf->wasmetal_core__DOT___031502_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046933_)))));
    vlSelf->wasmetal_core__DOT___032525_ = (1U & (IData)(
                                                         (0x4000ff00bfff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9fa2de6d__0))))))));
    vlSelf->wasmetal_core__DOT___046800_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046933_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___046932_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___046931_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___046930_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___063358_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5e419f7__0))));
    vlSelf->wasmetal_core__DOT___049005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___048562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048561_))));
    vlSelf->wasmetal_core__DOT___047803_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7fffffffff00ffULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047767_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_ha1c1569b__0)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4e415d3f__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab049741__0)))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4c404d9f__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4c404d9f__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                                         << 4U)) 
                                                                     | ((0x10U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h28672704__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc04260ca__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h28672704__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc04260ca__0)))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___064241_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128534___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___058085_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052586_))));
    vlSelf->wasmetal_core__DOT___071836_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071558_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___071834_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071556_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___071833_ = (1U & (0xf800U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071515_))))));
    vlSelf->wasmetal_core__DOT___071828_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071551_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___071826_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071549_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___071821_ = (1U & (0xf800U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071475_))))));
    vlSelf->wasmetal_core__DOT___071820_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071545_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___071818_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071543_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___071817_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071542_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___071816_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___071815_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071539_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___071814_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071538_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___071813_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071537_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___071812_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071536_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d)))));
    vlSelf->wasmetal_core__DOT___071811_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071535_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___071810_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071534_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d)))));
    vlSelf->wasmetal_core__DOT___071809_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071533_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d)))));
    vlSelf->wasmetal_core__DOT___071807_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he775e720__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___071804_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071523_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___071802_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071518_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d)))));
    vlSelf->wasmetal_core__DOT___071801_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071515_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___071796_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071501_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___071794_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d)))));
    vlSelf->wasmetal_core__DOT___071788_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058083_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___018318_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edivide_wide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048949_))));
    vlSelf->wasmetal_core__DOT___043576_ = ((IData)(vlSelf->wasmetal_core__DOT___043133_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___043135_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___043578_)));
    vlSelf->wasmetal_core__DOT___053423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052948_))));
    vlSelf->wasmetal_core__DOT___053565_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->busy) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052876_)))));
    vlSelf->wasmetal_core__DOT___063459_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26689d2d__0))));
    vlSelf->wasmetal_core__DOT___053002_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048481_))));
    vlSelf->wasmetal_core__DOT___053540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046420_))));
    vlSelf->wasmetal_core__DOT___064717_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064715_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___066299_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066297_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067721_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067719_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[1U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067803_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067801_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067856_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067854_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067890_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067888_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068068_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068066_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 6U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068142_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068140_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 7U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068228_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068226_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 9U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068467_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068465_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xdU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b47__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069081_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069079_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1aU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069229_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069227_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1dU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064882_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064880_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[0U]) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065395_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065501_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065499_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067951_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067949_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068194_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 8U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068390_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xcU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068543_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xfU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068594_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x10U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068693_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x12U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___069130_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x1bU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068013_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068011_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___064451_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064449_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___066003_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066001_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xaU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___067585_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068509_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0xeU)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068886_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068884_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x16U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068641_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068738_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068736_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___068838_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068836_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065156_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___065043_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052990_)))))));
    vlSelf->wasmetal_core__DOT___053287_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052860_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02edone)))))));
    vlSelf->wasmetal_core__DOT___065284_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065282_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065281_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065724_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065721_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065885_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066203_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068810_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068808_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068807_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___068956_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068954_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069005_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069002_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069054_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069052_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___069198_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069195_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___065789_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065787_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065786_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066066_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066064_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066063_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___052997_ = (1U & (IData)(
                                                         (0xe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048116_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052995_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052994_)))))))));
    vlSelf->wasmetal_core__DOT___070490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___019798_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)))))));
    vlSelf->wasmetal_core__DOT___039415_ = (1U & (0xeaaa2aaaU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__query_table)))))));
    vlSelf->wasmetal_core__DOT___070486_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->cmd_kind) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051277_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___053094_ = (1U & (0xfe0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->cmd_kind)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->cmd_kind) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->cmd_kind)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->cmd_kind) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___053737_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xfaf0f0f3U 
                                                         >> 
                                                         ((0x18U 
                                                           & ((IData)(vlSelf->cmd_kind) 
                                                              << 2U)) 
                                                          | ((4U 
                                                              & ((IData)(vlSelf->cmd_kind) 
                                                                 >> 1U)) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->cmd_kind) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___038805_)))))))));
    vlSelf->wasmetal_core__DOT___052861_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052858_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___050389_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050385_))));
    vlSelf->wasmetal_core__DOT___050454_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___069281_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b64__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069310_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069307_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069306_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b65__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069338_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b66__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[2U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069361_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b67__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069386_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069383_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069382_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b68__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069412_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b69__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069438_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069432_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b70__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069463_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069459_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069458_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b71__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069491_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b72__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 6U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069557_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b75__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069628_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069622_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b78__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069673_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069669_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069668_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b80__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069848_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069843_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069842_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b88__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069869_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069863_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b89__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069889_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069884_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069883_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b90__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069910_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b91__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069930_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069925_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b92__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069951_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069946_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069945_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b93__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___070011_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070007_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b96__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___053618_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053615_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___053345_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053335_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053308_))));
    vlSelf->wasmetal_core__DOT___063057_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053614_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination_kind__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___053616_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053614_))));
    vlSelf->wasmetal_core__DOT___048487_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048485_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048483_)))));
    vlSelf->wasmetal_core__DOT___053264_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003040_))));
    vlSelf->wasmetal_core__DOT___056255_ = (1U & (IData)(
                                                         (0x101010101ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___052731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___053779_ = (1U & (0x10101ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))));
    vlSelf->wasmetal_core__DOT___053754_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047783_))))));
    vlSelf->wasmetal_core__DOT___053757_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___019203_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048283_)))))));
    vlSelf->wasmetal_core__DOT___048456_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048321_)))));
    vlSelf->__VdfgTmp_h4ab35b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048321_));
    vlSelf->wasmetal_core__DOT___048323_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___053332_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053331_))));
    vlSelf->wasmetal_core__DOT___052892_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052891_))));
    vlSelf->wasmetal_core__DOT___053087_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___025060_)))));
    vlSelf->wasmetal_core__DOT___053989_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052693_))));
    vlSelf->wasmetal_core__DOT___048352_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000354_))))));
    vlSelf->wasmetal_core__DOT___007194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048434_))));
    vlSelf->wasmetal_core__DOT___052851_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052850_))));
    vlSelf->wasmetal_core__DOT___055311_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052850_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052891_))));
    vlSelf->wasmetal_core__DOT___056254_ = (1U & ((0x10U 
                                                   & vlSelf->insn_op)
                                                   ? 
                                                  (0xaaa22aaaU 
                                                   >> 
                                                   ((0x1cU 
                                                     & (vlSelf->insn_op 
                                                        >> 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010005_))))
                                                   : 
                                                  (0xa2222aaaU 
                                                   >> 
                                                   ((0x1cU 
                                                     & (vlSelf->insn_op 
                                                        >> 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010005_))))));
    vlSelf->wasmetal_core__DOT___053496_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053495_))));
    vlSelf->wasmetal_core__DOT___053767_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053495_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048283_))))));
    vlSelf->wasmetal_core__DOT___064012_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    vlSelf->wasmetal_core__DOT___048443_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048381_))));
    vlSelf->wasmetal_core__DOT___007033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048383_))));
    vlSelf->wasmetal_core__DOT___019205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048404_))));
    vlSelf->wasmetal_core__DOT___007034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    vlSelf->wasmetal_core__DOT___007035_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048344_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048350_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048370_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___007031_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048384_))));
    vlSelf->wasmetal_core__DOT___048374_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048366_)))));
    vlSelf->wasmetal_core__DOT___065610_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048414_))));
    vlSelf->wasmetal_core__DOT___052846_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048440_))));
    vlSelf->wasmetal_core__DOT___048442_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048440_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048439_))));
    vlSelf->wasmetal_core__DOT___053776_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048418_))));
    vlSelf->wasmetal_core__DOT___050366_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050357_))));
    vlSelf->wasmetal_core__DOT___053761_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048320_)))))));
    vlSelf->wasmetal_core__DOT___054146_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048474_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ff00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048468_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051531_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010007_))))))))))));
    vlSelf->wasmetal_core__DOT___053013_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc62a6006__0))));
    vlSelf->wasmetal_core__DOT___052896_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc62a6006__0))));
    vlSelf->wasmetal_core__DOT___052905_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052904_))));
    vlSelf->wasmetal_core__DOT___053755_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053753_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x4000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb92dbfd9__0))))))));
    vlSelf->wasmetal_core__DOT___060659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007190_))));
    vlSelf->wasmetal_core__DOT___052899_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a5b8c23__0))));
    vlSelf->wasmetal_core__DOT___052902_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048461_))));
    vlSelf->wasmetal_core__DOT___053777_ = (1U & (IData)(
                                                         (0x1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048461_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___052906_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048460_))));
    vlSelf->wasmetal_core__DOT___053768_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048460_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048336_))))));
    vlSelf->wasmetal_core__DOT___048464_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048460_))));
    vlSelf->wasmetal_core__DOT___053012_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048439_)))));
    vlSelf->wasmetal_core__DOT___071777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048324_))));
    vlSelf->wasmetal_core__DOT___052746_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc8342b84__0))));
    vlSelf->wasmetal_core__DOT___052901_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8342b84__0)))));
    vlSelf->wasmetal_core__DOT___065611_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d3657d5__0))));
    vlSelf->wasmetal_core__DOT___048312_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d3657d5__0))));
    vlSelf->wasmetal_core__DOT___052584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1515153fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048404_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_haa5fc240__0)))))))))));
    vlSelf->wasmetal_core__DOT___048411_ = (1U & (0x303035fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa5fc240__0))))));
    vlSelf->wasmetal_core__DOT___048373_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048304_)))));
    vlSelf->wasmetal_core__DOT___052645_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048513_))));
    vlSelf->wasmetal_core__DOT___048401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048398_))));
    vlSelf->wasmetal_core__DOT___048465_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xc7f8ffffffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                     << 4U) 
                                                                    | (0xfU 
                                                                       & vlSelf->insn_op))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048462_))));
    vlSelf->wasmetal_core__DOT___052845_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048400_))));
    vlSelf->wasmetal_core__DOT___007874_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048490_))));
    vlSelf->wasmetal_core__DOT___052886_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025061_))));
    vlSelf->wasmetal_core__DOT___063817_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052891_)))));
    vlSelf->wasmetal_core__DOT___052893_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025061_))));
    vlSelf->wasmetal_core__DOT___054744_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___048451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048368_))));
    vlSelf->wasmetal_core__DOT___063824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048438_))));
    vlSelf->wasmetal_core__DOT___063860_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048366_)))));
    vlSelf->wasmetal_core__DOT___019246_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    vlSelf->wasmetal_core__DOT___048369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048364_))));
    vlSelf->wasmetal_core__DOT___052897_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019304_))));
    vlSelf->wasmetal_core__DOT___054677_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052741_))));
    vlSelf->wasmetal_core__DOT___052840_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haf8eec33__0)))));
    vlSelf->wasmetal_core__DOT___007060_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf8eec33__0))));
    vlSelf->wasmetal_core__DOT___054145_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf8eec33__0))));
    vlSelf->wasmetal_core__DOT___050449_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019304_)))));
    vlSelf->wasmetal_core__DOT___052884_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050447_))));
    vlSelf->wasmetal_core__DOT___061644_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052879_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052878_))));
    vlSelf->wasmetal_core__DOT___052882_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf2823744__0))));
    vlSelf->wasmetal_core__DOT___048372_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf2823744__0))));
    vlSelf->wasmetal_core__DOT___065609_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048403_))));
    vlSelf->wasmetal_core__DOT___048408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048402_))));
    vlSelf->wasmetal_core__DOT___061648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___007032_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___048415_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___053762_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052878_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053760_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047781_)))))))));
    vlSelf->wasmetal_core__DOT___048416_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019304_))));
    vlSelf->wasmetal_core__DOT___066332_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048405_))));
    vlSelf->wasmetal_core__DOT___048441_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048405_))));
    vlSelf->wasmetal_core__DOT___007036_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048371_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048358_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048342_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    if (vlSelf->wasmetal_core__DOT__sp__05b6__05d) {
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128459___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___056256_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002994_)))))))));
    vlSelf->wasmetal_core__DOT___053766_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053764_))));
    vlSelf->wasmetal_core__DOT___052894_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048437_)))));
    vlSelf->wasmetal_core__DOT___052895_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048437_))));
    vlSelf->wasmetal_core__DOT___025062_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)))))));
    vlSelf->wasmetal_core__DOT___007054_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))));
    vlSelf->wasmetal_core__DOT___048357_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h9205a979__0))));
    vlSelf->wasmetal_core__DOT___048348_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h9205a979__0))));
    vlSelf->wasmetal_core__DOT___054144_ = (1U & (0x1f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048472_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048473_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)))))))));
    vlSelf->wasmetal_core__DOT___019396_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048324_)))));
    vlSelf->wasmetal_core__DOT___019336_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___053758_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___053756_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb92dbfd9__0))))))));
    vlSelf->wasmetal_core__DOT___063854_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048351_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048347_))))));
    vlSelf->wasmetal_core__DOT___064017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048360_))));
    vlSelf->wasmetal_core__DOT___048452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048376_))))));
    vlSelf->wasmetal_core__DOT___048470_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hcc483c10__0)))));
    vlSelf->wasmetal_core__DOT___048454_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_hcc483c10__0)))));
    vlSelf->wasmetal_core__DOT___045662_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(wasmetal_core__DOT___045666_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : 
                                                        (0x4fU 
                                                         >> 
                                                         ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & (vlSelf->insn_op 
                                                                   >> 6U))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070629_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (vlSelf->insn_op 
                                                                   >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___053266_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047787_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           ((4U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbcc95063__0))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048362_)))));
    vlSelf->wasmetal_core__DOT___048390_ = (1U & (0x1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048363_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048362_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048361_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048360_)))))));
    vlSelf->wasmetal_core__DOT___048380_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048269_))))));
    vlSelf->wasmetal_core__DOT___045734_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(wasmetal_core__DOT___045738_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045735_))))));
    vlSelf->wasmetal_core__DOT___003034_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x8000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___047969_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___047968_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___047967_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047966_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7f7f7fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28012a28__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047964_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047963_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047962_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047961_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002985_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfffeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfbfbfbfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___047784_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x80U 
                                                           >> 
                                                           ((4U 
                                                             & ((0x1000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x8000U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___000368_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047780_))))));
    vlSelf->wasmetal_core__DOT___003147_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003040_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002965_)))))))));
    vlSelf->wasmetal_core__DOT___047988_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003045_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___003044_)) 
                                                     & (IData)(
                                                               (0x80ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003042_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003041_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003040_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003039_)))))))))));
    vlSelf->wasmetal_core__DOT___003032_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 7U))))));
    vlSelf->__VdfgTmp_h93f3e051__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048419_));
    vlSelf->wasmetal_core__DOT___063786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053367_))));
    vlSelf->wasmetal_core__DOT___053011_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___050381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->wasmetal_core__DOT___048422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048418_))));
    vlSelf->wasmetal_core__DOT___002967_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___001234_)
                                                   ? (IData)(
                                                             (0x11111000fffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))))))
                                                   : (IData)(wasmetal_core__DOT___001235_)));
    vlSelf->wasmetal_core__DOT___047975_ = (1U & ((1U 
                                                   & (0x8000U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                                                   ? (IData)(
                                                             (0x11111000fffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))))))
                                                   : (IData)(wasmetal_core__DOT___001235_)));
    vlSelf->wasmetal_core__DOT___051567_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0))))));
    vlSelf->wasmetal_core__DOT___051572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051564_))));
    vlSelf->wasmetal_core__DOT___036595_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051253_)))));
    vlSelf->wasmetal_core__DOT___036767_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8befad22__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051253_))))));
    vlSelf->wasmetal_core__DOT___053010_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052888_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052839_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___052880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051201_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->wasmetal_core__DOT___052887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052837_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048435_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048424_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001233_)))));
    vlSelf->wasmetal_core__DOT___052881_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___000357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052898_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___000357_))));
    vlSelf->wasmetal_core__DOT___048429_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000359_)) 
                                                  & (IData)(
                                                            (0x7f7f7fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___000357_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4a5b8c23__0))))))));
    vlSelf->wasmetal_core__DOT___051200_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->__VdfgTmp_hced715c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___051191_));
    vlSelf->wasmetal_core__DOT___062971_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048519_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___000357_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048425_)))));
    vlSelf->wasmetal_core__DOT___053427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051569_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___054460_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))))))));
    vlSelf->wasmetal_core__DOT___052883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052796_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___000357_)))));
    vlSelf->wasmetal_core__DOT___052648_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052647_)))));
    vlSelf->wasmetal_core__DOT___054465_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0)))))));
    vlSelf->wasmetal_core__DOT___045703_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(wasmetal_core__DOT___045709_) 
                                                          | (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h323e8784__0))))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT___053476_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052940_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048286_))))));
    vlSelf->wasmetal_core__DOT___019414_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052940_))));
    vlSelf->wasmetal_core__DOT___052114_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044655_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___003145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044645_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___000416_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044636_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___045615_))));
    vlSelf->wasmetal_core__DOT___000417_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045615_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044616_))));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))) {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT___021741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052015_))));
    vlSelf->wasmetal_core__DOT___021740_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d))));
    vlSelf->wasmetal_core__DOT___053260_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003092_))));
    vlSelf->wasmetal_core__DOT___048308_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048306_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048305_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048304_)))));
    vlSelf->wasmetal_core__DOT___053772_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___043582_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___043138_))));
    vlSelf->wasmetal_core__DOT___048393_ = (1U & (0xf8880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045672_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide)))))));
    vlSelf->wasmetal_core__DOT___053482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045693_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044157_))));
    vlSelf->wasmetal_core__DOT___053333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052955_))));
    vlSelf->__VdfgTmp_h223d2b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___003012_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003011_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0)))));
    vlSelf->wasmetal_core__DOT___054463_ = (1U & (IData)(
                                                         (0xff00ff00ff00e000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048317_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___051191_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048314_)))))))));
    vlSelf->wasmetal_core__DOT___045716_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045719_))));
    vlSelf->wasmetal_core__DOT___045725_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___044194_) 
                                                          | (IData)(wasmetal_core__DOT___045726_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128721___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)
                 : (IData)(wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128721___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035215_)))));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 6U) & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x40U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 6U) : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029940_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029907_)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032892_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032859_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063109_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063115_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128196___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029771_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029738_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d));
    vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029408_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029375_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027827_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027794_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 6U) & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063456_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051016_))));
    vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029247_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029214_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d));
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 6U)) & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h53b39b5e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5035dc07__0));
    vlSelf->wasmetal_core__DOT___071578_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))))));
    vlSelf->wasmetal_core__DOT___071583_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019418_))));
    vlSelf->wasmetal_core__DOT___045535_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___045547_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128426___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032220_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032187_)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___052873_ = (1U & (IData)(
                                                         (0x8000ffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052871_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052870_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044720_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___044719_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___044718_))))))))))));
    vlSelf->wasmetal_core__DOT___070633_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___070634_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032667_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___066197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___066364_ = (1U & (IData)(
                                                         (0x5ff3ffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                               << 5U)) 
                                                           | (IData)(__VdfgTmp_h5fe12ba6__0)))));
    vlSelf->wasmetal_core__DOT___065568_ = (1U & (IData)(
                                                         (0x5ff3ffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                               << 5U)) 
                                                           | (IData)(__VdfgTmp_h5fe12ba6__0)))));
    vlSelf->wasmetal_core__DOT___068869_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068912_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069172_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068537_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068979_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069010_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069211_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068675_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069059_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___068576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069105_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067563_))));
    vlSelf->wasmetal_core__DOT___069471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___070129_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065560_))));
    vlSelf->wasmetal_core__DOT___065567_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065559_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065558_))))));
    vlSelf->wasmetal_core__DOT___019390_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT___064097_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT___064244_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2f701d9__0))));
    vlSelf->wasmetal_core__DOT___069828_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066372_)))));
    vlSelf->wasmetal_core__DOT___069653_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066372_))));
    vlSelf->__VdfgTmp_hfed1012b__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067563_));
    vlSelf->__VdfgTmp_h7eff58ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 8U)));
    vlSelf->wasmetal_core__DOT___066456_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067215_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___067359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___066669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->__VdfgTmp_h7e1b7882__0 = (((IData)(vlSelf->wasmetal_core__DOT___066368_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->mem_rdata[0U] 
                                                    >> 0xfU)));
    vlSelf->wasmetal_core__DOT___066808_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->wasmetal_core__DOT___066479_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066368_))));
    vlSelf->__VdfgTmp_hb1936621__0 = (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066368_));
    vlSelf->wasmetal_core__DOT___065647_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065842_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->__VdfgTmp_h04a3d61f__0 = (((IData)(vlSelf->wasmetal_core__DOT___065566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___066368_));
    vlSelf->wasmetal_core__DOT___065572_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066020_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066218_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___066176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065975_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___065755_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065566_))));
    vlSelf->wasmetal_core__DOT___069996_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___070246_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1dU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067561_)))));
    vlSelf->wasmetal_core__DOT___067562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067561_))));
    vlSelf->wasmetal_core__DOT___069675_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069720_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069807_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069698_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069742_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___069654_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067557_))));
    vlSelf->wasmetal_core__DOT___067568_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067565_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 4U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065557_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065565_)))))));
    vlSelf->wasmetal_core__DOT___065581_ = (1U & (IData)(
                                                         (0xffff800000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065579_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___065578_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065554_)))))))));
    vlSelf->wasmetal_core__DOT___066370_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066365_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065578_)))));
    vlSelf->wasmetal_core__DOT___071830_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___071798_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071507_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___071838_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___071806_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071527_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___071822_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071546_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))));
    vlSelf->wasmetal_core__DOT___071790_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071481_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037210_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037178_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0))));
    vlSelf->wasmetal_core__DOT___034669_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___034658_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___034647_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128704___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__ 
        = (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                            << 2U) | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___128704___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035128_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035053_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128688___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d)))))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___034925_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)) 
                                            & (IData)(wasmetal_core__DOT___128688___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026287_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026254_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d));
    vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026191_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026158_)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026350_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d));
    vlSelf->wasmetal_core__DOT___054480_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054483_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___052580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___051018_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___071832_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071555_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___071800_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071513_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___071808_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___071824_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071548_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___071792_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071489_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___071831_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071554_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___071799_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___071823_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071547_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___071791_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071485_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___071829_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___071797_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071504_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___071837_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071559_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___071805_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071525_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___071789_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071476_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___071827_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071550_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___071795_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___071835_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071557_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___071803_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___071819_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__ 
        = (1U & (7U >> ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___070574_))));
    vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032813_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___031203_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046932_))));
    vlSelf->wasmetal_core__DOT___031491_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046932_)))));
    vlSelf->wasmetal_core__DOT___032514_ = (1U & (0x4f00b0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032386_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063361_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill)))))));
    vlSelf->wasmetal_core__DOT___046799_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063361_))));
    vlSelf->wasmetal_core__DOT___031192_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046931_))));
    vlSelf->wasmetal_core__DOT___031480_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046931_)))));
    vlSelf->wasmetal_core__DOT___032503_ = (1U & (0x4f00b0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032375_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063360_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill)))))));
    vlSelf->wasmetal_core__DOT___046798_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063360_))));
    vlSelf->wasmetal_core__DOT___063359_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048485_))));
    vlSelf->wasmetal_core__DOT___031181_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046930_))));
    vlSelf->wasmetal_core__DOT___031469_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___046930_)))));
    vlSelf->wasmetal_core__DOT___032492_ = (1U & (IData)(
                                                         (0x4000ff00bfff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_backwards) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9fa2de6d__0))))))));
    vlSelf->wasmetal_core__DOT___046797_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__ 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___063357_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063358_))));
    vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__ 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063358_))));
    vlSelf->wasmetal_core__DOT___053206_ = (1U & (IData)(
                                                         (0xfdf00c000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 2U)) 
                                                                 | (2U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                              << 1U)) 
                                                                            << 1U))) 
                                                                       << 1U))))))));
    vlSelf->wasmetal_core__DOT___065824_ = (1U & (IData)(
                                                         (0xee000f00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                     << 2U) 
                                                                    | (2U 
                                                                       & ((1U 
                                                                           >> 
                                                                           (3U 
                                                                            & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))) 
                                                                          << 1U)))))))));
    vlSelf->wasmetal_core__DOT___050550_ = (1U & (IData)(
                                                         (0xbfffa00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 3U)) 
                                                                 | (1U 
                                                                    & (4U 
                                                                       >> 
                                                                       (2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                             << 1U)) 
                                                                           << 1U))))))))));
    vlSelf->wasmetal_core__DOT___066104_ = (1U & (IData)(
                                                         (0xf0f0f080ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                            << 5U) 
                                                           | (4U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                 << 2U))))));
    vlSelf->wasmetal_core__DOT___051409_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf8ff00ff00ff00ffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                      << 5U)) 
                                                                  | ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                     << 3U))))))));
    vlSelf->__VdfgTmp_haa60ee2a__0 = ((2U & ((4U >> 
                                              (2U & 
                                               ((4U 
                                                 >> 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                  << 1U)) 
                                                << 1U))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                << 1U))));
    vlSelf->__VdfgTmp_hc31691c0__0 = ((2U & ((4U >> 
                                              ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                               << 1U)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___049005_));
    vlSelf->wasmetal_core__DOT___053122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->__VdfgTmp_h9a0c5050__0 = ((2U & ((1U >> 
                                              (3U & 
                                               (- (IData)(
                                                          (1U 
                                                           & (4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                               << 1U))))))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                << 1U))));
    vlSelf->wasmetal_core__DOT___052608_ = (1U & (0xa300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (- (IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___049695_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___053371_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> 
                                                               (3U 
                                                                & (- (IData)(
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))))))))))));
    vlSelf->wasmetal_core__DOT___053578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048562_))));
    vlSelf->__VdfgTmp_h8594c810__0 = (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                       << 5U) | (0x1cU 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                    << 2U)));
    vlSelf->wasmetal_core__DOT___048563_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048562_))));
    vlSelf->wasmetal_core__DOT___049743_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___050482_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> 
                                                         (1U 
                                                          & (0x80U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))))));
    vlSelf->wasmetal_core__DOT___049333_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | ((4U 
                                                       & ((0x80U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___048562_)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___048562_)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048562_))))));
    vlSelf->wasmetal_core__DOT___051607_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                    << 4U) 
                                                   | (0xfU 
                                                      & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O), 3U)))));
    vlSelf->wasmetal_core__DOT___050548_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe0000000U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                          << 2U))))));
    vlSelf->wasmetal_core__DOT___049791_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (0x80U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___049879_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe0000000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___051006_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (0x80U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))))));
    vlSelf->wasmetal_core__DOT___051107_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xe000U 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                            << 2U)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___051767_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xe000U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                          << 2U))))));
    vlSelf->wasmetal_core__DOT___049480_ = (1U & (0xfe000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                      << 3U))));
    vlSelf->__VdfgTmp_hf59791bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                       << 4U) | (0xfU 
                                                 & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O), 2U)));
    vlSelf->wasmetal_core__DOT___049787_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                         << 1U)) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (- (IData)(
                                                                   (1U 
                                                                    & (4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                        << 1U)))))))));
    vlSelf->wasmetal_core__DOT___051105_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->__VdfgTmp_h3e63cb74__0 = ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                << 4U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                          << 2U) | 
                                         (1U & (0x80U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))));
    vlSelf->wasmetal_core__DOT___051049_ = (1U & (0xe0U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___048562_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))));
    vlSelf->__VdfgTmp_h73ce3765__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                         << 4U));
    vlSelf->__VdfgTmp_h06d4437a__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                << 5U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                         << 3U));
    vlSelf->wasmetal_core__DOT___049878_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                         << 2U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                          << 1U))))));
    vlSelf->__VdfgTmp_h25023fb5__0 = ((2U & ((8U >> (IData)(vlSelf->wasmetal_core__DOT___048562_)) 
                                             << 1U)) 
                                      | (1U & (0x80U 
                                               >> (IData)(vlSelf->wasmetal_core__DOT___048562_))));
    vlSelf->__VdfgTmp_h84873f61__0 = (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                       << 5U) | (0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                    << 4U)));
    vlSelf->wasmetal_core__DOT___048676_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___009534_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047803_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128568___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058085_))));
    vlSelf->wasmetal_core__DOT___053773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043283_))));
    vlSelf->wasmetal_core__DOT___053771_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043576_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043129_))));
    vlSelf->wasmetal_core__DOT___053561_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053423_))));
    vlSelf->__VdfgTmp_hf748d2ff__0 = ((2U & ((0xf38f2779U 
                                              >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___063459_));
    vlSelf->wasmetal_core__DOT___063461_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063459_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052859_)))));
    vlSelf->wasmetal_core__DOT___053007_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xaaaa02aaaaaa282aULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052997_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___046017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
}
