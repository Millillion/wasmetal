#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__26(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__26\n"); );
    // Body
    vlSelf->__VdfgTmp_h3226e594__0 = (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007473_));
    vlSelf->wasmetal_core__DOT___027481_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007340_)))))))));
    vlSelf->__VdfgTmp_h161030dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007473_));
    vlSelf->__VdfgTmp_h51b5ea87__0 = (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054901_));
    vlSelf->__VdfgTmp_h3d308cc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053918_))))));
    if (vlSelf->wasmetal_core__DOT___007235_) {
        if (vlSelf->wasmetal_core__DOT___007234_) {
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007587_))));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0))));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0))));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h0761bbb4__0)));
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h66742b2d__0)));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h939caa69__0)));
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0)));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0))));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf2283ef8__0)));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hd4d40399__0)));
        } else {
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007585_))));
            vlSelf->wasmetal_core__DOT___009784_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))));
            vlSelf->wasmetal_core__DOT___010977_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0))));
            vlSelf->wasmetal_core__DOT___010988_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007566_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007565_))));
            vlSelf->wasmetal_core__DOT___010982_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007545_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007544_))));
            vlSelf->wasmetal_core__DOT___010193_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007525_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007524_))));
            vlSelf->wasmetal_core__DOT___010957_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___007628_));
            vlSelf->wasmetal_core__DOT___009796_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h009b2026__0))));
            vlSelf->wasmetal_core__DOT___054855_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007641_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007640_))));
            vlSelf->wasmetal_core__DOT___010231_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hae0eb281__0)));
        }
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))));
        vlSelf->wasmetal_core__DOT___010164_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h13d2f137__0)))
                                                    : 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he182d032__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___054806_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007589_)))));
        vlSelf->wasmetal_core__DOT___009784_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007740_)))));
        vlSelf->wasmetal_core__DOT___010977_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007755_)))));
        vlSelf->wasmetal_core__DOT___010988_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007569_)))));
        vlSelf->wasmetal_core__DOT___010982_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007548_)))));
        vlSelf->wasmetal_core__DOT___010193_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007528_)))));
        vlSelf->wasmetal_core__DOT___011003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007664_))));
        vlSelf->wasmetal_core__DOT___010164_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007729_)))));
        vlSelf->wasmetal_core__DOT___010957_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007623_)))));
        vlSelf->wasmetal_core__DOT___009796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007703_)))));
        vlSelf->wasmetal_core__DOT___054855_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007644_)))));
        vlSelf->wasmetal_core__DOT___010231_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007234_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007505_)))));
    }
    vlSelf->wasmetal_core__DOT___062025_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))));
    vlSelf->wasmetal_core__DOT___054952_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0)))));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007786_;
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007373_))))));
        vlSelf->wasmetal_core__DOT___010110_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007470_))))));
    } else {
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007789_));
        vlSelf->wasmetal_core__DOT___010110_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007471_))))));
    }
    vlSelf->wasmetal_core__DOT___010321_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hba71a165__0))));
    vlSelf->wasmetal_core__DOT___049009_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049008_))));
    vlSelf->wasmetal_core__DOT___049123_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049008_))));
    vlSelf->wasmetal_core__DOT___062084_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))));
    vlSelf->wasmetal_core__DOT___054991_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0)))));
    vlSelf->__VdfgTmp_hf6bbf4d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007390_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007789_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007754_)));
    vlSelf->__VdfgTmp_h5ce4c910__0 = (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054775_));
    vlSelf->wasmetal_core__DOT___049012_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___049126_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___062150_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))));
    vlSelf->wasmetal_core__DOT___055037_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))));
    vlSelf->__VdfgTmp_hf96aac0e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007420_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007792_))));
    vlSelf->__VdfgTmp_h5ffe6cff__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007792_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007769_)));
    vlSelf->wasmetal_core__DOT___010310_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h22d02546__0))));
    vlSelf->__VdfgTmp_hcb315704__0 = (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0)));
    vlSelf->__VdfgTmp_hb1a6f4d3__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd8993186__0))))));
    vlSelf->__VdfgTmp_h805d75e1__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c85186d__0))))));
    vlSelf->wasmetal_core__DOT___051548_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051547_))));
    vlSelf->__VdfgTmp_hce73595f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048605_));
    vlSelf->__VdfgTmp_h85e16522__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h08beb063__0))))));
    vlSelf->__VdfgTmp_h36154466__0 = (((IData)(vlSelf->wasmetal_core__DOT___051547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051579_));
    vlSelf->wasmetal_core__DOT___051612_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051611_))));
    vlSelf->__VdfgTmp_ha9985ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT___048660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048659_));
    vlSelf->__VdfgTmp_h1dedb610__0 = (((IData)(vlSelf->wasmetal_core__DOT___048605_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048660_));
    vlSelf->__VdfgTmp_h58306e5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___048617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048606_));
    vlSelf->wasmetal_core__DOT___051519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051518_))));
    vlSelf->__VdfgTmp_h627ddd53__0 = (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h29ef1e90__0));
    vlSelf->__VdfgTmp_h4f58838a__0 = (((IData)(vlSelf->wasmetal_core__DOT___048618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048617_));
    vlSelf->wasmetal_core__DOT___051365_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051364_))));
    vlSelf->__VdfgTmp_h5d9fd2de__0 = (((IData)(vlSelf->wasmetal_core__DOT___048629_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048618_));
    vlSelf->wasmetal_core__DOT___051345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051344_))));
    vlSelf->wasmetal_core__DOT___055863_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055860_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055859_)))))))));
    vlSelf->wasmetal_core__DOT___055062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027491_))));
    vlSelf->__VdfgTmp_he68aaf0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7e54e6f3__0));
    vlSelf->wasmetal_core__DOT___060957_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))));
    vlSelf->wasmetal_core__DOT___010887_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0761bbb4__0))))))));
    vlSelf->__VdfgTmp_h6df87d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010350_)));
    vlSelf->wasmetal_core__DOT___060881_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))));
    vlSelf->wasmetal_core__DOT___010715_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0))))))));
    vlSelf->__VdfgTmp_ha8fd39d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d));
    vlSelf->wasmetal_core__DOT___010881_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h66742b2d__0))))))));
    vlSelf->wasmetal_core__DOT___010374_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010368_)))))));
    vlSelf->wasmetal_core__DOT___010045_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010369_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010368_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010370_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010371_)))))));
    vlSelf->wasmetal_core__DOT___054870_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))));
    vlSelf->wasmetal_core__DOT___056187_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010319_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010320_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hba71a165__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                   ? 
                                                                  (0x305U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))
                                                                   : 
                                                                  (0x305U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))))))))));
    vlSelf->__VdfgTmp_h0fd3f1c4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h597612ae__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))))));
    vlSelf->wasmetal_core__DOT___055005_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h223b6529__0)))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010559_)));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010568_)));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d)));
    } else {
        vlSelf->wasmetal_core__DOT___012124_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                    ? 
                                                   (0xfaf3U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))
                                                    : 
                                                   (0xefU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010558_))))));
        vlSelf->wasmetal_core__DOT___012123_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
        vlSelf->wasmetal_core__DOT___012027_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d 
        = (1U & (IData)((0x5500cc000f0000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010558_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h79c46d44__0))))))));
    vlSelf->wasmetal_core__DOT___056182_ = (1U & (IData)(
                                                         (0xf00001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___010893_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h939caa69__0))))))));
    vlSelf->wasmetal_core__DOT___010172_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))));
    vlSelf->wasmetal_core__DOT___054743_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd4d40399__0))))))));
    vlSelf->wasmetal_core__DOT___055276_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))));
    vlSelf->wasmetal_core__DOT___053074_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045623_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->type_matches)))));
    vlSelf->wasmetal_core__DOT___053070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044045_))));
    vlSelf->wasmetal_core__DOT___061496_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061493_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061492_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054692_)))))))));
    vlSelf->__VdfgTmp_h88cf509b__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h72b22246__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))))));
    vlSelf->wasmetal_core__DOT___055051_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h49097fbe__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010569_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce8e9d12__0))))));
    vlSelf->wasmetal_core__DOT___055759_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055750_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055753_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008040_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055755_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055754_)))))))))))));
    vlSelf->wasmetal_core__DOT___061489_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054699_)))))))));
    vlSelf->__VdfgTmp_h16ee9b67__0 = (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007232_));
    vlSelf->wasmetal_core__DOT___027493_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007253_)))))))));
    vlSelf->__VdfgTmp_hbb919cd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007232_))));
    vlSelf->__VdfgTmp_hab146f1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054770_));
    vlSelf->wasmetal_core__DOT___007776_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    vlSelf->__VdfgTmp_h7b1353df__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    vlSelf->wasmetal_core__DOT___054278_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007529_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hca913760__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007524_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007525_)))))))))))))));
    vlSelf->wasmetal_core__DOT___049087_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->wasmetal_core__DOT___048974_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->wasmetal_core__DOT___049096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049095_))));
    vlSelf->wasmetal_core__DOT___049260_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049095_))));
    vlSelf->wasmetal_core__DOT___061488_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061485_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061484_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054702_)))))))));
    vlSelf->wasmetal_core__DOT___061111_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054908_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054900_))))))))))))));
    vlSelf->__VdfgTmp_hac54b2bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007473_))));
    vlSelf->wasmetal_core__DOT___027488_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007341_)))))))));
    vlSelf->__VdfgTmp_h988afe01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054900_));
    vlSelf->wasmetal_core__DOT___010271_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007470_)))))))));
    vlSelf->wasmetal_core__DOT___049064_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049063_))));
    vlSelf->wasmetal_core__DOT___049271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049063_))));
    vlSelf->wasmetal_core__DOT___055978_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055812_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055813_)))))))));
    vlSelf->wasmetal_core__DOT___019255_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055811_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008077_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055813_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055812_)))))))))))));
    vlSelf->wasmetal_core__DOT___049061_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049060_))));
    vlSelf->wasmetal_core__DOT___049270_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049060_))));
    vlSelf->wasmetal_core__DOT___061975_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))));
    vlSelf->__VdfgTmp_h544074d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)));
    vlSelf->wasmetal_core__DOT___010272_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)))))));
    vlSelf->wasmetal_core__DOT___061046_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))));
    vlSelf->__VdfgTmp_h4481aac1__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hbc236300__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf21032c8__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))))));
    vlSelf->wasmetal_core__DOT___010361_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))))));
    vlSelf->wasmetal_core__DOT___010151_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3856dbf8__0))))));
    vlSelf->__VdfgTmp_h249314f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))
                                                     : 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he182d032__0)))))));
    vlSelf->wasmetal_core__DOT___010131_ = (1U & (0xff550f33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))));
    vlSelf->wasmetal_core__DOT___010253_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))))));
    vlSelf->wasmetal_core__DOT___061127_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))));
    vlSelf->__VdfgTmp_hb52e5b74__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h0d308a29__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd27b8df6__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5cfad588__0)))))));
    vlSelf->wasmetal_core__DOT___009808_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xa0c0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb53fd6c1__0))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007604_))))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h973345c0__0))))));
    vlSelf->wasmetal_core__DOT___010141_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))));
    vlSelf->wasmetal_core__DOT___010322_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h37a4ed19__0))))))));
    vlSelf->wasmetal_core__DOT___061209_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))));
    vlSelf->wasmetal_core__DOT___010869_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))));
    vlSelf->wasmetal_core__DOT___055430_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h949b8002__0))));
    vlSelf->wasmetal_core__DOT___061842_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))));
    vlSelf->__VdfgTmp_h0f4209a4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc5dd9afa__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf131a410__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))))));
    vlSelf->__VdfgTmp_hafe0013c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_had16ce46__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb63b65e7__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1fbedb27__0)))))));
    vlSelf->__VdfgTmp_hd544aedd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010588_));
    vlSelf->__VdfgTmp_h20b0bc38__0 = (((IData)(vlSelf->wasmetal_core__DOT___010588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010589_));
    vlSelf->__VdfgTmp_h00532677__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010289_));
    vlSelf->wasmetal_core__DOT___019243_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055782_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055783_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008056_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055785_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055784_)))))))))))));
    vlSelf->wasmetal_core__DOT___061912_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))));
    vlSelf->__VdfgTmp_hc0fd2d13__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he6aadab7__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hca7cb6a3__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))))));
    vlSelf->__VdfgTmp_h9a768dd6__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h891cd943__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6b627b07__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15fa30e3__0)))))));
    vlSelf->wasmetal_core__DOT___009832_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010582_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007834_)))))))));
    vlSelf->__VdfgTmp_hc5fe5af8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___007834_)) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010582_));
    vlSelf->__VdfgTmp_h9e2ff648__0 = (((IData)(vlSelf->wasmetal_core__DOT___007703_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7619e45d__0));
    vlSelf->wasmetal_core__DOT___061502_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061499_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061498_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054683_)))))))));
    vlSelf->wasmetal_core__DOT___060863_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054779_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054769_))))))))))))));
    vlSelf->__VdfgTmp_h6995c07d__0 = (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054782_))));
    vlSelf->wasmetal_core__DOT___027485_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007254_)))))))));
    vlSelf->__VdfgTmp_h028c74de__0 = (((IData)(vlSelf->wasmetal_core__DOT___054780_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054779_));
    vlSelf->__VdfgTmp_h63abc8ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055135_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                                       << 2U) 
                                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                           & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))) 
                                                                          << 1U) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc18298c4__0))))))))))))));
    vlSelf->wasmetal_core__DOT___010102_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055135_))))));
    vlSelf->wasmetal_core__DOT___061497_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061495_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061494_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007720_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054778_)))))))));
    vlSelf->wasmetal_core__DOT___010875_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))));
    vlSelf->wasmetal_core__DOT___011520_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010308_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010309_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                              & (IData)(
                                                                        (0xf0f555500ff3333ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h22d02546__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf00001111ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2283ef8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055971_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055796_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055797_)))))))));
    vlSelf->wasmetal_core__DOT___055805_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f05555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055792_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055795_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008069_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055796_)))))))))))));
    vlSelf->wasmetal_core__DOT___061045_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT___054905_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb33d3cb7__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007589_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007590_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007586_)))))))))))))));
    vlSelf->wasmetal_core__DOT___055105_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055089_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h284fdec6__0)))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf5533ffU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xc0aU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h705cf6e2__0)))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0xc0aU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebcfe313__0)))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ad9b652__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___055683_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055680_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->__VdfgTmp_he6780703__0 = (((IData)(vlSelf->wasmetal_core__DOT___009650_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009649_));
    vlSelf->__VdfgTmp_h831e3e64__0 = (((IData)(vlSelf->wasmetal_core__DOT___009792_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009791_));
    vlSelf->__VdfgTmp_h910334c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009791_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009792_)));
    vlSelf->__VdfgTmp_h1f90c42a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010288_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010287_));
    vlSelf->__VdfgTmp_h0549af28__0 = (((IData)(vlSelf->wasmetal_core__DOT___010290_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010289_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010287_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010288_))));
    vlSelf->__VdfgTmp_h9bd5098e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009795_));
    vlSelf->__VdfgTmp_h35b20f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010278_));
    vlSelf->wasmetal_core__DOT___061062_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->wasmetal_core__DOT___054904_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha17fb340__0)))));
    vlSelf->__VdfgTmp_h8e4b209e__0 = ((2U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010269_));
    vlSelf->__VdfgTmp_h047929cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009815_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009814_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054852_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054851_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054850_)))))));
    vlSelf->__VdfgTmp_hd7e7c41d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010250_));
    vlSelf->wasmetal_core__DOT___061490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061482_))));
    vlSelf->__VdfgTmp_h0b52da3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009781_));
    vlSelf->__VdfgTmp_h4965d650__0 = (((IData)(vlSelf->wasmetal_core__DOT___010240_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010239_));
    vlSelf->__VdfgTmp_hb5f0d294__0 = (((IData)(vlSelf->wasmetal_core__DOT___010239_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010240_));
    vlSelf->__VdfgTmp_hab0a7d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___009830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_hcdc85607__0 = (((IData)(vlSelf->wasmetal_core__DOT___010214_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010213_));
    vlSelf->__VdfgTmp_h15c467ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010213_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010214_)));
    vlSelf->__VdfgTmp_h479e0c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcab0eaad__0))))));
    vlSelf->__VdfgTmp_hd25df3ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___011622_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he26aa999__0)))))));
    vlSelf->__VdfgTmp_h4e8951c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___054157_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he26aa999__0))) 
                                                     << 2U)) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xf0f0aaaaff00ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007430_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2966a39c__0)))))));
    vlSelf->wasmetal_core__DOT___061668_ = (1U & (IData)(
                                                         (0xff00fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061666_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h73a9d128__0)))))));
    vlSelf->wasmetal_core__DOT___069246_ = (1U & (IData)(
                                                         (0xcc00f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000169_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048922_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048923_)))))))));
    vlSelf->wasmetal_core__DOT___055026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055020_))));
    vlSelf->wasmetal_core__DOT___053694_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___064770_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064538_))));
    vlSelf->wasmetal_core__DOT___064541_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hab155f14__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x4fff00ff00000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h101b2914__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h75b63843__0))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h61f75715__0 = (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h75b63843__0))));
    vlSelf->wasmetal_core__DOT___042153_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042208_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65785f77__0))));
    vlSelf->wasmetal_core__DOT___042387_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0410a6dd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___042354_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070500_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h67b52d18__0))));
    vlSelf->wasmetal_core__DOT___051629_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051628_))));
    vlSelf->__VdfgTmp_hb6137419__0 = (((IData)(vlSelf->wasmetal_core__DOT___051628_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051648_));
    vlSelf->__VdfgTmp_h3f02e9b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___048670_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048669_));
    vlSelf->__VdfgTmp_h309182ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___048659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048670_));
    vlSelf->wasmetal_core__DOT___062094_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))));
    vlSelf->__VdfgTmp_hcf41fd11__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h61af7368__0))))));
    vlSelf->__VdfgTmp_hc6adb13e__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6e5b7cf0__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h997e3a26__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9c4c7506__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                     ? (IData)((0xff0fff0fff55ff33ULL 
                                >> (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                     << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                << 4U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___007824_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(
                                                                 (0xf0f555500ff3333ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h447558a7__0))))))) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007628_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8d86a2a9__0))))))))))
                     : (2U >> (IData)(vlSelf->wasmetal_core__DOT___007824_)))));
    vlSelf->wasmetal_core__DOT___010336_ = (1U & (0x1111fff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010330_)))))));
    vlSelf->wasmetal_core__DOT___033416_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010332_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010333_)))))));
    vlSelf->wasmetal_core__DOT___070026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053071_))));
    vlSelf->wasmetal_core__DOT___061908_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061649_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007301_)))))))));
    vlSelf->wasmetal_core__DOT___061503_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054782_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054675_)))))))));
    vlSelf->wasmetal_core__DOT___062139_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))));
    vlSelf->__VdfgTmp_h415259f4__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_haef34542__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5d8e5746__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))))));
    vlSelf->__VdfgTmp_h84a7ba42__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb53c364f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd9dc27af__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haef34542__0)))))));
    vlSelf->__VdfgTmp_hc9e45bda__0 = (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->__VdfgTmp_h9c14d25f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010529_));
    vlSelf->wasmetal_core__DOT___022502_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))));
    vlSelf->__VdfgTmp_hcf8aa4a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h29c4951c__0)));
    vlSelf->wasmetal_core__DOT___048816_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h29c4951c__0))))));
    vlSelf->wasmetal_core__DOT___054947_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054941_))));
    vlSelf->wasmetal_core__DOT___051506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h419b9e2f__0))));
    vlSelf->__VdfgTmp_h170507c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001317_));
    vlSelf->__VdfgTmp_h89619cd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001785_)));
    vlSelf->__VdfgTmp_h73960028__0 = (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001786_));
    vlSelf->wasmetal_core__DOT___054918_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1c7a54d6__0)))));
    vlSelf->wasmetal_core__DOT___069039_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002853_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048684_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048685_)))))));
    vlSelf->__VdfgTmp_h804cf86b__0 = (((IData)(vlSelf->wasmetal_core__DOT___002390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h47d0b828__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x80U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0c779906__0))))))))))));
    vlSelf->wasmetal_core__DOT___022498_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha93fec6f__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___006115_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048703_))))));
    vlSelf->wasmetal_core__DOT___068941_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048841_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048842_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->__VdfgTmp_hcd5a09ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001316_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001315_))))));
    vlSelf->wasmetal_core__DOT___002894_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001786_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001785_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001783_)))))))));
    vlSelf->wasmetal_core__DOT___061475_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061473_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061472_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007340_)))))))));
    vlSelf->wasmetal_core__DOT___056419_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91a424ff__0))))));
    vlSelf->wasmetal_core__DOT___054722_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a046d69__0)))));
    vlSelf->__VdfgTmp_hfc864313__0 = (((IData)(vlSelf->wasmetal_core__DOT___010386_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb4fb5a01__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010594_))));
    vlSelf->__VdfgTmp_hdea69a06__0 = ((2U & ((IData)(
                                                     (0xf0f0ccccff00aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007433_)))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010594_));
    vlSelf->wasmetal_core__DOT___051504_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_)))));
    vlSelf->wasmetal_core__DOT___022496_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he648fa65__0))));
    if (vlSelf->wasmetal_core__DOT___000181_) {
        vlSelf->wasmetal_core__DOT___002933_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h47d0b828__0)))));
        vlSelf->wasmetal_core__DOT___002324_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001314_)))));
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___002144_));
    } else {
        if (vlSelf->wasmetal_core__DOT___000180_) {
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___002235_)));
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001317_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001316_))));
        } else {
            vlSelf->wasmetal_core__DOT___002933_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))));
            vlSelf->wasmetal_core__DOT___002324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___001313_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001312_))));
        }
        vlSelf->wasmetal_core__DOT___002689_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8c923865__0)))));
    }
    vlSelf->wasmetal_core__DOT___002509_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002234_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002233_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he7245d4a__0))))))));
    vlSelf->__VdfgTmp_hb043089c__0 = (((IData)(vlSelf->wasmetal_core__DOT___048630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048629_));
    vlSelf->wasmetal_core__DOT___051325_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051324_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127601___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb70db301__0))) 
           ^ (1U | ((8U & (((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d)) 
                            | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__)) 
                           << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__) 
                                       << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                 << 1U)))));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hdb0eb761__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___000924_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001930_)));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___001930_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001657_))))));
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000179_))))));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001773_;
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___001734_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___000183_));
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001896_));
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___002225_;
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001770_;
    } else {
        vlSelf->wasmetal_core__DOT___002510_ = vlSelf->wasmetal_core__DOT___002148_;
        vlSelf->wasmetal_core__DOT___002650_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001773_));
        vlSelf->wasmetal_core__DOT___002932_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001734_));
        vlSelf->wasmetal_core__DOT___002563_ = vlSelf->wasmetal_core__DOT___001659_;
        vlSelf->wasmetal_core__DOT___001721_ = vlSelf->wasmetal_core__DOT___000184_;
        vlSelf->wasmetal_core__DOT___001337_ = vlSelf->wasmetal_core__DOT___001658_;
        vlSelf->wasmetal_core__DOT___000163_ = vlSelf->wasmetal_core__DOT___000183_;
        vlSelf->wasmetal_core__DOT___001964_ = vlSelf->wasmetal_core__DOT___001896_;
        vlSelf->wasmetal_core__DOT___001935_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0)));
        vlSelf->wasmetal_core__DOT___001854_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0)));
        vlSelf->wasmetal_core__DOT___048755_ = vlSelf->wasmetal_core__DOT___001728_;
        vlSelf->wasmetal_core__DOT___048888_ = vlSelf->wasmetal_core__DOT___001344_;
    }
    vlSelf->__VdfgTmp_hc673eb53__0 = (((IData)(vlSelf->wasmetal_core__DOT___048641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048630_));
    vlSelf->__VdfgTmp_h7cd11e4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___051111_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051286_));
    vlSelf->wasmetal_core__DOT___002730_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001314_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001315_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001312_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001313_)))))))));
    vlSelf->__VdfgTmp_hc6bfb5bb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002465_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001780_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))))))));
    vlSelf->__VdfgTmp_h5e317429__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___002110_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___002465_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001783_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001302_))))))))));
    vlSelf->__VdfgTmp_h2ac6c9b8__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___001780_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___001290_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))))))));
    vlSelf->wasmetal_core__DOT___001849_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001781_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001301_))))));
    vlSelf->__VdfgTmp_h4212348e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd03398e3__0));
    vlSelf->wasmetal_core__DOT___054919_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h91f4b3ba__0)))));
    vlSelf->wasmetal_core__DOT___056195_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x11110000fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))))));
    vlSelf->__VdfgTmp_he9e11b30__0 = (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010358_));
    vlSelf->wasmetal_core__DOT___054929_ = (1U & (IData)(
                                                         (0xfff0fff0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054928_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1111fff0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h8a3dc284__0))))))))))));
    vlSelf->__VdfgTmp_hb2b84c00__0 = (((IData)(vlSelf->wasmetal_core__DOT___048642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048641_));
    vlSelf->wasmetal_core__DOT___051112_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051111_))));
    vlSelf->wasmetal_core__DOT___060481_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060480_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019197_)))))))));
    vlSelf->wasmetal_core__DOT___058692_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048727_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x80000000U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)))))))))));
    vlSelf->__VdfgTmp_h9be80f53__0 = (((IData)(vlSelf->wasmetal_core__DOT___002770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002769_));
    vlSelf->wasmetal_core__DOT___058932_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051501_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048703_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006115_)))))));
    vlSelf->wasmetal_core__DOT___022492_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h21922827__0))));
    vlSelf->__VdfgTmp_hcfd16dec__0 = (((IData)(vlSelf->wasmetal_core__DOT___047927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048642_));
    vlSelf->__VdfgTmp_h4cf0cb93__0 = (((IData)(vlSelf->wasmetal_core__DOT___050690_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051054_));
    vlSelf->wasmetal_core__DOT___022491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he55adf41__0))));
    vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005903_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_ha0b2e14a__0 = (((IData)(vlSelf->wasmetal_core__DOT___047928_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047927_));
    vlSelf->wasmetal_core__DOT___050691_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049883_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050690_))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013778_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h77ed0e73__0 = (((IData)(vlSelf->wasmetal_core__DOT___047945_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047928_));
    vlSelf->wasmetal_core__DOT___049884_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049794_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049883_))));
    vlSelf->wasmetal_core__DOT___061474_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061471_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007341_)))))))));
    vlSelf->wasmetal_core__DOT___054723_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1b99479d__0)))));
    vlSelf->wasmetal_core__DOT___061620_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc135002__0))));
    vlSelf->wasmetal_core__DOT___054748_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054735_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52d73039__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___010229_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054738_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__ 
        = (1U & (IData)((0xccccaaaa000f000fULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha85bab6c__0))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xf0f555500ff3333ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d6eeee4__0))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0f555500ff3333ULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0))))))))))));
    vlSelf->__VdfgTmp_hdc4dab2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010780_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xf00001111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h86442115__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009818_))));
    vlSelf->wasmetal_core__DOT___010298_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                   ? 
                                                  (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007431_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009818_)))))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf00eeU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007663_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007662_)))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeee0000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007660_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h86442115__0)))))))))))));
    vlSelf->__VdfgTmp_h3d1308f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___047946_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047945_));
    vlSelf->wasmetal_core__DOT___049795_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049794_))));
    vlSelf->wasmetal_core__DOT___063909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063901_))));
    vlSelf->__VdfgTmp_hf5f2577b__0 = ((4U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)))));
    vlSelf->__VdfgTmp_h12bbe12d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xaaaaf0f0ff00ccccULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055862_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___055859_))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (0x3500U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055861_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___055860_)))))))));
    vlSelf->wasmetal_core__DOT___055864_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055857_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008093_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055855_)))))))));
    vlSelf->__VdfgTmp_h7ffc48a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h42c557be__0)));
    vlSelf->wasmetal_core__DOT___047871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047870_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049697_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047870_))));
    vlSelf->__VdfgTmp_hc3924088__0 = (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014037_));
    vlSelf->wasmetal_core__DOT___055990_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055989_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5300U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055832_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055829_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaacc0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___019266_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0cc55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055644_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055647_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b713560__0))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055829_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f05533U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055828_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055645_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055832_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008085_)))))))))))))))));
    vlSelf->__VdfgTmp_hc2d8d129__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h95b8e055__0)));
    vlSelf->__VdfgTmp_he957a5af__0 = (((IData)(vlSelf->wasmetal_core__DOT___047851_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047872_));
    vlSelf->__VdfgTmp_hfbafed17__0 = (((IData)(vlSelf->wasmetal_core__DOT___049497_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049613_));
    vlSelf->__VdfgTmp_h6d3ebca4__0 = (((IData)(vlSelf->wasmetal_core__DOT___047852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047851_));
    vlSelf->wasmetal_core__DOT___049498_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049497_))));
    vlSelf->wasmetal_core__DOT___048930_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d))))));
    vlSelf->__VdfgTmp_he278c168__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0));
    vlSelf->__VdfgTmp_he2ba16db__0 = (((IData)(vlSelf->wasmetal_core__DOT___002852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002851_));
    vlSelf->__VdfgTmp_hfac3f09e__0 = (((IData)(vlSelf->wasmetal_core__DOT___047909_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047852_));
    vlSelf->wasmetal_core__DOT___049116_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049115_))));
    vlSelf->wasmetal_core__DOT___055958_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0f555500ff3333ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055423_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055425_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))));
    vlSelf->wasmetal_core__DOT___055777_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055764_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055418_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055423_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008048_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055761_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055422_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055425_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055424_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055427_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x330fff55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055426_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h949b8002__0))))))))))))));
    vlSelf->__VdfgTmp_hc36aba22__0 = (((IData)(vlSelf->wasmetal_core__DOT___047910_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047909_));
    vlSelf->wasmetal_core__DOT___048581_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048577_))));
    vlSelf->__VdfgTmp_h868ae0cf__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4a43881d__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4a43881d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h74f7a068__0))))))))));
    vlSelf->__VdfgTmp_hd6896023__0 = (((IData)(vlSelf->wasmetal_core__DOT___047891_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047910_));
    vlSelf->wasmetal_core__DOT___049117_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048578_))));
    vlSelf->wasmetal_core__DOT___019211_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00bbbbf0f0ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f05533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055732_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055726_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055725_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf5f3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008032_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055723_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5533f0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055727_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f7f3a50__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0bbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3d8d5ec6__0))))))))))));
    vlSelf->wasmetal_core__DOT___061476_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061468_))));
    vlSelf->__VdfgTmp_h87becbe1__0 = (((IData)(vlSelf->wasmetal_core__DOT___047892_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047891_));
    vlSelf->wasmetal_core__DOT___048582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048580_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048579_))));
    vlSelf->wasmetal_core__DOT___063923_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063915_))));
    vlSelf->__VdfgTmp_ha333b59f__0 = (((IData)(vlSelf->wasmetal_core__DOT___047831_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047892_));
    vlSelf->__VdfgTmp_hf502c6b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___048583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048580_));
    vlSelf->__VdfgTmp_ha952ad99__0 = (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002068_));
    vlSelf->wasmetal_core__DOT___063967_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063964_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042167_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___042176_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042172_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___042171_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___042170_))))))))))));
    vlSelf->wasmetal_core__DOT___054986_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054980_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))));
    vlSelf->__VdfgTmp_h96c76ab3__0 = (((IData)(vlSelf->wasmetal_core__DOT___047832_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047831_));
    vlSelf->wasmetal_core__DOT___048587_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048583_))));
    vlSelf->__VdfgTmp_he9d730e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___002601_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0));
    vlSelf->__VdfgTmp_h2956b7c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___047813_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047832_));
    vlSelf->wasmetal_core__DOT___049119_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048585_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048584_))));
    vlSelf->__VdfgTmp_h211aef5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___047814_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047813_));
    vlSelf->wasmetal_core__DOT___048588_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048585_))));
    vlSelf->__VdfgTmp_h07a6aef0__0 = (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002271_));
    vlSelf->__VdfgTmp_h343b1824__0 = (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000167_));
    vlSelf->wasmetal_core__DOT___002931_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->wasmetal_core__DOT___002688_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4408f503__0)))))));
    vlSelf->__VdfgTmp_ha4843895__0 = (((IData)(vlSelf->wasmetal_core__DOT___047814_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048689_));
    vlSelf->wasmetal_core__DOT___049142_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049141_))));
    vlSelf->__VdfgTmp_h09589e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___049365_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048689_));
    vlSelf->wasmetal_core__DOT___049503_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049139_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049141_))));
    vlSelf->wasmetal_core__DOT___054766_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054760_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054759_)))))))));
    vlSelf->__VdfgTmp_h2b3afffd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049365_));
    vlSelf->__VdfgTmp_h0a02dc0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049140_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049139_));
    vlSelf->wasmetal_core__DOT___006972_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048702_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048701_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___005903_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x8000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006226_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))))))))));
    vlSelf->__VdfgTmp_hc4ac601e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049366_));
    vlSelf->wasmetal_core__DOT___049501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049140_))));
    vlSelf->wasmetal_core__DOT___063924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063921_))));
    vlSelf->wasmetal_core__DOT___063820_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))))))))));
    vlSelf->__VdfgTmp_h00f9b844__0 = (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2e505808__0))));
    vlSelf->wasmetal_core__DOT___042295_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042317_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h607fca11__0))));
    vlSelf->wasmetal_core__DOT___042083_ = (1U & (0xfeU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he88617ec__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___042116_ = (1U & (0xfeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff973d2d__0))));
    vlSelf->wasmetal_core__DOT___049021_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049020_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049020_))));
    vlSelf->wasmetal_core__DOT___049359_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049125_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049122_))));
    vlSelf->__VdfgTmp_h1e7febb9__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___000718_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hec35f81b__0))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___002144_))));
    vlSelf->wasmetal_core__DOT___053590_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0))))));
    vlSelf->wasmetal_core__DOT___052709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->__VdfgTmp_hca0be130__0 = (((IData)(vlSelf->wasmetal_core__DOT___070452_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052700_));
    vlSelf->wasmetal_core__DOT___052687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->__VdfgTmp_h568bee24__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___052578_));
    vlSelf->wasmetal_core__DOT___049022_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049017_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049017_))));
    vlSelf->wasmetal_core__DOT___049360_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049080_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049081_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049080_))));
    vlSelf->wasmetal_core__DOT___001336_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0))))))));
    vlSelf->__VdfgTmp_hdf798121__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hca6242ab__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___001846_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf20b3c9b__0)))))));
    vlSelf->wasmetal_core__DOT___000164_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff0fff0033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000574_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h436041ff__0))))))));
    vlSelf->__VdfgTmp_hea3488cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0fd3d582__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002385_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h436041ff__0)))))));
    vlSelf->wasmetal_core__DOT___055967_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055966_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055780_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055779_)))))))));
    vlSelf->wasmetal_core__DOT___001963_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001661_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0))))))));
    vlSelf->__VdfgTmp_hae207145__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b3c1bbf__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___002181_)
                                                     : 
                                                    (0x35U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8bf08b0f__0)))))));
    vlSelf->wasmetal_core__DOT___049039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049035_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049035_))));
    vlSelf->wasmetal_core__DOT___049351_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049076_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049078_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049076_))));
    vlSelf->wasmetal_core__DOT___001934_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001735_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000573_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8c923865__0))))))));
    vlSelf->wasmetal_core__DOT___055950_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055949_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055751_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055750_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055749_)))))))));
    vlSelf->wasmetal_core__DOT___049040_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049038_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049275_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049038_))));
    vlSelf->wasmetal_core__DOT___049352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049070_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049071_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049070_))));
    vlSelf->wasmetal_core__DOT___062502_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___070004_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0))));
    vlSelf->wasmetal_core__DOT___069508_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc0be46f7__0)))));
    vlSelf->wasmetal_core__DOT___069532_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd746550__0)))));
    vlSelf->wasmetal_core__DOT___069601_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e014765__0)))));
    vlSelf->wasmetal_core__DOT___070025_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5702c3be__0)))));
    vlSelf->wasmetal_core__DOT___069309_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069304_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b4e7e80__0))))))));
    vlSelf->wasmetal_core__DOT___069360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069355_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb8b9d9d__0))))))));
    vlSelf->wasmetal_core__DOT___069385_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069380_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9699bb18__0))))))));
    vlSelf->wasmetal_core__DOT___070063_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h103d8e23__0))))))));
    vlSelf->wasmetal_core__DOT___070080_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbbacc71f__0))))))));
    vlSelf->wasmetal_core__DOT___070107_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h880089dc__0))))))));
    vlSelf->wasmetal_core__DOT___070197_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc85d0f69__0))))))));
    vlSelf->wasmetal_core__DOT___070212_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9d0797f2__0))))))));
    vlSelf->wasmetal_core__DOT___070227_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he9b54a3e__0))))))));
    vlSelf->wasmetal_core__DOT___070308_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x13U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h063ae0f2__0))))))));
    vlSelf->wasmetal_core__DOT___070360_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x17U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h24206284__0))))))));
    vlSelf->wasmetal_core__DOT___069645_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f949c7c__0)))));
    vlSelf->wasmetal_core__DOT___069712_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2e498b5e__0)))));
    vlSelf->wasmetal_core__DOT___069734_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc135e20a__0)))));
    vlSelf->wasmetal_core__DOT___069756_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74dbdf51__0)))));
    vlSelf->wasmetal_core__DOT___069777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha6dc66a3__0)))));
    vlSelf->wasmetal_core__DOT___069799_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0f5e432a__0)))));
    vlSelf->wasmetal_core__DOT___069821_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h26cb2e9d__0)))));
    vlSelf->wasmetal_core__DOT___069966_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77d6a635__0)))));
    vlSelf->wasmetal_core__DOT___069986_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66a2df13__0)))));
    vlSelf->wasmetal_core__DOT___070052_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070046_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053335_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b98__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & vlSelf->cmd_data[3U]) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070044_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_imm[3U]) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h79a44c81__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___070262_ = (1U & (0x700U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070256_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070255_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b112__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[3U] 
                                                                              >> 0xeU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h26689d2d__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h154ca593__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051016_))))));
    vlSelf->wasmetal_core__DOT___069407_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d34c5b9__0)))));
    vlSelf->wasmetal_core__DOT___069552_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1b5c1c30__0)))));
    vlSelf->wasmetal_core__DOT___070092_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b621180__0))))))));
    vlSelf->wasmetal_core__DOT___070152_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0))))))));
    vlSelf->wasmetal_core__DOT___070165_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h45475158__0))))))));
    vlSelf->wasmetal_core__DOT___070179_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1dfe6e3d__0))))))));
    vlSelf->wasmetal_core__DOT___070240_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4b62075b__0))))))));
    vlSelf->wasmetal_core__DOT___070269_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcbd0c1b7__0))))))));
    vlSelf->wasmetal_core__DOT___070281_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x11U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0fc0fcd7__0))))))));
    vlSelf->wasmetal_core__DOT___070293_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x12U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbe45befc__0))))))));
    vlSelf->wasmetal_core__DOT___070319_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x14U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha36008d9__0))))))));
    vlSelf->wasmetal_core__DOT___070331_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x15U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab2bfea3__0))))))));
    vlSelf->wasmetal_core__DOT___070343_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x16U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb797e152__0))))))));
    vlSelf->wasmetal_core__DOT___070371_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x18U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb476a254__0))))))));
    vlSelf->wasmetal_core__DOT___070383_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x19U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c9d0618__0))))))));
    vlSelf->wasmetal_core__DOT___070395_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1aU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h928bb96c__0))))))));
    vlSelf->wasmetal_core__DOT___070408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1bU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf0d36e17__0))))))));
    vlSelf->wasmetal_core__DOT___070420_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1cU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h778ea1a1__0))))))));
    vlSelf->wasmetal_core__DOT___070433_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1dU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha95ffc90__0))))))));
    vlSelf->wasmetal_core__DOT___070445_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xb0bbb0bbb0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 0x1eU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbd4ae96e__0))))))));
    vlSelf->wasmetal_core__DOT___065937_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h71467b4f__0)))));
    vlSelf->wasmetal_core__DOT___066082_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h20a47ce2__0)))));
    vlSelf->wasmetal_core__DOT___067313_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb30bed30__0))));
    vlSelf->wasmetal_core__DOT___065603_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c8de641__0))));
    vlSelf->wasmetal_core__DOT___065801_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11929a69__0))));
    vlSelf->wasmetal_core__DOT___066400_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h57521c49__0)))));
    vlSelf->wasmetal_core__DOT___066526_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68543eec__0)))));
    vlSelf->wasmetal_core__DOT___066648_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a3667e8__0)))));
    vlSelf->wasmetal_core__DOT___066770_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d92aff2__0)))));
    vlSelf->wasmetal_core__DOT___066894_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heec1cc96__0)))));
    vlSelf->wasmetal_core__DOT___065412_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h01ed509a__0))));
    vlSelf->wasmetal_core__DOT___065699_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25819d29__0))));
    vlSelf->wasmetal_core__DOT___065188_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc6273ca__0)))));
    vlSelf->wasmetal_core__DOT___066277_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed5e83f9__0))));
    vlSelf->wasmetal_core__DOT___065897_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h51a5c0e8__0))));
    vlSelf->wasmetal_core__DOT___066314_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b995397__0)))));
    vlSelf->wasmetal_core__DOT___066603_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2653381__0)))));
    vlSelf->wasmetal_core__DOT___067455_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c9b01b4__0))));
    vlSelf->wasmetal_core__DOT___066853_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h898dd08d__0)))));
    vlSelf->wasmetal_core__DOT___067343_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc454ae75__0))));
    vlSelf->wasmetal_core__DOT___066124_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11733417__0)))));
    vlSelf->wasmetal_core__DOT___064898_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf58c538__0))));
    vlSelf->wasmetal_core__DOT___065062_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04643804__0))));
    vlSelf->wasmetal_core__DOT___065302_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ad4d6dd__0))));
    vlSelf->wasmetal_core__DOT___067076_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27758395__0)))));
    vlSelf->wasmetal_core__DOT___067154_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c2ac443__0)))));
    vlSelf->wasmetal_core__DOT___067195_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc7b7ff9d__0)))));
    vlSelf->wasmetal_core__DOT___066971_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09cdcbfb__0)))));
    vlSelf->__VdfgTmp_h9c6bfb0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052880_));
    vlSelf->wasmetal_core__DOT___064731_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff7a62d4__0)))));
    vlSelf->wasmetal_core__DOT___053568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___052804_ = (1U & (0xeU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___034488_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052801_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034477_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034492_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034499_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034478_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034476_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha80d5d1f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034507_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034496_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034501_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034490_))))))))))))))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052802_))));
    vlSelf->wasmetal_core__DOT___050435_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050434_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050433_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x100000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___050415_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050414_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050413_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050421_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050420_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050419_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001124_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050430_)))))));
    vlSelf->wasmetal_core__DOT___049840_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049274_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049276_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049274_))));
    vlSelf->wasmetal_core__DOT___049608_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049069_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049072_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049069_))));
    vlSelf->wasmetal_core__DOT___062164_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___055059_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055058_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061706_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061700_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055934_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055682_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->wasmetal_core__DOT___055684_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055670_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055669_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf5f3U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008007_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055667_)))))))));
    vlSelf->__VdfgTmp_ha587a88f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                       << 2U) | ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055028_))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___055027_))))));
    vlSelf->wasmetal_core__DOT___022853_ = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127477___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006099_) 
             << 3U) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006022_)) 
                              << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006106_)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___005868_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___061705_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061696_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055927_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055642_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055656_)))))))));
    vlSelf->wasmetal_core__DOT___055660_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055655_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055653_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055643_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055642_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055656_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007999_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055014_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061707_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061704_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055916_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055601_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055602_)))))))));
    vlSelf->wasmetal_core__DOT___055606_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055597_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055600_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055602_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055601_)))))))))))));
    vlSelf->__VdfgTmp_h8cc03967__0 = (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054937_));
    vlSelf->wasmetal_core__DOT___062058_ = (1U & (IData)(
                                                         (0xfff05550fff0333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048385_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061708_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2014cd64__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055909_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055525_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055526_)))))))));
    vlSelf->wasmetal_core__DOT___055558_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055523_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055524_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007983_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055526_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055525_)))))))))))));
    vlSelf->wasmetal_core__DOT___049849_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049093_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049098_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049093_))));
    vlSelf->wasmetal_core__DOT___049835_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049261_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049263_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049261_))));
    vlSelf->wasmetal_core__DOT___061688_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061682_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055902_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055506_)))))))));
    vlSelf->wasmetal_core__DOT___055510_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055503_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055501_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055504_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007970_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055505_)))))))))))));
    vlSelf->wasmetal_core__DOT___054890_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061687_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8be24d75__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055890_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055420_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055434_)))))))));
    vlSelf->wasmetal_core__DOT___054844_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061674_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061673_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84babf9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf785b2f__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2d6a2af__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055877_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055381_)))))))));
    vlSelf->wasmetal_core__DOT___055411_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055379_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007954_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055381_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055380_)))))))))))));
    vlSelf->wasmetal_core__DOT___048976_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004253_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1fced7c0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002244_)))))))));
    vlSelf->wasmetal_core__DOT___066899_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066611_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066898_)))));
    vlSelf->wasmetal_core__DOT___061642_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaaccccff00f0f0ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061606_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061612_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ef442fa__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061637_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055872_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055323_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055343_)))))))));
    vlSelf->wasmetal_core__DOT___055364_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055324_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055323_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055343_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007946_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___048965_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003957_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2852ec0c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002041_)))))))));
    vlSelf->wasmetal_core__DOT___066862_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066530_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066861_)))));
    vlSelf->wasmetal_core__DOT___002476_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048735_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2135b46c__0))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___002143_)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h162766a7__0))))))));
    vlSelf->wasmetal_core__DOT___055192_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055027_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055028_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055021_)))))))));
    vlSelf->wasmetal_core__DOT___055032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff33ff550f0f0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055017_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h57d78adc__0)))))))))));
    vlSelf->wasmetal_core__DOT___048968_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003659_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_had67ef57__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002477_)))))))));
    vlSelf->wasmetal_core__DOT___066775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066774_)))));
    vlSelf->wasmetal_core__DOT___055183_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054977_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054978_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054980_)))))))));
    vlSelf->wasmetal_core__DOT___048994_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004623_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hcbae1cfc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002153_)))))))));
    vlSelf->wasmetal_core__DOT___066653_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066324_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066652_)))));
    vlSelf->wasmetal_core__DOT___055175_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054938_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054937_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054934_)))))))));
    vlSelf->wasmetal_core__DOT___054939_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___054934_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054686_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h57efbd27__0))))))));
    vlSelf->wasmetal_core__DOT___048991_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004179_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1f7a3fb7__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002116_)))))))));
    vlSelf->wasmetal_core__DOT___066612_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066611_)))));
    vlSelf->wasmetal_core__DOT___055153_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054914_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054917_)))))))));
    vlSelf->wasmetal_core__DOT___048986_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004105_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h1f83dfd6__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002079_)))))))));
    vlSelf->wasmetal_core__DOT___066531_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066530_)))));
    vlSelf->wasmetal_core__DOT___055144_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054878_)))))))));
    vlSelf->wasmetal_core__DOT___048983_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003511_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h07f42939__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002356_)))))))));
    vlSelf->wasmetal_core__DOT___063000_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))));
    vlSelf->wasmetal_core__DOT___053514_ = (1U & (IData)(
                                                         (0x700ffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053512_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7e6b8024__0))))))));
    vlSelf->wasmetal_core__DOT___063363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052836_))));
    vlSelf->wasmetal_core__DOT___062979_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052677_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))))));
    vlSelf->wasmetal_core__DOT___052706_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052678_))));
    vlSelf->__VdfgTmp_h461b3fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___052678_)))));
    vlSelf->wasmetal_core__DOT___066405_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066404_)))));
    vlSelf->wasmetal_core__DOT___055130_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054828_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054833_)))))))));
    vlSelf->wasmetal_core__DOT___049193_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003437_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5d126061__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002434_)))))))));
    vlSelf->wasmetal_core__DOT___066325_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066324_)))));
    vlSelf->wasmetal_core__DOT___066133_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065810_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066132_)))));
    vlSelf->wasmetal_core__DOT___049196_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003585_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h74bfec90__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002396_)))))))));
    vlSelf->wasmetal_core__DOT___066268_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065906_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066267_)))));
    vlSelf->wasmetal_core__DOT___049183_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003733_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbe250e1d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002519_)))))))));
    vlSelf->wasmetal_core__DOT___049186_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004549_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb5c2181f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002199_)))))))));
    vlSelf->wasmetal_core__DOT___066076_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065708_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066075_)))));
    vlSelf->wasmetal_core__DOT___049178_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004401_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3bba44d5__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001744_)))))))));
    vlSelf->wasmetal_core__DOT___065931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065620_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065930_)))));
    vlSelf->wasmetal_core__DOT___065811_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065308_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065810_)))));
    vlSelf->wasmetal_core__DOT___056905_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___056779_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056777_)))))));
    vlSelf->wasmetal_core__DOT___056463_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33bf650d__0))))))));
    vlSelf->wasmetal_core__DOT___012477_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057205_)))))));
    vlSelf->wasmetal_core__DOT___056916_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))))));
    vlSelf->wasmetal_core__DOT___011957_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056769_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056768_)))))));
    vlSelf->wasmetal_core__DOT___011353_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056598_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056597_)))))));
    vlSelf->wasmetal_core__DOT___011100_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056501_)))))));
    vlSelf->wasmetal_core__DOT___057388_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057384_)))))));
    vlSelf->wasmetal_core__DOT___057322_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012580_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012581_))))));
    vlSelf->wasmetal_core__DOT___057173_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012411_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012412_))))));
    vlSelf->wasmetal_core__DOT___056987_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056983_)))))));
    vlSelf->wasmetal_core__DOT___056481_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3fcac4a1__0))))))));
    vlSelf->wasmetal_core__DOT___056749_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056745_)))))));
    vlSelf->wasmetal_core__DOT___057445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012964_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012965_))))));
    vlSelf->wasmetal_core__DOT___057658_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___057635_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057574_)))))));
    vlSelf->__VdfgTmp_hedbbe05b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011103_));
    vlSelf->__VdfgTmp_hdfb2d71e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011101_)))));
    vlSelf->wasmetal_core__DOT___011026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010084_))));
    vlSelf->wasmetal_core__DOT___049175_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004327_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4ff79496__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001679_)))))))));
    vlSelf->wasmetal_core__DOT___005663_ = (1U & ((0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___003130_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003129_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003128_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h28ae1e0e__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h76ba8332__0))))))))))));
    vlSelf->wasmetal_core__DOT___065907_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065906_)))));
    vlSelf->wasmetal_core__DOT___049166_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004475_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h627c070d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001254_)))))))));
    vlSelf->__VdfgTmp_h56f16561__0 = (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052834_));
    vlSelf->wasmetal_core__DOT___028115_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1cU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h946ed16f__0)))));
    vlSelf->wasmetal_core__DOT___028114_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1bU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1dU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000657_))))));
    vlSelf->wasmetal_core__DOT___028112_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1aU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1cU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_))))));
    vlSelf->wasmetal_core__DOT___028111_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x19U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1bU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000613_))))));
    vlSelf->wasmetal_core__DOT___028110_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x18U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1aU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000591_))))));
    vlSelf->wasmetal_core__DOT___028109_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x17U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h17df9f02__0)))));
    vlSelf->wasmetal_core__DOT___028108_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x16U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x18U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000542_))))));
    vlSelf->wasmetal_core__DOT___028107_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x15U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x17U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000520_))))));
    vlSelf->wasmetal_core__DOT___028106_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x14U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5d86514__0)))));
    vlSelf->wasmetal_core__DOT___028105_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x13U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000476_))))));
    vlSelf->wasmetal_core__DOT___028104_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x12U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000464_))))));
    vlSelf->wasmetal_core__DOT___028103_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x11U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd7080d55__0)))));
    vlSelf->wasmetal_core__DOT___028101_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x10U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfe93be6e__0)))));
    vlSelf->wasmetal_core__DOT___028100_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x11U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001646_))))));
    vlSelf->wasmetal_core__DOT___028099_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xeU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x10U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001624_))))));
    vlSelf->wasmetal_core__DOT___028098_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xfU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001612_))))));
    vlSelf->wasmetal_core__DOT___028097_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xcU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001580_))))));
    vlSelf->wasmetal_core__DOT___028096_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8243d19d__0)))));
    vlSelf->wasmetal_core__DOT___028095_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xcU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001536_))))));
    vlSelf->wasmetal_core__DOT___028094_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 9U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xbU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001524_))))));
    vlSelf->wasmetal_core__DOT___028093_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 8U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8f67c93__0)))));
    vlSelf->wasmetal_core__DOT___028092_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 7U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haf096c00__0)))));
    vlSelf->wasmetal_core__DOT___028122_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 6U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 8U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001381_))))));
    vlSelf->wasmetal_core__DOT___028121_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 7U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001369_))))));
    vlSelf->wasmetal_core__DOT___028120_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 6U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001487_))))));
    vlSelf->wasmetal_core__DOT___028119_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001475_))))));
    vlSelf->wasmetal_core__DOT___028118_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfcd21fa2__0)))));
    vlSelf->wasmetal_core__DOT___028117_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 3U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001437_))))));
    vlSelf->wasmetal_core__DOT___028116_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_x) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4104a354__0)))));
    vlSelf->wasmetal_core__DOT___028113_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001874_))))));
    vlSelf->wasmetal_core__DOT___028102_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & vlSelf->insn_y) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___028091_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h521b28ea__0)))));
    vlSelf->wasmetal_core__DOT___049572_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049164_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049164_))));
    vlSelf->wasmetal_core__DOT___050510_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049316_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049317_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049316_))));
    vlSelf->__VdfgTmp_h15546f37__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa759b39__0));
    vlSelf->wasmetal_core__DOT___061907_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061905_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ac55b8c__0))))))))))))));
    vlSelf->__VdfgTmp_h14ad002b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0));
    vlSelf->wasmetal_core__DOT___033390_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfd1fc688__0))))));
    vlSelf->wasmetal_core__DOT___050475_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049156_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049160_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049156_))));
}
