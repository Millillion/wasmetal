#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__17(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__17\n"); );
    // Body
    vlSelf->__VdfgTmp_h9e0385bc__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003071_));
    vlSelf->__VdfgTmp_hb342b047__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003072_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003071_)))));
    vlSelf->wasmetal_core__DOT___005205_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002917_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d))))));
    vlSelf->wasmetal_core__DOT___002920_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002917_))))));
    vlSelf->wasmetal_core__DOT___005589_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003076_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d))))));
    vlSelf->wasmetal_core__DOT___003079_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003076_))))));
    vlSelf->__VdfgTmp_h36fcb829__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___002916_)));
    vlSelf->wasmetal_core__DOT___002921_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___002916_)))));
    vlSelf->__VdfgTmp_hfb9f47b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003075_)));
    vlSelf->wasmetal_core__DOT___003080_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003075_)))));
    vlSelf->wasmetal_core__DOT___069158_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1dU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068752_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x14U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___065602_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066399_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067153_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___069232_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1eU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069139_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1cU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069090_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069040_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1aU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068968_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x19U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068942_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x18U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068898_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x17U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068851_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x16U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068796_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x15U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068703_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x13U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068655_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x12U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068605_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x11U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___064897_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___064730_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071263_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054103_))))));
    vlSelf->wasmetal_core__DOT___065411_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071272_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054127_))))));
    vlSelf->wasmetal_core__DOT___065301_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065187_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065058_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071267_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054115_))))));
    vlSelf->wasmetal_core__DOT___065896_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071277_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054158_))))));
    vlSelf->wasmetal_core__DOT___065800_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065698_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128052___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066123_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071282_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054170_))))));
    vlSelf->wasmetal_core__DOT___066081_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065936_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128053___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071292_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054191_))))));
    vlSelf->wasmetal_core__DOT___066602_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066525_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071287_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054182_))))));
    vlSelf->wasmetal_core__DOT___066313_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128054___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066893_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071297_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054197_))))));
    vlSelf->wasmetal_core__DOT___066852_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066769_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066647_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067194_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071302_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054203_))))));
    vlSelf->wasmetal_core__DOT___067075_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066970_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d))));
    vlSelf->wasmetal_core__DOT___071312_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054215_))))));
    vlSelf->wasmetal_core__DOT___067454_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067342_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___071307_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054209_))))));
    vlSelf->wasmetal_core__DOT___067312_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067724_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___071317_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054221_))))));
    vlSelf->wasmetal_core__DOT___067657_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->insn_imm[1U]) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___067606_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___071322_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054227_))))));
    vlSelf->wasmetal_core__DOT___071332_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054239_))))));
    vlSelf->wasmetal_core__DOT___071327_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054233_))))));
    vlSelf->wasmetal_core__DOT___071337_ = (1U & (0xa3ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054245_))))));
    vlSelf->wasmetal_core__DOT___052159_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001161_)))));
    vlSelf->__VdfgTmp_hac8a82be__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001161_)));
    vlSelf->wasmetal_core__DOT___052146_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001139_)))));
    vlSelf->__VdfgTmp_h87463cf8__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001139_)));
    vlSelf->wasmetal_core__DOT___052186_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001117_)))));
    vlSelf->__VdfgTmp_h7685727c__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001117_)));
    vlSelf->wasmetal_core__DOT___052481_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001095_)))));
    vlSelf->__VdfgTmp_hca84dae7__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001095_)));
    vlSelf->wasmetal_core__DOT___052486_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001073_)))));
    vlSelf->__VdfgTmp_hb0b41010__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001073_)));
    vlSelf->wasmetal_core__DOT___052173_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001051_)))));
    vlSelf->__VdfgTmp_h1871ad84__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001051_)));
    vlSelf->wasmetal_core__DOT___052164_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001029_)))));
    vlSelf->__VdfgTmp_hccb9e3d4__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001029_)));
    vlSelf->wasmetal_core__DOT___052427_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001007_)))));
    vlSelf->__VdfgTmp_hd6ccf561__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001007_)));
    vlSelf->wasmetal_core__DOT___052422_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000963_)))));
    vlSelf->__VdfgTmp_ha8f762bd__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000963_)));
    vlSelf->wasmetal_core__DOT___001158_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001155_))))));
    vlSelf->wasmetal_core__DOT___001136_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001133_))))));
    vlSelf->wasmetal_core__DOT___001114_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001111_))))));
    vlSelf->wasmetal_core__DOT___001092_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001089_))))));
    vlSelf->wasmetal_core__DOT___001070_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001067_))))));
    vlSelf->wasmetal_core__DOT___001048_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001045_))))));
    vlSelf->wasmetal_core__DOT___001026_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001023_))))));
    vlSelf->wasmetal_core__DOT___001004_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001001_))))));
    vlSelf->wasmetal_core__DOT___000960_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000957_))))));
    vlSelf->__VdfgTmp_h2ee186c3__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001155_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001154_))))));
    vlSelf->wasmetal_core__DOT___001159_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b62__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001154_)))));
    vlSelf->__VdfgTmp_h5085d456__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001133_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001132_))))));
    vlSelf->wasmetal_core__DOT___001137_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001132_)))));
    vlSelf->__VdfgTmp_h5ef7d401__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001111_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001110_))))));
    vlSelf->wasmetal_core__DOT___001115_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001110_)))));
    vlSelf->__VdfgTmp_hdf96a80c__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001089_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001088_))))));
    vlSelf->wasmetal_core__DOT___001093_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001088_)))));
    vlSelf->__VdfgTmp_h26403b1c__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001067_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001066_))))));
    vlSelf->wasmetal_core__DOT___001071_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001066_)))));
    vlSelf->__VdfgTmp_hfbb7166b__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001045_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001044_))))));
    vlSelf->wasmetal_core__DOT___001049_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001044_)))));
    vlSelf->__VdfgTmp_hec62ba82__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001023_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001022_))))));
    vlSelf->wasmetal_core__DOT___001027_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001022_)))));
    vlSelf->__VdfgTmp_hc6c0965f__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001001_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001000_))))));
    vlSelf->wasmetal_core__DOT___001005_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001000_)))));
    vlSelf->__VdfgTmp_h2e9416a5__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000957_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000956_))))));
    vlSelf->wasmetal_core__DOT___000961_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000956_)))));
    vlSelf->wasmetal_core__DOT___052123_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000973_)))));
    vlSelf->__VdfgTmp_h23462764__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000973_)));
    vlSelf->wasmetal_core__DOT___052118_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000941_)))));
    vlSelf->__VdfgTmp_h9d577f3c__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000941_)));
    vlSelf->wasmetal_core__DOT___052443_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000931_)))));
    vlSelf->__VdfgTmp_hc0908881__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000931_)));
    vlSelf->wasmetal_core__DOT___052439_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000901_)))));
    vlSelf->__VdfgTmp_he74cbbd8__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000901_)));
    vlSelf->wasmetal_core__DOT___052435_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000911_)))));
    vlSelf->__VdfgTmp_h3a817888__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000911_)));
    vlSelf->wasmetal_core__DOT___052431_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000877_)))));
    vlSelf->__VdfgTmp_hebb33e32__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000877_)));
    vlSelf->wasmetal_core__DOT___052131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000887_)))));
    vlSelf->__VdfgTmp_hffc6befa__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000887_)));
    vlSelf->wasmetal_core__DOT___052127_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000853_)))));
    vlSelf->__VdfgTmp_h70e821ff__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000853_)));
    vlSelf->wasmetal_core__DOT___052196_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000863_)))));
    vlSelf->__VdfgTmp_hb87fbc4d__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000863_)));
    vlSelf->wasmetal_core__DOT___003884_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000930_)))))))));
    vlSelf->__VdfgTmp_h6366d506__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000930_)));
    vlSelf->wasmetal_core__DOT___004100_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000901_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000900_)))))))));
    vlSelf->__VdfgTmp_hbe4c2cfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000900_)));
    vlSelf->wasmetal_core__DOT___004322_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000911_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000910_)))))))));
    vlSelf->__VdfgTmp_h650b1858__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000910_)));
    vlSelf->wasmetal_core__DOT___004026_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000877_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000876_)))))))));
    vlSelf->__VdfgTmp_hf5ca71c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000876_)));
    vlSelf->wasmetal_core__DOT___003728_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000886_)))))))));
    vlSelf->__VdfgTmp_h57e567b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000886_)));
    vlSelf->wasmetal_core__DOT___004692_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000853_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000852_)))))))));
    vlSelf->__VdfgTmp_hc3ffba8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000852_)));
    vlSelf->wasmetal_core__DOT___004248_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000863_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000862_)))))))));
    vlSelf->__VdfgTmp_ha87e62b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000862_)));
    vlSelf->wasmetal_core__DOT___000970_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000967_))))));
    vlSelf->wasmetal_core__DOT___000948_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000945_))))));
    vlSelf->wasmetal_core__DOT___003883_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___000938_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000935_))))));
    vlSelf->wasmetal_core__DOT___004099_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000905_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___000908_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000905_))))));
    vlSelf->wasmetal_core__DOT___004321_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000915_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d))))));
    vlSelf->wasmetal_core__DOT___000918_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000915_))))));
    vlSelf->wasmetal_core__DOT___004025_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000881_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___000884_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000881_))))));
    vlSelf->wasmetal_core__DOT___003727_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000891_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___000894_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000891_))))));
    vlSelf->wasmetal_core__DOT___004691_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000857_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d))))));
    vlSelf->wasmetal_core__DOT___000860_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000857_))))));
    vlSelf->wasmetal_core__DOT___004247_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000867_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___000870_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000867_))))));
    vlSelf->__VdfgTmp_hc0a5660d__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000967_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000966_))))));
    vlSelf->wasmetal_core__DOT___000971_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b53__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000966_)))));
    vlSelf->__VdfgTmp_h651ffab0__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000945_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000944_))))));
    vlSelf->wasmetal_core__DOT___000949_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000944_)))));
    vlSelf->__VdfgTmp_h55f26059__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000934_)));
    vlSelf->wasmetal_core__DOT___000939_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000934_)))));
    vlSelf->__VdfgTmp_h4b0186c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000904_)));
    vlSelf->wasmetal_core__DOT___000909_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000904_)))));
    vlSelf->__VdfgTmp_h5a6445ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000914_)));
    vlSelf->wasmetal_core__DOT___000919_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000914_)))));
    vlSelf->__VdfgTmp_hcba3b702__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000880_)));
    vlSelf->wasmetal_core__DOT___000885_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000880_)))));
    vlSelf->__VdfgTmp_h5e9c07be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000890_)));
    vlSelf->wasmetal_core__DOT___000895_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000890_)))));
    vlSelf->__VdfgTmp_h60070975__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000856_)));
    vlSelf->wasmetal_core__DOT___000861_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000856_)))));
    vlSelf->__VdfgTmp_h74f399ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000866_)));
    vlSelf->wasmetal_core__DOT___000871_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000866_)))));
    vlSelf->wasmetal_core__DOT___052261_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000839_)))));
    vlSelf->__VdfgTmp_hdfd359a7__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000839_)));
    vlSelf->wasmetal_core__DOT___052498_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000829_)))));
    vlSelf->__VdfgTmp_h49f908f3__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000829_)));
    vlSelf->wasmetal_core__DOT___052494_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000800_)))));
    vlSelf->__VdfgTmp_hfd0db41d__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000800_)));
    vlSelf->wasmetal_core__DOT___052135_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000810_)))));
    vlSelf->__VdfgTmp_h90eba162__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000810_)));
    vlSelf->wasmetal_core__DOT___052112_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000776_)))));
    vlSelf->__VdfgTmp_h636dab99__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000776_)));
    vlSelf->wasmetal_core__DOT___052410_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000786_)))));
    vlSelf->__VdfgTmp_h3ff40a3b__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000786_)));
    vlSelf->wasmetal_core__DOT___052406_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000762_)))));
    vlSelf->__VdfgTmp_hea8a286f__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000762_)));
    vlSelf->wasmetal_core__DOT___052501_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000752_)))));
    vlSelf->__VdfgTmp_hfcc5cb61__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000752_)));
    vlSelf->wasmetal_core__DOT___052490_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000738_)))));
    vlSelf->__VdfgTmp_h3d4b630e__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000738_)));
    vlSelf->wasmetal_core__DOT___004174_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000838_)))))))));
    vlSelf->__VdfgTmp_h807ad9d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000838_)));
    vlSelf->wasmetal_core__DOT___003580_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000829_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000828_)))))))));
    vlSelf->__VdfgTmp_h456da093__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000828_)));
    vlSelf->wasmetal_core__DOT___003506_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000800_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000799_)))))))));
    vlSelf->__VdfgTmp_hc5f6f937__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000799_)));
    vlSelf->wasmetal_core__DOT___003654_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000810_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000809_)))))))));
    vlSelf->__VdfgTmp_hd28cbf2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000809_)));
    vlSelf->wasmetal_core__DOT___003802_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000776_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000775_)))))))));
    vlSelf->__VdfgTmp_hb4397905__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000775_)));
    vlSelf->wasmetal_core__DOT___004618_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000786_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000785_)))))))));
    vlSelf->__VdfgTmp_hce8a559f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000785_)));
    vlSelf->wasmetal_core__DOT___004470_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000762_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000761_)))))))));
    vlSelf->__VdfgTmp_hc5320df5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000761_)));
    vlSelf->wasmetal_core__DOT___004396_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000752_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000751_)))))))));
    vlSelf->__VdfgTmp_hd6e95fa8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000751_)));
    vlSelf->wasmetal_core__DOT___004544_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000738_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000737_)))))))));
    vlSelf->__VdfgTmp_h8fdaff69__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000737_)));
    vlSelf->wasmetal_core__DOT___004173_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000843_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d))))));
    vlSelf->wasmetal_core__DOT___000846_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000843_))))));
    vlSelf->wasmetal_core__DOT___003579_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000833_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d))))));
    vlSelf->wasmetal_core__DOT___000836_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000833_))))));
    vlSelf->wasmetal_core__DOT___003505_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000804_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___000807_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000804_))))));
    vlSelf->wasmetal_core__DOT___003653_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000814_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d))))));
    vlSelf->wasmetal_core__DOT___000817_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000814_))))));
    vlSelf->wasmetal_core__DOT___003801_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000780_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d))))));
    vlSelf->wasmetal_core__DOT___000783_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000780_))))));
    vlSelf->wasmetal_core__DOT___004617_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000790_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d))))));
    vlSelf->wasmetal_core__DOT___000793_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000790_))))));
    vlSelf->wasmetal_core__DOT___004469_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000766_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___000769_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000766_))))));
    vlSelf->wasmetal_core__DOT___004395_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000756_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___000759_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000756_))))));
    vlSelf->wasmetal_core__DOT___004543_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000742_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___000745_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000742_))))));
    vlSelf->__VdfgTmp_h9cca9eb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000842_)));
    vlSelf->wasmetal_core__DOT___000847_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b44__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000842_)))));
    vlSelf->__VdfgTmp_h67445948__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000832_)));
    vlSelf->wasmetal_core__DOT___000837_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000832_)))));
    vlSelf->__VdfgTmp_h252badb1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000803_)));
    vlSelf->wasmetal_core__DOT___000808_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000803_)))));
    vlSelf->__VdfgTmp_h34a57f42__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000813_)));
    vlSelf->wasmetal_core__DOT___000818_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000813_)))));
    vlSelf->__VdfgTmp_h4e280dfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000779_)));
    vlSelf->wasmetal_core__DOT___000784_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000779_)))));
    vlSelf->__VdfgTmp_h054c8d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000789_)));
    vlSelf->wasmetal_core__DOT___000794_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000789_)))));
    vlSelf->__VdfgTmp_hc00537e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000765_)));
    vlSelf->wasmetal_core__DOT___000770_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000765_)))));
    vlSelf->__VdfgTmp_h4f517b43__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000755_)));
    vlSelf->wasmetal_core__DOT___000760_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000755_)))));
    vlSelf->__VdfgTmp_haf89032c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000741_)));
    vlSelf->wasmetal_core__DOT___000746_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000741_)))));
    vlSelf->wasmetal_core__DOT___052150_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000728_)))));
    vlSelf->__VdfgTmp_hc72a6a37__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000728_)));
    vlSelf->wasmetal_core__DOT___052181_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000708_)))));
    vlSelf->__VdfgTmp_heda84e5a__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000708_)));
    vlSelf->wasmetal_core__DOT___052154_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000698_)))));
    vlSelf->__VdfgTmp_h550ff904__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000698_)));
    vlSelf->wasmetal_core__DOT___052414_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000674_)))));
    vlSelf->__VdfgTmp_h339ccfdb__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000674_)));
    vlSelf->wasmetal_core__DOT___052230_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000684_)))));
    vlSelf->__VdfgTmp_hfafc2bd6__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000684_)));
    vlSelf->wasmetal_core__DOT___052220_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000650_)))));
    vlSelf->__VdfgTmp_h981495cf__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000650_)));
    vlSelf->wasmetal_core__DOT___052215_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000628_)))));
    vlSelf->__VdfgTmp_h346dffe3__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000628_)));
    vlSelf->wasmetal_core__DOT___052210_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000606_)))));
    vlSelf->__VdfgTmp_h4641aed4__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000606_)));
    vlSelf->wasmetal_core__DOT___052564_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000584_)))));
    vlSelf->__VdfgTmp_hb9d73245__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000584_)));
    vlSelf->wasmetal_core__DOT___004766_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000728_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000727_)))))))));
    vlSelf->__VdfgTmp_hb26c7187__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000727_)));
    vlSelf->wasmetal_core__DOT___004840_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000708_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000707_)))))))));
    vlSelf->__VdfgTmp_hf3a0142d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000707_)));
    vlSelf->__VdfgTmp_h13262e9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000697_)));
    vlSelf->__VdfgTmp_h1512c46f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000673_)));
    vlSelf->__VdfgTmp_h149fa621__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000683_)));
    vlSelf->wasmetal_core__DOT___004765_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000732_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d))))));
    vlSelf->wasmetal_core__DOT___000735_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000732_))))));
    vlSelf->wasmetal_core__DOT___004839_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000712_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___000715_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000712_))))));
    vlSelf->wasmetal_core__DOT___003295_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000702_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___000705_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000702_))))));
    vlSelf->wasmetal_core__DOT___003215_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000678_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___000681_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000678_))))));
    vlSelf->wasmetal_core__DOT___005625_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000688_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d))))));
    vlSelf->wasmetal_core__DOT___000691_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000688_))))));
    vlSelf->wasmetal_core__DOT___000647_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000644_))))));
    vlSelf->wasmetal_core__DOT___000625_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000622_))))));
    vlSelf->wasmetal_core__DOT___000603_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000600_))))));
    vlSelf->wasmetal_core__DOT___000581_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000578_))))));
    vlSelf->__VdfgTmp_h5500fae9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000731_)));
    vlSelf->wasmetal_core__DOT___000736_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000731_)))));
    vlSelf->__VdfgTmp_h3c930b99__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000711_)));
    vlSelf->wasmetal_core__DOT___000716_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000711_)))));
    vlSelf->__VdfgTmp_h95280768__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000701_)));
    vlSelf->wasmetal_core__DOT___000706_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000701_)))));
    vlSelf->__VdfgTmp_hf410ea07__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000677_)));
    vlSelf->wasmetal_core__DOT___000682_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000677_)))));
    vlSelf->__VdfgTmp_h2a120d0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000687_)));
    vlSelf->wasmetal_core__DOT___000692_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000687_)))));
    vlSelf->__VdfgTmp_h38fef573__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000644_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000643_))))));
    vlSelf->wasmetal_core__DOT___000648_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000643_)))));
    vlSelf->__VdfgTmp_hf146791e__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000622_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000621_))))));
    vlSelf->wasmetal_core__DOT___000626_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000621_)))));
    vlSelf->__VdfgTmp_hd0875e26__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000600_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000599_))))));
    vlSelf->wasmetal_core__DOT___000604_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000599_)))));
    vlSelf->__VdfgTmp_h1a1b2f4c__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000578_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000577_))))));
    vlSelf->wasmetal_core__DOT___000582_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000577_)))));
    vlSelf->wasmetal_core__DOT___052512_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000557_)))));
    vlSelf->__VdfgTmp_hd4b6f7f5__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000557_)));
    vlSelf->__VdfgTmp_h6f0fb759__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000535_)));
    vlSelf->__VdfgTmp_h64f45cce__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000513_)));
    vlSelf->wasmetal_core__DOT___052517_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000491_)))));
    vlSelf->__VdfgTmp_h0990f42c__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000491_)));
    vlSelf->wasmetal_core__DOT___052522_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000447_)))));
    vlSelf->__VdfgTmp_h5680e757__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000447_)));
    vlSelf->__VdfgTmp_hc8339843__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000457_)));
    vlSelf->__VdfgTmp_h6fec380d__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000409_)));
    vlSelf->wasmetal_core__DOT___052550_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000399_)))));
    vlSelf->__VdfgTmp_h4633c50c__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000399_)));
    vlSelf->__VdfgTmp_h42c0d879__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001639_)));
    vlSelf->__VdfgTmp_hb1ddac1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000535_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000534_)))));
    vlSelf->__VdfgTmp_hf6a1a834__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000534_)));
    vlSelf->__VdfgTmp_h27610e5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000513_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000512_)))));
    vlSelf->__VdfgTmp_h8a521099__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000512_)));
    vlSelf->__VdfgTmp_hda033d4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000457_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000456_)))));
    vlSelf->__VdfgTmp_h12d7401d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000456_)));
    vlSelf->__VdfgTmp_hfbabec73__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000409_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000408_)))));
    vlSelf->__VdfgTmp_h4f514d50__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000408_)));
    vlSelf->__VdfgTmp_h9975f0a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001639_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001638_)))));
    vlSelf->__VdfgTmp_h252dd1a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001638_)));
    vlSelf->wasmetal_core__DOT___000554_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000551_))))));
    vlSelf->wasmetal_core__DOT___000532_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000529_))))));
    vlSelf->wasmetal_core__DOT___000510_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000507_))))));
    vlSelf->wasmetal_core__DOT___000488_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000485_))))));
    vlSelf->wasmetal_core__DOT___000444_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000441_))))));
    vlSelf->wasmetal_core__DOT___000454_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000451_))))));
    vlSelf->wasmetal_core__DOT___000406_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000403_))))));
    vlSelf->wasmetal_core__DOT___000396_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000393_))))));
    vlSelf->wasmetal_core__DOT___001636_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001633_))))));
    vlSelf->__VdfgTmp_hbb570836__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000551_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000550_))))));
    vlSelf->wasmetal_core__DOT___000555_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b26__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000550_)))));
    vlSelf->__VdfgTmp_hdc070dcf__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000529_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000528_))))));
    vlSelf->wasmetal_core__DOT___000533_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000528_)))));
    vlSelf->__VdfgTmp_h329ed040__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000507_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000506_))))));
    vlSelf->wasmetal_core__DOT___000511_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000506_)))));
    vlSelf->__VdfgTmp_h5d3f3876__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000485_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000484_))))));
    vlSelf->wasmetal_core__DOT___000489_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000484_)))));
    vlSelf->__VdfgTmp_h3c70beb3__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000441_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000440_))))));
    vlSelf->wasmetal_core__DOT___000445_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000440_)))));
    vlSelf->__VdfgTmp_h6effbe38__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000451_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000450_))))));
    vlSelf->wasmetal_core__DOT___000455_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000450_)))));
    vlSelf->__VdfgTmp_h1dec8a5e__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000403_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000402_))))));
    vlSelf->wasmetal_core__DOT___000407_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000402_)))));
    vlSelf->__VdfgTmp_h5d5da343__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000393_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000392_))))));
    vlSelf->wasmetal_core__DOT___000397_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000392_)))));
    vlSelf->__VdfgTmp_h4c7ff695__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001633_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001632_))))));
    vlSelf->wasmetal_core__DOT___001637_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001632_)))));
    vlSelf->__VdfgTmp_h464afc51__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001605_)));
    vlSelf->__VdfgTmp_h0e64e6bd__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001595_)));
    vlSelf->wasmetal_core__DOT___052385_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001561_)))));
    vlSelf->__VdfgTmp_h348ae581__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001561_)));
    vlSelf->wasmetal_core__DOT___052393_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001551_)))));
    vlSelf->__VdfgTmp_h32a20063__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001551_)));
    vlSelf->wasmetal_core__DOT___052251_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001517_)))));
    vlSelf->__VdfgTmp_h92680a0a__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001517_)));
    vlSelf->wasmetal_core__DOT___052201_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001507_)))));
    vlSelf->__VdfgTmp_hc6a0da7a__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001507_)));
    vlSelf->wasmetal_core__DOT___052472_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001406_)))));
    vlSelf->__VdfgTmp_h77c9da1a__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001406_)));
    vlSelf->wasmetal_core__DOT___052467_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001396_)))));
    vlSelf->__VdfgTmp_h63e2f59d__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001396_)));
    vlSelf->wasmetal_core__DOT___052375_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001352_)))));
    vlSelf->__VdfgTmp_h7b4dcb8a__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001352_)));
    vlSelf->__VdfgTmp_h40e72268__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001605_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001604_)))));
    vlSelf->__VdfgTmp_h2dcfbe3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001604_)));
    vlSelf->__VdfgTmp_h7409986d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001595_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001594_)))));
    vlSelf->__VdfgTmp_he176d11c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001594_)));
    vlSelf->wasmetal_core__DOT___001602_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001599_))))));
    vlSelf->wasmetal_core__DOT___001592_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001589_))))));
    vlSelf->wasmetal_core__DOT___001558_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001555_))))));
    vlSelf->wasmetal_core__DOT___001548_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001545_))))));
    vlSelf->wasmetal_core__DOT___001514_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001511_))))));
    vlSelf->wasmetal_core__DOT___001504_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001501_))))));
    vlSelf->wasmetal_core__DOT___001403_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001400_))))));
    vlSelf->wasmetal_core__DOT___001393_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001390_))))));
    vlSelf->wasmetal_core__DOT___001349_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001346_))))));
    vlSelf->__VdfgTmp_h152b96e8__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001599_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001598_))))));
    vlSelf->wasmetal_core__DOT___001603_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b17__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001598_)))));
    vlSelf->__VdfgTmp_hd259e3cd__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001589_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001588_))))));
    vlSelf->wasmetal_core__DOT___001593_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001588_)))));
    vlSelf->__VdfgTmp_h121dc976__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001555_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001554_))))));
    vlSelf->wasmetal_core__DOT___001559_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001554_)))));
    vlSelf->__VdfgTmp_hcb57359d__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001545_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001544_))))));
    vlSelf->wasmetal_core__DOT___001549_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001544_)))));
    vlSelf->__VdfgTmp_habe5487e__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001511_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001510_))))));
    vlSelf->wasmetal_core__DOT___001515_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001510_)))));
    vlSelf->__VdfgTmp_h56e67fc1__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001501_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001500_))))));
    vlSelf->wasmetal_core__DOT___001505_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001500_)))));
    vlSelf->__VdfgTmp_hd416e14c__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001400_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001399_))))));
    vlSelf->wasmetal_core__DOT___001404_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001399_)))));
    vlSelf->__VdfgTmp_h382fd4d9__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001390_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001389_))))));
    vlSelf->wasmetal_core__DOT___001394_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001389_)))));
    vlSelf->__VdfgTmp_h63bcab38__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001346_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001345_))))));
    vlSelf->wasmetal_core__DOT___001350_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001345_)))));
    vlSelf->wasmetal_core__DOT___052380_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001362_)))));
    vlSelf->__VdfgTmp_hbc2ed277__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001362_)));
    vlSelf->wasmetal_core__DOT___052545_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001468_)))));
    vlSelf->__VdfgTmp_haec160c4__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001468_)));
    vlSelf->wasmetal_core__DOT___052533_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001458_)))));
    vlSelf->__VdfgTmp_hc089566f__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001458_)));
    vlSelf->wasmetal_core__DOT___052457_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001193_)))));
    vlSelf->__VdfgTmp_h5875da01__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001193_)));
    vlSelf->wasmetal_core__DOT___052462_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001203_)))));
    vlSelf->__VdfgTmp_h283b87b9__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001203_)));
    vlSelf->wasmetal_core__DOT___052241_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000261_)))));
    vlSelf->__VdfgTmp_h86168fd0__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000261_)));
    vlSelf->wasmetal_core__DOT___052246_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000389_)))));
    vlSelf->__VdfgTmp_h1495cfda__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000389_)));
    vlSelf->wasmetal_core__DOT___052205_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001861_)))));
    vlSelf->__VdfgTmp_hf7db9798__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001861_)));
    vlSelf->wasmetal_core__DOT___052540_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001837_)))));
    vlSelf->__VdfgTmp_hea8c2790__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001837_)));
    vlSelf->__VdfgTmp_h6a684ffb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001860_)));
    vlSelf->__VdfgTmp_h173fc958__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001836_)));
    vlSelf->wasmetal_core__DOT___001359_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001356_))))));
    vlSelf->wasmetal_core__DOT___001465_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001462_))))));
    vlSelf->wasmetal_core__DOT___001455_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001452_))))));
    vlSelf->wasmetal_core__DOT___001190_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001187_))))));
    vlSelf->wasmetal_core__DOT___001200_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001197_))))));
    vlSelf->wasmetal_core__DOT___000192_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000186_))))));
    vlSelf->wasmetal_core__DOT___000386_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000383_))))));
    vlSelf->wasmetal_core__DOT___001868_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001865_))))));
    vlSelf->wasmetal_core__DOT___003277_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001865_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___001844_ = (1U & (0xea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001841_))))));
    vlSelf->wasmetal_core__DOT___003197_ = (1U & (0x5333U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001841_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d))))));
    vlSelf->__VdfgTmp_h3b706e40__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001356_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001355_))))));
    vlSelf->wasmetal_core__DOT___001360_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b8__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001355_)))));
    vlSelf->__VdfgTmp_h86663798__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001462_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001461_))))));
    vlSelf->wasmetal_core__DOT___001466_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001461_)))));
    vlSelf->__VdfgTmp_hc4ffb8dc__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001452_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001451_))))));
    vlSelf->wasmetal_core__DOT___001456_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001451_)))));
    vlSelf->__VdfgTmp_hc8d1ef5e__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001187_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001186_))))));
    vlSelf->wasmetal_core__DOT___001191_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001186_)))));
    vlSelf->__VdfgTmp_h55f072d8__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001197_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001196_))))));
    vlSelf->wasmetal_core__DOT___001201_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001196_)))));
    vlSelf->__VdfgTmp_h60503c86__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000186_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000185_))))));
    vlSelf->wasmetal_core__DOT___000193_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000185_)))));
    vlSelf->__VdfgTmp_hc4c8e202__0 = ((2U & ((0x5333U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___000189_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000188_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000383_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d))))) 
                                             << 1U)) 
                                      | (1U & (0x35U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000382_))))));
    vlSelf->wasmetal_core__DOT___000387_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000382_)))));
    vlSelf->wasmetal_core__DOT___001869_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001864_)))));
    vlSelf->__VdfgTmp_hc744024d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001864_)));
    vlSelf->wasmetal_core__DOT___001845_ = (1U & (0xe2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001840_)))));
    vlSelf->__VdfgTmp_h856b720a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000187_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___001840_)));
    vlSelf->wasmetal_core__DOT___135425___DOT__maj_xyz 
        = (vlSelf->wasmetal_core__DOT___135425___DOT__X 
           & vlSelf->wasmetal_core__DOT___135425___DOT__Z);
    vlSelf->wasmetal_core__DOT___135425___DOT__xor_xyz_muxed 
        = (vlSelf->wasmetal_core__DOT___135425___DOT__X 
           ^ vlSelf->wasmetal_core__DOT___135425___DOT__Z);
    vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128474___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128139___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053280_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052858_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                                >> 8U)) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                                >> 3U)) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                                                >> 0xeU))))))) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                                >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031053_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128322___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___045491_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045515_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045287_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045311_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045484_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045508_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045280_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045304_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045485_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045509_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045281_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045305_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045490_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___045514_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___045286_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->wasmetal_core__DOT___045310_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->wasmetal_core__DOT___045483_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045507_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045279_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045303_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045486_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045510_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045282_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045306_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045488_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045512_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045284_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045308_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045487_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045511_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045283_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___045307_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___064465_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064462_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & vlSelf->insn_imm[0U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->__VdfgTmp_h978f5c03__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hacde19aa__0));
    vlSelf->wasmetal_core__DOT___052354_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbc270d96__0)))));
    vlSelf->__VdfgTmp_h567f5b99__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_heece1a14__0));
    vlSelf->wasmetal_core__DOT___052101_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hacecf0f9__0)))));
    vlSelf->__VdfgTmp_h6ab68aeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2a05cb02__0));
    vlSelf->__VdfgTmp_h3ecae377__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5621a27e__0));
    vlSelf->wasmetal_core__DOT___052107_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h27483593__0)))));
    vlSelf->__VdfgTmp_hc521e256__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7b7ca35d__0));
    vlSelf->wasmetal_core__DOT___052108_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc644e6af__0)))));
    vlSelf->__VdfgTmp_hed1e62e4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha36d230f__0));
    vlSelf->__VdfgTmp_h76024217__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h0e59039e__0));
    vlSelf->__VdfgTmp_hc0def293__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h802db31a__0));
    vlSelf->wasmetal_core__DOT___052100_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2876322d__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7de933ba__0))))))));
    vlSelf->__VdfgTmp_h563719e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004809_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb1d9bcba__0))));
    vlSelf->wasmetal_core__DOT___004811_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb1d9bcba__0))));
    vlSelf->wasmetal_core__DOT___004953_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h360aedc6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b90__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053141_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_heece1a14__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004951_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h360aedc6__0)))))))))));
    vlSelf->wasmetal_core__DOT___005021_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he20a0bf9__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b91__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052089_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005019_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he20a0bf9__0)))))))))));
    vlSelf->wasmetal_core__DOT___005012_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002871_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002870_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcb2b4d33__0)))))))));
    vlSelf->wasmetal_core__DOT___005011_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcb2b4d33__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002871_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002870_)))))));
    vlSelf->wasmetal_core__DOT___004885_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1aa0b795__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b92__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052740_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2a05cb02__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004883_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1aa0b795__0)))))))))));
    vlSelf->wasmetal_core__DOT___005293_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30461973__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b93__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053143_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5621a27e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005291_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h30461973__0)))))))))));
    vlSelf->wasmetal_core__DOT___051972_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005223_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005291_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3a3933c4__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h30461973__0)))))))));
    vlSelf->wasmetal_core__DOT___005225_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3a3933c4__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b94__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053145_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h7b7ca35d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005223_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3a3933c4__0)))))))))));
    vlSelf->__VdfgTmp_ha0b12c43__0 = (((IData)(vlSelf->wasmetal_core__DOT___003259_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hff0b1f3c__0))));
    vlSelf->wasmetal_core__DOT___003261_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff0b1f3c__0))));
    vlSelf->wasmetal_core__DOT___003181_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3cd3193e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b96__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053149_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h0e59039e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003179_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3cd3193e__0)))))))))));
    vlSelf->wasmetal_core__DOT___005609_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b95__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053147_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h802db31a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005607_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0)))))))))));
    vlSelf->__VdfgTmp_he1a2a265__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9ef9e390__0));
    vlSelf->wasmetal_core__DOT___052282_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6f7c691c__0)))));
    vlSelf->__VdfgTmp_hcf9144f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h84ec00f9__0));
    vlSelf->wasmetal_core__DOT___052294_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9340bbb8__0)))));
    vlSelf->__VdfgTmp_h27cfb5f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5d1eeffa__0));
    vlSelf->wasmetal_core__DOT___052281_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4e57fd92__0)))));
    vlSelf->__VdfgTmp_h4c59d32e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h04b492c5__0));
    vlSelf->__VdfgTmp_h8de0b505__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc33bf0b0__0));
    vlSelf->__VdfgTmp_he4198019__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9c74c594__0));
    vlSelf->__VdfgTmp_h80bd54db__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc01010d2__0));
    vlSelf->__VdfgTmp_h572d5497__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hed80111e__0));
    vlSelf->wasmetal_core__DOT___052293_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h20122d13__0)))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff555503f303f3ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 5U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbe2bd06c__0)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff555503f303f3ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                        << 5U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h75fb7e4c__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff555503f303f3ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf100045e__0))))))))));
    vlSelf->wasmetal_core__DOT___005275_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce3a0449__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b125__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053161_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9ef9e390__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005273_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hce3a0449__0)))))))))));
    vlSelf->wasmetal_core__DOT___004935_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b122__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053246_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h84ec00f9__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004933_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0)))))))))));
    vlSelf->__VdfgTmp_h70f8ca0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005001_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb177e111__0))));
    vlSelf->wasmetal_core__DOT___005003_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb177e111__0))));
    vlSelf->wasmetal_core__DOT___004994_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002881_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002880_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0589a813__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1c139036__0)))))))));
    vlSelf->wasmetal_core__DOT___004993_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0589a813__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1c139036__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002881_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002880_)))))));
    vlSelf->wasmetal_core__DOT___052300_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004933_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004865_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbd8a32bd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h149c0bef__0)))))))));
    vlSelf->wasmetal_core__DOT___004867_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h149c0bef__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b124__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053159_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5d1eeffa__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004865_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h149c0bef__0)))))))))));
    vlSelf->__VdfgTmp_h8783294b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005341_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1f619b05__0))));
    vlSelf->wasmetal_core__DOT___005343_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f619b05__0))));
    vlSelf->wasmetal_core__DOT___003391_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8889c5b6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b117__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053236_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc33bf0b0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003389_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h8889c5b6__0)))))))))));
    vlSelf->wasmetal_core__DOT___003323_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9046ca2f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b118__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053238_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9c74c594__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003321_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h9046ca2f__0)))))))))));
    vlSelf->wasmetal_core__DOT___005071_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9ff07be6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b120__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053242_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc01010d2__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005069_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h9ff07be6__0)))))))))));
    vlSelf->__VdfgTmp_h533e26e9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005137_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc8258b97__0))));
    vlSelf->wasmetal_core__DOT___005139_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc8258b97__0))));
    vlSelf->__VdfgTmp_hbd2d90ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd380d548__0));
    vlSelf->__VdfgTmp_h7b9c68be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h18ef2d35__0));
    vlSelf->__VdfgTmp_h3348ca28__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51a38bc3__0));
    vlSelf->wasmetal_core__DOT___052353_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h04a005a2__0)))));
    vlSelf->__VdfgTmp_h924e7878__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb29d3d73__0));
    vlSelf->__VdfgTmp_ha95b5bdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he7b219d6__0));
    vlSelf->__VdfgTmp_h14eebae7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2c3dfb0e__0));
    vlSelf->__VdfgTmp_hea93726f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha9ea3386__0));
    vlSelf->wasmetal_core__DOT___052344_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h93ad939a__0)))));
    vlSelf->__VdfgTmp_h82193735__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc2746ec0__0));
    vlSelf->__VdfgTmp_he04a0e99__0 = (((IData)(vlSelf->wasmetal_core__DOT___003549_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2657a63f__0))));
    vlSelf->wasmetal_core__DOT___003551_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2657a63f__0))));
    vlSelf->__VdfgTmp_hd9174715__0 = (((IData)(vlSelf->wasmetal_core__DOT___003475_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0a7ec8f3__0))));
    vlSelf->wasmetal_core__DOT___003477_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0a7ec8f3__0))));
    vlSelf->__VdfgTmp_h6e2b8153__0 = (((IData)(vlSelf->wasmetal_core__DOT___004735_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hdf1c1f2d__0))));
    vlSelf->wasmetal_core__DOT___004737_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf1c1f2d__0))));
    vlSelf->__VdfgTmp_h9014fa0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___004513_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb173ffdf__0))));
    vlSelf->wasmetal_core__DOT___004515_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb173ffdf__0))));
    vlSelf->__VdfgTmp_h11abcf6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004365_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3fc50e0d__0))));
    vlSelf->wasmetal_core__DOT___004367_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3fc50e0d__0))));
    vlSelf->__VdfgTmp_h9e847741__0 = (((IData)(vlSelf->wasmetal_core__DOT___004439_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc1565767__0))));
    vlSelf->wasmetal_core__DOT___004441_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1565767__0))));
    vlSelf->__VdfgTmp_hae654b01__0 = (((IData)(vlSelf->wasmetal_core__DOT___003623_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf661f789__0))));
    vlSelf->wasmetal_core__DOT___003625_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf661f789__0))));
    vlSelf->wasmetal_core__DOT___003616_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002420_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002419_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8e2ab84__0)))))))));
    vlSelf->wasmetal_core__DOT___003111_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha8e2ab84__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002420_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002419_)))))));
    vlSelf->__VdfgTmp_h4c8e22c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003771_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h5234eb1f__0))));
    vlSelf->wasmetal_core__DOT___003773_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5234eb1f__0))));
    vlSelf->wasmetal_core__DOT___052320_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004587_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003321_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hce07ecc6__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h9046ca2f__0)))))))));
    vlSelf->wasmetal_core__DOT___004589_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce07ecc6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b103__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053176_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc2746ec0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004587_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hce07ecc6__0)))))))))));
    vlSelf->__VdfgTmp_h1e17785c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h36663d57__0));
    vlSelf->__VdfgTmp_h5fa501f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf4f843fa__0));
    vlSelf->__VdfgTmp_hcced7fa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h84403644__0));
    vlSelf->wasmetal_core__DOT___052061_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4c3dd507__0)))));
    vlSelf->__VdfgTmp_hb92015b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd77b503a__0));
    vlSelf->wasmetal_core__DOT___052060_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8b19f5ab__0)))));
    vlSelf->__VdfgTmp_h33748258__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51c7c353__0));
    vlSelf->wasmetal_core__DOT___051961_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005019_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he20a0bf9__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0)))))))));
    vlSelf->wasmetal_core__DOT___005361_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b89__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052091_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0352b565__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005359_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0)))))))))));
    vlSelf->wasmetal_core__DOT___005352_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002707_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002706_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0352b565__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8396fa72__0)))))))));
    vlSelf->wasmetal_core__DOT___005351_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h0352b565__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8396fa72__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002707_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002706_)))))));
    vlSelf->wasmetal_core__DOT___004053_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h559eadff__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b82__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053135_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h36663d57__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004051_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h559eadff__0)))))))))));
    vlSelf->__VdfgTmp_hdcdc0b33__0 = (((IData)(vlSelf->wasmetal_core__DOT___003835_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3e1bf990__0))));
    vlSelf->wasmetal_core__DOT___003837_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1bf990__0))));
    vlSelf->wasmetal_core__DOT___003828_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001215_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001214_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42aab1a0__0)))))))));
    vlSelf->wasmetal_core__DOT___003827_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h42aab1a0__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001215_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001214_)))))));
    vlSelf->wasmetal_core__DOT___003929_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c1149ce__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b84__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053137_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf4f843fa__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003927_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h5c1149ce__0)))))))))));
    vlSelf->wasmetal_core__DOT___003409_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb5e938__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b85__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062383_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h84403644__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003407_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdfb5e938__0)))))))))));
    vlSelf->wasmetal_core__DOT___003341_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec05375a__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b86__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053139_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd77b503a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003339_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hec05375a__0)))))))))));
    vlSelf->wasmetal_core__DOT___004275_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc280317b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b81__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053133_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51c7c353__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004273_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hc280317b__0)))))))))));
    vlSelf->wasmetal_core__DOT___005089_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a29f22b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b88__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052087_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7762895e__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005087_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8a29f22b__0)))))))))));
    vlSelf->wasmetal_core__DOT___005080_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002668_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002667_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7762895e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70bc9fce__0)))))))));
    vlSelf->wasmetal_core__DOT___005079_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7762895e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70bc9fce__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002668_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002667_)))))));
    vlSelf->__VdfgTmp_h106a7f5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005155_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2f54f550__0))));
    vlSelf->wasmetal_core__DOT___005157_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f54f550__0))));
    vlSelf->wasmetal_core__DOT___005148_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002950_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002949_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h128bed99__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd4bbf89e__0)))))))));
    vlSelf->wasmetal_core__DOT___005147_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h128bed99__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd4bbf89e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002950_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002949_)))))));
    vlSelf->__VdfgTmp_h3971fc45__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h57ccb970__0));
    vlSelf->wasmetal_core__DOT___052280_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0b18d540__0)))));
    vlSelf->__VdfgTmp_hc2399f9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8294d615__0));
    vlSelf->__VdfgTmp_h3ed820c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h563364ee__0));
    vlSelf->wasmetal_core__DOT___052276_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7c824381__0)))));
    vlSelf->__VdfgTmp_haa9d6aae__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he9f02b45__0));
    vlSelf->wasmetal_core__DOT___052345_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbd2119cc__0)))));
    vlSelf->__VdfgTmp_h70b5eab4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1008ab3f__0));
    vlSelf->wasmetal_core__DOT___052275_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2098039d__0)))));
    vlSelf->__VdfgTmp_h94eb455b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hac420052__0));
    vlSelf->__VdfgTmp_h5528d6fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_heb838ef1__0));
    vlSelf->wasmetal_core__DOT___052277_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5f1be76b__0)))));
    vlSelf->__VdfgTmp_h78e77464__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1836318f__0));
    vlSelf->__VdfgTmp_hb129d53d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcf8490b8__0));
    vlSelf->wasmetal_core__DOT___052343_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc7901b89__0)))));
    vlSelf->wasmetal_core__DOT___003911_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h945f14c8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b116__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053234_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h57ccb970__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003909_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h945f14c8__0)))))))))));
    vlSelf->wasmetal_core__DOT___004145_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3a5851b5__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b108__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053203_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8294d615__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004143_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3a5851b5__0)))))))))));
    vlSelf->wasmetal_core__DOT___004219_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b109__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053201_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h563364ee__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004217_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0)))))))))));
    vlSelf->__VdfgTmp_h8b084513__0 = (((IData)(vlSelf->wasmetal_core__DOT___004661_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1b531bc8__0))));
    vlSelf->wasmetal_core__DOT___004663_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1b531bc8__0))));
    vlSelf->wasmetal_core__DOT___052326_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004069_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003909_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he222bc5e__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h945f14c8__0)))))))));
    vlSelf->wasmetal_core__DOT___004071_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he222bc5e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b114__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053228_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1008ab3f__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004069_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he222bc5e__0)))))))))));
    vlSelf->wasmetal_core__DOT___052340_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004143_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003853_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3a5851b5__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h72f11ee8__0)))))))));
    vlSelf->wasmetal_core__DOT___003855_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h72f11ee8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b115__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053232_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hac420052__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003853_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h72f11ee8__0)))))))))));
    vlSelf->wasmetal_core__DOT___052339_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004291_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004217_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4896ffc2__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0)))))))));
    vlSelf->wasmetal_core__DOT___004293_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4896ffc2__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b113__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053230_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_heb838ef1__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004291_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h4896ffc2__0)))))))))));
    vlSelf->__VdfgTmp_h6806bd5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003995_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h082bf779__0))));
    vlSelf->wasmetal_core__DOT___003997_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h082bf779__0))));
    vlSelf->__VdfgTmp_he6df8ac0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003697_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2e7cac69__0))));
    vlSelf->wasmetal_core__DOT___003699_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2e7cac69__0))));
    vlSelf->__VdfgTmp_h81a5b0aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hbef8f541__0));
    vlSelf->__VdfgTmp_hde496412__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h76a42199__0));
    vlSelf->__VdfgTmp_hd368a607__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h71c3dfae__0));
    vlSelf->wasmetal_core__DOT___052099_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6823128b__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h2d07d754__0))))))));
    vlSelf->__VdfgTmp_hfbf79e7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9946d772__0));
    vlSelf->__VdfgTmp_he0d5eea6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha028a74d__0));
    vlSelf->wasmetal_core__DOT___052083_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h96657cd6__0)))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xff555503f303f3ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 5U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04cce861__0)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff555503f303f3ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                        << 5U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h7e6d032b__0)))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff555503f303f3ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h187cbe57__0))))))))));
    vlSelf->__VdfgTmp_hb62a6dc2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce8127e9__0));
    vlSelf->wasmetal_core__DOT___052080_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9efd96c7__0)))));
    vlSelf->__VdfgTmp_hab141f26__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he96756cd__0));
    vlSelf->wasmetal_core__DOT___052079_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb156040c__0)))));
    vlSelf->__VdfgTmp_hfe998686__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h95f4bf2d__0));
    vlSelf->wasmetal_core__DOT___052078_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he10ebbb0__0)))));
    vlSelf->wasmetal_core__DOT___003979_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b80__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053131_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hbef8f541__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003977_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0)))))))))));
    vlSelf->wasmetal_core__DOT___003459_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b04a080__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b74__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052729_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h76a42199__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003457_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3b04a080__0)))))))))));
    vlSelf->wasmetal_core__DOT___051966_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003457_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3b04a080__0)))))))));
    vlSelf->wasmetal_core__DOT___003533_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b75__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052788_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h71c3dfae__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003531_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hc01dbaa7__0)))))))))));
    vlSelf->wasmetal_core__DOT___004127_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h18b22471__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b76__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052790_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9946d772__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004125_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h18b22471__0)))))))))));
    vlSelf->wasmetal_core__DOT___052049_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004199_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004125_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3b77bad1__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h18b22471__0)))))))));
    vlSelf->wasmetal_core__DOT___004201_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b77bad1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b77__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052792_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha028a74d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004199_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3b77bad1__0)))))))))));
    vlSelf->wasmetal_core__DOT___004645_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd76f194b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b78__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052794_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hce8127e9__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004643_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd76f194b__0)))))))))));
    vlSelf->wasmetal_core__DOT___003607_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h24f58f01__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b73__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052077_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5352532__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003605_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h24f58f01__0)))))))))));
    vlSelf->wasmetal_core__DOT___003598_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002410_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002409_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha5352532__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h75b3f6cb__0)))))))));
    vlSelf->wasmetal_core__DOT___003597_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha5352532__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h75b3f6cb__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002410_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002409_)))))));
    vlSelf->wasmetal_core__DOT___052043_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003753_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003605_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h09110191__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h24f58f01__0)))))))));
    vlSelf->wasmetal_core__DOT___003755_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09110191__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b72__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052745_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he96756cd__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003753_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h09110191__0)))))))))));
    vlSelf->wasmetal_core__DOT___052044_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003679_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004643_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hdd586d2e__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hd76f194b__0)))))))));
    vlSelf->wasmetal_core__DOT___003681_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd586d2e__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b79__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052798_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h95f4bf2d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003679_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd586d2e__0)))))))))));
    vlSelf->__VdfgTmp_hb257a383__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd2a6e22a__0));
    vlSelf->wasmetal_core__DOT___052062_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h18733fd3__0)))));
    vlSelf->__VdfgTmp_h04880fd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3be345de__0));
    vlSelf->__VdfgTmp_hc20a91e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8261d40e__0));
    vlSelf->__VdfgTmp_h97006b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_had5b2ab5__0));
    vlSelf->__VdfgTmp_h336c7598__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51bf3013__0));
    vlSelf->__VdfgTmp_h302dd625__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h50808fd0__0));
    vlSelf->wasmetal_core__DOT___052069_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff555503f303f3ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9a831d1c__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff555503f303f3ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                   << 5U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h3e0c1557__0))))))));
    vlSelf->wasmetal_core__DOT___004571_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d398ac8__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b71__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052743_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd2a6e22a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004569_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h6d398ac8__0)))))))))));
    vlSelf->wasmetal_core__DOT___004793_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5f8f87da__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b66__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052068_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004791_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h5f8f87da__0)))))))))));
    vlSelf->wasmetal_core__DOT___004784_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001981_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001980_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h71ee5e5b__0)))))))));
    vlSelf->wasmetal_core__DOT___004783_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h71ee5e5b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001981_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001980_)))))));
    vlSelf->wasmetal_core__DOT___052035_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004791_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004717_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h5f8f87da__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6be40165__0)))))))));
    vlSelf->wasmetal_core__DOT___004719_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6be40165__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b67__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052067_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004717_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6be40165__0)))))))))));
    vlSelf->wasmetal_core__DOT___004710_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002016_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002015_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdb1fbe21__0)))))))));
    vlSelf->wasmetal_core__DOT___004709_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdb1fbe21__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002016_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002015_)))))));
    vlSelf->wasmetal_core__DOT___004497_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h252a6e11__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b68__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052714_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3be345de__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004495_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h252a6e11__0)))))))))));
    vlSelf->wasmetal_core__DOT___052030_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004495_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004347_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h252a6e11__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h813f07f7__0)))))))));
    vlSelf->wasmetal_core__DOT___004349_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h813f07f7__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b69__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052716_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8261d40e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004347_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h813f07f7__0)))))))))));
    vlSelf->wasmetal_core__DOT___051979_ = (1U & (0x8888f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004421_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6d398ac8__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x35U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h37bfe82f__0)))))))));
    vlSelf->wasmetal_core__DOT___004423_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h37bfe82f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b70__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062340_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_had5b2ab5__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004421_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h37bfe82f__0)))))))))));
    vlSelf->wasmetal_core__DOT___003243_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb1226e0__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b65__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052642_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51bf3013__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003241_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcb1226e0__0)))))))))));
    vlSelf->wasmetal_core__DOT___003163_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b64__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052640_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h50808fd0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003161_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0)))))))))));
    vlSelf->__VdfgTmp_h98b5e894__0 = (((IData)(vlSelf->wasmetal_core__DOT___005643_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h10b5f536__0))));
    vlSelf->wasmetal_core__DOT___005645_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h10b5f536__0))));
    vlSelf->wasmetal_core__DOT___005636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001185_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001184_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbe8cca87__0)))))))));
    vlSelf->wasmetal_core__DOT___001330_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbe8cca87__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001185_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001184_)))))));
    vlSelf->__VdfgTmp_h5a3a45b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa91003e__0));
    vlSelf->__VdfgTmp_he6a8c031__0 = (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9e0385bc__0));
    vlSelf->wasmetal_core__DOT___052355_ = (1U & (IData)(
                                                         (0xff555503f303f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb342b047__0)))));
    vlSelf->wasmetal_core__DOT___005207_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h36fcb829__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b126__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053253_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hfa91003e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005205_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h36fcb829__0)))))))))));
    vlSelf->wasmetal_core__DOT___005591_ = (1U & (0xca00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b127__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053165_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9e0385bc__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005589_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0)))))))))));
    vlSelf->wasmetal_core__DOT___065604_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066402_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067156_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067153_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064899_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064730_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065413_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065303_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065301_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065190_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065187_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065064_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065058_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065898_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065802_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065800_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065700_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066278_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xeU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066126_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066123_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066084_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066081_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065939_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065936_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066605_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066602_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066528_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066525_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x11U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
}
