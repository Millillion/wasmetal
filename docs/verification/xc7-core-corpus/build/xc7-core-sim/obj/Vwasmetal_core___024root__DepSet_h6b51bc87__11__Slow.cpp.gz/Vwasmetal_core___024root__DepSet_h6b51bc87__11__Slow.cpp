#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__36(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__36\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006928_;
    wasmetal_core__DOT___006928_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006929_;
    wasmetal_core__DOT___006929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013636_;
    wasmetal_core__DOT___013636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013676_;
    wasmetal_core__DOT___013676_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013726_;
    wasmetal_core__DOT___013726_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013839_;
    wasmetal_core__DOT___013839_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013906_;
    wasmetal_core__DOT___013906_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013910_;
    wasmetal_core__DOT___013910_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014191_;
    wasmetal_core__DOT___014191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014225_;
    wasmetal_core__DOT___014225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014226_;
    wasmetal_core__DOT___014226_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014260_;
    wasmetal_core__DOT___014260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014261_;
    wasmetal_core__DOT___014261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014262_;
    wasmetal_core__DOT___014262_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014268_;
    wasmetal_core__DOT___014268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014270_;
    wasmetal_core__DOT___014270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014271_;
    wasmetal_core__DOT___014271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014272_;
    wasmetal_core__DOT___014272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014280_;
    wasmetal_core__DOT___014280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017818_;
    wasmetal_core__DOT___017818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017820_;
    wasmetal_core__DOT___017820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017856_;
    wasmetal_core__DOT___017856_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017868_;
    wasmetal_core__DOT___017868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017870_;
    wasmetal_core__DOT___017870_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017881_;
    wasmetal_core__DOT___017881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022694_;
    wasmetal_core__DOT___022694_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044911_;
    wasmetal_core__DOT___044911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045332_;
    wasmetal_core__DOT___045332_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045341_;
    wasmetal_core__DOT___045341_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045344_;
    wasmetal_core__DOT___045344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045353_;
    wasmetal_core__DOT___045353_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045366_;
    wasmetal_core__DOT___045366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045375_;
    wasmetal_core__DOT___045375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045378_;
    wasmetal_core__DOT___045378_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045387_;
    wasmetal_core__DOT___045387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045400_;
    wasmetal_core__DOT___045400_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045409_;
    wasmetal_core__DOT___045409_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045412_;
    wasmetal_core__DOT___045412_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045421_;
    wasmetal_core__DOT___045421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045907_;
    wasmetal_core__DOT___045907_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045918_;
    wasmetal_core__DOT___045918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045927_;
    wasmetal_core__DOT___045927_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045930_;
    wasmetal_core__DOT___045930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045939_;
    wasmetal_core__DOT___045939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051561_;
    wasmetal_core__DOT___051561_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057737_;
    wasmetal_core__DOT___057737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057740_;
    wasmetal_core__DOT___057740_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059141_;
    wasmetal_core__DOT___059141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059177_;
    wasmetal_core__DOT___059177_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063240_;
    wasmetal_core__DOT___063240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063246_;
    wasmetal_core__DOT___063246_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063252_;
    wasmetal_core__DOT___063252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063258_;
    wasmetal_core__DOT___063258_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070582_;
    wasmetal_core__DOT___070582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070583_;
    wasmetal_core__DOT___070583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070585_;
    wasmetal_core__DOT___070585_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127440___O;
    wasmetal_core__DOT____Vcellout___127440___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127485___O;
    wasmetal_core__DOT____Vcellout___127485___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127614___O;
    wasmetal_core__DOT____Vcellout___127614___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127857___CO;
    wasmetal_core__DOT____Vcellout___127857___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127873___O;
    wasmetal_core__DOT____Vcellout___127873___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127973___O;
    wasmetal_core__DOT____Vcellout___127973___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___O;
    wasmetal_core__DOT____Vcellout___128065___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___CO;
    wasmetal_core__DOT____Vcellout___128065___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127924___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127924___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127924___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127924___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127924___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127924___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127941___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127941___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127941___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127941___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127941___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127941___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128074___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128074___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128074___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128074___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128074___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128074___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128074___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128074___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128083___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128083___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128083___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128083___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128092___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128092___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128092___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128092___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128092___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128092___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128092___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128092___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128101___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128101___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128101___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128101___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128110___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128110___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128110___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128110___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128110___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128110___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128110___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128110___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128118___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128118___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128118___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128118___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128128___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128128___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128128___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128128___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128128___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128128___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128136___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128136___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128136___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128136___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128136___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128136___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128669___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128669___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hcd9ab9ab__0;
    __VdfgTmp_hcd9ab9ab__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5ef591ab__0;
    __VdfgTmp_h5ef591ab__0 = 0;
    CData/*2:0*/ __VdfgTmp_hae3c9710__0;
    __VdfgTmp_hae3c9710__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0ec09017__0;
    __VdfgTmp_h0ec09017__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8aee5dd6__0;
    __VdfgTmp_h8aee5dd6__0 = 0;
    CData/*2:0*/ __VdfgTmp_h49f92928__0;
    __VdfgTmp_h49f92928__0 = 0;
    CData/*1:0*/ __VdfgTmp_h857f834a__0;
    __VdfgTmp_h857f834a__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ede2138__0;
    __VdfgTmp_h3ede2138__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0996db4e__0;
    __VdfgTmp_h0996db4e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9b6b58da__0;
    __VdfgTmp_h9b6b58da__0 = 0;
    CData/*1:0*/ __VdfgTmp_hda5b9960__0;
    __VdfgTmp_hda5b9960__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfdee4508__0;
    __VdfgTmp_hfdee4508__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1bfa5608__0;
    __VdfgTmp_h1bfa5608__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf9553abf__0;
    __VdfgTmp_hf9553abf__0 = 0;
    CData/*5:0*/ __VdfgTmp_hb5812008__0;
    __VdfgTmp_hb5812008__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc8c79887__0;
    __VdfgTmp_hc8c79887__0 = 0;
    // Body
    __VdfgTmp_h3ede2138__0 = (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006882_));
    __VdfgTmp_h0ec09017__0 = (((IData)(vlSelf->wasmetal_core__DOT___006866_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006882_));
    vlSelf->wasmetal_core__DOT___006897_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                   ? 
                                                  (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006908_)))))
                                                   : 
                                                  (0xc05U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006907_)))))));
    __VdfgTmp_h857f834a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006907_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006644_));
    __VdfgTmp_h8aee5dd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___006908_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006907_));
    wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___022641_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022624_));
    vlSelf->wasmetal_core__DOT____Vcellout___127562___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006106_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005989_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023462_)))));
    vlSelf->wasmetal_core__DOT___023466_ = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127579___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002629_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0ed8cd5e__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023583_)))));
    vlSelf->wasmetal_core__DOT___023587_ = ((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127472___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022792_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022791_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022790_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022789_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022757_)))));
    vlSelf->wasmetal_core__DOT___022761_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022792_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))));
    vlSelf->wasmetal_core__DOT___059145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))))));
    vlSelf->wasmetal_core__DOT___022796_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))))));
    vlSelf->wasmetal_core__DOT___022795_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0))))));
    vlSelf->wasmetal_core__DOT___022794_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0))))));
    wasmetal_core__DOT___059141_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))));
    vlSelf->wasmetal_core__DOT___022793_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))));
    wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) {
        wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d;
        wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d;
    } else {
        wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028107_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028074_)
                  : (vlSelf->insn_x >> 0x18U)));
    vlSelf->wasmetal_core__DOT___054570_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000614_)))));
    vlSelf->wasmetal_core__DOT___054571_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000636_)))));
    vlSelf->wasmetal_core__DOT___054572_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000658_)))));
    vlSelf->wasmetal_core__DOT___054573_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005617_)))));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034308_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034371_));
    wasmetal_core__DOT___128118___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028863_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128118___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    wasmetal_core__DOT___128083___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028484_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005232_));
    wasmetal_core__DOT___128101___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028658_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005300_));
    wasmetal_core__DOT___128136___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029070_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029035_)
            : (IData)(vlSelf->wasmetal_core__DOT___000520_));
    wasmetal_core__DOT___128128___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028970_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128128___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128441___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128441___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___000657_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___000657_)
                 : (IData)(vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032277_)))));
    vlSelf->wasmetal_core__DOT___045374_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b56__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___045386_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b58__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b57__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b56__05d)))))))));
    wasmetal_core__DOT___128110___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028727_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT____Vcellout___127856___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026473_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026472_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026471_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026470_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026436_)))));
    vlSelf->wasmetal_core__DOT___026440_ = ((IData)(vlSelf->wasmetal_core__DOT___026473_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d));
    vlSelf->wasmetal_core__DOT___071278_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071277_))));
    vlSelf->wasmetal_core__DOT___045340_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052177_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052178_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052503_))))))));
    vlSelf->wasmetal_core__DOT___045352_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052178_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052177_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052503_)))))))));
    wasmetal_core__DOT___128092___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026683_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026617_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT___054378_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054374_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054380_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127941___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027153_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027087_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d));
    wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026580_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000565_));
    vlSelf->wasmetal_core__DOT___054377_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054373_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054379_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054375_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127924___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026953_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026887_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT___045926_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052566_))))))));
    vlSelf->wasmetal_core__DOT___045938_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052566_)))))))));
    vlSelf->wasmetal_core__DOT___045408_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe9e3bd4__0))))));
    vlSelf->wasmetal_core__DOT___045420_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004972_)))))))));
    vlSelf->wasmetal_core__DOT___045090_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071064_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071063_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071062_))))))));
    vlSelf->wasmetal_core__DOT___045114_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071064_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071063_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071062_)))))))));
    vlSelf->wasmetal_core__DOT___045880_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005096_)))))))));
    vlSelf->wasmetal_core__DOT___045904_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005368_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005096_)))))))));
    wasmetal_core__DOT___128074___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026818_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026752_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    wasmetal_core__DOT___128669___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___000657_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030109_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030076_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030237_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030172_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028303_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028238_));
    wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027351_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b26__05d));
    vlSelf->__VdfgTmp_ha48aeb8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h97a6ba37__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O)))))));
    vlSelf->__VdfgTmp_h4caf4ac4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->__VdfgTmp_h454147c9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_h9936ac51__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h9937e7c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006171_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022523_));
    wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___013726_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8f0bea78__0))))))));
    wasmetal_core__DOT___013676_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0))))))));
    vlSelf->wasmetal_core__DOT___013641_ = (1U & ((0xb0bbU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013672_))))) 
                                                  & (IData)(
                                                            (0x1000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013683_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013682_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O)) 
                                                                    | ((4U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h87a694d3__0)) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_haeb5561e__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f0bea78__0))))))))))));
    wasmetal_core__DOT___057740_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O))
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___013698_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___013698_));
    wasmetal_core__DOT___057737_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                              >> 3U)) 
                                          & (IData)(
                                                    (0xb0bbb0bb0000b0bbULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                             << 3U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O)) 
                                                            | ((4U 
                                                                & ((0xeU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___013648_))))))))));
    vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023684_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d));
    wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d) {
        wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d;
        vlSelf->wasmetal_core__DOT___023886_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d;
    } else {
        wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023886_ = wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___006894_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___006619_));
    vlSelf->__VdfgTmp_h42a31070__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___006870_)
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006882_)))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                         & (IData)(
                                                   (0xff00ccccf0f0aaaaULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006869_))))))))));
    vlSelf->__VdfgTmp_he163c644__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006835_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006855_))))))))) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x80U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006907_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006643_)))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006874_)))));
    wasmetal_core__DOT___006928_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___006874_));
    __VdfgTmp_h49f92928__0 = (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                               << 2U) | (IData)(__VdfgTmp_h3ede2138__0));
    vlSelf->wasmetal_core__DOT___016290_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051542_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h3ede2138__0))))))));
    vlSelf->__VdfgTmp_h690a20a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006639_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006850_))))))))) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x3500U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                 << 2U) 
                                                                | (IData)(__VdfgTmp_h0ec09017__0)))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006843_)))));
    vlSelf->__VdfgTmp_h63494727__0 = ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___006843_)) 
                                       << 1U) | (1U 
                                                 & (0xcfafU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_h0ec09017__0)))))));
    __VdfgTmp_h5ef591ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                               << 2U) | (IData)(__VdfgTmp_h0ec09017__0));
    vlSelf->__VdfgTmp_h3bcc9f30__0 = (((IData)(vlSelf->wasmetal_core__DOT___006897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006896_));
    wasmetal_core__DOT___006929_ = (1U & (0x7fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h857f834a__0)))));
    vlSelf->wasmetal_core__DOT___016289_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051541_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h857f834a__0))))))));
    wasmetal_core__DOT___051561_ = (1U & (0x3a000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006862_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h8aee5dd6__0))))));
    vlSelf->wasmetal_core__DOT___006916_ = (1U & (0xcf5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h8aee5dd6__0))))));
    __VdfgTmp_hae3c9710__0 = (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                               << 2U) | (IData)(__VdfgTmp_h8aee5dd6__0));
    if (vlSelf->wasmetal_core__DOT___006623_) {
        vlSelf->wasmetal_core__DOT___006942_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006966_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h0ec09017__0))))))));
        vlSelf->wasmetal_core__DOT___016288_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006969_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h8aee5dd6__0))))))));
        if (vlSelf->wasmetal_core__DOT___006952_) {
            vlSelf->wasmetal_core__DOT___006941_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006951_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h5ef591ab__0)))))));
            vlSelf->wasmetal_core__DOT___006943_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006959_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hae3c9710__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___006941_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006951_)));
            vlSelf->wasmetal_core__DOT___006943_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006959_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___006942_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006966_)));
        vlSelf->wasmetal_core__DOT___016288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006969_)));
        vlSelf->wasmetal_core__DOT___006941_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006951_)));
        vlSelf->wasmetal_core__DOT___006943_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006959_)));
    }
    wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022642_)
            ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022625_));
    vlSelf->wasmetal_core__DOT___006675_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005989_))))));
    vlSelf->__VdfgTmp_h4f1b49a4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023466_));
    vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002636_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023587_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) {
        wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d;
        vlSelf->wasmetal_core__DOT___022876_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d;
    } else {
        wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022876_ = wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059146_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059141_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059140_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022793_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022761_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h57318413__0))));
    wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028108_)
                  ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x19U)));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034309_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128118___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028864_)
            ? (IData)(wasmetal_core__DOT___128118___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    wasmetal_core__DOT___128083___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128083___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128083___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028660_)
            ? (IData)(wasmetal_core__DOT___128101___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___005232_));
    wasmetal_core__DOT___128136___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029071_)
            ? (IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000542_));
    wasmetal_core__DOT___128128___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028972_)
            ? (IData)(wasmetal_core__DOT___128128___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d));
    wasmetal_core__DOT___128110___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028762_)
            ? (IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT___044910_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                                                  << 1U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                          >> 2U)))))))));
    wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026474_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026440_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d));
    vlSelf->wasmetal_core__DOT___071279_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071278_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d)))))))));
    wasmetal_core__DOT___128092___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026684_)
            ? (IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT___070717_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d)))))));
    wasmetal_core__DOT___127941___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027154_)
            ? (IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127872___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026581_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026580_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026579_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026578_)))) 
           ^ (((IData)(wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026511_)))));
    vlSelf->wasmetal_core__DOT___026515_ = ((IData)(vlSelf->wasmetal_core__DOT___026581_)
                                             ? (IData)(wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000592_));
    vlSelf->wasmetal_core__DOT___070820_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054375_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d)))))));
    wasmetal_core__DOT___127924___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026954_)
            ? (IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    wasmetal_core__DOT___128074___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026819_)
            ? (IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT____Vcellout___128669___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128441___S) 
           ^ (((IData)(wasmetal_core__DOT___128669___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128669___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034527_)))));
    vlSelf->wasmetal_core__DOT___034532_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)) 
                                            & (IData)(wasmetal_core__DOT___128669___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030110_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030238_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128064___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028304_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028303_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028302_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028301_)))) 
           ^ (((IData)(wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028267_)))));
    vlSelf->wasmetal_core__DOT___028271_ = ((IData)(vlSelf->wasmetal_core__DOT___028304_)
                                             ? (IData)(wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028239_));
    wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127957___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027352_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027351_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027350_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027349_)))) 
           ^ (((IData)(wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027283_)))));
    vlSelf->wasmetal_core__DOT___027287_ = ((IData)(vlSelf->wasmetal_core__DOT___027352_)
                                             ? (IData)(wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b27__05d));
    vlSelf->wasmetal_core__DOT___023212_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4caf4ac4__0))));
    vlSelf->wasmetal_core__DOT___023211_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h454147c9__0))));
    vlSelf->wasmetal_core__DOT___023210_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006099_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))));
    vlSelf->wasmetal_core__DOT___023209_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005989_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006144_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)) 
           & (IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hdff3685b__0 = ((((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O))
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                            & (IData)(wasmetal_core__DOT___013726_))
                                         : (IData)(wasmetal_core__DOT___013726_)) 
                                       << 1U) | (1U 
                                                 & ((~ 
                                                     ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                      >> 3U)) 
                                                    & (IData)(
                                                              (0xb0bbb0bb0000b0bbULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                 << 5U) 
                                                                | ((0x18U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___013668_))))))))));
    vlSelf->wasmetal_core__DOT___022695_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022712_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013641_)))));
    wasmetal_core__DOT___014226_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))));
    vlSelf->wasmetal_core__DOT___057782_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))));
    wasmetal_core__DOT___014225_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013652_)))))));
    vlSelf->wasmetal_core__DOT___014224_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xeU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))))));
    vlSelf->wasmetal_core__DOT___013638_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))));
    vlSelf->wasmetal_core__DOT___014234_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013692_)))))));
    vlSelf->wasmetal_core__DOT___013637_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))));
    vlSelf->wasmetal_core__DOT___014233_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))));
    wasmetal_core__DOT___013636_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013654_)))))));
    vlSelf->wasmetal_core__DOT___014232_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013648_)))))));
    wasmetal_core__DOT___014191_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013666_)))))));
    vlSelf->wasmetal_core__DOT___014231_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013658_)))))));
    wasmetal_core__DOT___014268_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013719_)))))));
    wasmetal_core__DOT___014262_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013701_)))))));
    wasmetal_core__DOT___014272_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013722_)))))));
    wasmetal_core__DOT___014261_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))));
    wasmetal_core__DOT___014271_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))));
    wasmetal_core__DOT___014260_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))));
    wasmetal_core__DOT___014270_ = (1U & (0x4000U >> 
                                          (((IData)(wasmetal_core__DOT___057737_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___057740_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    vlSelf->wasmetal_core__DOT___013640_ = (1U & (0x80U 
                                                  >> 
                                                  ((((4U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                      & (IData)(wasmetal_core__DOT___013676_))
                                                      : (IData)(wasmetal_core__DOT___013676_)) 
                                                    << 2U) 
                                                   | ((((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O))
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___013663_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___013663_)) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057737_)))));
    vlSelf->__VdfgTmp_h7c6f7838__0 = (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___057740_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___057737_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127629___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024008_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d) {
        vlSelf->wasmetal_core__DOT___024013_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024013_ = wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023886_;
    }
    vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127613___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023881_)))));
    vlSelf->__VdfgTmp_h8599270c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006899_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006894_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006895_))));
    vlSelf->__VdfgTmp_hedae78d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___016197_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h42a31070__0)));
    vlSelf->wasmetal_core__DOT___017821_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fa33ffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he163c644__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017829_ = (1U 
                                                & (0xefefefU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0x40U 
                                                         >> (IData)(__VdfgTmp_h49f92928__0)) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006862_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                           << 2U) 
                                                          | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                               & (IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006639_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006872_))))))))) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                    ? 
                                                                   (0xc0aU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___006870_)))))))));
        vlSelf->wasmetal_core__DOT___016255_ = (1U 
                                                & (0xf0faccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 3U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                ? 
                                                               (0xfcaaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8420cdb8__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050132_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006639_)))))
                                                                : 
                                                               (0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006640_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006638_)))))) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xf0aaccffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                       << 3U) 
                                                                      | (IData)(__VdfgTmp_h5ef591ab__0)))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006619_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___017829_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003808_)));
        vlSelf->wasmetal_core__DOT___016255_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005770_)));
    }
    vlSelf->wasmetal_core__DOT___006915_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h49f92928__0))));
    vlSelf->wasmetal_core__DOT___017849_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fa33ffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_)))));
    vlSelf->__VdfgTmp_h6ef172e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___016206_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h63494727__0)));
    vlSelf->wasmetal_core__DOT___006931_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5ef591ab__0)))))));
    vlSelf->wasmetal_core__DOT___017910_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3bcc9f30__0)))));
    vlSelf->__VdfgTmp_hb02141c6__0 = (((IData)(wasmetal_core__DOT___006929_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___006928_));
    vlSelf->wasmetal_core__DOT___057877_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___006928_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___006929_))))));
    vlSelf->__VdfgTmp_h8655efce__0 = (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016297_));
    vlSelf->wasmetal_core__DOT___016258_ = (1U & (IData)(
                                                         (0xefefff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___051561_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                             ? 
                                                                            (0xc0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006853_)))))
                                                                             : 
                                                                            (0xc0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006852_)))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                          & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006836_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006858_)))))))))))))))));
    vlSelf->__VdfgTmp_h4068d69c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006917_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006916_));
    vlSelf->__VdfgTmp_haa0d8025__0 = ((2U & ((0xf055ccffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                      << 3U) 
                                                     | (IData)(__VdfgTmp_hae3c9710__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006853_))))))))));
    vlSelf->wasmetal_core__DOT___006940_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hae3c9710__0)))))));
    wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022626_)
            ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022626_));
    vlSelf->wasmetal_core__DOT___006704_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4f1b49a4__0)))));
    vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127492___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022934_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) {
        vlSelf->wasmetal_core__DOT___022939_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022939_ = wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022876_;
    }
    vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022794_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127484___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022871_)))));
    wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028109_)
                  ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x1aU)));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034310_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128118___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028865_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028864_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028863_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028862_)))) 
           ^ (((IData)(wasmetal_core__DOT___128118___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128118___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128118___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028827_)))));
    vlSelf->wasmetal_core__DOT___028831_ = ((IData)(vlSelf->wasmetal_core__DOT___028865_)
                                             ? (IData)(wasmetal_core__DOT___128118___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT____Vcellout___128083___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028485_)
              ? (IData)(wasmetal_core__DOT___128083___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT___005618_)) 
            << 3U) | (IData)(wasmetal_core__DOT___128083___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128083___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028485_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028484_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028482_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028481_)))) 
           ^ (((IData)(wasmetal_core__DOT___128083___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028447_)));
    wasmetal_core__DOT___128101___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128101___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128136___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029072_)
            ? (IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000564_));
    wasmetal_core__DOT___128128___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128128___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128128___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128128___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___128110___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028764_)
            ? (IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026475_)
            ? (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d));
    vlSelf->wasmetal_core__DOT___045046_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071279_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045022_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071279_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054131_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071277_))))));
    wasmetal_core__DOT___128092___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026686_)
            ? (IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___070719_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)))))))))));
    vlSelf->wasmetal_core__DOT___070718_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d)))))))));
    wasmetal_core__DOT___127941___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027156_)
            ? (IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d));
    vlSelf->wasmetal_core__DOT___045498_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071367_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071366_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071365_))))))));
    vlSelf->wasmetal_core__DOT___045522_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071367_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071366_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071365_)))))))));
    vlSelf->wasmetal_core__DOT___045294_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071430_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071429_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071428_))))))));
    vlSelf->wasmetal_core__DOT___045318_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071430_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071429_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071428_)))))))));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026582_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026515_)
            : (IData)(vlSelf->wasmetal_core__DOT___000614_));
    vlSelf->wasmetal_core__DOT___070822_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054373_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)))))))))));
    vlSelf->wasmetal_core__DOT___070821_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070820_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054373_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d)))))))));
    wasmetal_core__DOT___127924___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026956_)
            ? (IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    wasmetal_core__DOT___128074___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h0f13542d__0)))
            ? (IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___040027_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___040026_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___040025_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___040013_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b31__05d)))))))));
    vlSelf->__VdfgTmp_h8ccb0334__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)));
    vlSelf->__VdfgTmp_h380b0b0b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->__VdfgTmp_h0902fa8b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->__VdfgTmp_h5e64ea1f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128669___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034476_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034532_));
    vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034532_));
    wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030111_)
            ? (IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030239_)
            ? (IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    wasmetal_core__DOT___063240_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063246_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063252_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063258_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028305_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028271_)
            : (IData)(vlSelf->wasmetal_core__DOT___028240_));
    wasmetal_core__DOT____Vcellout___127973___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027413_)))));
    vlSelf->wasmetal_core__DOT___027418_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027353_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027287_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b28__05d));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006215_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128553___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011020_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033434_)))));
    vlSelf->wasmetal_core__DOT___033438_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___011020_)) 
                                            & (IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___014280_ = (1U & (0x80000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057743_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057742_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdff3685b__0))))));
    vlSelf->wasmetal_core__DOT___014263_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdff3685b__0))));
    __VdfgTmp_hda5b9960__0 = (((IData)(wasmetal_core__DOT___014268_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014272_));
    __VdfgTmp_h9b6b58da__0 = (((IData)(wasmetal_core__DOT___014261_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014260_));
    vlSelf->__VdfgTmp_h179d57be__0 = (((IData)(wasmetal_core__DOT___014271_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014270_));
    if (vlSelf->wasmetal_core__DOT___013641_) {
        vlSelf->wasmetal_core__DOT___017840_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014232_))))));
        wasmetal_core__DOT___017818_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013640_)
                                               ? (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0)))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___013637_))));
    } else {
        vlSelf->wasmetal_core__DOT___017840_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014231_))))));
        wasmetal_core__DOT___017818_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013640_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___013638_))
                                               : (2U 
                                                  >> (IData)(wasmetal_core__DOT___013636_))));
    }
    vlSelf->wasmetal_core__DOT___017847_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014226_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014225_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014234_)))))))));
    wasmetal_core__DOT___013910_ = (1U & (0x10000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___014260_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    wasmetal_core__DOT___017820_ = (1U & (0x40000000U 
                                          >> (((IData)(wasmetal_core__DOT___014270_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    vlSelf->wasmetal_core__DOT___017908_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013637_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___013636_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___014191_)))))))));
    vlSelf->wasmetal_core__DOT___017867_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___014231_)))))))));
    vlSelf->wasmetal_core__DOT___014198_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013637_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___013636_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___014191_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014268_)))))))));
    vlSelf->wasmetal_core__DOT___017848_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014262_)))))))));
    wasmetal_core__DOT___013906_ = (1U & (IData)((0xff00ccccf0f0aaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___014262_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___014261_)))))))));
    vlSelf->wasmetal_core__DOT___017819_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014191_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014268_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___014272_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014271_)))))))));
    __VdfgTmp_hfdee4508__0 = (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___014260_)));
    __VdfgTmp_h1bfa5608__0 = (((IData)(wasmetal_core__DOT___014270_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013640_)));
    vlSelf->wasmetal_core__DOT___022696_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___017839_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                ? (0x110fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___014225_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x7f00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___057737_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                                       << 1U) 
                                                                      | (IData)(wasmetal_core__DOT___057740_))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x8000U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7c6f7838__0))))))))
                                                : (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___014226_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014224_))))));
    wasmetal_core__DOT___022694_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x80U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022711_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___002636_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d) {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024013_;
        vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023750_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d));
    vlSelf->__VdfgTmp_h276f18a3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->__VdfgTmp_h8ddb6508__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->__VdfgTmp_hf2c31503__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_h87705c6a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127613___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->__VdfgTmp_hf64b2678__0 = (((IData)(vlSelf->wasmetal_core__DOT___006914_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006915_));
    vlSelf->__VdfgTmp_ha11b0f77__0 = (((IData)(vlSelf->wasmetal_core__DOT___006931_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006930_));
    vlSelf->__VdfgTmp_h161c803b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017829_));
    vlSelf->wasmetal_core__DOT___017887_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4068d69c__0)))));
    vlSelf->__VdfgTmp_h9c807cdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                          ? 
                                                         (0xfcaaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050132_))) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8420cdb8__0)) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006835_)))))
                                                          : 
                                                         (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006836_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___006834_)))))) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_haa0d8025__0))));
    vlSelf->wasmetal_core__DOT___017874_ = (1U & (0xafcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa0d8025__0))))));
    vlSelf->wasmetal_core__DOT___006947_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006940_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006930_)))));
    vlSelf->__VdfgTmp_h04c27d81__0 = (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006943_));
    vlSelf->wasmetal_core__DOT____Vcellout___127450___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022627_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022626_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022642_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022641_)))) 
           ^ (((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022635_ = ((IData)(vlSelf->wasmetal_core__DOT___022627_)
                                             ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___022627_));
    wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022939_;
        vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022795_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0))));
    vlSelf->__VdfgTmp_hcc8c0380__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->__VdfgTmp_h747f7a26__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->__VdfgTmp_h1eb7369a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_h183d05b4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127484___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT____Vcellout___128048___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028110_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028109_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028108_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028107_)))) 
           ^ (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028074_)))));
    vlSelf->wasmetal_core__DOT___028078_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028110_)
                                                   ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x1bU)));
    vlSelf->wasmetal_core__DOT____Vcellout___128654___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034311_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034310_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034309_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034308_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034371_)))));
    vlSelf->wasmetal_core__DOT___034375_ = ((IData)(vlSelf->wasmetal_core__DOT___034311_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___028870_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->wasmetal_core__DOT___028869_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___028867_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___028866_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128101___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028661_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028660_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028658_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028657_)))) 
           ^ (((IData)(wasmetal_core__DOT___128101___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028623_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128136___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029073_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029072_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029071_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029070_)))) 
           ^ (((IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029035_)))));
    vlSelf->wasmetal_core__DOT___029039_ = ((IData)(vlSelf->wasmetal_core__DOT___029073_)
                                             ? (IData)(wasmetal_core__DOT___128136___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000591_));
    vlSelf->wasmetal_core__DOT____Vcellout___128128___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028973_)
              ? (IData)(wasmetal_core__DOT___128128___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___128128___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128128___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028973_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028972_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028970_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028969_)))) 
           ^ (((IData)(wasmetal_core__DOT___128128___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028935_)));
    wasmetal_core__DOT___128110___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026477_)
            ? (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d));
    wasmetal_core__DOT___128092___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___026622_ = ((IData)(vlSelf->wasmetal_core__DOT___026687_)
                                             ? (IData)(wasmetal_core__DOT___128092___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT___045250_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070718_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054372_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___045226_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070719_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054376_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x17U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054372_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070718_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127941___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027157_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027156_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027154_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027153_)))) 
           ^ (((IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027087_)))));
    vlSelf->wasmetal_core__DOT___027092_ = ((IData)(vlSelf->wasmetal_core__DOT___027157_)
                                             ? (IData)(wasmetal_core__DOT___127941___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026583_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000636_));
    vlSelf->wasmetal_core__DOT___044978_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___044954_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070822_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054375_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x17U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054371_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070821_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127924___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026957_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026956_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026954_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026953_)))) 
           ^ (((IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026887_)))));
    vlSelf->wasmetal_core__DOT___026892_ = ((IData)(vlSelf->wasmetal_core__DOT___026957_)
                                             ? (IData)(wasmetal_core__DOT___127924___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    wasmetal_core__DOT___128074___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___026757_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd6a330ca__0)))
                                             ? (IData)(wasmetal_core__DOT___128074___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT___030117_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ccb0334__0))));
    vlSelf->wasmetal_core__DOT___030245_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ccb0334__0))));
    vlSelf->wasmetal_core__DOT___030116_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h380b0b0b__0)))));
    vlSelf->wasmetal_core__DOT___030244_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h380b0b0b__0)))));
    vlSelf->wasmetal_core__DOT___030114_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0902fa8b__0)))));
    vlSelf->wasmetal_core__DOT___030242_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0902fa8b__0)))));
    vlSelf->wasmetal_core__DOT___030113_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e64ea1f__0)))));
    vlSelf->wasmetal_core__DOT___030241_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e64ea1f__0)))));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034477_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128237___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030112_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030111_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030110_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030109_)))) 
           ^ (((IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030076_)))));
    vlSelf->wasmetal_core__DOT___030080_ = ((IData)(vlSelf->wasmetal_core__DOT___030112_)
                                             ? (IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128251___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030240_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030239_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030238_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030237_)))) 
           ^ (((IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030172_)))));
    vlSelf->wasmetal_core__DOT___030176_ = ((IData)(vlSelf->wasmetal_core__DOT___030240_)
                                             ? (IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    vlSelf->wasmetal_core__DOT___063243_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063240_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063239_)))))));
    vlSelf->wasmetal_core__DOT___063249_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063245_)))))));
    vlSelf->wasmetal_core__DOT___063255_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063252_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063251_)))))));
    vlSelf->wasmetal_core__DOT___063261_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063258_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063257_)))))));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028306_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028241_));
    vlSelf->wasmetal_core__DOT___044888_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7aa341ef__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___044864_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7aa341ef__0)))))))))));
    __VdfgTmp_hc8c79887__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127973___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027418_));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027354_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b29__05d));
    wasmetal_core__DOT____Vcellout___127440___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h419b9e2f__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022523_)))));
    vlSelf->wasmetal_core__DOT___022528_ = ((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057004_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff55550f0fccccULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff55550f0f3333ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011020_)))))))))))))));
    vlSelf->wasmetal_core__DOT___056824_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))))))))));
    vlSelf->wasmetal_core__DOT___011162_ = (1U & (0x5f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff55550f0f3333ULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff55550f0fccccULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___056529_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff55550f0f3333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033438_));
    vlSelf->wasmetal_core__DOT___057835_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013666_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014261_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014262_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014260_))))))));
    vlSelf->wasmetal_core__DOT___057852_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013658_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014268_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014271_)))))
                                                      : 
                                                     (0xcf5fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014272_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014270_))))))));
    vlSelf->__VdfgTmp_h9cc49427__0 = (((IData)(vlSelf->wasmetal_core__DOT___017903_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___014260_))))));
    vlSelf->wasmetal_core__DOT___022698_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014263_))));
    vlSelf->wasmetal_core__DOT___017906_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hda5b9960__0))));
    vlSelf->wasmetal_core__DOT___014094_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___013636_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014191_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hda5b9960__0))))))));
    vlSelf->wasmetal_core__DOT___017846_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h9b6b58da__0))))));
    vlSelf->wasmetal_core__DOT___057856_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h9b6b58da__0))))));
    vlSelf->__VdfgTmp_h7f08cefc__0 = (((IData)(wasmetal_core__DOT___014262_) 
                                       << 2U) | (IData)(__VdfgTmp_h9b6b58da__0));
    vlSelf->wasmetal_core__DOT___017907_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h179d57be__0))));
    vlSelf->wasmetal_core__DOT___017882_ = (1U & (IData)(
                                                         (0xf3faf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179d57be__0))))))));
    vlSelf->__VdfgTmp_hc1104829__0 = (((IData)(wasmetal_core__DOT___014272_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h179d57be__0));
    if (vlSelf->wasmetal_core__DOT___013909_) {
        vlSelf->wasmetal_core__DOT___057897_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014350_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h9b6b58da__0))))))));
        vlSelf->wasmetal_core__DOT___057890_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014338_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h179d57be__0))))))));
        if (vlSelf->wasmetal_core__DOT___014263_) {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014289_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014300_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
        }
        vlSelf->wasmetal_core__DOT___017869_ = vlSelf->wasmetal_core__DOT___014198_;
        vlSelf->wasmetal_core__DOT___017883_ = wasmetal_core__DOT___013906_;
    } else {
        vlSelf->wasmetal_core__DOT___057897_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014350_)));
        vlSelf->wasmetal_core__DOT___057890_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014338_)));
        vlSelf->wasmetal_core__DOT___057843_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
        vlSelf->wasmetal_core__DOT___057846_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
        vlSelf->wasmetal_core__DOT___017869_ = 0U;
        vlSelf->wasmetal_core__DOT___017883_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___017884_ = (1U & (0xff400000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hfdee4508__0)))));
    vlSelf->wasmetal_core__DOT___057893_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017903_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hfdee4508__0)))))));
    vlSelf->wasmetal_core__DOT___057873_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h1bfa5608__0))));
    vlSelf->wasmetal_core__DOT___057884_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h1bfa5608__0)))))));
    vlSelf->__VdfgTmp_h4cbcef22__0 = (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                       << 4U) | (((IData)(wasmetal_core__DOT___017820_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017819_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___017818_)))));
    vlSelf->wasmetal_core__DOT___057771_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___017820_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                   << 2U) 
                                                                  | (((IData)(wasmetal_core__DOT___017818_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___017819_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___022711_)) 
           & (IData)(wasmetal_core__DOT___022694_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d;
        wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127595___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023751_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023750_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023749_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023748_)))) 
           ^ (((IData)(wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023684_)))));
    vlSelf->wasmetal_core__DOT___023688_ = ((IData)(vlSelf->wasmetal_core__DOT___023751_)
                                             ? (IData)(wasmetal_core__DOT___127595___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d));
    vlSelf->wasmetal_core__DOT___023756_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058901_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058708_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0))))))));
    vlSelf->wasmetal_core__DOT___023755_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d))));
    vlSelf->wasmetal_core__DOT___058871_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d))))));
    vlSelf->wasmetal_core__DOT___023754_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d))));
    vlSelf->wasmetal_core__DOT___023753_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d))));
    vlSelf->wasmetal_core__DOT___017888_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf64b2678__0)))));
    vlSelf->wasmetal_core__DOT___057838_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006933_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha11b0f77__0))));
    vlSelf->wasmetal_core__DOT___017831_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0faccffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_)))));
    vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))));
    vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))));
    vlSelf->__VdfgTmp_h96af251d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)));
    vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022628_)
            ? (IData)(vlSelf->wasmetal_core__DOT___022635_)
            : (IData)(vlSelf->wasmetal_core__DOT___022628_));
    vlSelf->wasmetal_core__DOT____Vcellout___127563___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003806_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005868_)))) 
           ^ (((IData)(wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023466_)))));
    vlSelf->wasmetal_core__DOT___023471_ = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                            & (IData)(wasmetal_core__DOT___127563___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127580___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002193_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h80016717__0))) 
           ^ (((IData)(wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023587_)))));
    vlSelf->wasmetal_core__DOT___023592_ = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                            & (IData)(wasmetal_core__DOT___127580___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d;
        wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127473___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022796_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022795_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022794_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022793_)))) 
           ^ (((IData)(wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022761_)))));
    vlSelf->wasmetal_core__DOT___022765_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022796_)
                                                   ? (IData)(wasmetal_core__DOT___127473___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))));
    vlSelf->wasmetal_core__DOT___022801_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))))));
    vlSelf->wasmetal_core__DOT___059193_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h7e209046__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)))))))))));
    vlSelf->wasmetal_core__DOT___022800_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0))))));
    vlSelf->wasmetal_core__DOT___059088_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O)))))));
    vlSelf->wasmetal_core__DOT___059170_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059165_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)))))))))));
    vlSelf->wasmetal_core__DOT___022799_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0))))));
    vlSelf->wasmetal_core__DOT___059178_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059172_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)))))))))));
    vlSelf->wasmetal_core__DOT___022798_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))))));
    vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028111_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028078_)
                  : (vlSelf->insn_x >> 0x1cU)));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034312_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034375_));
    vlSelf->wasmetal_core__DOT___128119___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028866_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028831_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT___054167_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128101___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054171_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128101___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054175_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128101___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054179_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128101___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___029078_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029077_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___029075_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___029074_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128110___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028765_)
              ? (IData)(wasmetal_core__DOT___128110___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___128110___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128110___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028765_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028764_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028762_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028761_)))) 
           ^ (((IData)(wasmetal_core__DOT___128110___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028727_)));
    vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___127890___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026687_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026686_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026684_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026683_)))) 
           ^ (((IData)(wasmetal_core__DOT___128092___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026617_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127890___CO 
        = (((IData)(vlSelf->wasmetal_core__DOT___026622_) 
            << 3U) | (IData)(wasmetal_core__DOT___128092___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT___127891___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026688_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026622_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d));
    vlSelf->wasmetal_core__DOT___054384_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054386_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054388_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054382_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127942___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027158_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027092_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026585_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000658_));
    vlSelf->wasmetal_core__DOT___054383_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054387_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054381_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127925___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026958_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026892_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127907___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hd6a330ca__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h0f13542d__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___026819_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___026818_)))) 
           ^ (((IData)(wasmetal_core__DOT___128074___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026752_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127907___CO 
        = (((IData)(vlSelf->wasmetal_core__DOT___026757_) 
            << 3U) | (IData)(wasmetal_core__DOT___128074___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT___127908___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026757_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034478_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030113_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030080_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030241_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030176_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028308_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028243_));
    vlSelf->wasmetal_core__DOT___044889_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hc8c79887__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d))))))));
    vlSelf->wasmetal_core__DOT___044865_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hc8c79887__0)))))))))));
    vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027356_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b30__05d));
    vlSelf->__VdfgTmp_hb47c9e11__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hb48e3438__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127440___O)))))));
    vlSelf->__VdfgTmp_h2914f84f__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->__VdfgTmp_hd5e33f95__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127440___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_h584814f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h5b56c921__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127440___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_));
    vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022528_));
    vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059071_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016290_)
                                                   ? (IData)(
                                                             (0xbfffffffULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))
                                                   : (IData)(
                                                             (0xffffffff40000000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))));
    wasmetal_core__DOT___017881_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014094_));
    __VdfgTmp_hf9553abf__0 = ((0x10U & ((8U >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                        << 4U)) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017846_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017828_ = (1U 
                                                & (0xcfafU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___013910_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 4U) 
                                                                              | (((IData)(wasmetal_core__DOT___014225_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014233_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(wasmetal_core__DOT___013906_)))))));
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & ((~ (IData)(
                                                              (0x30a000000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((8U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                             << 2U)) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h179d57be__0)))))))) 
                                                   & (0x11fff0ffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014094_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0xf0f335500000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x305U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013637_)))))))))))));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & ((1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))
                                                    ? 
                                                   (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014198_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(
                                                                       (0x33550f0f00000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                             << 4U) 
                                                                            | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))))) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0x335500000f0fULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))))))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (IData)(
                                                               (0xfaa330000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc1104829__0))))))))));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (0xccf05555U 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))
                                                    : 
                                                   (0x330faaaaU 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___017828_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013656_)));
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013687_)));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002472_)));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))));
    }
    vlSelf->wasmetal_core__DOT___057781_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___017848_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017846_)))))));
    vlSelf->wasmetal_core__DOT___057858_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    vlSelf->wasmetal_core__DOT___017838_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    vlSelf->wasmetal_core__DOT___057806_ = (1U & (0x5fcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057805_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00ccccf0f0aaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff33330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014232_)))))))))))))));
    wasmetal_core__DOT___017868_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    __VdfgTmp_hb5812008__0 = (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017907_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017906_))))));
    vlSelf->wasmetal_core__DOT___057790_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3f500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017906_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___017907_))))))))))));
    wasmetal_core__DOT___017870_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fffaaff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
    vlSelf->__VdfgTmp_h103cd5d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017828_));
    vlSelf->wasmetal_core__DOT___057871_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017884_)))));
    vlSelf->wasmetal_core__DOT___057876_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017819_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    vlSelf->wasmetal_core__DOT___017859_ = (1U & (IData)(
                                                         (0xf8ffffff0700ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017819_)))))))));
    vlSelf->__VdfgTmp_h2b8ef9eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057884_));
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022712_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022695_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___023890_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023890_ = wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058907_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058901_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058900_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023688_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d));
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                  >> 2U) | (IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022629_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022629_));
    vlSelf->wasmetal_core__DOT___006673_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h276936c0__0)))));
    vlSelf->wasmetal_core__DOT___050105_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___050092_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006022_))))));
    vlSelf->wasmetal_core__DOT___006676_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005770_))))));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023471_));
    vlSelf->wasmetal_core__DOT___013822_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))))));
    __VdfgTmp_h0996db4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___013764_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002631_)))))))));
    vlSelf->wasmetal_core__DOT___013763_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002630_))))));
    vlSelf->wasmetal_core__DOT___013813_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002629_))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023592_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___022880_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022880_ = wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___059177_ = (1U & (IData)((0x700000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059170_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059169_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059168_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022798_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022765_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))));
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028112_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x1dU)));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034313_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028867_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128119___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029074_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029039_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    wasmetal_core__DOT___045366_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045378_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___CO) 
                                                          >> 3U)))))));
    wasmetal_core__DOT___045375_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d)))))))));
    wasmetal_core__DOT___045387_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d)))))))));
    wasmetal_core__DOT____Vcellout___127857___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___026478_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d)) 
          << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127857___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026478_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026477_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026475_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026474_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026440_)));
    vlSelf->wasmetal_core__DOT___071283_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071282_))));
    wasmetal_core__DOT___045341_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h14b4bf2b__0))))))));
    wasmetal_core__DOT___045353_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052189_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052188_)))))))));
    wasmetal_core__DOT___045332_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052175_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045344_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052175_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___CO) 
                                                          >> 3U)))))));
    wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026689_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127891___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT___070727_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070722_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027159_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127942___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d));
    wasmetal_core__DOT____Vcellout___127873___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026586_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026585_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026583_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026582_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026515_)))));
    vlSelf->wasmetal_core__DOT___026520_ = ((IData)(vlSelf->wasmetal_core__DOT___026586_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005617_));
    vlSelf->wasmetal_core__DOT___070830_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070825_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026959_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127925___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    wasmetal_core__DOT___045927_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052567_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h7bad9dec__0))))))));
    wasmetal_core__DOT___045939_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052567_)))))))));
    wasmetal_core__DOT___045409_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbd97d07b__0)))))));
    wasmetal_core__DOT___045421_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    vlSelf->wasmetal_core__DOT___045091_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071079_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071078_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071077_))))))));
    vlSelf->wasmetal_core__DOT___045115_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071079_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071078_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071077_)))))))));
    vlSelf->wasmetal_core__DOT___045861_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005618_))))))));
    vlSelf->wasmetal_core__DOT___045885_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005618_)))))))));
    vlSelf->wasmetal_core__DOT___045881_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))))));
    vlSelf->wasmetal_core__DOT___045905_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))))));
    wasmetal_core__DOT___045918_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045930_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                          >> 3U)))))));
    __VdfgTmp_hcd9ab9ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                               >> 3U)));
    wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127908___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128670___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034477_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034476_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034532_)))));
    vlSelf->wasmetal_core__DOT___034536_ = ((IData)(vlSelf->wasmetal_core__DOT___034479_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135441___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034532_)))));
    vlSelf->wasmetal_core__DOT___046632_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030114_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030242_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127958___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027357_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027356_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027354_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027353_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027287_)))));
    vlSelf->wasmetal_core__DOT___027292_ = ((IData)(vlSelf->wasmetal_core__DOT___027357_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b31__05d));
    vlSelf->wasmetal_core__DOT___023208_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))));
    vlSelf->wasmetal_core__DOT___023207_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))));
    vlSelf->wasmetal_core__DOT___023206_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006215_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))));
    vlSelf->wasmetal_core__DOT___023205_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))));
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022473_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h3ee80f1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017830_));
    vlSelf->__VdfgTmp_h378f1a2c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017884_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017882_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___017881_))))));
    vlSelf->wasmetal_core__DOT___057865_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017881_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017882_)))));
    vlSelf->wasmetal_core__DOT___057799_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017838_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017840_)))))))));
    vlSelf->wasmetal_core__DOT___017811_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (0xaf00cfU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0))
                                                          : 
                                                         (0xff50ff30U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0)))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (2U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xefU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057806_)))));
    vlSelf->wasmetal_core__DOT___057812_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017867_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017868_)))));
    vlSelf->wasmetal_core__DOT___043053_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057843_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057835_)))))))));
    vlSelf->wasmetal_core__DOT___017861_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057843_)))))))));
    vlSelf->wasmetal_core__DOT___017863_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017910_)
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017909_)) 
                                                   & (IData)(
                                                             (0xff0aff0cffffffffULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                   | (IData)(
                                                             (0xf500f300000000ULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))));
    vlSelf->__VdfgTmp_h0aec0439__0 = (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___017870_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___017868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017867_))))));
    vlSelf->wasmetal_core__DOT___057817_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017870_)))));
    vlSelf->wasmetal_core__DOT___043052_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    vlSelf->wasmetal_core__DOT___017860_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    wasmetal_core__DOT___070582_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017888_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057871_))));
    vlSelf->wasmetal_core__DOT___070580_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))));
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022696_)
            ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022696_));
    vlSelf->wasmetal_core__DOT____Vcellout___127630___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024013_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___024017_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024017_ = wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023890_;
    }
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d));
    wasmetal_core__DOT____Vcellout___127614___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023886_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___134185___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036988_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022630_)
            ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022630_));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013814_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h0996db4e__0))))))));
    wasmetal_core__DOT___013839_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h0996db4e__0))))))));
    vlSelf->wasmetal_core__DOT___013742_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013813_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___002633_)))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127493___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022939_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___022943_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022943_ = wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022880_;
    }
    vlSelf->wasmetal_core__DOT___059187_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059178_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059177_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059176_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))))))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022799_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0))));
    wasmetal_core__DOT____Vcellout___127485___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022876_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128049___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028115_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028114_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028112_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028111_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___028114_)
                       ? (IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__)
                       : (vlSelf->insn_x >> 0x1eU)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___028078_)))));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034314_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028869_)
            ? (IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029075_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT___045355_ = ((IData)(wasmetal_core__DOT___045378_)
                                             ? ((IData)(wasmetal_core__DOT___045387_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045386_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045385_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045384_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045383_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045382_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045381_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045380_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045379_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045377_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045365_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045367_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045368_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045369_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045370_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045371_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045372_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045373_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045374_))
                                                 : (IData)(wasmetal_core__DOT___045375_))
                                             : (IData)(wasmetal_core__DOT___045366_));
    wasmetal_core__DOT___044911_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127857___CO) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O)) 
                                                         | ((6U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                  >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___071284_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071283_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___045321_ = ((IData)(wasmetal_core__DOT___045344_)
                                             ? ((IData)(wasmetal_core__DOT___045353_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045352_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045351_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045350_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045349_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045348_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045347_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045346_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045345_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045343_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045331_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045333_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045334_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045335_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045336_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045337_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045338_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045339_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045340_))
                                                 : (IData)(wasmetal_core__DOT___045341_))
                                             : (IData)(wasmetal_core__DOT___045332_));
    wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026690_)
            ? (IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___070729_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070728_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070724_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070723_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027160_)
            ? (IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d));
    vlSelf->wasmetal_core__DOT___045479_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071371_))))))));
    vlSelf->wasmetal_core__DOT___045503_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071371_)))))))));
    vlSelf->wasmetal_core__DOT___045499_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045523_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045275_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071434_))))))));
    vlSelf->wasmetal_core__DOT___045299_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071434_)))))))));
    vlSelf->wasmetal_core__DOT___045295_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___045319_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___026520_));
    vlSelf->wasmetal_core__DOT___070832_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070831_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070827_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070826_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026960_)
            ? (IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    wasmetal_core__DOT___045907_ = ((IData)(wasmetal_core__DOT___045930_)
                                     ? ((IData)(wasmetal_core__DOT___045939_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___045938_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045937_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045936_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045935_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045934_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045933_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045932_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045931_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___045929_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___045917_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045919_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045920_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045921_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045922_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045923_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045924_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045925_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045926_))
                                         : (IData)(wasmetal_core__DOT___045927_))
                                     : (IData)(wasmetal_core__DOT___045918_));
    wasmetal_core__DOT___045400_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hcd9ab9ab__0))))));
    wasmetal_core__DOT___045412_ = (1U & (0x41000041U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                        >> 1U)) 
                                                    | (IData)(__VdfgTmp_hcd9ab9ab__0))))));
    wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)))
            ? (IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034536_));
    vlSelf->wasmetal_core__DOT___030249_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))))));
    vlSelf->wasmetal_core__DOT___030248_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___030247_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___030246_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046632_));
    vlSelf->wasmetal_core__DOT____Vcellout___128238___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030117_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030116_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030114_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030113_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030116_)
                 ? (IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030080_)))));
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030244_)
            ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    wasmetal_core__DOT____Vcellout___128065___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___028309_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028244_)) 
          << 3U) | (IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128065___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028309_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028308_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028306_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028305_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___028271_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127974___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
           ^ (((IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027418_)))));
    vlSelf->wasmetal_core__DOT___027422_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027292_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b32__05d));
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022474_) 
           & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128554___O 
        = (((8U & ((~ (0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033438_)))));
    vlSelf->wasmetal_core__DOT___033443_ = ((~ (0xfef0U 
                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                                            & (IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017858_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017888_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))));
    wasmetal_core__DOT___070585_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0))));
    vlSelf->wasmetal_core__DOT___070587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057799_))));
    vlSelf->wasmetal_core__DOT___043056_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057806_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017910_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057790_))))))))))));
    vlSelf->wasmetal_core__DOT___043062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017811_))));
    wasmetal_core__DOT___017856_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017874_)
                                           ? ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xb0bbULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xf0ff4044ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))
                                           : ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xbbbb00000b00ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xffff44440f000400ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))));
    wasmetal_core__DOT___070583_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017874_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057817_))));
    vlSelf->wasmetal_core__DOT___043059_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057923_)))));
    vlSelf->wasmetal_core__DOT___043051_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016297_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127459___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022697_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022696_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022705_ = ((IData)(vlSelf->wasmetal_core__DOT___022697_)
                                             ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___022697_));
    vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024017_));
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023755_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d));
    vlSelf->__VdfgTmp_hea953bdf__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h8fda36d2__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h9c2e8d35__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127614___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_hc450b1a0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT___022639_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022643_)
                                                   ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___022643_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127451___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022643_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022630_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022629_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022628_)))) 
           ^ (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022635_)))));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013825_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                & (IData)(wasmetal_core__DOT___013839_))
                                             : (IData)(wasmetal_core__DOT___013839_));
    vlSelf->__VdfgTmp_he2ae9361__0 = (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013672_));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022943_));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022800_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0))));
    vlSelf->__VdfgTmp_h0ecf04e3__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h3e9bda10__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h601f88f8__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127485___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_h36468d91__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT____Vcellout___128655___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034315_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034314_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034313_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034312_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034375_)))));
    vlSelf->wasmetal_core__DOT___034379_ = ((IData)(vlSelf->wasmetal_core__DOT___034315_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___028836_ = ((IData)(vlSelf->wasmetal_core__DOT___028870_)
                                             ? (IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128119___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028870_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028869_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028867_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028866_)))) 
           ^ (((IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128119___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028831_)))));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029077_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___044897_ = (1U & ((IData)(wasmetal_core__DOT___044911_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044910_)
                                                    ? 
                                                   ((1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044908_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044907_)
                                                       ? 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044906_))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044907_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044908_)))
                                                     : 
                                                    (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044910_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044911_))));
    vlSelf->wasmetal_core__DOT___045047_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045023_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054162_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071282_))))));
    vlSelf->__VdfgTmp_h19b7a9a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___052705_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127891___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026691_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026690_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026689_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026688_)))) 
           ^ (((IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127891___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026622_)))));
    vlSelf->wasmetal_core__DOT___026626_ = ((IData)(vlSelf->wasmetal_core__DOT___026691_)
                                             ? (IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___045231_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045207_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070729_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___045251_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045227_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070724_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127942___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027161_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027160_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027159_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027158_)))) 
           ^ (((IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127942___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027092_)))));
    vlSelf->wasmetal_core__DOT___027096_ = ((IData)(vlSelf->wasmetal_core__DOT___027161_)
                                             ? (IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___044959_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___044935_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070832_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___044979_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___044955_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070827_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127925___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026961_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026960_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026959_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026958_)))) 
           ^ (((IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127925___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026892_)))));
    vlSelf->wasmetal_core__DOT___026896_ = ((IData)(vlSelf->wasmetal_core__DOT___026961_)
                                             ? (IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___054021_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045423_))));
    vlSelf->wasmetal_core__DOT___045389_ = ((IData)(wasmetal_core__DOT___045412_)
                                             ? ((IData)(wasmetal_core__DOT___045421_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045420_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045419_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045418_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045417_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045416_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045415_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045414_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045413_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045411_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045399_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045401_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045402_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045403_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045404_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045405_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045406_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045407_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045408_))
                                                 : (IData)(wasmetal_core__DOT___045409_))
                                             : (IData)(wasmetal_core__DOT___045400_));
    vlSelf->wasmetal_core__DOT____Vcellout___127908___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127908___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026757_)))));
    vlSelf->wasmetal_core__DOT___026761_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)))
                                             ? (IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034481_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128252___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030245_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030244_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030242_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030241_)))) 
           ^ (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030176_)))));
    vlSelf->wasmetal_core__DOT___030181_ = ((IData)(vlSelf->wasmetal_core__DOT___030245_)
                                             ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d));
    vlSelf->wasmetal_core__DOT___063288_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___CO)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063264_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063270_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063282_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->__VdfgTmp_h4ddf67d8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d)))));
    vlSelf->__VdfgTmp_h3d4d4e87__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027422_));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027359_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127441___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022475_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022473_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022472_)))) 
           ^ (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022528_)))));
    vlSelf->wasmetal_core__DOT___022532_ = ((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                            & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057372_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___057236_ = (1U & (0x3fafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff33330f0f5555ULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054929_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0ccccff00aaaaULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O))))))))))))))));
    vlSelf->wasmetal_core__DOT___057670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 2U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033443_));
    vlSelf->wasmetal_core__DOT___043060_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017858_))));
    vlSelf->wasmetal_core__DOT___043054_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017887_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057865_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070582_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057876_)))))))));
    vlSelf->wasmetal_core__DOT___043063_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))));
    vlSelf->wasmetal_core__DOT___043057_ = (1U & (IData)(
                                                         (0xffff40ff40ff4040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017849_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057781_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___070585_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017828_)))))))));
    vlSelf->__VdfgTmp_hb36cd122__0 = ((2U & ((IData)(
                                                     (0xf8ffffff0700ULL 
                                                      >> 
                                                      ((0x20U 
                                                        & ((0xefU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                           << 5U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017848_)))))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___017856_));
    vlSelf->wasmetal_core__DOT___043055_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057812_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(wasmetal_core__DOT___017856_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057858_)))))))));
    vlSelf->wasmetal_core__DOT___043036_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043040_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))))))));
}
