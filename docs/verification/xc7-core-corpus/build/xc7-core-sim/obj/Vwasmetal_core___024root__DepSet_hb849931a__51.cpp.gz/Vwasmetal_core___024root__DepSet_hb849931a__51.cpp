#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__28(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__28\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044781_;
    wasmetal_core__DOT___044781_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052874_;
    wasmetal_core__DOT___052874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053541_;
    wasmetal_core__DOT___053541_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053559_;
    wasmetal_core__DOT___053559_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053577_;
    wasmetal_core__DOT___053577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063458_;
    wasmetal_core__DOT___063458_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128410___O;
    wasmetal_core__DOT____Vcellout___128410___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___039773_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039774_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039796_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039785_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039784_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039783_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039782_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039766_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039412_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039781_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039779_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039778_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039777_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039776_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039786_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039787_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039788_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039805_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039800_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039799_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___053334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053332_))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054486_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054488_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054490_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054492_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054494_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128517___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128525___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054496_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054498_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054500_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054502_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->__VdfgTmp_ha85820a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___053333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045596_));
    vlSelf->wasmetal_core__DOT___053437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053333_))));
    vlSelf->wasmetal_core__DOT___054340_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf4000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052997_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053733_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051277_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->mem_ready) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053000_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052986_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053615_)))));
    vlSelf->wasmetal_core__DOT___053006_ = (1U & (IData)(
                                                         (0xaf2300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052989_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052988_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->mem_ready) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019414_)))))))));
    vlSelf->wasmetal_core__DOT___005723_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003030_)))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036778_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___054639_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_wide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052805_))));
    vlSelf->wasmetal_core__DOT___050363_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___050405_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050397_))));
    vlSelf->wasmetal_core__DOT___048210_ = (1U & (0xa008aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_op) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->__VdfgTmp_h360595f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->__VdfgTmp_hdc23a011__0 = (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042683_));
    vlSelf->wasmetal_core__DOT___042595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___062628_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 1U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062619_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062639_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 2U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062631_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062650_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128010___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 3U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062642_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128163___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062661_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062653_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))));
    vlSelf->wasmetal_core__DOT___062672_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 5U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062664_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062683_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 6U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062675_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062694_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128011___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 7U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128164___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062705_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 8U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062697_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))));
    vlSelf->wasmetal_core__DOT___062716_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 9U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062708_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062727_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xaU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062719_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062738_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xbU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062730_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062749_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xcU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))));
    vlSelf->wasmetal_core__DOT___062760_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xdU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062752_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062771_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xeU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062763_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062782_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128013___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xfU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062774_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128166___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062793_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x10U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062785_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))));
    vlSelf->wasmetal_core__DOT___062804_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x11U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062796_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062815_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x12U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062807_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062826_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x13U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062818_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062837_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x14U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062829_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))));
    vlSelf->wasmetal_core__DOT___062848_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x15U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062859_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x16U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062851_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062870_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x17U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062862_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062881_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x18U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062873_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))));
    vlSelf->wasmetal_core__DOT___062892_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x19U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062884_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062903_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1aU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062914_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1bU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___062925_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1cU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062917_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))));
    vlSelf->wasmetal_core__DOT___062936_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1dU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062947_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1eU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062939_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062958_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1fU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062950_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030687_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128723___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128725___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->__VdfgTmp_hb9f44c2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003028_)));
    vlSelf->__VdfgTmp_h2de6a63c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003029_));
    vlSelf->wasmetal_core__DOT___042570_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003029_)))))));
    vlSelf->wasmetal_core__DOT___070601_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003029_))));
    vlSelf->wasmetal_core__DOT___055870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055339_))));
    if (vlSelf->wasmetal_core__DOT___003033_) {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
    } else {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003033_)));
        vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003033_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                 | (4U >> (IData)(vlSelf->__VdfgTmp_hefabe8e1__0))));
    vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_hefabe8e1__0)) 
                 | (8U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))));
    vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__ 
        = (1U & (5U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)));
    vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___003030_)));
    vlSelf->wasmetal_core__DOT___049419_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049399_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0f8ff227__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28f7b227__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed4d342a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051603_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050918_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h473eb647__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1387689e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce46baf__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051682_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63b8fe6d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f9812e4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40ae3a4f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050763_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050759_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43fa682b__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbdf51c76__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b1aa625__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050654_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050650_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28b8e598__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51b306d7__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b58ae94__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050771_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050606_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6d99021a__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf4526f03__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7c61c07__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050583_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050579_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b76__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b68__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b64__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051459_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051023_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b144__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b152__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b156__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___053468_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051847_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b204__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b196__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b195__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b194__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b193__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b192__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072235_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072231_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b76__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b68__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b64__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072227_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072223_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b144__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b152__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b156__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051396_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051384_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b204__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b196__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b195__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b194__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b193__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b192__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051043_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051027_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf690becd__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6a500089__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6124d0b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050755_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050742_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9d2c329__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h745b6463__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41f0b476__0))))))))))))));
    vlSelf->wasmetal_core__DOT___053452_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053444_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b44__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b36__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b32__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___072251_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072247_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b47__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b46__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b45__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b44__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b36__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b32__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050965_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___050961_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___050942_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050941_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031341_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___063428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063007_))));
    vlSelf->wasmetal_core__DOT___051210_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050441_))));
    vlSelf->wasmetal_core__DOT___050443_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___050401_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050398_))));
    vlSelf->wasmetal_core__DOT___063825_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___010423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___054752_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___008018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->__VdfgTmp_h5c1295c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053575_));
    vlSelf->wasmetal_core__DOT___063380_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063375_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053575_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___053491_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053344_))));
    vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030722_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034179_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->__VdfgTmp_h5812bf47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007234_));
    wasmetal_core__DOT___044781_ = ((IData)(vlSelf->wasmetal_core__DOT___044804_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___044813_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___044812_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044811_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044810_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044809_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044808_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044807_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044806_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044805_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___044803_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___044791_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044793_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044794_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044795_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044796_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044797_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044798_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044799_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044800_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___044801_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___044792_));
    vlSelf->wasmetal_core__DOT___019782_ = (1U & (0xbf000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053563_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053562_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->busy) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052857_)))))));
    vlSelf->wasmetal_core__DOT___063413_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->mem_fault) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaaaffff0303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_fault)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b3__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b2__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b1__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__ADDRBWRADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT___053347_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053334_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha85820a5__0))));
    vlSelf->wasmetal_core__DOT___039819_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039798_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039797_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039780_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039411_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039775_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039794_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039793_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039791_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039790_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039801_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039804_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039806_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039795_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039413_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039789_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039817_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039813_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039811_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039803_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039810_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039809_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039812_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039808_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039814_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039815_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039821_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039818_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039802_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039414_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039807_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039816_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___036749_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036781_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___070623_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070600_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h360595f8__0)))));
    vlSelf->wasmetal_core__DOT___070604_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360595f8__0))))));
    vlSelf->wasmetal_core__DOT___005714_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003031_)) 
                                                  | ((~ (IData)(vlSelf->wasmetal_core__DOT___003032_)) 
                                                     | (IData)(
                                                               (0xfeeffffeffffefffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb9f44c2b__0)))))))));
    vlSelf->wasmetal_core__DOT___005715_ = (1U & ((~ 
                                                   (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))) 
                                                  | (IData)(
                                                            (0xfff7ff4fffffffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003033_))))))))));
    vlSelf->wasmetal_core__DOT___070612_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->wasmetal_core__DOT___070617_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003035_)))));
    vlSelf->wasmetal_core__DOT___070614_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))))));
    vlSelf->wasmetal_core__DOT___058559_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->wasmetal_core__DOT___058525_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0))))));
    vlSelf->wasmetal_core__DOT___005712_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                                                  | (IData)(
                                                            (0xff0fff77ffffffffULL 
                                                             >> 
                                                             ((0x20U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2de6a63c__0)) 
                                                                  << 5U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))))))))))));
    vlSelf->wasmetal_core__DOT___042723_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070601_))));
    vlSelf->wasmetal_core__DOT___070603_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h360595f8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070601_))));
    if (vlSelf->wasmetal_core__DOT___003035_) {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
    } else {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128722___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                                << 1U)) 
                                         | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128724___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                          << 1U) | 
                                         (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134177___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003033_)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hefabe8e1__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___037030_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___134190___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003035_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                        << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___003034_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___051686_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051043_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051031_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa693494__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7031c855__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1756308__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051035_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87f17c6b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60760575__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6239803f__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051039_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980fd1a4__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h12f13bc4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ca396d5__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050775_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050755_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050738_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ee84e09__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05fef25b__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf75b3db8__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050728_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9adc8e2b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h35252d63__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac7d774c__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050751_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb13e555e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fc63e3e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b3781b6__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053472_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053452_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053448_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051878_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___072255_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072251_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051442_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072239_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031352_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___053261_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051210_))));
    vlSelf->wasmetal_core__DOT___051218_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051210_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h66357502__0)))))));
    vlSelf->wasmetal_core__DOT___053247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___063423_ = (1U & (0xb0fffff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5c1295c2__0))))));
    vlSelf->wasmetal_core__DOT___063396_ = (1U & (IData)(
                                                         (0x11ff0000f0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063382_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7770000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063377_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13477f5c__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063380_)))))))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034180_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d));
    vlSelf->__VdfgTmp_hc2fc9f8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5812bf47__0));
    wasmetal_core__DOT___052874_ = (1U & (0x10000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___044781_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044747_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044731_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___052872_)))))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036782_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036749_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h85ffa972__0))));
    vlSelf->wasmetal_core__DOT___042546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070623_))));
    vlSelf->wasmetal_core__DOT___070618_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070604_)))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128282___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___030687_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___030686_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b2__05d) {
        vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___070631_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___070613_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070617_))));
    vlSelf->wasmetal_core__DOT___042694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___018382_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))))))))));
    vlSelf->wasmetal_core__DOT___058938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___070605_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042740_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___042581_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___070630_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058525_))));
    vlSelf->wasmetal_core__DOT___042535_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042723_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___042616_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070603_))));
    vlSelf->wasmetal_core__DOT___042646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    if (vlSelf->wasmetal_core__DOT___003028_) {
        vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___035237_));
        vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
        vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
    } else {
        vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_)));
        vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___035253_));
        vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___037030_));
    }
    vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003028_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036925_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128346___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031355_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031352_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031341_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031330_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031323_ = ((IData)(vlSelf->wasmetal_core__DOT___031355_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___052656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128290___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___030722_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___030721_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128402___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___031968_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___031967_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___034151_ = ((IData)(vlSelf->wasmetal_core__DOT___034181_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128623___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034181_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034180_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034179_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034178_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___063421_ = (1U & (0xff400000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063417_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___052874_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___052875_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044200_)))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036783_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___042591_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070618_))));
    vlSelf->wasmetal_core__DOT___042687_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O))));
    vlSelf->wasmetal_core__DOT___063468_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___063476_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___063484_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128147___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d)))))))));
    if (vlSelf->wasmetal_core__DOT__sp__05b3__05d) {
        vlSelf->wasmetal_core__DOT___030679_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___030714_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___031960_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030679_ = vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030714_ = vlSelf->wasmetal_core__DOT___128290___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031960_ = vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___042697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070631_))));
    vlSelf->wasmetal_core__DOT___042606_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070613_))));
    vlSelf->wasmetal_core__DOT___042707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___042555_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042694_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070617_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___042636_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058938_))));
    vlSelf->wasmetal_core__DOT___042626_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___042676_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070605_))));
    vlSelf->wasmetal_core__DOT___042673_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070605_))));
    vlSelf->wasmetal_core__DOT___042566_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042581_))));
    vlSelf->wasmetal_core__DOT___042664_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070630_))));
    vlSelf->wasmetal_core__DOT___042653_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070630_)))));
    vlSelf->wasmetal_core__DOT___042656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___042722_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042616_)
                                                         ? 
                                                        (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042723_))))));
    vlSelf->wasmetal_core__DOT___042643_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042646_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042723_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070604_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128723___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035237_)));
    vlSelf->wasmetal_core__DOT____Vcellout___128725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((IData)(vlSelf->wasmetal_core__DOT___003029_)
                        ? (IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__)
                        : (~ (IData)(vlSelf->wasmetal_core__DOT___003029_))) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___128725___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035253_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134178___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128723___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134178___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036925_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134191___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128725___S) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___003029_)) 
                       | (IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(vlSelf->wasmetal_core__DOT___134191___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___037030_)));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031356_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031323_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O))));
    vlSelf->wasmetal_core__DOT___063457_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___011157_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->__VdfgTmp_h394cead1__0 = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                             << 3U)) 
                                      | (7U & (~ (7U 
                                                  & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                     >> 1U)))));
    vlSelf->__VdfgTmp_h46d848cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010077_));
    vlSelf->wasmetal_core__DOT___012929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010378_))));
    vlSelf->wasmetal_core__DOT___056504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)))));
    vlSelf->wasmetal_core__DOT___056535_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___011976_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___009681_ = (1U & (0x347U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___019781_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052861_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050454_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053565_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052875_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050389_)))));
    wasmetal_core__DOT___053541_ = (1U & (0x40ffU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___052875_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___063394_ = (1U & (0xbffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063392_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052875_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___052877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052875_))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036784_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h13987860__0))));
    vlSelf->wasmetal_core__DOT___042682_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___042595_)
                                                      ? 
                                                     ((1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hdc23a011__0)))
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___042687_) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042591_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___042683_))
                                                      : 
                                                     (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___042590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___070632_))))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b4__05d) {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030679_;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030714_;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031960_;
    }
    vlSelf->wasmetal_core__DOT___042693_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042697_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042694_))))));
    vlSelf->wasmetal_core__DOT___042713_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                                                         ? 
                                                        (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                                         : 
                                                        (0xeU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___070631_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___042694_))))))));
    vlSelf->wasmetal_core__DOT___042704_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042707_))));
    vlSelf->wasmetal_core__DOT___042739_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042740_))))));
    vlSelf->wasmetal_core__DOT___016504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    vlSelf->wasmetal_core__DOT___042749_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042626_))));
    if (vlSelf->wasmetal_core__DOT___042539_) {
        vlSelf->wasmetal_core__DOT___042587_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042576_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042534_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042554_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042622_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042564_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042612_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042601_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042632_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
    } else {
        vlSelf->wasmetal_core__DOT___042587_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___042595_)
                                                    ? 
                                                   (5U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hdc23a011__0))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___042590_)));
        if (vlSelf->wasmetal_core__DOT___042542_) {
            if (vlSelf->wasmetal_core__DOT___042541_) {
                if (vlSelf->wasmetal_core__DOT___042536_) {
                    vlSelf->wasmetal_core__DOT___042576_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042534_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042554_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042622_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042564_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042612_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042601_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                    vlSelf->wasmetal_core__DOT___042632_ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                } else {
                    vlSelf->wasmetal_core__DOT___042576_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042581_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___042740_))));
                    vlSelf->wasmetal_core__DOT___042534_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042546_)
                                  ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___042535_)));
                    vlSelf->wasmetal_core__DOT___042554_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042558_)
                                  ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___042555_)));
                    vlSelf->wasmetal_core__DOT___042622_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                                  ? (1U >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___042673_))));
                    vlSelf->wasmetal_core__DOT___042564_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                                 | (IData)(vlSelf->wasmetal_core__DOT___042566_)));
                    vlSelf->wasmetal_core__DOT___042612_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042616_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___042643_))));
                    vlSelf->wasmetal_core__DOT___042601_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___042704_))));
                    vlSelf->wasmetal_core__DOT___042632_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___042749_))));
                }
            } else {
                vlSelf->wasmetal_core__DOT___042576_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042534_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042554_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042622_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042564_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042612_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042601_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
                vlSelf->wasmetal_core__DOT___042632_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___042576_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042534_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042554_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042622_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042564_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042612_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042601_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
            vlSelf->wasmetal_core__DOT___042632_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        }
    }
    vlSelf->wasmetal_core__DOT___042731_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042672_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042676_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042673_))))));
    vlSelf->wasmetal_core__DOT___042662_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042570_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042664_))))));
    vlSelf->wasmetal_core__DOT___042652_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042656_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042653_))))));
    vlSelf->wasmetal_core__DOT___048117_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042722_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042534_))));
    vlSelf->wasmetal_core__DOT___042642_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042646_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135049___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042643_))))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031357_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___056530_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h394cead1__0))));
    vlSelf->__VdfgTmp_h0812d53d__0 = ((0x10U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                << 4U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h394cead1__0));
    vlSelf->wasmetal_core__DOT___056543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011976_))));
    vlSelf->wasmetal_core__DOT___019778_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053259_)))));
    vlSelf->wasmetal_core__DOT___019777_ = (1U & (0xb000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072258_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053259_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))));
    wasmetal_core__DOT___053559_ = (1U & (IData)((0xaa3f000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___038870_)))))))));
    vlSelf->wasmetal_core__DOT___000000_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052877_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->reset)))));
    vlSelf->wasmetal_core__DOT___052918_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052877_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___045525_)))));
    vlSelf->wasmetal_core__DOT___036753_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036785_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___047991_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042587_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128180___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029608_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b5__05d) {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___042703_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042707_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042704_))))));
    vlSelf->wasmetal_core__DOT___048121_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042554_))));
    vlSelf->wasmetal_core__DOT___048130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042576_))));
    vlSelf->wasmetal_core__DOT___042748_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042749_))))));
    vlSelf->__VdfgTmp_h4702c863__0 = (((IData)(vlSelf->wasmetal_core__DOT___042731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042622_));
    vlSelf->__VdfgTmp_h08bc6edf__0 = (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042612_));
    vlSelf->wasmetal_core__DOT___048118_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048117_)))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128171___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029502_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___056534_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036786_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036753_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___058528_ = (1U & (0xf44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff007fffffffffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)))))))))) 
                                                             << 1U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb9f44c2b__0)))))))))))));
    vlSelf->wasmetal_core__DOT___047992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042662_)))));
    vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128283___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030679_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b6__05d) {
        wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b6__05d;
    } else {
        wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___048119_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042601_))));
    vlSelf->wasmetal_core__DOT___047995_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042601_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042693_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))));
    vlSelf->wasmetal_core__DOT___017940_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048130_)))));
    vlSelf->wasmetal_core__DOT___048131_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042748_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042632_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128347___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031359_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031358_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031357_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031356_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031323_)))));
    vlSelf->wasmetal_core__DOT___031327_ = ((IData)(vlSelf->wasmetal_core__DOT___031359_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128291___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030714_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128403___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031960_)))));
    vlSelf->wasmetal_core__DOT___011156_ = (1U & (IData)(
                                                         (0xffff800000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056534_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                                                << 4U)) 
                                                                                | (0xfU 
                                                                                & ((0xcU 
                                                                                & ((~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & (~ 
                                                                                (7U 
                                                                                & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___034151_))) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056530_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___048132_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048130_))));
    vlSelf->wasmetal_core__DOT___047994_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x77707770777ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___042672_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042576_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042534_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047992_))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029608_));
    vlSelf->wasmetal_core__DOT___063492_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___063500_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___063508_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___063516_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128148___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___030683_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030683_));
    vlSelf->wasmetal_core__DOT___030718_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___128291___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030718_));
    vlSelf->wasmetal_core__DOT___031964_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031964_));
    vlSelf->wasmetal_core__DOT___048125_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 2U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017176_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128723___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xff7f7fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134178___O) 
                                                                         << 3U)) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134191___O) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h08bc6edf__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128725___O))))))));
    vlSelf->wasmetal_core__DOT___017171_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                                >> 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 3U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___017186_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xffff07770777ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                                >> 2U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017924_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O))))))));
    vlSelf->wasmetal_core__DOT___017185_ = (1U & (0xf0f55ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128722___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((0x777U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134190___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048117_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134177___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128724___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02ewide = (1U 
                                                & (0xff4f4fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x77770007U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048121_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048118_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048119_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xfffdf3ffffffffffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003033_)))))))))))))));
    vlSelf->wasmetal_core__DOT___032034_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    vlSelf->wasmetal_core__DOT___032033_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047995_))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031327_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029502_));
    wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036757_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    vlSelf->wasmetal_core__DOT___058549_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___018178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048131_))));
    vlSelf->__VdfgTmp_h2a482fa4__0 = (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048486_));
    vlSelf->wasmetal_core__DOT___048115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___047996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___048397_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047994_))));
    vlSelf->wasmetal_core__DOT___063439_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048393_))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b9__05d) {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___048128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017176_))));
    vlSelf->__VdfgTmp_h8bd952af__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->__VdfgTmp_he1590a3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017185_));
    vlSelf->__VdfgTmp_h10c9b581__0 = (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT___019044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018382_))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032033_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134153___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036758_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036757_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036787_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036786_)))) 
           ^ (((IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036753_)))));
    vlSelf->wasmetal_core__DOT___036726_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036758_)
                                                   ? (IData)(wasmetal_core__DOT___134153___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->wasmetal_core__DOT___019019_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016504_))));
    vlSelf->wasmetal_core__DOT___019074_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___050400_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___052659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___050359_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0))))));
    vlSelf->wasmetal_core__DOT___051217_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047994_))))));
    vlSelf->wasmetal_core__DOT___048133_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048116_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048115_))));
    vlSelf->wasmetal_core__DOT___007871_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048394_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h508bc82d__0))))))));
    vlSelf->wasmetal_core__DOT___053480_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050363_)))))))));
    vlSelf->wasmetal_core__DOT___072273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062496_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053488_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072270_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053014_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051199_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052895_)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053487_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___070488_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063439_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044240_))))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b10__05d) {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b10__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___016506_ = (1U & (0xfe3fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017924_)))))));
    vlSelf->wasmetal_core__DOT___048960_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017171_)))));
    vlSelf->wasmetal_core__DOT___058930_ = (1U & (0x6000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))));
    vlSelf->wasmetal_core__DOT___048129_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048128_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___060571_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))));
    vlSelf->wasmetal_core__DOT___017174_ = (1U & (IData)(
                                                         (0xc0f01f0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048125_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10c9b581__0))))))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032034_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___032026_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032026_));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___032030_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031331_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036759_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036726_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___050406_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050400_))));
    vlSelf->wasmetal_core__DOT___050445_ = (1U & (IData)(
                                                         (0x2220fff00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___052660_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052659_))));
    vlSelf->wasmetal_core__DOT___050364_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___051224_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050443_)))));
    vlSelf->wasmetal_core__DOT___051204_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___051202_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___051219_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051217_))));
    vlSelf->wasmetal_core__DOT___052655_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128181___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029608_)))));
    vlSelf->wasmetal_core__DOT___029612_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128284___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030683_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b11__05d) {
        vlSelf->wasmetal_core__DOT___030656_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___030691_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
        vlSelf->wasmetal_core__DOT___031937_ = vlSelf->wasmetal_core__DOT__sp__05b11__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030656_ = vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030691_ = wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031937_ = vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___005669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT___014613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___048134_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___060573_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060571_))));
    vlSelf->wasmetal_core__DOT___019194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017174_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128348___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031332_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031331_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031361_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031360_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031327_)))));
    vlSelf->wasmetal_core__DOT___031300_ = ((IData)(vlSelf->wasmetal_core__DOT___031332_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128172___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
           ^ (((IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029502_)))));
    vlSelf->wasmetal_core__DOT___029506_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128172___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128292___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(wasmetal_core__DOT___128292___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030718_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128404___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031964_)))));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036760_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___050459_ = (1U & (IData)(
                                                         (0xff00ffff07000707ULL 
                                                          >> 
                                                          (((IData)(vlSelf->reset) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050445_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048115_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050443_)))))))));
    vlSelf->wasmetal_core__DOT___053088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053087_))));
    vlSelf->wasmetal_core__DOT___052679_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052660_))));
    vlSelf->wasmetal_core__DOT___052684_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050363_)))));
    vlSelf->wasmetal_core__DOT___050380_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050364_))));
    vlSelf->wasmetal_core__DOT___050365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___051239_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051204_))));
    vlSelf->wasmetal_core__DOT___051205_ = (1U & (0xccca0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051201_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051200_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051199_)))))));
    vlSelf->wasmetal_core__DOT___051226_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051202_))));
    vlSelf->wasmetal_core__DOT___051225_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->wasmetal_core__DOT___053366_ = (1U & (IData)(
                                                         (0x40ff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053261_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053260_)))))))));
    vlSelf->wasmetal_core__DOT___052658_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052655_))));
    vlSelf->wasmetal_core__DOT___063524_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___063532_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___063540_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___063548_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128149___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029612_));
    if (vlSelf->wasmetal_core__DOT__sp__05b12__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
        vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b12__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030656_;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030691_;
        vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031937_;
    }
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048133_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048134_))));
    vlSelf->__VdfgTmp_hf36d9f62__0 = (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048133_));
    wasmetal_core__DOT____Vcellout___128410___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032034_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032033_)))) 
                                                   ^ 
                                                   (1U 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__0__KET__) 
                                                             << 1U)))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031333_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031300_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029506_));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036761_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    vlSelf->wasmetal_core__DOT___053097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053088_))));
    vlSelf->wasmetal_core__DOT___052863_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052860_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))));
    vlSelf->wasmetal_core__DOT___072279_ = (1U & (IData)(
                                                         (0xb000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054340_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053619_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052918_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052914_)))))))));
    vlSelf->wasmetal_core__DOT___050382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050380_))));
    vlSelf->wasmetal_core__DOT___000130_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->reset)))));
    vlSelf->wasmetal_core__DOT___053098_ = (1U & (0xfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053094_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->wasmetal_core__DOT___053621_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___051228_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053359_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___053493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))));
    vlSelf->wasmetal_core__DOT___053494_ = (1U & (0x2fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053091_))))));
    vlSelf->wasmetal_core__DOT___053499_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052847_)))));
    vlSelf->wasmetal_core__DOT___053576_ = (1U & (IData)(
                                                         (0x40400000ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c1295c2__0))))))));
    vlSelf->wasmetal_core__DOT___051230_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___052657_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051226_))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b13__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___006127_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))));
    vlSelf->wasmetal_core__DOT___063466_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128410___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063474_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063482_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063455_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128410___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___036730_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036762_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___053254_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052863_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051219_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053007_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053006_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053005_)))))))));
    vlSelf->wasmetal_core__DOT___053504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053493_))));
    vlSelf->wasmetal_core__DOT___039855_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053260_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    wasmetal_core__DOT___053577_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052658_))));
    vlSelf->wasmetal_core__DOT___053431_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053345_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
    vlSelf->wasmetal_core__DOT___053570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xe0c0c0cU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                   << 2U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___053364_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053259_))));
    vlSelf->wasmetal_core__DOT___072276_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072274_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072273_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053480_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)))))))))));
    vlSelf->wasmetal_core__DOT___052688_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b14__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___017494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___063467_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063465_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063475_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063473_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063483_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063482_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063481_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    wasmetal_core__DOT___063458_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (vlSelf->cmd_index 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf38f2779U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009510_)))))))));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031335_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036763_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036730_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___019775_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053475_))));
    vlSelf->wasmetal_core__DOT___039856_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039854_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039857_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___019783_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053493_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xbf000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                                     << 5U) 
                                                                    | (((IData)(wasmetal_core__DOT___053559_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052883_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053364_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128182___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029612_)))));
    vlSelf->wasmetal_core__DOT___029585_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128285___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030656_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b15__05d) {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___030695_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___031941_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030695_ = wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031941_ = wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___063462_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128349___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031336_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031335_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031334_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031300_)))));
    vlSelf->wasmetal_core__DOT___031304_ = ((IData)(vlSelf->wasmetal_core__DOT___031336_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128173___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           ^ (((IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029506_)))));
    vlSelf->wasmetal_core__DOT___029479_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128293___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030691_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128405___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031937_)))));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036764_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___063556_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___063564_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___063572_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___063580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029585_));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030660_));
    vlSelf->wasmetal_core__DOT____Vcellout___128411___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032026_)))));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031304_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
}
