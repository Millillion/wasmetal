#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__25(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__25\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006634_;
    wasmetal_core__DOT___006634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006636_;
    wasmetal_core__DOT___006636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006743_;
    wasmetal_core__DOT___006743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006928_;
    wasmetal_core__DOT___006928_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006929_;
    wasmetal_core__DOT___006929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013636_;
    wasmetal_core__DOT___013636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013676_;
    wasmetal_core__DOT___013676_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013726_;
    wasmetal_core__DOT___013726_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013906_;
    wasmetal_core__DOT___013906_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013910_;
    wasmetal_core__DOT___013910_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014191_;
    wasmetal_core__DOT___014191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014225_;
    wasmetal_core__DOT___014225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014226_;
    wasmetal_core__DOT___014226_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014260_;
    wasmetal_core__DOT___014260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014261_;
    wasmetal_core__DOT___014261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014262_;
    wasmetal_core__DOT___014262_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014268_;
    wasmetal_core__DOT___014268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014270_;
    wasmetal_core__DOT___014270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014271_;
    wasmetal_core__DOT___014271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014272_;
    wasmetal_core__DOT___014272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014280_;
    wasmetal_core__DOT___014280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017818_;
    wasmetal_core__DOT___017818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017820_;
    wasmetal_core__DOT___017820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017868_;
    wasmetal_core__DOT___017868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017870_;
    wasmetal_core__DOT___017870_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017881_;
    wasmetal_core__DOT___017881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022514_;
    wasmetal_core__DOT___022514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022660_;
    wasmetal_core__DOT___022660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022694_;
    wasmetal_core__DOT___022694_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022730_;
    wasmetal_core__DOT___022730_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023457_;
    wasmetal_core__DOT___023457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023578_;
    wasmetal_core__DOT___023578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023680_;
    wasmetal_core__DOT___023680_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023744_;
    wasmetal_core__DOT___023744_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023745_;
    wasmetal_core__DOT___023745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023746_;
    wasmetal_core__DOT___023746_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023747_;
    wasmetal_core__DOT___023747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029496_;
    wasmetal_core__DOT___029496_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029602_;
    wasmetal_core__DOT___029602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031954_;
    wasmetal_core__DOT___031954_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032016_;
    wasmetal_core__DOT___032016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032020_;
    wasmetal_core__DOT___032020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044781_;
    wasmetal_core__DOT___044781_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044911_;
    wasmetal_core__DOT___044911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050127_;
    wasmetal_core__DOT___050127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050128_;
    wasmetal_core__DOT___050128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050146_;
    wasmetal_core__DOT___050146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050148_;
    wasmetal_core__DOT___050148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050151_;
    wasmetal_core__DOT___050151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051561_;
    wasmetal_core__DOT___051561_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052874_;
    wasmetal_core__DOT___052874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053541_;
    wasmetal_core__DOT___053541_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053559_;
    wasmetal_core__DOT___053559_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057737_;
    wasmetal_core__DOT___057737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057740_;
    wasmetal_core__DOT___057740_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057758_;
    wasmetal_core__DOT___057758_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058877_;
    wasmetal_core__DOT___058877_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059083_;
    wasmetal_core__DOT___059083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059094_;
    wasmetal_core__DOT___059094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059095_;
    wasmetal_core__DOT___059095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059141_;
    wasmetal_core__DOT___059141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063240_;
    wasmetal_core__DOT___063240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063246_;
    wasmetal_core__DOT___063246_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063252_;
    wasmetal_core__DOT___063252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063258_;
    wasmetal_core__DOT___063258_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063368_;
    wasmetal_core__DOT___063368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063586_;
    wasmetal_core__DOT___063586_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063594_;
    wasmetal_core__DOT___063594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063602_;
    wasmetal_core__DOT___063602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063610_;
    wasmetal_core__DOT___063610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063618_;
    wasmetal_core__DOT___063618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063626_;
    wasmetal_core__DOT___063626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063634_;
    wasmetal_core__DOT___063634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063642_;
    wasmetal_core__DOT___063642_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063650_;
    wasmetal_core__DOT___063650_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063658_;
    wasmetal_core__DOT___063658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063666_;
    wasmetal_core__DOT___063666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063674_;
    wasmetal_core__DOT___063674_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127437___O;
    wasmetal_core__DOT____Vcellout___127437___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127482___O;
    wasmetal_core__DOT____Vcellout___127482___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127483___O;
    wasmetal_core__DOT____Vcellout___127483___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127611___O;
    wasmetal_core__DOT____Vcellout___127611___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127612___O;
    wasmetal_core__DOT____Vcellout___127612___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127857___CO;
    wasmetal_core__DOT____Vcellout___127857___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127873___O;
    wasmetal_core__DOT____Vcellout___127873___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127973___O;
    wasmetal_core__DOT____Vcellout___127973___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___O;
    wasmetal_core__DOT____Vcellout___128065___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___CO;
    wasmetal_core__DOT____Vcellout___128065___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128289___O;
    wasmetal_core__DOT____Vcellout___128289___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128415___O;
    wasmetal_core__DOT____Vcellout___128415___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128416___O;
    wasmetal_core__DOT____Vcellout___128416___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128417___O;
    wasmetal_core__DOT____Vcellout___128417___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h5ef591ab__0;
    __VdfgTmp_h5ef591ab__0 = 0;
    CData/*1:0*/ __VdfgTmp_h7052d05f__0;
    __VdfgTmp_h7052d05f__0 = 0;
    CData/*2:0*/ __VdfgTmp_hae3c9710__0;
    __VdfgTmp_hae3c9710__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0ec09017__0;
    __VdfgTmp_h0ec09017__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8aee5dd6__0;
    __VdfgTmp_h8aee5dd6__0 = 0;
    CData/*2:0*/ __VdfgTmp_h49f92928__0;
    __VdfgTmp_h49f92928__0 = 0;
    CData/*1:0*/ __VdfgTmp_h857f834a__0;
    __VdfgTmp_h857f834a__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ede2138__0;
    __VdfgTmp_h3ede2138__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9b6b58da__0;
    __VdfgTmp_h9b6b58da__0 = 0;
    CData/*1:0*/ __VdfgTmp_hda5b9960__0;
    __VdfgTmp_hda5b9960__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfdee4508__0;
    __VdfgTmp_hfdee4508__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1bfa5608__0;
    __VdfgTmp_h1bfa5608__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf9553abf__0;
    __VdfgTmp_hf9553abf__0 = 0;
    CData/*5:0*/ __VdfgTmp_hb5812008__0;
    __VdfgTmp_hb5812008__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc8c79887__0;
    __VdfgTmp_hc8c79887__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___045521_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071364_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071363_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071362_)))))))));
    vlSelf->wasmetal_core__DOT___045293_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071427_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071426_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071425_))))))));
    vlSelf->wasmetal_core__DOT___045317_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071427_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071426_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071425_)))))))));
    vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026578_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026511_)
            : (IData)(vlSelf->wasmetal_core__DOT___000521_));
    vlSelf->wasmetal_core__DOT____Vcellout___128352___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031349_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031348_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031347_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031346_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031313_)))));
    vlSelf->wasmetal_core__DOT___031317_ = ((IData)(vlSelf->wasmetal_core__DOT___031349_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034340_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034505_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128662___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127956___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027348_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027347_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027346_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027345_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027278_)))));
    vlSelf->wasmetal_core__DOT___027283_ = ((IData)(vlSelf->wasmetal_core__DOT___027348_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b23__05d));
    wasmetal_core__DOT___044781_ = ((IData)(vlSelf->wasmetal_core__DOT___044804_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___044813_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___044812_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044811_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044810_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044809_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044808_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044807_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044806_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044805_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___044803_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___044791_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044793_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044794_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044795_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044796_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044797_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044798_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044799_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044800_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___044801_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___044792_));
    vlSelf->wasmetal_core__DOT___053505_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffff44f400000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053498_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052845_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052847_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053499_))));
    vlSelf->wasmetal_core__DOT___072276_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072274_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072273_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053480_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)))))))))));
    vlSelf->wasmetal_core__DOT___053365_ = (1U & (IData)(
                                                         (0x10ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053354_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052849_)))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))))))));
    vlSelf->wasmetal_core__DOT___052855_ = (1U & (IData)(
                                                         (0xff40404000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052848_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052650_)))))))));
    wasmetal_core__DOT___063368_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052849_)))));
    wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033429_));
    wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030110_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030238_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    vlSelf->wasmetal_core__DOT___063652_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___063660_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___063668_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___063676_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128153___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029598_));
    wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023800_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d));
    vlSelf->__VdfgTmp_h79e73f20__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_ha15895e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h8b95dc84__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_ha7391b06__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127610___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023873_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024000_;
        wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT____Vcellout___127437___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he473afc4__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022510_)))));
    wasmetal_core__DOT___022514_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013771_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022813_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))));
    vlSelf->__VdfgTmp_h4b2bd90e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_));
    vlSelf->__VdfgTmp_hbed85956__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_hedc0f726__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_he0f48724__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127481___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022863_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022926_;
        wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___013909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057743_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057742_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127466___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013694_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hfe0efeb9__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022726_)))));
    wasmetal_core__DOT___022730_ = ((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005889_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT____Vcellout___127457___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005745_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022656_)))));
    wasmetal_core__DOT___022660_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___063586_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063594_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063602_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063610_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128414___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032011_));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026471_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d));
    wasmetal_core__DOT___063240_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063246_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063252_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063258_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128064___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028305_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028271_)
            : (IData)(vlSelf->wasmetal_core__DOT___028240_));
    vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026579_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000543_));
    vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031350_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031317_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128646___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034342_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034341_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034340_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034339_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___034341_) 
                & (IData)(vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034401_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128662___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034507_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha80d5d1f__0))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                & (IData)(wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128662___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034562_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127972___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
           ^ (((IData)(wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027409_)))));
    vlSelf->wasmetal_core__DOT___027413_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127972___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027349_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027283_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b24__05d));
    wasmetal_core__DOT___052874_ = (1U & (0x10000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052873_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___044781_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044747_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044731_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___052872_)))))));
    vlSelf->wasmetal_core__DOT___053370_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053364_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053362_)))))));
    vlSelf->wasmetal_core__DOT___063426_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h93f3e051__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128176___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
           ^ (((IData)(wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029487_)))));
    vlSelf->wasmetal_core__DOT___029492_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128176___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b26__05d) {
        wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b26__05d;
    } else {
        wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b27__05d) {
        vlSelf->wasmetal_core__DOT___030708_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
        wasmetal_core__DOT___031954_ = vlSelf->wasmetal_core__DOT__sp__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030708_ = wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___031954_ = vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128296___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(wasmetal_core__DOT___128296___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030704_)))));
    wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030111_)
            ? (IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030239_)
            ? (IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b28__05d) {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
        wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030673_;
        wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030708_;
        wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___031954_;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127592___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023796_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023785_)))) 
           ^ (((IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023711_)))));
    vlSelf->wasmetal_core__DOT___023738_ = ((IData)(vlSelf->wasmetal_core__DOT___023801_)
                                             ? (IData)(wasmetal_core__DOT___127592___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d));
    vlSelf->wasmetal_core__DOT___023743_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___058878_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d))));
    vlSelf->wasmetal_core__DOT___023742_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d))));
    vlSelf->wasmetal_core__DOT___058706_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0))))));
    vlSelf->wasmetal_core__DOT___023803_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d))));
    vlSelf->wasmetal_core__DOT___058870_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))))));
    vlSelf->wasmetal_core__DOT___058924_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0))))));
    vlSelf->wasmetal_core__DOT___058707_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___023802_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d))));
    vlSelf->__VdfgTmp_h6e06acca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_he245418c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_he137fc3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127437___O)))))));
    vlSelf->__VdfgTmp_hd90860df__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127437___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_h6f6c5c03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hbedf9838__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127437___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003806_) 
           & (IData)(wasmetal_core__DOT___022514_));
    vlSelf->wasmetal_core__DOT____Vcellout___127577___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h81ac2e72__0))) 
           ^ (((IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023574_)))));
    wasmetal_core__DOT___023578_ = ((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                    & (IData)(wasmetal_core__DOT___127577___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127470___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022814_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022813_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022811_)))) 
           ^ (((IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022779_)))));
    vlSelf->wasmetal_core__DOT___022783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022814_)
                                                   ? (IData)(wasmetal_core__DOT___127470___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))));
    vlSelf->wasmetal_core__DOT___022788_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))));
    vlSelf->wasmetal_core__DOT___059183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059191_ = (1U & (1U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5774c299__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))));
    vlSelf->wasmetal_core__DOT___022787_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))));
    vlSelf->wasmetal_core__DOT___059168_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    wasmetal_core__DOT___059083_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___022816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))))));
    vlSelf->wasmetal_core__DOT___059169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___022815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))))));
    vlSelf->wasmetal_core__DOT___022697_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___057741_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___002472_)))) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_haeb5561e__0)))))))));
    vlSelf->wasmetal_core__DOT___013698_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87a694d3__0))))))));
    vlSelf->__VdfgTmp_h8f0bea78__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013694_));
    wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013668_) 
           & (IData)(wasmetal_core__DOT___022730_));
    vlSelf->wasmetal_core__DOT____Vcellout___127560___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005955_)))) 
           ^ (((IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023453_)))));
    wasmetal_core__DOT___023457_ = ((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                    & (IData)(wasmetal_core__DOT___127560___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___022627_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006952_))));
    vlSelf->wasmetal_core__DOT___006631_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(wasmetal_core__DOT___022660_));
    vlSelf->wasmetal_core__DOT___063587_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063586_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063585_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063595_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063593_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063603_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063602_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063601_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063611_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063609_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026472_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d));
    vlSelf->wasmetal_core__DOT___063243_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063240_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063239_)))))));
    vlSelf->wasmetal_core__DOT___063249_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063245_)))))));
    vlSelf->wasmetal_core__DOT___063255_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063252_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063251_)))))));
    vlSelf->wasmetal_core__DOT___063261_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063258_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063257_)))))));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028306_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028241_));
    wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026580_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000565_));
    vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031351_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___044887_ = (1U & (IData)(
                                                         (0x8000400020001fULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d))))))));
    vlSelf->wasmetal_core__DOT___044863_ = (1U & (IData)(
                                                         (0xa220fbbafffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h7aa341ef__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027413_));
    vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027350_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b25__05d));
    vlSelf->wasmetal_core__DOT___063421_ = (1U & (0xff400000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063417_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___052874_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___052875_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044200_)))));
    vlSelf->wasmetal_core__DOT___019804_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128408___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031950_)))));
    wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029492_));
    wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d)) 
           & (IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128237___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030112_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030111_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030110_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030109_)))) 
           ^ (((IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030076_)))));
    vlSelf->wasmetal_core__DOT___030080_ = ((IData)(vlSelf->wasmetal_core__DOT___030112_)
                                             ? (IData)(wasmetal_core__DOT___128237___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128251___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030240_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030239_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030238_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030237_)))) 
           ^ (((IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030172_)))));
    vlSelf->wasmetal_core__DOT___030176_ = ((IData)(vlSelf->wasmetal_core__DOT___030240_)
                                             ? (IData)(wasmetal_core__DOT___128251___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128289___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       : (IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128289___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___030673_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___023877_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023877_ = wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023802_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023738_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d));
    vlSelf->wasmetal_core__DOT___023221_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003807_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_he137fc3d__0)))));
    vlSelf->wasmetal_core__DOT___023220_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd90860df__0))));
    vlSelf->wasmetal_core__DOT___023219_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003808_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6f6c5c03__0)))));
    vlSelf->wasmetal_core__DOT___023218_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbedf9838__0))));
    wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057748_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013771_))));
    vlSelf->wasmetal_core__DOT___057747_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013798_))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013805_) 
           & (IData)(wasmetal_core__DOT___023578_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
        vlSelf->wasmetal_core__DOT___022867_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d;
    } else {
        wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022867_ = wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059089_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059083_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059082_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)))))))))));
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022815_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022783_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he0f48724__0))));
    wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013670_) 
           & (IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006683_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xceU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d))))
                                                      : 
                                                     (0xf0f0fef0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005653_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))))))));
    vlSelf->__VdfgTmp_h90f032b2__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127560___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005711_) 
           & (IData)(wasmetal_core__DOT___023457_));
    wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127856___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026473_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026472_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026471_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026470_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026436_)))));
    vlSelf->wasmetal_core__DOT___026440_ = ((IData)(vlSelf->wasmetal_core__DOT___026473_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d));
    vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028308_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028243_));
    vlSelf->wasmetal_core__DOT____Vcellout___127872___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026581_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026580_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026579_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026578_)))) 
           ^ (((IData)(wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127872___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026511_)))));
    vlSelf->wasmetal_core__DOT___026515_ = ((IData)(vlSelf->wasmetal_core__DOT___026581_)
                                             ? (IData)(wasmetal_core__DOT___127872___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000592_));
    vlSelf->wasmetal_core__DOT____Vcellout___128353___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031354_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031353_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031351_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031350_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___031353_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128353___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031317_)))));
    wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027351_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b26__05d));
    vlSelf->wasmetal_core__DOT___063424_ = (1U & (IData)(
                                                         (0xff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->insn_valid) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048392_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x22330a0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063414_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063418_)))))))));
    vlSelf->wasmetal_core__DOT___019781_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052861_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050454_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053565_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052875_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050389_)))));
    wasmetal_core__DOT___053541_ = (1U & (0x40ffU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___052875_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___063394_ = (1U & (0xbffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063392_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052875_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___052877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052875_))));
    wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128552___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128552___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033429_)))));
    vlSelf->wasmetal_core__DOT___033434_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                                            & (IData)(wasmetal_core__DOT___128552___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030113_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030080_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030241_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030176_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128186___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
           ^ (((IData)(wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128186___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029598_)))));
    wasmetal_core__DOT___029602_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128288___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128186___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063684_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___063692_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___063700_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___063708_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128154___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127627___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127627___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024000_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___024004_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024004_ = wasmetal_core__DOT___127627___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023877_;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023803_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d));
    wasmetal_core__DOT____Vcellout___127611___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127611___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023873_)))));
    wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
           & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___057758_ = (1U & (IData)((0x8acfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057755_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057747_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127577___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                << 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002635_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127490___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127490___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022926_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) {
        vlSelf->wasmetal_core__DOT___022930_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022930_ = wasmetal_core__DOT___127490___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022867_;
    }
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022816_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0))));
    wasmetal_core__DOT____Vcellout___127482___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127482___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022863_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013672_) 
             << 2U) | (IData)(vlSelf->__VdfgTmp_hf8096cfd__0)) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                & (IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127467___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022730_)))));
    vlSelf->wasmetal_core__DOT___006706_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006683_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006151_))))))))));
    wasmetal_core__DOT___006743_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h90f032b2__0))))))));
    wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006215_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127458___O 
        = ((IData)(vlSelf->__VdfgTmp_h68317e95__0) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                & (IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127458___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022660_)))));
    wasmetal_core__DOT____Vcellout___128415___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128415___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032011_)))));
    wasmetal_core__DOT___032016_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)
                                     : (IData)(wasmetal_core__DOT___128415___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044910_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                                                  << 1U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                          >> 2U)))))))));
    wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026474_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026440_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d));
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___045498_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071367_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071366_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071365_))))))));
    vlSelf->wasmetal_core__DOT___045522_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071367_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071366_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071365_)))))))));
    vlSelf->wasmetal_core__DOT___045294_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071430_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071429_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071428_))))))));
    vlSelf->wasmetal_core__DOT___045318_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071430_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071429_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071428_)))))))));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026582_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026515_)
            : (IData)(vlSelf->wasmetal_core__DOT___000614_));
    wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127957___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027352_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027351_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027350_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027349_)))) 
           ^ (((IData)(wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127957___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027283_)))));
    vlSelf->wasmetal_core__DOT___027287_ = ((IData)(vlSelf->wasmetal_core__DOT___027352_)
                                             ? (IData)(wasmetal_core__DOT___127957___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b27__05d));
    vlSelf->wasmetal_core__DOT___019778_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053259_)))));
    vlSelf->wasmetal_core__DOT___019777_ = (1U & (0xb000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072258_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053259_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))));
    wasmetal_core__DOT___053559_ = (1U & (IData)((0xaa3f000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053541_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053540_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___038870_)))))))));
    vlSelf->wasmetal_core__DOT___000000_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052877_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->reset)))));
    vlSelf->wasmetal_core__DOT___052918_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052877_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___045525_)))));
    wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)
            : (IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128297___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128297___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030708_)))));
    wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033434_));
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030114_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030242_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
           & (IData)(wasmetal_core__DOT___029602_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) {
        vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d;
        wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024004_;
        wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023742_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d));
    vlSelf->__VdfgTmp_hff1f1b74__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_he6c218f0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h2bc5853c__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127611___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_hec73a4f8__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127611___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->wasmetal_core__DOT____Vcellout___127438___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005868_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_)))) 
           ^ (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___022514_)))));
    vlSelf->wasmetal_core__DOT___022519_ = ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                            & (IData)(wasmetal_core__DOT___127438___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057761_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057758_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057757_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014245_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002632_) 
           & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) {
        vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d;
        wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022930_;
        wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))));
    vlSelf->__VdfgTmp_h5308e2ff__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->__VdfgTmp_h360b04fb__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h6a2fda60__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127482___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_));
    vlSelf->__VdfgTmp_h607e9020__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127482___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    wasmetal_core__DOT___013726_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8f0bea78__0))))))));
    wasmetal_core__DOT___013676_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0))))))));
    vlSelf->wasmetal_core__DOT___013641_ = (1U & ((0xb0bbU 
                                                   >> 
                                                   ((8U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013672_))))) 
                                                  & (IData)(
                                                            (0x1000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013683_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013682_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O)) 
                                                                    | ((4U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h87a694d3__0)) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_haeb5561e__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f0bea78__0))))))))))));
    wasmetal_core__DOT___057740_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O))
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___013698_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___013698_));
    wasmetal_core__DOT___057737_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                              >> 3U)) 
                                          & (IData)(
                                                    (0xb0bbb0bb0000b0bbULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                             << 3U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O)) 
                                                            | ((4U 
                                                                & ((0xeU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___013648_))))))))));
    vlSelf->wasmetal_core__DOT___050096_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                & (IData)(wasmetal_core__DOT___006743_))
                                             : (IData)(wasmetal_core__DOT___006743_));
    wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006144_) 
           & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___050151_ = (1U & (0xb0bbU >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005731_))))));
    wasmetal_core__DOT___050127_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_))));
    wasmetal_core__DOT___050146_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___050128_ = (1U & (0xb0bbU >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005738_))))));
    wasmetal_core__DOT___006634_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O) 
                                              >> 3U)) 
                                          & (IData)(
                                                    (0xb0bbb0bb0000b0bbULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                             << 3U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___003811_))))))))));
    __VdfgTmp_h7052d05f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O)) 
                              | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    wasmetal_core__DOT___063618_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063626_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128415___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063634_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063642_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128415___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d)
            : (IData)(wasmetal_core__DOT___032016_));
    wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)
            : (IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            : (IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___032020_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)
                                     : (IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d)
            : (IData)(wasmetal_core__DOT___032020_));
    if (vlSelf->wasmetal_core__DOT__sp__05b29__05d) {
        wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
        wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b29__05d;
    } else {
        wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026475_)
            ? (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d));
    wasmetal_core__DOT____Vcellout___128065___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___028309_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028244_)) 
          << 3U) | (IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128065___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028309_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028308_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028306_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028305_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___028271_)));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026583_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000636_));
    wasmetal_core__DOT____Vcellout___127973___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127973___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027413_)))));
    vlSelf->wasmetal_core__DOT___027418_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127956___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127973___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027353_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027287_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b28__05d));
    vlSelf->wasmetal_core__DOT___019783_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053493_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xbf000000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                                     << 5U) 
                                                                    | (((IData)(wasmetal_core__DOT___053559_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052883_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053364_)))));
    vlSelf->wasmetal_core__DOT___072279_ = (1U & (IData)(
                                                         (0xb000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054340_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053619_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052918_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052914_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128409___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                 : (IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128409___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031954_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128177___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
           ^ (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029492_)))));
    wasmetal_core__DOT___029496_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___128177___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128238___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030117_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030116_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030114_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030113_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030116_)
                 ? (IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030080_)))));
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030244_)
            ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__ 
        = (((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d) {
        wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d;
        wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d;
    } else {
        wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127593___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023743_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023742_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023803_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023802_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023738_)))));
    wasmetal_core__DOT___023680_ = ((IData)(vlSelf->wasmetal_core__DOT___023743_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___127593___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d));
    wasmetal_core__DOT___023747_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d))));
    wasmetal_core__DOT___058877_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d))));
    vlSelf->wasmetal_core__DOT___058916_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058913_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)))))))))));
    vlSelf->wasmetal_core__DOT___058730_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0))))));
    wasmetal_core__DOT___023746_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d))));
    vlSelf->wasmetal_core__DOT___058906_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b95dc84__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___058742_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0))))));
    wasmetal_core__DOT___023745_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d))));
    wasmetal_core__DOT___023744_ = (1U & (6U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d))));
    vlSelf->__VdfgTmp_haba8fa43__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hab9caa42__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O)))))));
    vlSelf->__VdfgTmp_hbec5a32d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->__VdfgTmp_hcdb7900c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005855_));
    vlSelf->__VdfgTmp_hb86fa734__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hb869da0d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127438___O) 
                                                                >> 3U)))))));
    wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022519_));
    vlSelf->wasmetal_core__DOT____Vcellout___127578___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002631_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0d220f7a__0))) 
           ^ (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023578_)))));
    vlSelf->wasmetal_core__DOT___023583_ = ((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                            & (IData)(wasmetal_core__DOT___127578___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) {
        wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d;
        wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d;
    } else {
        wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127471___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022788_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022787_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022816_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022815_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022783_)))));
    vlSelf->wasmetal_core__DOT___022757_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022788_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127471___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))));
    vlSelf->wasmetal_core__DOT___059171_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))))));
    vlSelf->wasmetal_core__DOT___022792_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))))));
    vlSelf->wasmetal_core__DOT___059140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    vlSelf->wasmetal_core__DOT___059172_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    vlSelf->wasmetal_core__DOT___022791_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))))));
    wasmetal_core__DOT___059095_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))));
    vlSelf->wasmetal_core__DOT___022790_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))));
    wasmetal_core__DOT___059094_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))))));
    vlSelf->wasmetal_core__DOT___022789_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))))));
    vlSelf->__VdfgTmp_hdff3685b__0 = ((((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O))
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                            & (IData)(wasmetal_core__DOT___013726_))
                                         : (IData)(wasmetal_core__DOT___013726_)) 
                                       << 1U) | (1U 
                                                 & ((~ 
                                                     ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                      >> 3U)) 
                                                    & (IData)(
                                                              (0xb0bbb0bb0000b0bbULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                 << 5U) 
                                                                | ((0x18U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127466___O) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___013668_))))))))));
    vlSelf->wasmetal_core__DOT___022695_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022712_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013641_)))));
    wasmetal_core__DOT___014226_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))));
    vlSelf->wasmetal_core__DOT___057782_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013656_)))))));
    wasmetal_core__DOT___014225_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013652_)))))));
    vlSelf->wasmetal_core__DOT___014224_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xeU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))))));
    vlSelf->wasmetal_core__DOT___013638_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013705_)))))));
    vlSelf->wasmetal_core__DOT___014234_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013692_)))))));
    vlSelf->wasmetal_core__DOT___013637_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013712_)))))));
    vlSelf->wasmetal_core__DOT___014233_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013690_)))))));
    wasmetal_core__DOT___013636_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013654_)))))));
    vlSelf->wasmetal_core__DOT___014232_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013648_)))))));
    wasmetal_core__DOT___014191_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013666_)))))));
    vlSelf->wasmetal_core__DOT___014231_ = (1U & (0xbfff8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057740_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013658_)))))));
    wasmetal_core__DOT___014268_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013719_)))))));
    wasmetal_core__DOT___014262_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013722_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013701_)))))));
    wasmetal_core__DOT___014272_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013694_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013722_)))))));
    wasmetal_core__DOT___014261_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013694_)))))));
    wasmetal_core__DOT___014271_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013668_)))))));
    wasmetal_core__DOT___014260_ = (1U & (0xbfff8000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___057740_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___057737_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013670_)))))));
    wasmetal_core__DOT___014270_ = (1U & (0x4000U >> 
                                          (((IData)(wasmetal_core__DOT___057737_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___057740_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    vlSelf->wasmetal_core__DOT___013640_ = (1U & (0x80U 
                                                  >> 
                                                  ((((4U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127467___O))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___013672_) 
                                                      & (IData)(wasmetal_core__DOT___013676_))
                                                      : (IData)(wasmetal_core__DOT___013676_)) 
                                                    << 2U) 
                                                   | ((((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O))
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___013663_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___013663_)) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057737_)))));
    vlSelf->__VdfgTmp_h7c6f7838__0 = (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___057740_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___057737_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127561___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006171_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023457_)))));
    vlSelf->wasmetal_core__DOT___023462_ = ((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                            & (IData)(wasmetal_core__DOT___127561___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___050148_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___050128_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___050131_))));
    vlSelf->wasmetal_core__DOT___006643_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___050151_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___006634_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050130_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050145_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(__VdfgTmp_h7052d05f__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___050127_)))))))));
    wasmetal_core__DOT___006636_ = (1U & (0xb0bbU >> 
                                          ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h7052d05f__0)))));
    vlSelf->wasmetal_core__DOT___063619_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063617_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063627_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063626_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063625_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063635_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063634_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063633_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063643_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063641_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026477_)
            ? (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d));
    vlSelf->wasmetal_core__DOT___063288_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___CO)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063264_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063270_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063282_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026585_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000658_));
    vlSelf->wasmetal_core__DOT___044888_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7aa341ef__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___044864_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127972___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7aa341ef__0)))))))))));
    __VdfgTmp_hc8c79887__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127973___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027418_));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027354_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b29__05d));
    wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
           & (IData)(wasmetal_core__DOT___029496_));
    wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)) 
           & (IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128252___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030245_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030244_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030242_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030241_)))) 
           ^ (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030176_)))));
    vlSelf->wasmetal_core__DOT___030181_ = ((IData)(vlSelf->wasmetal_core__DOT___030245_)
                                             ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128187___O 
        = ((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
           ^ ((0xfffffff8U & (((IData)(wasmetal_core__DOT____Vcellout___128289___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128187___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029602_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) {
        wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d;
        vlSelf->wasmetal_core__DOT___023881_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d;
    } else {
        wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023881_ = wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058883_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058878_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058877_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc26f8061__0))))))));
    wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___023744_) ? (IData)(wasmetal_core__DOT___023680_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d));
    vlSelf->wasmetal_core__DOT___023217_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbec5a32d__0))));
    vlSelf->wasmetal_core__DOT___023216_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcdb7900c__0))));
    vlSelf->wasmetal_core__DOT___023215_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005770_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))));
    vlSelf->wasmetal_core__DOT___023214_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005868_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))));
    wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002634_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023583_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) {
        wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d;
        vlSelf->wasmetal_core__DOT___022871_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d;
    } else {
        wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022871_ = wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059105_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059095_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059094_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7e209046__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)))))))))));
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022789_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022757_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h607e9020__0))));
    wasmetal_core__DOT___014280_ = (1U & (0x80000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057743_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057742_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdff3685b__0))))));
    vlSelf->wasmetal_core__DOT___014263_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdff3685b__0))));
    __VdfgTmp_hda5b9960__0 = (((IData)(wasmetal_core__DOT___014268_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014272_));
    __VdfgTmp_h9b6b58da__0 = (((IData)(wasmetal_core__DOT___014261_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014260_));
    vlSelf->__VdfgTmp_h179d57be__0 = (((IData)(wasmetal_core__DOT___014271_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014270_));
    if (vlSelf->wasmetal_core__DOT___013641_) {
        vlSelf->wasmetal_core__DOT___017840_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014232_))))));
        wasmetal_core__DOT___017818_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013640_)
                                               ? (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0)))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___013637_))));
    } else {
        vlSelf->wasmetal_core__DOT___017840_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014231_))))));
        wasmetal_core__DOT___017818_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013640_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___013638_))
                                               : (2U 
                                                  >> (IData)(wasmetal_core__DOT___013636_))));
    }
    vlSelf->wasmetal_core__DOT___017847_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014226_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014225_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014234_)))))))));
    wasmetal_core__DOT___013910_ = (1U & (0x10000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___014260_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    wasmetal_core__DOT___017820_ = (1U & (0x40000000U 
                                          >> (((IData)(wasmetal_core__DOT___014270_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    vlSelf->wasmetal_core__DOT___017908_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013637_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___013636_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___014191_)))))))));
    vlSelf->wasmetal_core__DOT___017867_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___014231_)))))))));
    vlSelf->wasmetal_core__DOT___014198_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013637_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___013636_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___014191_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014268_)))))))));
    vlSelf->wasmetal_core__DOT___017848_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014262_)))))))));
    wasmetal_core__DOT___013906_ = (1U & (IData)((0xff00ccccf0f0aaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014232_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___014262_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___014261_)))))))));
    vlSelf->wasmetal_core__DOT___017819_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014191_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014268_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___014272_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___014271_)))))))));
    __VdfgTmp_hfdee4508__0 = (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___014260_)));
    __VdfgTmp_h1bfa5608__0 = (((IData)(wasmetal_core__DOT___014270_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013640_)));
    vlSelf->wasmetal_core__DOT___022696_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___017839_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                ? (0x110fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___014225_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x7f00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___057737_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057741_) 
                                                                       << 1U) 
                                                                      | (IData)(wasmetal_core__DOT___057740_))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0x8000U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7c6f7838__0))))))))
                                                : (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___014226_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014224_))))));
    wasmetal_core__DOT___022694_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x80U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022711_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___002636_)))));
    vlSelf->wasmetal_core__DOT___006672_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005711_))));
    vlSelf->__VdfgTmp_h276936c0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_hd5a5809b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005989_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023462_));
    vlSelf->wasmetal_core__DOT___006644_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___050148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050147_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050146_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___022626_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___006623_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___006636_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___050128_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127458___O)) 
                                                                 | (((IData)(wasmetal_core__DOT___050127_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006631_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127457___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005745_))))))))))));
    vlSelf->wasmetal_core__DOT___050132_ = ((IData)(wasmetal_core__DOT___006636_) 
                                            & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006635_) 
                                                         << 5U) 
                                                        | (((IData)(wasmetal_core__DOT___006634_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006633_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006632_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006631_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)))))))))));
    vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127857___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___063291_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063288_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063287_)))))));
    vlSelf->wasmetal_core__DOT___063267_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063264_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063263_)))))));
    vlSelf->wasmetal_core__DOT___063273_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063270_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063269_)))))));
    vlSelf->wasmetal_core__DOT___063279_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063275_)))))));
    vlSelf->wasmetal_core__DOT___063285_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063282_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063281_)))))));
    wasmetal_core__DOT____Vcellout___127873___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026586_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026585_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026583_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026582_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026515_)))));
    vlSelf->wasmetal_core__DOT___026520_ = ((IData)(vlSelf->wasmetal_core__DOT___026586_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005617_));
    vlSelf->wasmetal_core__DOT___044889_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_hc8c79887__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d))))))));
    vlSelf->wasmetal_core__DOT___044865_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127973___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_hc8c79887__0)))))))))));
    vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027356_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b30__05d));
    wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128553___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011020_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128553___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033434_)))));
    vlSelf->wasmetal_core__DOT___033438_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___011020_)) 
                                            & (IData)(wasmetal_core__DOT___128553___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030246_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030181_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127628___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127628___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127628___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024004_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d) {
        vlSelf->wasmetal_core__DOT___024008_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024008_ = wasmetal_core__DOT___127628___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023881_;
    }
    wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___023745_) ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d));
    wasmetal_core__DOT____Vcellout___127612___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127612___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127612___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127612___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023877_)))));
    wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
           & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002633_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127491___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127491___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127491___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022930_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) {
        vlSelf->wasmetal_core__DOT___022934_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d;
        vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022934_ = wasmetal_core__DOT___127491___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022871_;
    }
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022790_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))));
    wasmetal_core__DOT____Vcellout___127483___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127483___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127483___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127483___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022867_)))));
    vlSelf->wasmetal_core__DOT___057835_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013666_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014261_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014262_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014260_))))))));
    vlSelf->wasmetal_core__DOT___057852_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013658_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___013641_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014268_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014271_)))))
                                                      : 
                                                     (0xcf5fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014280_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___014272_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___014270_))))))));
    vlSelf->__VdfgTmp_h9cc49427__0 = (((IData)(vlSelf->wasmetal_core__DOT___017903_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___014260_))))));
    vlSelf->wasmetal_core__DOT___022698_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014263_))));
    vlSelf->wasmetal_core__DOT___017906_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hda5b9960__0))));
    vlSelf->wasmetal_core__DOT___014094_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___013636_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___014191_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hda5b9960__0))))))));
    vlSelf->wasmetal_core__DOT___017846_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h9b6b58da__0))))));
    vlSelf->wasmetal_core__DOT___057856_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h9b6b58da__0))))));
    vlSelf->__VdfgTmp_h7f08cefc__0 = (((IData)(wasmetal_core__DOT___014262_) 
                                       << 2U) | (IData)(__VdfgTmp_h9b6b58da__0));
    vlSelf->wasmetal_core__DOT___017907_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h179d57be__0))));
    vlSelf->wasmetal_core__DOT___017882_ = (1U & (IData)(
                                                         (0xf3faf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179d57be__0))))))));
    vlSelf->__VdfgTmp_hc1104829__0 = (((IData)(wasmetal_core__DOT___014272_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h179d57be__0));
    if (vlSelf->wasmetal_core__DOT___013909_) {
        vlSelf->wasmetal_core__DOT___057897_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014350_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h9b6b58da__0))))))));
        vlSelf->wasmetal_core__DOT___057890_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014338_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h179d57be__0))))))));
        if (vlSelf->wasmetal_core__DOT___014263_) {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014289_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014300_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
        }
        vlSelf->wasmetal_core__DOT___017869_ = vlSelf->wasmetal_core__DOT___014198_;
        vlSelf->wasmetal_core__DOT___017883_ = wasmetal_core__DOT___013906_;
    } else {
        vlSelf->wasmetal_core__DOT___057897_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014350_)));
        vlSelf->wasmetal_core__DOT___057890_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014338_)));
        vlSelf->wasmetal_core__DOT___057843_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
        vlSelf->wasmetal_core__DOT___057846_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
        vlSelf->wasmetal_core__DOT___017869_ = 0U;
        vlSelf->wasmetal_core__DOT___017883_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___017884_ = (1U & (0xff400000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hfdee4508__0)))));
    vlSelf->wasmetal_core__DOT___057893_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017903_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hfdee4508__0)))))));
    vlSelf->wasmetal_core__DOT___057873_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h1bfa5608__0))));
    vlSelf->wasmetal_core__DOT___057884_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h1bfa5608__0)))))));
    vlSelf->__VdfgTmp_h4cbcef22__0 = (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                       << 4U) | (((IData)(wasmetal_core__DOT___017820_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017819_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___017818_)))));
    vlSelf->wasmetal_core__DOT___057771_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___017820_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                   << 2U) 
                                                                  | (((IData)(wasmetal_core__DOT___017818_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___017819_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))))))));
    vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___022711_)) 
           & (IData)(wasmetal_core__DOT___022694_));
    vlSelf->wasmetal_core__DOT___006737_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5a5809b__0)))));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006099_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___022625_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)))));
    vlSelf->wasmetal_core__DOT___022642_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006644_)))));
    vlSelf->wasmetal_core__DOT___006862_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006623_))));
    vlSelf->wasmetal_core__DOT___006930_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006952_))));
    vlSelf->wasmetal_core__DOT___006900_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_h8420cdb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050132_));
    vlSelf->wasmetal_core__DOT___006640_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_)))));
    vlSelf->wasmetal_core__DOT___006836_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_)))));
    vlSelf->wasmetal_core__DOT___006639_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he473afc4__0))));
    vlSelf->wasmetal_core__DOT___006835_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_)))));
    vlSelf->wasmetal_core__DOT___006638_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_)))));
    vlSelf->wasmetal_core__DOT___006834_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003810_)))));
    vlSelf->wasmetal_core__DOT___006850_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hadeaba1a__0))));
    vlSelf->wasmetal_core__DOT___006858_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005982_)))));
    vlSelf->wasmetal_core__DOT___006872_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28ae1e0e__0))));
    vlSelf->wasmetal_core__DOT___006855_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_)))));
    vlSelf->wasmetal_core__DOT___006869_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc1c04e5__0))));
    vlSelf->wasmetal_core__DOT___006854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_)))));
    vlSelf->wasmetal_core__DOT___006868_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_)))));
    vlSelf->wasmetal_core__DOT___006853_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbe1bed2__0))));
    vlSelf->wasmetal_core__DOT___006867_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7a338fa__0))));
    vlSelf->wasmetal_core__DOT___006852_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_)))));
    vlSelf->wasmetal_core__DOT___006866_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_)))));
    vlSelf->wasmetal_core__DOT___006908_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_)))));
    vlSelf->wasmetal_core__DOT___006882_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76ba8332__0))));
    vlSelf->wasmetal_core__DOT___006907_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___022624_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050132_)))));
    vlSelf->wasmetal_core__DOT___022641_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050132_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005868_)))));
    wasmetal_core__DOT____Vcellout___128416___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128416___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032016_)))));
    wasmetal_core__DOT____Vcellout___127857___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___026478_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d)) 
          << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127857___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026478_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026477_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026475_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026474_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026440_)));
    vlSelf->wasmetal_core__DOT___045479_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071371_))))))));
    vlSelf->wasmetal_core__DOT___045503_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071371_)))))))));
    vlSelf->wasmetal_core__DOT___045499_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045523_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045275_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071434_))))))));
    vlSelf->wasmetal_core__DOT___045299_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071434_)))))))));
    vlSelf->wasmetal_core__DOT___045295_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___045319_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___026520_));
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127958___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027357_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027356_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027354_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027353_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027287_)))));
    vlSelf->wasmetal_core__DOT___027292_ = ((IData)(vlSelf->wasmetal_core__DOT___027357_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128178___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
           ^ ((0xfffffff8U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128297___O) 
                               << 1U) & ((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__) 
                                         << 3U))) | 
              (((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__1__KET__) 
                << 2U) | (((IData)(wasmetal_core__DOT___128178___DOT__CO__BRA__0__KET__) 
                           << 1U) | (IData)(wasmetal_core__DOT___029496_)))));
    vlSelf->wasmetal_core__DOT___057004_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff55550f0fccccULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff55550f0f3333ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011020_)))))))))))))));
    vlSelf->wasmetal_core__DOT___056824_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))))))))));
    vlSelf->wasmetal_core__DOT___011162_ = (1U & (0x5f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff55550f0f3333ULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff55550f0fccccULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___056529_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff55550f0f3333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033438_));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030247_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024008_;
        vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___023746_) ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d));
    vlSelf->__VdfgTmp_h9141ccce__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    vlSelf->__VdfgTmp_h3ada9ffa__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_));
    vlSelf->__VdfgTmp_hd665514e__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127612___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_hd093a298__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127612___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT____Vcellout___127439___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005989_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006106_)))) 
           ^ (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022519_)))));
    vlSelf->wasmetal_core__DOT___022523_ = ((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                            & (IData)(wasmetal_core__DOT___127439___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002630_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) {
        vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d;
        wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022934_;
        wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022791_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0))));
    vlSelf->__VdfgTmp_hc4a2ed9e__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003805_));
    vlSelf->__VdfgTmp_h686e5d09__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003808_));
    vlSelf->__VdfgTmp_h4dc2cdc8__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127483___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_));
    vlSelf->__VdfgTmp_h57318413__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127483___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    wasmetal_core__DOT___017881_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014094_));
    __VdfgTmp_hf9553abf__0 = ((0x10U & ((8U >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                        << 4U)) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017846_)))));
    vlSelf->wasmetal_core__DOT___057781_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___017848_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017846_)))))));
    vlSelf->wasmetal_core__DOT___057858_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    vlSelf->wasmetal_core__DOT___017838_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    vlSelf->wasmetal_core__DOT___057806_ = (1U & (0x5fcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057805_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00ccccf0f0aaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff33330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014232_)))))))))))))));
    wasmetal_core__DOT___017868_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    __VdfgTmp_hb5812008__0 = (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017907_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017906_))))));
    vlSelf->wasmetal_core__DOT___057790_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3f500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017906_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___017907_))))))))))));
    wasmetal_core__DOT___017870_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fffaaff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
    vlSelf->wasmetal_core__DOT___057871_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017884_)))));
    vlSelf->wasmetal_core__DOT___057876_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017819_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022712_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022695_));
    vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___022628_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006900_))));
    vlSelf->wasmetal_core__DOT___006896_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006854_)))))))));
    vlSelf->wasmetal_core__DOT___006619_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006868_)))))))));
    vlSelf->wasmetal_core__DOT___006843_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))))));
    vlSelf->wasmetal_core__DOT___006917_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006852_)))))))));
    vlSelf->wasmetal_core__DOT___006870_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006866_))))));
    vlSelf->wasmetal_core__DOT___006914_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006866_)))))))));
    vlSelf->wasmetal_core__DOT___006874_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006908_)))))))));
    vlSelf->wasmetal_core__DOT___006895_ = (1U & (IData)(
                                                         (0xaaf0ccffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006882_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006866_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))))));
    __VdfgTmp_h3ede2138__0 = (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006882_));
    __VdfgTmp_h0ec09017__0 = (((IData)(vlSelf->wasmetal_core__DOT___006866_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006882_));
    vlSelf->wasmetal_core__DOT___006897_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                   ? 
                                                  (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006908_)))))
                                                   : 
                                                  (0xc05U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006907_)))))));
    __VdfgTmp_h857f834a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006907_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006644_));
    __VdfgTmp_h8aee5dd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___006908_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006907_));
    wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___022641_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022624_));
    wasmetal_core__DOT___063650_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063658_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128416___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063666_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063674_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128416___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___044911_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127857___CO) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O)) 
                                                         | ((6U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                  >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127974___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
           ^ (((IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027418_)))));
    vlSelf->wasmetal_core__DOT___027422_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027292_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b32__05d));
    vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030248_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d) {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d;
        wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127594___O 
        = ((((IData)(wasmetal_core__DOT___023747_) 
             << 3U) | (((IData)(wasmetal_core__DOT___023746_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___023745_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___023744_)))) 
           ^ (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023680_)))));
    vlSelf->wasmetal_core__DOT___023684_ = ((IData)(wasmetal_core__DOT___023747_)
                                             ? (IData)(wasmetal_core__DOT___127594___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d));
    vlSelf->wasmetal_core__DOT___058714_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0))))));
    vlSelf->wasmetal_core__DOT___023751_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d))));
    vlSelf->wasmetal_core__DOT___058917_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058914_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)))))))))));
    vlSelf->wasmetal_core__DOT___058729_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0))))));
    vlSelf->wasmetal_core__DOT___023750_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d))));
    vlSelf->wasmetal_core__DOT___023749_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d))));
    vlSelf->wasmetal_core__DOT___058868_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058863_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___023748_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d))));
    vlSelf->__VdfgTmp_ha48aeb8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h97a6ba37__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O)))))));
    vlSelf->__VdfgTmp_h4caf4ac4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->__VdfgTmp_h454147c9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_h9936ac51__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h9937e7c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127439___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006171_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022523_));
    vlSelf->wasmetal_core__DOT____Vcellout___127579___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___002629_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0ed8cd5e__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023583_)))));
    vlSelf->wasmetal_core__DOT___023587_ = ((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127579___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) {
        wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d;
        wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d;
    } else {
        wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127472___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022792_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022791_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022790_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022789_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022757_)))));
    vlSelf->wasmetal_core__DOT___022761_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022792_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127472___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0))));
    vlSelf->wasmetal_core__DOT___059145_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))))));
    vlSelf->wasmetal_core__DOT___022796_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0))))));
    vlSelf->wasmetal_core__DOT___022795_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0))))));
    vlSelf->wasmetal_core__DOT___022794_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0))))));
    wasmetal_core__DOT___059141_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))));
    vlSelf->wasmetal_core__DOT___022793_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))));
    vlSelf->__VdfgTmp_h378f1a2c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017884_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017882_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___017881_))))));
    vlSelf->wasmetal_core__DOT___057865_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017881_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017882_)))));
    vlSelf->wasmetal_core__DOT___057799_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017838_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017840_)))))))));
    vlSelf->wasmetal_core__DOT___057812_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017867_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017868_)))));
    vlSelf->__VdfgTmp_h0aec0439__0 = (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___017870_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___017868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017867_))))));
    vlSelf->wasmetal_core__DOT___057817_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017870_)))));
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022696_)
            ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022696_));
    vlSelf->wasmetal_core__DOT____Vcellout___127562___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006106_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005989_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023462_)))));
    vlSelf->wasmetal_core__DOT___023466_ = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127562___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006894_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___006619_));
    vlSelf->__VdfgTmp_h42a31070__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___006870_)
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006882_)))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                         & (IData)(
                                                   (0xff00ccccf0f0aaaaULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006872_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006869_))))))))));
    vlSelf->__VdfgTmp_he163c644__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006835_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006855_))))))))) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x80U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006907_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006643_)))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006874_)))));
    wasmetal_core__DOT___006928_ = ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___006874_));
    __VdfgTmp_h49f92928__0 = (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                               << 2U) | (IData)(__VdfgTmp_h3ede2138__0));
    vlSelf->wasmetal_core__DOT___016290_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051542_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h3ede2138__0))))))));
    vlSelf->__VdfgTmp_h690a20a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006639_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006850_))))))))) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x3500U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                 << 2U) 
                                                                | (IData)(__VdfgTmp_h0ec09017__0)))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006843_)))));
    vlSelf->__VdfgTmp_h63494727__0 = ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___006843_)) 
                                       << 1U) | (1U 
                                                 & (0xcfafU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_h0ec09017__0)))))));
    __VdfgTmp_h5ef591ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___006867_) 
                               << 2U) | (IData)(__VdfgTmp_h0ec09017__0));
    vlSelf->__VdfgTmp_h3bcc9f30__0 = (((IData)(vlSelf->wasmetal_core__DOT___006897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006896_));
    wasmetal_core__DOT___006929_ = (1U & (0x7fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h857f834a__0)))));
    vlSelf->wasmetal_core__DOT___016289_ = (1U & (IData)(
                                                         (0x7fffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051541_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h857f834a__0))))))));
    wasmetal_core__DOT___051561_ = (1U & (0x3a000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006862_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h8aee5dd6__0))))));
    vlSelf->wasmetal_core__DOT___006916_ = (1U & (0xcf5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h8aee5dd6__0))))));
    __VdfgTmp_hae3c9710__0 = (((IData)(vlSelf->wasmetal_core__DOT___006852_) 
                               << 2U) | (IData)(__VdfgTmp_h8aee5dd6__0));
    if (vlSelf->wasmetal_core__DOT___006623_) {
        vlSelf->wasmetal_core__DOT___006942_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006966_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h0ec09017__0))))))));
        vlSelf->wasmetal_core__DOT___016288_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006952_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006969_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h8aee5dd6__0))))))));
        if (vlSelf->wasmetal_core__DOT___006952_) {
            vlSelf->wasmetal_core__DOT___006941_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006951_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h5ef591ab__0)))))));
            vlSelf->wasmetal_core__DOT___006943_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006959_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hae3c9710__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___006941_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006951_)));
            vlSelf->wasmetal_core__DOT___006943_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006959_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___006942_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006966_)));
        vlSelf->wasmetal_core__DOT___016288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006969_)));
        vlSelf->wasmetal_core__DOT___006941_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006951_)));
        vlSelf->wasmetal_core__DOT___006943_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006959_)));
    }
    wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022642_)
            ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022625_));
    vlSelf->wasmetal_core__DOT___063651_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063650_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063649_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063659_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063658_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063667_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063665_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063675_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063673_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128296___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___044897_ = (1U & ((IData)(wasmetal_core__DOT___044911_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044910_)
                                                    ? 
                                                   ((1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044908_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044907_)
                                                       ? 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044906_))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044907_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044908_)))
                                                     : 
                                                    (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044910_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044911_))));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026494_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h4ddf67d8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d)))));
    vlSelf->__VdfgTmp_h3d4d4e87__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027422_));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027359_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b33__05d));
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128253___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030249_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030248_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030247_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030246_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030181_)))));
    vlSelf->wasmetal_core__DOT___030185_ = ((IData)(vlSelf->wasmetal_core__DOT___030249_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d) {
        wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d;
        vlSelf->wasmetal_core__DOT___023886_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d;
    } else {
        wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023886_ = wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023748_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023684_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d));
    vlSelf->wasmetal_core__DOT___023212_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4caf4ac4__0))));
    vlSelf->wasmetal_core__DOT___023211_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h454147c9__0))));
    vlSelf->wasmetal_core__DOT___023210_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006099_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))));
    vlSelf->wasmetal_core__DOT___023209_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005989_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006144_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002636_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023587_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) {
        wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d;
        vlSelf->wasmetal_core__DOT___022876_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d;
    } else {
        wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022876_ = wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___059146_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059141_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059140_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022793_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022761_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h57318413__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127459___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022697_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022696_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022705_ = ((IData)(vlSelf->wasmetal_core__DOT___022697_)
                                             ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___022697_));
    vlSelf->wasmetal_core__DOT___006675_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005989_))))));
    vlSelf->__VdfgTmp_h4f1b49a4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127562___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005868_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023466_));
    vlSelf->__VdfgTmp_h8599270c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006899_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006894_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006895_))));
    vlSelf->__VdfgTmp_hedae78d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___016197_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h42a31070__0)));
    vlSelf->wasmetal_core__DOT___017821_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fa33ffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he163c644__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003811_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017829_ = (1U 
                                                & (0xefefefU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0x40U 
                                                         >> (IData)(__VdfgTmp_h49f92928__0)) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006862_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                           << 2U) 
                                                          | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                               & (IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006639_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006638_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006850_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006872_))))))))) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                    ? 
                                                                   (0xc0aU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006869_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___006867_)))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___006870_)))))))));
        vlSelf->wasmetal_core__DOT___016255_ = (1U 
                                                & (0xf0faccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                        << 3U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                ? 
                                                               (0xfcaaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h8420cdb8__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050132_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006639_)))))
                                                                : 
                                                               (0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006640_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006638_)))))) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xf0aaccffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                       << 3U) 
                                                                      | (IData)(__VdfgTmp_h5ef591ab__0)))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006619_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___017829_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003808_)));
        vlSelf->wasmetal_core__DOT___016255_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005770_)));
    }
    vlSelf->wasmetal_core__DOT___006915_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h49f92928__0))));
    vlSelf->wasmetal_core__DOT___059071_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016290_)
                                                   ? (IData)(
                                                             (0xbfffffffULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))
                                                   : (IData)(
                                                             (0xffffffff40000000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))));
    vlSelf->wasmetal_core__DOT___017849_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0fa33ffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003806_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017828_ = (1U 
                                                & (0xcfafU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___013910_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 4U) 
                                                                              | (((IData)(wasmetal_core__DOT___014225_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014233_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(wasmetal_core__DOT___013906_)))))));
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & ((~ (IData)(
                                                              (0x30a000000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((8U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                             << 2U)) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h179d57be__0)))))))) 
                                                   & (0x11fff0ffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014094_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0xf0f335500000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x305U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013637_)))))))))))));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & ((1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))
                                                    ? 
                                                   (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014198_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(
                                                                       (0x33550f0f00000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                             << 4U) 
                                                                            | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))))) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0x335500000f0fULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))))))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (IData)(
                                                               (0xfaa330000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc1104829__0))))))))));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (0xccf05555U 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))
                                                    : 
                                                   (0x330faaaaU 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___017828_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013656_)));
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013687_)));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002472_)));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))));
    }
    vlSelf->__VdfgTmp_h6ef172e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___016206_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h63494727__0)));
    vlSelf->wasmetal_core__DOT___006931_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006868_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5ef591ab__0)))))));
    vlSelf->wasmetal_core__DOT___017910_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3bcc9f30__0)))));
    vlSelf->__VdfgTmp_hb02141c6__0 = (((IData)(wasmetal_core__DOT___006929_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___006928_));
    vlSelf->wasmetal_core__DOT___057877_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___006928_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___006929_))))));
    vlSelf->__VdfgTmp_h2b8ef9eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057884_));
    vlSelf->__VdfgTmp_h8655efce__0 = (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016297_));
    vlSelf->wasmetal_core__DOT___016258_ = (1U & (IData)(
                                                         (0xefefff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___051561_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                                             ? 
                                                                            (0xc0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006853_)))))
                                                                             : 
                                                                            (0xc0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006852_)))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                                          & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006836_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006835_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006834_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006858_)))))))))))))))));
    vlSelf->__VdfgTmp_h4068d69c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006917_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006916_));
    vlSelf->__VdfgTmp_haa0d8025__0 = ((2U & ((0xf055ccffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                      << 3U) 
                                                     | (IData)(__VdfgTmp_hae3c9710__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff00ccccf0f0aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006858_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006855_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006854_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006853_))))))))));
    vlSelf->wasmetal_core__DOT___006940_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006644_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006853_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hae3c9710__0)))))));
    wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022626_)
            ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022626_));
    wasmetal_core__DOT____Vcellout___128417___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128289___S) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)
                                                       : (IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128417___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___032020_)))));
    vlSelf->__VdfgTmp_h57a1bcce__0 = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128898___Q) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044897_));
    vlSelf->wasmetal_core__DOT___062970_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128896___Q) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044897_))));
    vlSelf->wasmetal_core__DOT___053592_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___053430_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044897_)))));
    vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___044866_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)))))))))));
    vlSelf->wasmetal_core__DOT___044890_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d))))))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b34__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128554___O 
        = (((8U & ((~ (0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033438_)))));
    vlSelf->wasmetal_core__DOT___033443_ = ((~ (0xfef0U 
                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                                            & (IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030250_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030185_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127629___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127629___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024008_)))));
    vlSelf->wasmetal_core__DOT___024013_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)
                                             : (IData)(wasmetal_core__DOT___127629___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023749_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127595___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127613___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127613___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127613___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023881_)))));
    vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006215_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127440___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127580___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127492___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127492___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127492___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022934_)))));
    vlSelf->wasmetal_core__DOT___022939_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)
                                             : (IData)(wasmetal_core__DOT___127492___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022794_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127473___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127484___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127484___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127484___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127484___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022871_)))));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022698_)
            ? (IData)(vlSelf->wasmetal_core__DOT___022705_)
            : (IData)(vlSelf->wasmetal_core__DOT___022698_));
    vlSelf->wasmetal_core__DOT___006704_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127561___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4f1b49a4__0)))));
    vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127563___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017811_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (0xaf00cfU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0))
                                                          : 
                                                         (0xff50ff30U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0)))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (2U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xefU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057806_)))));
    vlSelf->__VdfgTmp_h103cd5d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017828_));
    vlSelf->__VdfgTmp_hf64b2678__0 = (((IData)(vlSelf->wasmetal_core__DOT___006914_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006915_));
    vlSelf->wasmetal_core__DOT___070587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057799_))));
    vlSelf->__VdfgTmp_ha11b0f77__0 = (((IData)(vlSelf->wasmetal_core__DOT___006931_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006930_));
    vlSelf->wasmetal_core__DOT___017863_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017910_)
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017909_)) 
                                                   & (IData)(
                                                             (0xff0aff0cffffffffULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                   | (IData)(
                                                             (0xf500f300000000ULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))));
    vlSelf->wasmetal_core__DOT___017859_ = (1U & (IData)(
                                                         (0xf8ffffff0700ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017819_)))))))));
    vlSelf->wasmetal_core__DOT___070580_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))));
    vlSelf->__VdfgTmp_h3ee80f1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017830_));
    vlSelf->__VdfgTmp_h161c803b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017829_));
    vlSelf->wasmetal_core__DOT___017887_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4068d69c__0)))));
    vlSelf->__VdfgTmp_h9c807cdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___006623_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___006644_)
                                                          ? 
                                                         (0xfcaaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050132_))) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8420cdb8__0)) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006835_)))))
                                                          : 
                                                         (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006643_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006836_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___006834_)))))) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_haa0d8025__0))));
    vlSelf->wasmetal_core__DOT___017874_ = (1U & (0xafcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa0d8025__0))))));
    vlSelf->wasmetal_core__DOT___006947_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006940_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006930_)))));
    vlSelf->wasmetal_core__DOT___043052_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    vlSelf->wasmetal_core__DOT___017860_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    vlSelf->__VdfgTmp_h04c27d81__0 = (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006943_));
    vlSelf->wasmetal_core__DOT____Vcellout___127450___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022627_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022626_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022642_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022641_)))) 
           ^ (((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022635_ = ((IData)(vlSelf->wasmetal_core__DOT___022627_)
                                             ? (IData)(wasmetal_core__DOT___127450___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___022627_));
    vlSelf->wasmetal_core__DOT___063682_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063690_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128417___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063706_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128417___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___019791_ = (1U & (IData)(
                                                         (0xf3a2a2a200000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))))));
    vlSelf->wasmetal_core__DOT___063400_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___063368_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053568_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___063371_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___019788_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___019790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053428_))));
    vlSelf->wasmetal_core__DOT___039572_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051570_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039632_ = (1U & (0xaea2aeaeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill)))))));
    vlSelf->wasmetal_core__DOT___039755_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039629_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039633_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039634_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039635_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039636_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039637_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039638_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039639_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039640_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039663_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039652_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039651_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039650_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039649_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___040059_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b15__05d)))))));
}
