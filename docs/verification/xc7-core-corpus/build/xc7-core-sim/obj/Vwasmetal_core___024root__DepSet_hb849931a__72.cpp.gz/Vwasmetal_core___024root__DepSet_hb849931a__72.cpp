#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__39(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__39\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___025141_;
    wasmetal_core__DOT___025141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025149_;
    wasmetal_core__DOT___025149_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025154_;
    wasmetal_core__DOT___025154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025158_;
    wasmetal_core__DOT___025158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061720_;
    wasmetal_core__DOT___061720_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127762___O;
    wasmetal_core__DOT____Vcellout___127762___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    // Body
    wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___025164_)
            : (IData)(vlSelf->wasmetal_core__DOT___025136_));
    wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025177_)
            ? (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025137_));
    wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___025178_)
            ? (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025138_));
    wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128264___DOT__CO__BRA__0__KET__)));
    if (vlSelf->wasmetal_core__DOT___025172_) {
        vlSelf->wasmetal_core__DOT___025168_ = wasmetal_core__DOT___128264___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025168_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025141_ = wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025141_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___025145_ = wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025145_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025149_ = vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025149_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025154_ = wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025154_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___025158_ = wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___025158_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___025168_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025141_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___025145_ = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025149_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025154_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___025158_ = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
        wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___025132_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127758___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___025172_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025178_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025177_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025176_)))) 
           ^ (((IData)(wasmetal_core__DOT___128264___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025164_)));
    vlSelf->wasmetal_core__DOT___019316_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019304_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff440f0f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054939_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054966_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8cc03967__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054696_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___019319_)))))
                                                   : 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___055606_))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xf088U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                     << 1U)) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___048324_)))))))))));
    vlSelf->wasmetal_core__DOT___019311_ = (1U & (IData)(
                                                         (0x11110000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061951_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf088U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048324_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054920_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019323_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127759___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127759___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___025168_))))));
    wasmetal_core__DOT___061720_ = (1U & (0x777U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048325_))))));
    vlSelf->wasmetal_core__DOT___061722_ = (1U & (0xf1f1ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___061720_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb5edd3cc__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127760___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127760___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025141_))))));
    vlSelf->wasmetal_core__DOT___062187_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127760___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127761___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127761___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___025145_))))));
    vlSelf->wasmetal_core__DOT___061884_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___061813_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    wasmetal_core__DOT____Vcellout___127762___O = (0xfU 
                                                   & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127762___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___025149_))))));
    vlSelf->wasmetal_core__DOT___062013_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127762___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___062072_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___061953_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127763___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__2__KET__) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127763___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025154_))))));
    vlSelf->wasmetal_core__DOT___061715_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___019293_)
                                                   ? 
                                                  (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (0xf1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0x30f030f000055ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061446_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019211_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127763___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O))))))))))))))))))
                                                   : 
                                                  (0xf0a0303U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & ((IData)(
                                                                               (0xf0f00000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127757___O))))))))))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019304_)))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xf0f00000ccaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___025168_))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127764___O 
        = (0xfU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___025172_))) 
                   ^ ((((IData)(vlSelf->wasmetal_core__DOT___025172_)
                         ? (IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__)
                         : (IData)(vlSelf->wasmetal_core__DOT___025132_)) 
                       << 3U) | (((IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__1__KET__) 
                                  << 2U) | (((IData)(wasmetal_core__DOT___127764___DOT__CO__BRA__0__KET__) 
                                             << 1U) 
                                            | (IData)(wasmetal_core__DOT___025158_))))));
    vlSelf->wasmetal_core__DOT___062191_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff1100000f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x3300ff0f0faaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062187_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055712_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                >> 3U))))))))))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x30f030f000055ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062185_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055997_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127764___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127762___O) 
                                                                                >> 3U))))))))))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019292_)))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__44(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__44\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___058084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058083_))));
    vlSelf->__VdfgTmp_hb0c92cfa__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048948_));
    vlSelf->wasmetal_core__DOT___018318_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edivide_wide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048949_))));
    vlSelf->wasmetal_core__DOT___071839_ = (1U & (IData)(
                                                         (0xffff0077ffff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he775e720__0))))))));
    vlSelf->wasmetal_core__DOT___071787_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT___005670_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048949_))));
    vlSelf->wasmetal_core__DOT___020524_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid))));
    vlSelf->wasmetal_core__DOT___019773_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___058085_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052586_))));
    vlSelf->wasmetal_core__DOT___071836_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071558_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___071834_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071556_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___071833_ = (1U & (0xf800U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071515_))))));
    vlSelf->wasmetal_core__DOT___071828_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071551_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___071826_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071549_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___071821_ = (1U & (0xf800U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071475_))))));
    vlSelf->wasmetal_core__DOT___071820_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071545_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___071818_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071543_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___071817_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071542_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___071816_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___071815_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071539_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___071814_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071538_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___071813_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071537_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___071812_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071536_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d)))));
    vlSelf->wasmetal_core__DOT___071811_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071535_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___071810_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071534_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d)))));
    vlSelf->wasmetal_core__DOT___071809_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071533_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d)))));
    vlSelf->wasmetal_core__DOT___071807_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he775e720__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___071804_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071523_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___071802_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071518_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d)))));
    vlSelf->wasmetal_core__DOT___071801_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071515_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___071796_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071501_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___071794_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d)))));
    vlSelf->wasmetal_core__DOT___071788_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058083_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___071838_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___071837_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071559_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___071835_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071557_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___071832_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071555_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___071831_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071554_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___071830_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___071829_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___071827_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071550_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___071824_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071548_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___071823_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071547_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___071822_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071546_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))));
    vlSelf->wasmetal_core__DOT___071819_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___071808_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___071806_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071527_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___071805_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071525_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___071803_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___071800_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071513_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___071799_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___071798_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071507_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___071797_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071504_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___071795_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___071792_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071489_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___071791_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071485_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___071790_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071481_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___071789_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071476_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__ 
        = (1U & (7U >> ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___070574_))));
    vlSelf->wasmetal_core__DOT___019023_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0))))));
    vlSelf->wasmetal_core__DOT___014875_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058620_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058648_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___058611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015025_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015166_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015078_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___015032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___014714_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005670_))));
    vlSelf->wasmetal_core__DOT___071562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058085_))));
    vlSelf->wasmetal_core__DOT___040092_ = (1U & (0xfb080808U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__45(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__45\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006582_;
    wasmetal_core__DOT___006582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014672_;
    wasmetal_core__DOT___014672_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014690_;
    wasmetal_core__DOT___014690_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014696_;
    wasmetal_core__DOT___014696_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014704_;
    wasmetal_core__DOT___014704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014770_;
    wasmetal_core__DOT___014770_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014805_;
    wasmetal_core__DOT___014805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014821_;
    wasmetal_core__DOT___014821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014874_;
    wasmetal_core__DOT___014874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015190_;
    wasmetal_core__DOT___015190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015210_;
    wasmetal_core__DOT___015210_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015295_;
    wasmetal_core__DOT___015295_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015296_;
    wasmetal_core__DOT___015296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015297_;
    wasmetal_core__DOT___015297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015346_;
    wasmetal_core__DOT___015346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015543_;
    wasmetal_core__DOT___015543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016558_;
    wasmetal_core__DOT___016558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016567_;
    wasmetal_core__DOT___016567_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016571_;
    wasmetal_core__DOT___016571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016581_;
    wasmetal_core__DOT___016581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016593_;
    wasmetal_core__DOT___016593_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016599_;
    wasmetal_core__DOT___016599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016602_;
    wasmetal_core__DOT___016602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016615_;
    wasmetal_core__DOT___016615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016639_;
    wasmetal_core__DOT___016639_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016647_;
    wasmetal_core__DOT___016647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035970_;
    wasmetal_core__DOT___035970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035981_;
    wasmetal_core__DOT___035981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036068_;
    wasmetal_core__DOT___036068_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036121_;
    wasmetal_core__DOT___036121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036125_;
    wasmetal_core__DOT___036125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036128_;
    wasmetal_core__DOT___036128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036241_;
    wasmetal_core__DOT___036241_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036260_;
    wasmetal_core__DOT___036260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058118_;
    wasmetal_core__DOT___058118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058119_;
    wasmetal_core__DOT___058119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058127_;
    wasmetal_core__DOT___058127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058128_;
    wasmetal_core__DOT___058128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058138_;
    wasmetal_core__DOT___058138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058139_;
    wasmetal_core__DOT___058139_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058165_;
    wasmetal_core__DOT___058165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058168_;
    wasmetal_core__DOT___058168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058604_;
    wasmetal_core__DOT___058604_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058608_;
    wasmetal_core__DOT___058608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058610_;
    wasmetal_core__DOT___058610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058624_;
    wasmetal_core__DOT___058624_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058630_;
    wasmetal_core__DOT___058630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058647_;
    wasmetal_core__DOT___058647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058655_;
    wasmetal_core__DOT___058655_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128818___O;
    wasmetal_core__DOT____Vcellout___128818___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128833___O;
    wasmetal_core__DOT____Vcellout___128833___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128834___O;
    wasmetal_core__DOT____Vcellout___128834___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_heded5023__0;
    __VdfgTmp_heded5023__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1a362e4f__0;
    __VdfgTmp_h1a362e4f__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4528f615__0;
    __VdfgTmp_h4528f615__0 = 0;
    CData/*3:0*/ __VdfgTmp_h7d44b025__0;
    __VdfgTmp_h7d44b025__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4ac2372d__0;
    __VdfgTmp_h4ac2372d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a7f7b8b__0;
    __VdfgTmp_h7a7f7b8b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2e6695c3__0;
    __VdfgTmp_h2e6695c3__0 = 0;
    CData/*4:0*/ __VdfgTmp_hbc941cc7__0;
    __VdfgTmp_hbc941cc7__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc2887b39__0;
    __VdfgTmp_hc2887b39__0 = 0;
    CData/*4:0*/ __VdfgTmp_h4ef0e6f0__0;
    __VdfgTmp_h4ef0e6f0__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8cd84d2f__0;
    __VdfgTmp_h8cd84d2f__0 = 0;
    CData/*2:0*/ __VdfgTmp_he63183d7__0;
    __VdfgTmp_he63183d7__0 = 0;
    CData/*2:0*/ __VdfgTmp_he967bd3f__0;
    __VdfgTmp_he967bd3f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h56377d30__0;
    __VdfgTmp_h56377d30__0 = 0;
    CData/*2:0*/ __VdfgTmp_h823d6b3b__0;
    __VdfgTmp_h823d6b3b__0 = 0;
    CData/*2:0*/ __VdfgTmp_hea8c747f__0;
    __VdfgTmp_hea8c747f__0 = 0;
    CData/*2:0*/ __VdfgTmp_hed321262__0;
    __VdfgTmp_hed321262__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2e1acbd8__0;
    __VdfgTmp_h2e1acbd8__0 = 0;
    CData/*2:0*/ __VdfgTmp_he527e66f__0;
    __VdfgTmp_he527e66f__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___040087_ = (1U & (0xf220022U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058549_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___040077_ = (1U & (IData)(
                                                         (0x2a2a2aeaeaeaea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b50__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b49__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b44__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b43__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b42__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b41__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b40__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b39__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b38__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b37__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b36__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b35__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b30__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b29__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b28__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b27__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b26__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b25__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b24__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b23__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b21__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b19__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b18__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b17__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b16__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b14__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b12__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b11__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b10__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b9__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b8__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b7__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b6__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b5__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b4__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b3__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b2__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d)))))));
    vlSelf->__VdfgTmp_h9a302586__0 = (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051336_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b33__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b31__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b48__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b46__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b47__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b45__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b15__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b13__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b22__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b20__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b34__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b32__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___040073_ = (1U & (0xeaeaea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058086_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___040074_ = (1U & (IData)(
                                                         (0x2aea2a2aeaeaeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b52__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___060218_ = (1U & (0x7d00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060213_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005669_))))));
    wasmetal_core__DOT___006582_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006589_)) 
                                    & ((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       & (IData)((0xfffffffffffffffeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))))));
    vlSelf->wasmetal_core__DOT___017803_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02emajorExc_Z)))))));
    vlSelf->wasmetal_core__DOT___058137_ = (1U & (IData)(
                                                         (0xf0f111100ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b4__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0)))
                                                                              : (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0))))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0)))
                                                                              : (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5c2d914__0))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                                          & (IData)(
                                                                                (0xdf2f20d00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014966_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___058098_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O))))))));
    vlSelf->wasmetal_core__DOT___058095_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT___014930_ = ((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___005668_)
                                                ? (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014936_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___058134_)))))))
                                                : (0xf0f0fcfaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0xdf2f20dU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014936_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                 >> 2U)) 
                                                             | (1U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)))))))));
    vlSelf->wasmetal_core__DOT___015056_ = (1U & (IData)(
                                                         (0xf0f111100ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0)))
                                                                              : (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0))))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                                              ? (IData)(
                                                                                (0xf0f0000aa2eaa22ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0)))
                                                                              : (IData)(
                                                                                (0xaaaaaaaa0f8b0088ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h96193a8e__0))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                                          & (IData)(
                                                                                (0xdf2f20d00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015070_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))))))))));
    vlSelf->__VdfgTmp_h09c9c684__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015432_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d)));
    __VdfgTmp_h2e1acbd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                               << 2U) | ((2U & ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d)));
    vlSelf->__VdfgTmp_ha028555e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | ((2U 
                                                  & ((0xf0f3355U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d)));
    __VdfgTmp_he527e66f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                               << 2U) | ((2U & ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d)));
    wasmetal_core__DOT___058610_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___014838_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f3355U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___014688_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hdfd6d7e7__0)))));
    wasmetal_core__DOT___058624_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xf0f3355U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))));
    wasmetal_core__DOT___058630_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xc0aU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7410d216__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127770___O) 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___005669_)))))))));
    wasmetal_core__DOT___058608_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xc0aU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h943c9679__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> 
                                                       ((2U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___005669_)))))))));
    vlSelf->__VdfgTmp_h069b89c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 2U) | ((2U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014590_))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 3U))))))));
    wasmetal_core__DOT___058604_ = (1U & (0x110fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015540_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015541_))))));
    vlSelf->wasmetal_core__DOT___036073_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b12__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                                 ^ (IData)(vlSelf->wasmetal_core__DOT___036940_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (~ 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___035703_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__)
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___035703_)))))))))));
    vlSelf->wasmetal_core__DOT___036072_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b11__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b10__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b9__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT___036071_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O))))))));
    vlSelf->wasmetal_core__DOT___040084_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040099_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___040103_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040100_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___040076_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040101_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040098_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___040080_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049343_))));
    vlSelf->wasmetal_core__DOT___040102_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d)))))))));
    vlSelf->__VdfgTmp_h7054d7e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058620_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058619_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058618_))));
    vlSelf->__VdfgTmp_h9624abf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___058620_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058618_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058619_))));
    vlSelf->__VdfgTmp_h60abdace__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058648_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058203_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058202_))));
    __VdfgTmp_h7d44b025__0 = (((IData)(vlSelf->wasmetal_core__DOT___058648_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058202_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058203_))));
    vlSelf->__VdfgTmp_hab75b8e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058645_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058644_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058643_))));
    __VdfgTmp_heded5023__0 = (((IData)(vlSelf->wasmetal_core__DOT___058645_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058643_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058644_))));
    vlSelf->__VdfgTmp_h38acc8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058641_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058205_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058204_))));
    __VdfgTmp_h1a362e4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058641_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058204_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058205_))));
    vlSelf->__VdfgTmp_hb8495bec__0 = (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058611_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058207_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058206_))));
    __VdfgTmp_h4528f615__0 = (((IData)(vlSelf->wasmetal_core__DOT___058611_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___058206_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058207_))));
    wasmetal_core__DOT___058647_ = (1U & (0x1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015438_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015439_))))));
    vlSelf->wasmetal_core__DOT___015127_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015140_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015139_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h22db4e96__0)))))))));
    vlSelf->wasmetal_core__DOT___014995_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015025_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015024_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h5b356604__0)))))))));
    vlSelf->wasmetal_core__DOT___015131_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015166_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015165_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h375bf609__0)))))))));
    vlSelf->wasmetal_core__DOT___015060_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015102_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015101_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h1e28f3c0__0)))))))));
    vlSelf->wasmetal_core__DOT___015059_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015096_)) 
                                                  & (IData)(
                                                            (0xff00fffcfff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015095_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h39f326f7__0)))))))));
    vlSelf->wasmetal_core__DOT___015057_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015078_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015077_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h1a5afed0__0)))))))));
    vlSelf->wasmetal_core__DOT___015061_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015109_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015108_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hf7593d1b__0)))))))));
    vlSelf->wasmetal_core__DOT___014996_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015032_)) 
                                                  & (IData)(
                                                            (0xff00fff3fff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015031_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h210df1ee__0)))))))));
    vlSelf->wasmetal_core__DOT___014686_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014714_)) 
                                                  & (IData)(
                                                            (0xff00fffcfff5ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014713_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hd148b96b__0)))))))));
    vlSelf->wasmetal_core__DOT___036005_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b50__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___036004_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b49__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___035998_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071832_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b44__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___035997_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071831_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b43__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___035996_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b42__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___035995_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b41__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___035994_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071828_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b40__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___035993_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b39__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___035991_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071826_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b38__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___035990_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff0077ffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b37__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___035989_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b36__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___035988_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071823_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b35__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___035983_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b30__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___035982_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071817_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b29__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___035980_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071816_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b28__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___035979_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b27__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___035978_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071814_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b26__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___035977_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071813_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___035976_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b24__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___035975_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071811_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b23__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___035973_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b21__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___035971_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___035969_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071806_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___035968_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b17__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___035967_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071804_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b16__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___035965_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b14__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___035963_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b12__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___035962_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b11__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___035961_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071798_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___035960_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071797_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b9__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___036014_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b8__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___036013_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___036012_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b6__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___036011_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff00bbffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b5__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___036010_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071792_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b4__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___036003_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b3__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___035992_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b2__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d 
        = (1U & (0x4f44U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b53__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT___036006_ = (1U & (0xf8ff0700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071839_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b0__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT___036009_ = (1U & (0xbb0bbbbU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048948_)))))));
    vlSelf->wasmetal_core__DOT___035986_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b33__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___035984_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b31__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___036002_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___036000_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071834_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b46__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___036001_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b47__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___035999_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b45__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___035966_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071803_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b15__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___035964_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071801_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___035974_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___035972_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b20__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___035987_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b34__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___035985_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b32__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___036007_ = (1U & (IData)(
                                                         (0xffff753000008acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___071561_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058086_)))))))));
    vlSelf->wasmetal_core__DOT___017156_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005670_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                      ? 
                                                     (0x7f5f3f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_he488fa83__0)))))
                                                      : 
                                                     (0xb333U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xdf2f20dU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0))))))))));
    vlSelf->__VdfgTmp_h2ddde49a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058098_));
    vlSelf->__VdfgTmp_hf4c0ee7d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->__VdfgTmp_h283c0448__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->__VdfgTmp_h187f5418__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->wasmetal_core__DOT___058096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d))));
    vlSelf->__VdfgTmp_h42abc930__0 = (((IData)(vlSelf->wasmetal_core__DOT___014930_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014931_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        if (vlSelf->wasmetal_core__DOT___005669_) {
            vlSelf->wasmetal_core__DOT___015058_ = 
                (1U & (2U >> (1U & (0x80000000U >> 
                                    (((IData)(vlSelf->wasmetal_core__DOT___058152_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058151_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((IData)(
                                                               (0x100000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058147_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                             >> 1U))) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058145_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127795___O)) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127793___O) 
                                                                                >> 3U))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x100000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___058144_) 
                                                                     << 5U) 
                                                                    | ((0x18U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127776___O) 
                                                                           << 1U)) 
                                                                       | ((6U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127775___O) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127774___O) 
                                                                                >> 3U))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x100000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___058143_) 
                                                                      << 5U) 
                                                                     | ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127765___O) 
                                                                            << 3U)) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127795___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127794___O) 
                                                                                >> 3U))))))))))))))));
            vlSelf->wasmetal_core__DOT___015428_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127777___O) 
                                    >> 3U))));
        } else {
            vlSelf->wasmetal_core__DOT___015058_ = 
                (1U & (0xc0f5U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                          << 3U)) | 
                                   ((4U & ((0xdf2f20dU 
                                            >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                           << 2U)) 
                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                        << 1U) | (1U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                     >> 1U)))))));
            vlSelf->wasmetal_core__DOT___015428_ = 
                (1U & (0x77f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0x33330f270f0f331bULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h91abfcdf__0)))
                                                  : (IData)(
                                                            (0xf0f331b33330f27ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h91abfcdf__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014949_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007129_))))));
        }
        vlSelf->wasmetal_core__DOT___015203_ = (1U 
                                                & (0xf0f0077U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014970_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127778___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x80U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007170_)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015058_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b0__05d)));
        vlSelf->wasmetal_core__DOT___015203_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b5__05d)));
        vlSelf->wasmetal_core__DOT___015428_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b3__05d)));
    }
    vlSelf->wasmetal_core__DOT___014909_ = (1U & (IData)(
                                                         (0xc500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015428_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h09c9c684__0)))))));
    wasmetal_core__DOT___058655_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014688_))));
    vlSelf->__VdfgTmp_hd141341a__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    __VdfgTmp_h2e6695c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d));
    vlSelf->wasmetal_core__DOT___058172_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d))))));
    vlSelf->__VdfgTmp_h66d515d6__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058174_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_hd20fe4de__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)));
    vlSelf->__VdfgTmp_hcbc91db2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    vlSelf->wasmetal_core__DOT___015429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d))));
    wasmetal_core__DOT___058165_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___036071_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d));
    __VdfgTmp_h7a7f7b8b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)));
    vlSelf->wasmetal_core__DOT___020523_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT___072257_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048947_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase)))));
    vlSelf->wasmetal_core__DOT___040093_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040095_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040094_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)))))))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        if (vlSelf->wasmetal_core__DOT___005669_) {
            vlSelf->wasmetal_core__DOT___014998_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127781___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___015394_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___014718_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___015062_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___015130_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127766___O) 
                                    >> 1U))));
            vlSelf->wasmetal_core__DOT___014992_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127782___O) 
                                    >> 2U))));
            vlSelf->wasmetal_core__DOT___014723_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 1U))));
            vlSelf->wasmetal_core__DOT___015523_ = 
                (1U & (1U >> (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O))));
            vlSelf->wasmetal_core__DOT___015264_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                    >> 3U))));
            vlSelf->wasmetal_core__DOT___014928_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127772___O) 
                                    >> 1U))));
            vlSelf->wasmetal_core__DOT___014592_ = 
                (1U & (1U >> (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127773___O) 
                                    >> 3U))));
            vlSelf->wasmetal_core__DOT___017801_ = 
                (1U & (8U >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)));
        } else {
            vlSelf->wasmetal_core__DOT___014998_ = 
                (1U & (0xbb0fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_he1094429__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_he1094429__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)))));
            vlSelf->wasmetal_core__DOT___015394_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hd481047b__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hd481047b__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014632_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014631_))))));
            vlSelf->wasmetal_core__DOT___014718_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h9f7a6ca7__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h9f7a6ca7__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014757_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014756_))))));
            vlSelf->wasmetal_core__DOT___015062_ = 
                (1U & (0xbb0fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h207e55f4__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h207e55f4__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hb48763c1__0)))));
            vlSelf->wasmetal_core__DOT___015130_ = 
                (1U & (0xbb0fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h328f8271__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h328f8271__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h52595424__0)))));
            vlSelf->wasmetal_core__DOT___014992_ = 
                (1U & (0xbb0fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hddb36baf__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hddb36baf__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)))));
            vlSelf->wasmetal_core__DOT___014723_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1c3d35c0__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1c3d35c0__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014746_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014745_))))));
            vlSelf->wasmetal_core__DOT___015523_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf5c220e3__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf5c220e3__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014659_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014658_))))));
            vlSelf->wasmetal_core__DOT___015264_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf7faa60c__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf7faa60c__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014827_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014826_))))));
            vlSelf->wasmetal_core__DOT___014928_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h7bf8c9f6__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h7bf8c9f6__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014792_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014791_))))));
            vlSelf->wasmetal_core__DOT___014592_ = 
                (1U & (0x110fU >> (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                    << 3U) | ((4U & 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                  ? (IData)(
                                                            (0xccccf0d8f0f0cce4ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_ha523ac5f__0)))
                                                  : (IData)(
                                                            (0xf0f0cce4ccccf0d8ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_ha523ac5f__0)))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014602_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014601_))))));
            vlSelf->wasmetal_core__DOT___017801_ = 
                (1U & (0x7f7f7f00U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___005666_)))))));
        }
        vlSelf->wasmetal_core__DOT___015133_ = (1U 
                                                & (0xf0f3355U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127780___O) 
                                                              >> 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                                    ? (IData)(
                                                                              (0xccccf0d8f0f0cce4ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6827e815__0)))
                                                                    : (IData)(
                                                                              (0xf0f0cce4ccccf0d8ULL 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6827e815__0)))))))))));
        vlSelf->wasmetal_core__DOT___014813_ = (1U 
                                                & (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)));
        wasmetal_core__DOT___014805_ = (1U & (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0)));
        vlSelf->wasmetal_core__DOT___014778_ = (1U 
                                                & (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0)));
        vlSelf->wasmetal_core__DOT___014732_ = (1U 
                                                & (0xf0f0ccaaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)));
        wasmetal_core__DOT___014696_ = (1U & (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)));
        vlSelf->wasmetal_core__DOT___015129_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8d338479__0)));
        vlSelf->wasmetal_core__DOT___015134_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4eb011e3__0)));
        vlSelf->wasmetal_core__DOT___015128_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5b73c7a2__0)));
        vlSelf->wasmetal_core__DOT___014993_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0)));
        vlSelf->wasmetal_core__DOT___014997_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0)));
        vlSelf->wasmetal_core__DOT___014999_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5047773c__0)));
        vlSelf->wasmetal_core__DOT___014680_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014682_));
        vlSelf->wasmetal_core__DOT___014653_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014655_));
        wasmetal_core__DOT___014672_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___014674_));
        wasmetal_core__DOT___014821_ = (1U & (0xf0f0ccaaU 
                                              >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)));
        vlSelf->wasmetal_core__DOT___014786_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014788_));
        wasmetal_core__DOT___014704_ = (1U & (0xf0f0ccaaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127768___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h66dab408__0))))));
        vlSelf->wasmetal_core__DOT___014588_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hac6eec7f__0)));
        vlSelf->wasmetal_core__DOT___014994_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hadaed6e9__0)));
    } else {
        vlSelf->wasmetal_core__DOT___014998_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b18__05d)));
        vlSelf->wasmetal_core__DOT___015133_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d)));
        vlSelf->wasmetal_core__DOT___015394_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d)));
        vlSelf->wasmetal_core__DOT___014718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b50__05d)));
        vlSelf->wasmetal_core__DOT___014813_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d)));
        wasmetal_core__DOT___014805_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d)));
        vlSelf->wasmetal_core__DOT___014778_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)));
        vlSelf->wasmetal_core__DOT___014732_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d)));
        wasmetal_core__DOT___014696_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d)));
        vlSelf->wasmetal_core__DOT___015129_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d)));
        vlSelf->wasmetal_core__DOT___015134_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d)));
        vlSelf->wasmetal_core__DOT___015128_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d)));
        vlSelf->wasmetal_core__DOT___015062_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b26__05d)));
        vlSelf->wasmetal_core__DOT___015130_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b25__05d)));
        vlSelf->wasmetal_core__DOT___014992_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b22__05d)));
        vlSelf->wasmetal_core__DOT___014723_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d)));
        vlSelf->wasmetal_core__DOT___015523_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b52__05d)));
        vlSelf->wasmetal_core__DOT___015264_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b51__05d)));
        vlSelf->wasmetal_core__DOT___014928_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b49__05d)));
        vlSelf->wasmetal_core__DOT___014592_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d)));
        vlSelf->wasmetal_core__DOT___017801_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d)));
        vlSelf->wasmetal_core__DOT___014993_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d)));
        vlSelf->wasmetal_core__DOT___014997_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d)));
        vlSelf->wasmetal_core__DOT___014999_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d)));
        vlSelf->wasmetal_core__DOT___014680_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)));
        vlSelf->wasmetal_core__DOT___014653_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)));
        wasmetal_core__DOT___014672_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)));
        wasmetal_core__DOT___014821_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)));
        vlSelf->wasmetal_core__DOT___014786_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)));
        wasmetal_core__DOT___014704_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d)));
        vlSelf->wasmetal_core__DOT___014588_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)));
        vlSelf->wasmetal_core__DOT___014994_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d)));
    }
    vlSelf->wasmetal_core__DOT___014911_ = ((IData)(vlSelf->wasmetal_core__DOT___014999_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___014998_) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014995_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014994_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014992_))))))))));
    vlSelf->wasmetal_core__DOT___036008_ = (1U & (0xf807U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0))))))));
    wasmetal_core__DOT___035981_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071789_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b1__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d)))))))));
    wasmetal_core__DOT___035970_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071788_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b0__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___060219_ = (1U & (IData)(
                                                         (0xff4f4444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060218_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060217_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf530U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060214_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11374272__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005670_)))))))));
    vlSelf->wasmetal_core__DOT___058107_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))));
    vlSelf->__VdfgTmp_hc2843286__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h6a8cbae2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h8e2d1d0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h283c0448__0));
    vlSelf->__VdfgTmp_h9949a0e3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h187f5418__0))));
    vlSelf->wasmetal_core__DOT___058106_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058098_))));
    vlSelf->__VdfgTmp_hb1419641__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h187f5418__0));
    vlSelf->__VdfgTmp_h786a2bba__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058096_));
    vlSelf->wasmetal_core__DOT___058099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058096_))));
    vlSelf->__VdfgTmp_h372a4d3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd141341a__0));
    vlSelf->wasmetal_core__DOT___058188_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058190_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(__VdfgTmp_h2e6695c3__0)))))));
    vlSelf->wasmetal_core__DOT___058191_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h7751e274__0 = ((2U & ((1U >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058163_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h2e6695c3__0))));
    vlSelf->wasmetal_core__DOT___058183_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058174_)))));
    vlSelf->wasmetal_core__DOT___058175_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h639f1e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058177_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))))));
    vlSelf->wasmetal_core__DOT___058161_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xe0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058171_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128825___S 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)));
    vlSelf->wasmetal_core__DOT___058184_ = (1U & (0x7f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058097_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->wasmetal_core__DOT___036176_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015429_))));
    vlSelf->wasmetal_core__DOT___058155_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036071_)))))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
           & (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___015569_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___017059_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015521_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015511_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___058156_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7a7f7b8b__0)))));
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035970_) ? (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d));
    vlSelf->wasmetal_core__DOT___060654_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060219_))));
    vlSelf->wasmetal_core__DOT___060220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016506_))));
    vlSelf->__VdfgTmp_hb0ec899f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058107_));
    vlSelf->__VdfgTmp_hfd58f84f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_hc4384494__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_h4352298b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_h2e648f5f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_h730b9e6e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058106_));
    vlSelf->__VdfgTmp_h8cb25dc3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    vlSelf->__VdfgTmp_h63b44d2e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058191_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))));
    vlSelf->wasmetal_core__DOT___058189_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7751e274__0))))));
    vlSelf->wasmetal_core__DOT___058164_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058163_))));
    vlSelf->wasmetal_core__DOT___016659_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    __VdfgTmp_hc2887b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0));
    vlSelf->wasmetal_core__DOT___058176_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0))));
    vlSelf->wasmetal_core__DOT___015427_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___058165_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058097_))));
    wasmetal_core__DOT___036068_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036072_)) 
                                          | (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128815___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036072_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)))) 
           ^ (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
                                          << 1U)))));
    vlSelf->__VdfgTmp_h92569eda__0 = (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014838_));
    vlSelf->wasmetal_core__DOT___015223_ = ((8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))))))) 
                                            & (IData)(wasmetal_core__DOT___014672_));
    vlSelf->wasmetal_core__DOT___036181_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h1a362e4f__0))));
    vlSelf->__VdfgTmp_h6560f9f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015129_));
    vlSelf->wasmetal_core__DOT___015348_ = (1U & ((0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xe0U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                      ? 
                                                     (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d)))));
    vlSelf->__VdfgTmp_h112e4f0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014997_));
    vlSelf->__VdfgTmp_ha1ddff2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015132_ = (1U 
                                                & (0xf0f3355U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfeac399d__0)));
        vlSelf->wasmetal_core__DOT___014626_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014628_));
        vlSelf->wasmetal_core__DOT___014645_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014647_));
        vlSelf->wasmetal_core__DOT___014740_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014742_));
    } else {
        vlSelf->wasmetal_core__DOT___015132_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d)));
        vlSelf->wasmetal_core__DOT___014626_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d)));
        vlSelf->wasmetal_core__DOT___014645_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d)));
        vlSelf->wasmetal_core__DOT___014740_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d)));
    }
    vlSelf->wasmetal_core__DOT___015222_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058098_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014740_));
    vlSelf->wasmetal_core__DOT___058185_ = ((0x10000000U 
                                             >> ((0x10U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                     << 4U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)))))))) 
                                            & (IData)(wasmetal_core__DOT___014805_));
    wasmetal_core__DOT___015297_ = (1U & ((0x80U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___058188_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___058190_)))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hac6eec7f__0))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b30__05d)))));
    wasmetal_core__DOT___015296_ = (1U & ((0x4000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058191_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___058190_))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (IData)(
                                                        (0xfff0fffcfff0fffaULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015140_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015139_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h22db4e96__0)))))))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___015140_)))));
    vlSelf->wasmetal_core__DOT___015559_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058184_)))));
    vlSelf->wasmetal_core__DOT___015565_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015564_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___017105_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058171_)))));
    vlSelf->wasmetal_core__DOT___015443_ = (1U & (IData)(
                                                         (0x7f000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058172_)))))))));
    vlSelf->wasmetal_core__DOT___015554_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___017072_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015589_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015542_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015526_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))));
    vlSelf->wasmetal_core__DOT___015534_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058188_)))));
    vlSelf->wasmetal_core__DOT___015533_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058190_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))))))));
    vlSelf->wasmetal_core__DOT___015496_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xe0U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd141341a__0))))));
    vlSelf->wasmetal_core__DOT___016680_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    vlSelf->wasmetal_core__DOT___015491_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058099_))))));
    vlSelf->wasmetal_core__DOT___016632_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058096_))))));
    vlSelf->wasmetal_core__DOT___015435_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_h124450b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc2843286__0));
    vlSelf->wasmetal_core__DOT___015454_ = (1U & (IData)(
                                                         (0xef0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_hb78750ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058177_));
    vlSelf->wasmetal_core__DOT___016840_ = (1U & (IData)(
                                                         (0xbf000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0)))))));
    vlSelf->wasmetal_core__DOT___016805_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058161_)))));
    vlSelf->wasmetal_core__DOT___015516_ = (1U & (IData)(
                                                         (0x4fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h187f5418__0))))))));
    vlSelf->wasmetal_core__DOT___015501_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0)))))));
    vlSelf->wasmetal_core__DOT___016706_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___015486_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf7f00000U 
                                                            >> 
                                                            ((0x10U 
                                                              & ((8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))))))));
    vlSelf->wasmetal_core__DOT___015266_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x8fff000000000000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015262_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xefff000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015451_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)))))));
    vlSelf->__VdfgTmp_h62a95291__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xbfff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0))))));
    vlSelf->__VdfgTmp_h5cb76656__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xefff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((8U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0))))));
    vlSelf->wasmetal_core__DOT___015263_ = (1U & (IData)(
                                                         (0x40ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035981_) ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d));
    vlSelf->wasmetal_core__DOT___060222_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060220_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    vlSelf->wasmetal_core__DOT___016668_ = (1U & (IData)(
                                                         (0xf8ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___015481_ = (1U & (IData)(
                                                         (0xfe000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___016828_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->wasmetal_core__DOT___015506_ = (1U & (IData)(
                                                         (0x8fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->__VdfgTmp_hac20e9d0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0));
    wasmetal_core__DOT___015346_ = (1U & ((0x10U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                << 3U) 
                                               | (IData)(vlSelf->__VdfgTmp_h63b44d2e__0)))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h8d338479__0))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___015532_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h63b44d2e__0)))));
    vlSelf->__VdfgTmp_hb7a356d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058189_));
    wasmetal_core__DOT___058168_ = (1U & ((0x1000U 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                              ? (IData)(
                                                        (0xfff0fffcfff0fff5ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015196_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((8U 
                                                                        >> 
                                                                        ((2U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127779___O) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___005669_))) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3f743267__0)))))))
                                              : (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT___015196_)))));
    vlSelf->wasmetal_core__DOT___016612_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058164_)))));
    vlSelf->wasmetal_core__DOT___016644_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___016578_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058095_))))));
    vlSelf->wasmetal_core__DOT___016564_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))))));
    vlSelf->__VdfgTmp_h1cfd4ffd__0 = (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015059_));
    vlSelf->wasmetal_core__DOT___015522_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xbfffU 
                                                            >> 
                                                            ((0x10U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                 << 3U) 
                                                                | (IData)(__VdfgTmp_hc2887b39__0)))))))));
    vlSelf->wasmetal_core__DOT___015450_ = (1U & (IData)(
                                                         (0xbf0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_hc2887b39__0)))))));
    vlSelf->__VdfgTmp_hf715e513__0 = (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058175_));
    vlSelf->wasmetal_core__DOT___058186_ = ((0x40U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058184_)))) 
                                            & (IData)(wasmetal_core__DOT___014821_));
    vlSelf->wasmetal_core__DOT___015584_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058176_)))));
    vlSelf->__VdfgTmp_hc4af22e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058183_)));
    __VdfgTmp_h8cd84d2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015428_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015427_)));
    vlSelf->wasmetal_core__DOT___015434_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058098_)))));
    vlSelf->wasmetal_core__DOT___015204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015427_))));
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                 | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___014593_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014589_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014944_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    vlSelf->__VdfgTmp_he686eaae__0 = (((IData)(vlSelf->wasmetal_core__DOT___015559_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058624_));
    vlSelf->__VdfgTmp_hd270292e__0 = (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                       << 3U) | (IData)(__VdfgTmp_he527e66f__0));
    vlSelf->__VdfgTmp_ha6af91c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014686_));
    vlSelf->__VdfgTmp_hce52e19d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058655_));
    vlSelf->wasmetal_core__DOT___036184_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015443_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h7d44b025__0))));
    vlSelf->__VdfgTmp_h8ba6f9f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___015554_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058647_));
    vlSelf->wasmetal_core__DOT___036182_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_heded5023__0))));
    vlSelf->__VdfgTmp_h79cf8a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___015589_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058610_));
    vlSelf->__VdfgTmp_h98703c04__0 = (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058608_));
    vlSelf->__VdfgTmp_h1ae5646c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015526_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058604_));
    vlSelf->__VdfgTmp_hacb35d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015534_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h069b89c3__0));
    vlSelf->__VdfgTmp_h0abefb0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014588_));
    vlSelf->__VdfgTmp_hc38ac7a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___015496_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015128_));
    vlSelf->__VdfgTmp_h1f9a82f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015131_));
    vlSelf->__VdfgTmp_h84efc1e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015491_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015057_));
    vlSelf->wasmetal_core__DOT___015464_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015057_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016632_))))));
    vlSelf->__VdfgTmp_h9711c1d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___016632_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015061_));
    vlSelf->__VdfgTmp_h3aabb4dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014996_));
    vlSelf->__VdfgTmp_h4e293e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___015454_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014928_));
    vlSelf->wasmetal_core__DOT___015549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))));
    vlSelf->__VdfgTmp_h0e9f92ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015062_));
    vlSelf->__VdfgTmp_h8a1979d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014993_));
    vlSelf->__VdfgTmp_h4ee6c9c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014992_));
    vlSelf->__VdfgTmp_hb48d784b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014998_));
    vlSelf->wasmetal_core__DOT___058199_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015133_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016680_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015060_))))));
    vlSelf->__VdfgTmp_hdbf08427__0 = (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014995_));
    vlSelf->__VdfgTmp_h2a76d0fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___015486_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015133_));
    vlSelf->wasmetal_core__DOT___036202_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->__VdfgTmp_h71404310__0 = (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014723_));
    vlSelf->__VdfgTmp_ha00e7863__0 = (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    vlSelf->wasmetal_core__DOT___015531_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h62a95291__0))));
    vlSelf->wasmetal_core__DOT___015347_ = (1U & ((0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015511_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5cb76656__0))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                      ? 
                                                     (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5047773c__0))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___016760_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cb76656__0))));
    vlSelf->__VdfgTmp_h34f07943__0 = (((IData)(vlSelf->wasmetal_core__DOT___015263_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015394_));
    vlSelf->wasmetal_core__DOT____Vcellout___128795___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035992_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035981_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035970_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035936_ = ((IData)(vlSelf->wasmetal_core__DOT___035992_)
                                             ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d));
    vlSelf->__VdfgTmp_hee3b5d3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016668_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015060_));
    vlSelf->__VdfgTmp_h1758afa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015132_));
    vlSelf->wasmetal_core__DOT___058213_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015128_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015130_))))));
    vlSelf->__VdfgTmp_hebdd5702__0 = (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015130_));
    vlSelf->__VdfgTmp_he6b298f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___015506_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014994_));
    vlSelf->__VdfgTmp_hbe619ad7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015127_));
    wasmetal_core__DOT___015295_ = ((0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                << 2U) 
                                               | (IData)(vlSelf->__VdfgTmp_hb7a356d8__0))) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014786_));
    vlSelf->wasmetal_core__DOT___015442_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a356d8__0))));
    vlSelf->__VdfgTmp_h1cf51478__0 = (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d))))));
    vlSelf->__VdfgTmp_h9c126c52__0 = (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h42abc930__0));
    vlSelf->wasmetal_core__DOT___036203_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014931_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014930_)))));
    vlSelf->__VdfgTmp_hefd4f1fe__0 = (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015056_));
    vlSelf->wasmetal_core__DOT___058201_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016578_))))));
    vlSelf->wasmetal_core__DOT___058167_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->wasmetal_core__DOT___015202_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->__VdfgTmp_hd5ff8c3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015203_));
    vlSelf->__VdfgTmp_h7d39981d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015264_));
    vlSelf->wasmetal_core__DOT___015265_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015522_))));
    vlSelf->wasmetal_core__DOT___058212_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015454_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015454_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d))))) 
                                                  & (IData)(
                                                            (0xeee0eee0eee00000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___015450_))))))))));
    vlSelf->__VdfgTmp_h59ed23b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014718_));
    vlSelf->wasmetal_core__DOT___015395_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015454_))));
    vlSelf->wasmetal_core__DOT___015221_ = ((4U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf715e513__0)))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014778_));
    vlSelf->wasmetal_core__DOT___015579_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf715e513__0)))));
    vlSelf->__VdfgTmp_hcec7f9ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___015584_) 
                                       << 3U) | (IData)(__VdfgTmp_h2e1acbd8__0));
    wasmetal_core__DOT___014770_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___014772_)
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))));
    vlSelf->wasmetal_core__DOT___058187_ = ((0x4000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___058175_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc4af22e3__0))) 
                                            & (IData)(wasmetal_core__DOT___014770_));
    vlSelf->wasmetal_core__DOT___015574_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc4af22e3__0))));
    vlSelf->__VdfgTmp_hc0955a68__0 = (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015428_));
    wasmetal_core__DOT___016599_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128816___O 
        = ((3U & (- (IData)((IData)(vlSelf->wasmetal_core__DOT___036073_)))) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                       | (IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___017498_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014592_))));
    vlSelf->__VdfgTmp_hb05d86c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___014589_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058604_));
    vlSelf->__VdfgTmp_h7eb9770e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014589_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014588_));
    vlSelf->wasmetal_core__DOT___017471_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058608_))));
    vlSelf->wasmetal_core__DOT___014929_ = ((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                            & (IData)(wasmetal_core__DOT___014704_));
    vlSelf->wasmetal_core__DOT___036094_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058608_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014944_))));
    vlSelf->wasmetal_core__DOT___058104_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___058100_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014944_)))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___015361_ = (1U 
                                                & (IData)(
                                                          (0xfff0fffcfff0fffaULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015166_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015165_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h375bf609__0))))))));
        vlSelf->wasmetal_core__DOT___015409_ = (1U 
                                                & (IData)(
                                                          (0xfff0fffcfff0fffaULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015109_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015108_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf7593d1b__0))))))));
        vlSelf->wasmetal_core__DOT___015566_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015569_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014647_)));
        wasmetal_core__DOT___015543_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015554_)) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014682_)));
    } else {
        vlSelf->wasmetal_core__DOT___015361_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015166_)));
        vlSelf->wasmetal_core__DOT___015409_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015109_)));
        vlSelf->wasmetal_core__DOT___015566_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015569_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d))));
        wasmetal_core__DOT___015543_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015554_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d))));
    }
    vlSelf->wasmetal_core__DOT___015462_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015549_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___015549_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d))))) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                        ? 
                                                       ((~ (IData)(vlSelf->wasmetal_core__DOT___015559_)) 
                                                        & (0xf0f0ccaaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)))
                                                        : 
                                                       ((~ (IData)(vlSelf->wasmetal_core__DOT___015559_)) 
                                                        & (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d))))) 
                                                     & (IData)(
                                                               (0xff11ff0fULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___015543_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015542_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b32__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015541_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___015540_)))))))))));
    vlSelf->__VdfgTmp_h4200eb01__0 = (((IData)(vlSelf->wasmetal_core__DOT___015549_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058630_));
    vlSelf->wasmetal_core__DOT___015188_ = (1U & (0xeeeef0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016706_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014995_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2a76d0fc__0))))));
    vlSelf->wasmetal_core__DOT___015537_ = (1U & (IData)(
                                                         (0xeee0eee0eee00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015532_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015129_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015062_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015531_)))))))));
    vlSelf->__VdfgTmp_h645aaafb__0 = (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015134_));
    vlSelf->wasmetal_core__DOT___015212_ = (1U & ((~ 
                                                   ((0x40U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h62a95291__0))) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                        ? 
                                                       (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4eb011e3__0))
                                                        : 
                                                       (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b27__05d))))) 
                                                  & ((~ 
                                                      ((IData)(
                                                               (0x1000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))))) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? (IData)(
                                                                     (0xfff0fffcfff0fffaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015102_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015101_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e28f3c0__0)))))))
                                                           : 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015102_))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015348_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015347_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015346_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (((0x2000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058161_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d))))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d)))) 
                                                                              << 2U)) 
                                                                          | ((((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))))) 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT___015361_)) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((0x40000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xe0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d)))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b73c7a2__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b24__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___015463_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014992_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014998_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016760_))))));
    vlSelf->__VdfgTmp_hf4473e75__0 = (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014999_));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036003_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035936_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d));
    vlSelf->wasmetal_core__DOT___015211_ = (1U & ((~ 
                                                   ((0x8000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058177_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0))))))) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___014732_))) 
                                                  & ((~ 
                                                      ((0x10000000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                             << 4U)) 
                                                         | ((8U 
                                                             & ((0xf8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                << 3U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h124450b0__0)))) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? (IData)(
                                                                     (0xfff0fff3fff0fffaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014714_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014713_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd148b96b__0)))))))
                                                           : 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___014714_))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___015297_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___015296_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015295_) 
                                                                        << 3U) 
                                                                       | ((((0x8000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058189_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))) 
                                                                            & (IData)(wasmetal_core__DOT___014696_)) 
                                                                           << 2U) 
                                                                          | ((((0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_))))) 
                                                                               & (IData)(wasmetal_core__DOT___014704_)) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((0x1000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058188_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___014926_)
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___036180_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h4528f615__0))));
    vlSelf->wasmetal_core__DOT___015189_ = (1U & (IData)(
                                                         (0xbf00bfbfULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058168_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058167_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015427_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015428_)))))))));
    wasmetal_core__DOT___015190_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014592_)
                                           ? (IData)(
                                                     (0xcc0c5505ff0fff0fULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015202_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d))))))))
                                           : (0xdU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015203_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015202_)))));
    __VdfgTmp_hbc941cc7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015265_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015263_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h71404310__0))));
    __VdfgTmp_h4ef0e6f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015395_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015266_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h34f07943__0))));
    vlSelf->wasmetal_core__DOT___036191_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015579_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9624abf4__0))));
    wasmetal_core__DOT___015210_ = (1U & (IData)((0xfbULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058187_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058186_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058185_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015451_)))))))));
    vlSelf->__VdfgTmp_hd6a04253__0 = (((IData)(vlSelf->wasmetal_core__DOT___015574_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_ha028555e__0));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058215_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015589_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014628_)));
        vlSelf->wasmetal_core__DOT___015473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015496_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4cab1815__0))));
        vlSelf->wasmetal_core__DOT___015474_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015501_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfeac399d__0))));
        vlSelf->wasmetal_core__DOT___015475_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015506_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd6336c37__0))));
        vlSelf->wasmetal_core__DOT___058200_ = (1U 
                                                & (0xfac8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015432_))))));
    } else {
        vlSelf->wasmetal_core__DOT___058215_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015589_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d))));
        vlSelf->wasmetal_core__DOT___015473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015496_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b23__05d))));
        vlSelf->wasmetal_core__DOT___015474_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015501_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b17__05d))));
        vlSelf->wasmetal_core__DOT___015475_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015506_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b20__05d))));
        vlSelf->wasmetal_core__DOT___058200_ = (1U 
                                                & (0xf351U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b8__05d))))));
    }
    vlSelf->wasmetal_core__DOT___016551_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058200_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058199_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016668_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfff01110U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                              ? 
                                                                             (0xfff00bbU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))
                                                                              : 
                                                                             (0xff0fbb00U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b1__05d) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h8cd84d2f__0))))))))))))));
    vlSelf->__VdfgTmp_h605612ae__0 = (((IData)(wasmetal_core__DOT___016599_) 
                                       << 1U) | (1U 
                                                 & (0xc5U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h09c9c684__0))));
    wasmetal_core__DOT___036128_ = (1U & (0xc500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017498_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h069b89c3__0))));
    vlSelf->wasmetal_core__DOT___058109_ = ((0x800000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hac20e9d0__0)))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014626_));
    vlSelf->wasmetal_core__DOT___058110_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014645_));
    vlSelf->wasmetal_core__DOT___058114_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hfd58f84f__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014680_));
    vlSelf->wasmetal_core__DOT___058121_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h786a2bba__0))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014813_));
    vlSelf->wasmetal_core__DOT___058122_ = ((0x10000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8cb25dc3__0))))) 
                                            & (IData)(wasmetal_core__DOT___014821_));
    vlSelf->wasmetal_core__DOT___058111_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058099_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___014653_));
    vlSelf->wasmetal_core__DOT___058113_ = ((0x40000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___058107_)))))) 
                                            & (IData)(wasmetal_core__DOT___014672_));
    wasmetal_core__DOT___058118_ = ((0x1000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfd58f84f__0))))) 
                                    & (IData)(wasmetal_core__DOT___014770_));
    wasmetal_core__DOT___058119_ = ((0x10000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0ec899f__0))))) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014778_));
    wasmetal_core__DOT___014690_ = ((0x40000000U >> 
                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058106_)))))) 
                                    & (IData)(wasmetal_core__DOT___014696_));
    vlSelf->wasmetal_core__DOT___014845_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014917_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014886_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014881_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014901_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb25dc3__0))))));
    vlSelf->wasmetal_core__DOT___014891_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h786a2bba__0))))));
    vlSelf->wasmetal_core__DOT___014850_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc4384494__0))))));
    vlSelf->wasmetal_core__DOT___014860_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0))))));
    vlSelf->wasmetal_core__DOT___014896_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hac20e9d0__0)))));
    vlSelf->__VdfgTmp_h89d6ed4e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_h98bb6818__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0ec899f__0))));
    vlSelf->__VdfgTmp_hd1e881b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h283c0448__0))));
    vlSelf->wasmetal_core__DOT___058115_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058100_))));
    __VdfgTmp_h4ac2372d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036010_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058133_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014589_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014926_)));
        vlSelf->wasmetal_core__DOT___058211_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015443_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0xf0f3355U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)))))
                                                    : 
                                                   (0x110010U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((0xf0f3355U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf11accec__0)) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015439_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015438_))))))));
    } else {
        vlSelf->wasmetal_core__DOT___058133_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014589_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d))));
        vlSelf->wasmetal_core__DOT___058211_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015443_)
                                                    ? 
                                                   (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d)))
                                                    : 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015442_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015441_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d))))));
    }
    vlSelf->wasmetal_core__DOT___016552_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058212_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058211_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfc00aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017059_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058207_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058206_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xfc00aaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017072_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058205_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058204_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfc00aaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017105_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058203_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___016554_ = (1U & ((IData)(
                                                          (0xfff0fff01111ffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015056_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h42abc930__0))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015190_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015189_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015188_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xeeeef0ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015516_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014992_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he6b298f6__0))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xfff0bbbbU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___016840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016828_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015531_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015062_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xfff0bbbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015501_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015481_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014998_))))))))))))))));
    vlSelf->wasmetal_core__DOT___058216_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___015579_)) 
                                                   & (0xf0f0ccaaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c8b9fc6__0)))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___015579_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___016553_ = (1U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058216_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (0xf0f0ccaaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0)))
                                                                : 
                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___015584_)) 
                                                                & (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d)))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___015263_)))))) 
                                                  & (((~ 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___014772_))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___015574_)) 
                                                         & (2U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))))) 
                                                      & (IData)(
                                                                (0xaaaf888cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015566_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015565_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015564_))))))))) 
                                                     & (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015464_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015463_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015462_) 
                                                                        << 3U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___015534_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___015537_)
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___015537_))) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014926_))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015526_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d))))) 
                                                                                & (IData)(
                                                                                (0xeee0eee0eee00000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015262_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015523_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015134_))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hadaed6e9__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015516_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b21__05d))))) 
                                                                                & ((~ 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5047773c__0)))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___015511_)) 
                                                                                & (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b19__05d))))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015475_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015474_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015473_) 
                                                                                << 3U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015491_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015409_)) 
                                                                                << 2U) 
                                                                                | ((((~ (IData)(vlSelf->wasmetal_core__DOT___015486_)) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___015361_)) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___015481_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? (IData)(
                                                                                (0xfff0fffcfff0fffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015025_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015024_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b356604__0)))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015025_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___016555_ = (1U & ((1U 
                                                   >> 
                                                   ((8U 
                                                     & (((0x80U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0))) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                             ? (IData)(
                                                                       (0xfff0fffcfff0fffaULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015078_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015077_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1a5afed0__0)))))))
                                                             : 
                                                            (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___015078_)))) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & (((0x4000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___058096_))))) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                ? (IData)(
                                                                          (0xfff0fffcfff0fffaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015032_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015031_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h210df1ee__0)))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___015032_)))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (((0x80U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))) 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                   ? (IData)(
                                                                             (0xfff0fff3fff0fffaULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015096_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015095_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39f326f7__0)))))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015096_)))) 
                                                              << 1U)) 
                                                          | ((0x4000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_ha1ddff2b__0)))) 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___015409_)))))) 
                                                  & (((~ 
                                                       ((0x4000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058183_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058098_))))) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___014813_))) 
                                                      & ((1U 
                                                          & (4U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015522_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015450_))))
                                                          ? (IData)(
                                                                    (0xef00efef00000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                       << 5U) 
                                                                      | (IData)(__VdfgTmp_h4ef0e6f0__0))))
                                                          : 
                                                         (0xef00efefU 
                                                          >> (IData)(__VdfgTmp_h4ef0e6f0__0)))) 
                                                     & (IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015212_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015211_) 
                                                                     << 4U) 
                                                                    | (((IData)(wasmetal_core__DOT___015210_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (((~ 
                                                                                ((0x10000000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h124450b0__0)))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014626_))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___015266_)
                                                                                 ? 
                                                                                (0xef00efefU 
                                                                                >> (IData)(__VdfgTmp_hbc941cc7__0))
                                                                                 : (IData)(
                                                                                (0xef00efef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (IData)(__VdfgTmp_hbc941cc7__0)))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & (((~ 
                                                                                ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015569_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014645_))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015223_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015222_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015221_) 
                                                                                << 3U) 
                                                                                | ((((0x10000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc2843286__0))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014680_)) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((0x8000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                                 ? 
                                                                                (0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfd6d7e7__0))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b40__05d)))) 
                                                                                << 1U)) 
                                                                                | ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058156_)))))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___014653_)))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x13135f0000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b2__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015204_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014592_)))))))))))))))))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0))));
    wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                 & (7U >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0))));
    vlSelf->wasmetal_core__DOT___014585_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058119_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058118_) 
                                                       << 3U) 
                                                      | ((((0x40000000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)))))))) 
                                                           & (IData)(vlSelf->wasmetal_core__DOT___014786_)) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058106_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d))))))))))));
    vlSelf->__VdfgTmp_h8afeda64__0 = (((IData)(vlSelf->wasmetal_core__DOT___014845_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058624_));
    vlSelf->__VdfgTmp_h3b293f2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014917_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_ha028555e__0));
    vlSelf->__VdfgTmp_hdd2d87f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___014886_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014838_));
    vlSelf->__VdfgTmp_had382f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___014881_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058630_));
    vlSelf->__VdfgTmp_hc81f4faf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014901_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058655_));
    vlSelf->wasmetal_core__DOT___017569_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014891_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60abdace__0))));
    vlSelf->wasmetal_core__DOT___036100_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014891_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h7d44b025__0))));
    vlSelf->__VdfgTmp_h10ee820a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014850_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058647_));
    vlSelf->wasmetal_core__DOT___017513_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014860_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8495bec__0))));
    vlSelf->wasmetal_core__DOT___036096_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014860_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h4528f615__0))));
    vlSelf->wasmetal_core__DOT___014842_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___014901_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___014655_))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___014901_)) 
                                                         & (2U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                            ? 
                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___014896_)) 
                                                            & (IData)(vlSelf->wasmetal_core__DOT___014628_))
                                                            : 
                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___014896_)) 
                                                            & (2U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b33__05d)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                             ? 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___014891_)) 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___014742_))
                                                             : 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___014891_)) 
                                                             & (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d)))))))));
    vlSelf->__VdfgTmp_h7463a48f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014896_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058610_));
    vlSelf->wasmetal_core__DOT___058120_ = ((0x4000U 
                                             >> (IData)(vlSelf->__VdfgTmp_h89d6ed4e__0)) 
                                            & (IData)(wasmetal_core__DOT___014805_));
    vlSelf->wasmetal_core__DOT___014987_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d6ed4e__0))));
    vlSelf->wasmetal_core__DOT___017527_ = (1U & (0xfef00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38acc8e1__0))));
    vlSelf->__VdfgTmp_h003f7a85__0 = ((2U & ((0xf8ffU 
                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015523_));
    vlSelf->wasmetal_core__DOT___036097_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_h1a362e4f__0))));
    vlSelf->wasmetal_core__DOT___017544_ = (1U & (0xfef00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab75b8e3__0))));
    vlSelf->__VdfgTmp_h6f76189e__0 = ((2U & ((0xf8ffU 
                                              >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___014723_));
    vlSelf->wasmetal_core__DOT___036098_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x80ffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                       << 4U)) 
                                                   | (IData)(__VdfgTmp_heded5023__0))));
    vlSelf->wasmetal_core__DOT___014583_ = (1U & ((~ 
                                                   ((0x10000000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))) 
                                                    & (IData)(wasmetal_core__DOT___014704_))) 
                                                  & (IData)(
                                                            (0x454545cfULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___014690_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0x40U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058106_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058115_))))))))))))));
    vlSelf->wasmetal_core__DOT___014719_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___058108_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h786a2bba__0)))));
    vlSelf->wasmetal_core__DOT___014720_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0)))));
    vlSelf->wasmetal_core__DOT___014722_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc4384494__0)))));
    vlSelf->wasmetal_core__DOT___014982_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h4ac2372d__0))));
    if (vlSelf->wasmetal_core__DOT___005670_) {
        vlSelf->wasmetal_core__DOT___058132_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014917_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___014772_)));
        wasmetal_core__DOT___014874_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014886_)) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014647_)));
        wasmetal_core__DOT___058128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014860_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hf11accec__0))));
        wasmetal_core__DOT___058127_ = (1U & ((~ (0x80ffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0))) 
                                              & (IData)(vlSelf->wasmetal_core__DOT___014674_)));
        wasmetal_core__DOT___058138_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014987_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_hcbc05328__0))));
        wasmetal_core__DOT___058139_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014982_)) 
                                              & (0xf0f0ccaaU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h4984bec9__0))));
    } else {
        vlSelf->wasmetal_core__DOT___058132_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014917_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b45__05d))));
        wasmetal_core__DOT___014874_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014886_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b43__05d))));
        wasmetal_core__DOT___058128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014860_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b34__05d))));
        wasmetal_core__DOT___058127_ = (1U & ((~ (0x80ffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0))) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b36__05d))));
        wasmetal_core__DOT___058138_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014987_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d))));
        wasmetal_core__DOT___058139_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014982_)) 
                                              & (2U 
                                                 >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b48__05d))));
    }
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036011_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d));
    vlSelf->wasmetal_core__DOT___058217_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016555_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016554_))));
    wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036176_) 
           & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036094_) 
           & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hfc02ca5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014987_) 
                                       << 3U) | (IData)(__VdfgTmp_h2e1acbd8__0));
    vlSelf->wasmetal_core__DOT___014840_ = (1U & (IData)(
                                                         (0xdULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058128_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015196_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058127_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                                          ? 
                                                                         ((~ 
                                                                           (0x80ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___014788_))
                                                                          : 
                                                                         ((~ 
                                                                           (0x80ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))) 
                                                                          & (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015433_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005670_)))))))));
    vlSelf->__VdfgTmp_h75855164__0 = (((IData)(vlSelf->wasmetal_core__DOT___014719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014718_));
    vlSelf->wasmetal_core__DOT___036093_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058108_))));
    vlSelf->__VdfgTmp_h1a8efff9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015264_));
    vlSelf->wasmetal_core__DOT___036092_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014722_))));
    vlSelf->__VdfgTmp_h6dc90017__0 = (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014928_));
    vlSelf->wasmetal_core__DOT___014837_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h283c0448__0)))));
    vlSelf->wasmetal_core__DOT___014873_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___014927_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128801___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036012_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036011_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036010_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036003_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035936_)))));
    vlSelf->wasmetal_core__DOT___035957_ = ((IData)(vlSelf->wasmetal_core__DOT___036012_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d));
    vlSelf->wasmetal_core__DOT___058218_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058217_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128828___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036176_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h605612ae__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h605612ae__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___036241_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0)) 
                                    & (IData)(wasmetal_core__DOT___128828___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128817___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036094_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___036128_)))) 
           ^ (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT___036128_)) 
                                          << 1U)))));
    wasmetal_core__DOT___036121_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                    & (IData)(wasmetal_core__DOT___128817___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014584_ = (1U & ((~ 
                                                   ((0x10000000U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0))))) 
                                                    & (IData)(vlSelf->wasmetal_core__DOT___014732_))) 
                                                  & ((~ 
                                                      ((0x40000000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___058096_)))))) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___014740_))) 
                                                     & (IData)(
                                                               (0xefefefefef00efefULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((0xf8ffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h75855164__0))))))))));
    vlSelf->wasmetal_core__DOT___014910_ = (1U & (IData)(
                                                         (0xfca8ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058139_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf8ffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015394_)))))))));
    vlSelf->wasmetal_core__DOT___017606_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014837_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7054d7e2__0))));
    vlSelf->wasmetal_core__DOT___036082_ = (1U & (0xffe0ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014837_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9624abf4__0))));
    vlSelf->wasmetal_core__DOT___014841_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___014881_)) 
                                                     & (0xf0f0ccaaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd3180128__0)))
                                                     : 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___014881_)) 
                                                     & (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b42__05d))))) 
                                                  & (IData)(
                                                            (0xcf8aULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014875_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___014874_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014873_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014872_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014686_))))))))));
    vlSelf->__VdfgTmp_h40a80dc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___014873_) 
                                       << 3U) | (IData)(__VdfgTmp_he527e66f__0));
    vlSelf->wasmetal_core__DOT___017660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014686_))));
    vlSelf->wasmetal_core__DOT___036078_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014686_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014927_))));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036013_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035957_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d));
    wasmetal_core__DOT___016602_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___016599_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016593_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015434_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016558_ = (1U & (0xd5555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)) 
           & (IData)(wasmetal_core__DOT___036241_));
    wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036096_) 
           & (IData)(wasmetal_core__DOT___036121_));
    vlSelf->wasmetal_core__DOT___017473_ = (1U & ((IData)(
                                                          (0xfdULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058122_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058121_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058120_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015264_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xf8ffU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014584_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014583_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaf8cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058114_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058113_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058108_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015523_)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((IData)(
                                                                                (0xfdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058111_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058110_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015394_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058108_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b31__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005670_))))
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? 
                                                                                (0xa3U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___014589_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___014593_)
                                                                                 ? (IData)(
                                                                                (0xaaaaaaaa3f3f3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7eb9770e__0)))))))
                                                                                 : 
                                                                                (0x777fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014591_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014590_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014589_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___017469_ = (((IData)(vlSelf->wasmetal_core__DOT___015134_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___015133_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015132_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015131_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015130_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015129_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015128_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015127_)))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___015062_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015061_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015060_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015059_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015058_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015057_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015056_))))))))) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014911_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014910_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___014931_)) 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___014930_)) 
                                                                            & (IData)(
                                                                                (0xaaaf888cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014719_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014927_)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfca8ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058133_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058132_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014718_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014720_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014722_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014588_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014593_))))))))))))));
    vlSelf->wasmetal_core__DOT___017470_ = (1U & ((1U 
                                                   >> 
                                                   ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                          ? 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (IData)(vlSelf->wasmetal_core__DOT___014682_))
                                                          : 
                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___014850_)) 
                                                          & (2U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b37__05d)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                           ? 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (0xf0f0ccaaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7c5b2a1d__0)))
                                                           : 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___014845_)) 
                                                           & (2U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b46__05d))))))) 
                                                  & (IData)(
                                                            (0xe00000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014842_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014841_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014840_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((0xf8ffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___015523_))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014838_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___014837_))))))))));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036014_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d));
    wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036203_) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036097_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058948_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 3U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb05d86c8__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___017498_)))))))));
    __VdfgTmp_he63183d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014589_)));
    __VdfgTmp_he967bd3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014944_)));
    __VdfgTmp_h56377d30__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014896_)));
    __VdfgTmp_h823d6b3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014860_)));
    __VdfgTmp_hea8c747f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_h98bb6818__0)))));
    __VdfgTmp_hed321262__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                          << 1U) | 
                                         (1U & (0x80ffU 
                                                >> (IData)(vlSelf->__VdfgTmp_hd1e881b7__0)))));
    vlSelf->__VdfgTmp_h624ea096__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014850_)));
    vlSelf->__VdfgTmp_h44742984__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014891_)));
    vlSelf->__VdfgTmp_hb82ac2db__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014901_)));
    vlSelf->__VdfgTmp_h703c2d50__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014927_)));
    vlSelf->__VdfgTmp_hb3e763f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014873_)));
    vlSelf->__VdfgTmp_h0a1cab09__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014881_)));
    vlSelf->__VdfgTmp_h98026846__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014886_)));
    vlSelf->__VdfgTmp_h9f21faf7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014837_)));
    vlSelf->__VdfgTmp_hba893859__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014917_)));
    vlSelf->__VdfgTmp_h9bcd87c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014845_)));
    vlSelf->__VdfgTmp_h6331a531__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014987_)));
    vlSelf->__VdfgTmp_h155f9d55__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014982_)));
    vlSelf->__VdfgTmp_hb895011c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014719_)));
    vlSelf->__VdfgTmp_heacb01d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014720_)));
    vlSelf->wasmetal_core__DOT___058153_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017469_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017473_)))));
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035960_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hc0955a68__0)))));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (1U >> (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___058137_))))));
        } else {
            vlSelf->wasmetal_core__DOT___058563_ = 
                (1U & (IData)(wasmetal_core__DOT___016602_));
            vlSelf->wasmetal_core__DOT___016585_ = 
                (1U & (IData)(wasmetal_core__DOT___016593_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058563_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016602_));
        vlSelf->wasmetal_core__DOT___016585_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016593_));
    }
    vlSelf->__VdfgTmp_h4cc4790a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058563_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016585_));
    vlSelf->wasmetal_core__DOT___016586_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016554_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd5ff8c3b__0))))
                                                    : (IData)(wasmetal_core__DOT___016558_))
                                                   : (IData)(wasmetal_core__DOT___016558_)));
    vlSelf->__VdfgTmp_h6047dcd2__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___016585_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___016586_)))));
    wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
           & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036098_) 
           & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058942_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017471_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_he63183d7__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128802___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035961_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035960_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036014_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036013_)))) 
           ^ (((IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035957_)))));
    vlSelf->wasmetal_core__DOT___035905_ = ((IData)(vlSelf->wasmetal_core__DOT___035961_)
                                             ? (IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d));
    wasmetal_core__DOT____Vcellout___128833___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036203_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036241_)))));
    wasmetal_core__DOT___036260_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)) 
                                    & (IData)(wasmetal_core__DOT___128833___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128818___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036098_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036097_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036121_)))));
    wasmetal_core__DOT___036125_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                    & (IData)(wasmetal_core__DOT___128818___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT___017473_) {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017471_))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (4U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___058949_ = (1U 
                                                & (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | (IData)(__VdfgTmp_he63183d7__0)))));
        vlSelf->wasmetal_core__DOT___058943_ = (1U 
                                                & (0x7f00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O)) 
                                                       | (IData)(__VdfgTmp_he967bd3f__0)))));
    }
    vlSelf->__VdfgTmp_h74f09674__0 = (((IData)(vlSelf->wasmetal_core__DOT___058942_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058943_));
    vlSelf->wasmetal_core__DOT___053600_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035962_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035905_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d));
    wasmetal_core__DOT___016567_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016564_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128833___O))))))));
    wasmetal_core__DOT___016581_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___016647_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016644_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___016615_ = (1U & (0x75555555U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016612_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128833___O) 
                                                             >> 3U))))))));
    if (vlSelf->wasmetal_core__DOT___016555_) {
        if (vlSelf->wasmetal_core__DOT___016554_) {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_hefd4f1fe__0)))));
            wasmetal_core__DOT___016571_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (0xe0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c126c52__0)))));
            wasmetal_core__DOT___016639_ = (1U & (1U 
                                                  >> 
                                                  (1U 
                                                   & (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1cf51478__0)))));
            vlSelf->wasmetal_core__DOT___016607_ = 
                (1U & (1U >> (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h3aabb4dd__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___016572_ = 
                (1U & (IData)(wasmetal_core__DOT___016567_));
            wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
            wasmetal_core__DOT___016639_ = (1U & (IData)(wasmetal_core__DOT___016647_));
            vlSelf->wasmetal_core__DOT___016607_ = 
                (1U & (IData)(wasmetal_core__DOT___016615_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___016572_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016567_));
        wasmetal_core__DOT___016571_ = (1U & (IData)(wasmetal_core__DOT___016581_));
        wasmetal_core__DOT___016639_ = (1U & (IData)(wasmetal_core__DOT___016647_));
        vlSelf->wasmetal_core__DOT___016607_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016615_));
    }
    wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)) 
           & (IData)(wasmetal_core__DOT___036260_));
    vlSelf->__VdfgTmp_ha3f8ca93__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff007f7f0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128817___O) 
                                                           << 1U)) 
                                                       | ((8U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7463a48f__0)) 
                                                              << 3U)) 
                                                          | (IData)(__VdfgTmp_he967bd3f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017513_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 3U)) 
                                                         | (IData)(__VdfgTmp_h56377d30__0)))))));
    vlSelf->__VdfgTmp_ha61a6e02__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 4U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017513_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h56377d30__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017527_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 2U)) 
                                                         | (IData)(__VdfgTmp_h823d6b3b__0)))))));
    vlSelf->__VdfgTmp_hac5f758c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017527_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_h823d6b3b__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017544_)))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                             << 1U)) 
                                                         | (IData)(__VdfgTmp_hea8c747f__0)))))));
    vlSelf->__VdfgTmp_h6c11e1cc__0 = ((((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                        & (IData)((0xff00ff00bfbf0000ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                     << 5U) 
                                                    | ((0x10U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017544_) 
                                                           << 3U) 
                                                          | (IData)(__VdfgTmp_hea8c747f__0))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                     ? 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)))))
                                                     : 
                                                    (0xbf00U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128818___O)) 
                                                         | (IData)(__VdfgTmp_hed321262__0)))))));
    vlSelf->wasmetal_core__DOT___058985_ = ((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                            & (IData)(
                                                      (0xff00ff00bfbf0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017473_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128818___O) 
                                                               << 1U)) 
                                                           | ((8U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10ee820a__0)) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hed321262__0)))))));
    wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036100_) 
           & (IData)(wasmetal_core__DOT___036125_));
    wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035963_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d));
    wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035964_)
            ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d));
    vlSelf->__VdfgTmp_h52207b53__0 = (((IData)(vlSelf->wasmetal_core__DOT___016572_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016571_));
    vlSelf->__VdfgTmp_hc5bb64fc__0 = (((IData)(wasmetal_core__DOT___016571_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016639_));
    vlSelf->__VdfgTmp_he0d8c702__0 = (((IData)(wasmetal_core__DOT___016639_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016607_));
    wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
           & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036078_) 
           & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128803___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035965_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035964_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035963_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035962_)))) 
           ^ (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128803___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035905_)))));
    vlSelf->wasmetal_core__DOT___035909_ = ((IData)(vlSelf->wasmetal_core__DOT___035965_)
                                             ? (IData)(wasmetal_core__DOT___128803___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d));
    wasmetal_core__DOT____Vcellout___128834___O = (
                                                   ((8U 
                                                     & ((7U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((7U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1cfd4ffd__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((7U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84efc1e5__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (7U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h9711c1d2__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036260_)))));
    vlSelf->wasmetal_core__DOT___036210_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hee3b5d3c__0)) 
                                            & (IData)(wasmetal_core__DOT___128834___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128819___O 
        = (((8U & ((0x3affU >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036078_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc81f4faf__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___036100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036125_)))));
    vlSelf->wasmetal_core__DOT___058986_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017473_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017569_)))
                                                   : 
                                                  (0xbf00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128819___O) 
                                                           << 3U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h624ea096__0))))));
    vlSelf->wasmetal_core__DOT___036104_ = ((0x3affU 
                                             >> (IData)(vlSelf->__VdfgTmp_h40a80dc0__0)) 
                                            & (IData)(wasmetal_core__DOT___128819___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053611_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053598_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035966_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035909_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d));
    vlSelf->wasmetal_core__DOT___016623_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015435_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128834___O))))))));
    vlSelf->wasmetal_core__DOT___016635_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016632_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016694_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___016662_ = (1U & (0x75555555U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016659_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128834___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128835___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h1f9a82f6__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036210_));
}
