#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__49(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__49\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006365_;
    wasmetal_core__DOT___006365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006366_;
    wasmetal_core__DOT___006366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006442_;
    wasmetal_core__DOT___006442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006443_;
    wasmetal_core__DOT___006443_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006531_;
    wasmetal_core__DOT___006531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006532_;
    wasmetal_core__DOT___006532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006572_;
    wasmetal_core__DOT___006572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006608_;
    wasmetal_core__DOT___006608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006611_;
    wasmetal_core__DOT___006611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006612_;
    wasmetal_core__DOT___006612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006618_;
    wasmetal_core__DOT___006618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007069_;
    wasmetal_core__DOT___007069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007072_;
    wasmetal_core__DOT___007072_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007075_;
    wasmetal_core__DOT___007075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007087_;
    wasmetal_core__DOT___007087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007091_;
    wasmetal_core__DOT___007091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007100_;
    wasmetal_core__DOT___007100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007109_;
    wasmetal_core__DOT___007109_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007113_;
    wasmetal_core__DOT___007113_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007117_;
    wasmetal_core__DOT___007117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007123_;
    wasmetal_core__DOT___007123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007135_;
    wasmetal_core__DOT___007135_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007145_;
    wasmetal_core__DOT___007145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007155_;
    wasmetal_core__DOT___007155_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007169_;
    wasmetal_core__DOT___007169_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007185_;
    wasmetal_core__DOT___007185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009495_;
    wasmetal_core__DOT___009495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012317_;
    wasmetal_core__DOT___012317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012357_;
    wasmetal_core__DOT___012357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012358_;
    wasmetal_core__DOT___012358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012359_;
    wasmetal_core__DOT___012359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012971_;
    wasmetal_core__DOT___012971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013023_;
    wasmetal_core__DOT___013023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014473_;
    wasmetal_core__DOT___014473_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014483_;
    wasmetal_core__DOT___014483_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014497_;
    wasmetal_core__DOT___014497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014500_;
    wasmetal_core__DOT___014500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014501_;
    wasmetal_core__DOT___014501_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014511_;
    wasmetal_core__DOT___014511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014525_;
    wasmetal_core__DOT___014525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014553_;
    wasmetal_core__DOT___014553_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015115_;
    wasmetal_core__DOT___015115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015117_;
    wasmetal_core__DOT___015117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015154_;
    wasmetal_core__DOT___015154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024194_;
    wasmetal_core__DOT___024194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024325_;
    wasmetal_core__DOT___024325_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024876_;
    wasmetal_core__DOT___024876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024881_;
    wasmetal_core__DOT___024881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035704_;
    wasmetal_core__DOT___035704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035705_;
    wasmetal_core__DOT___035705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035706_;
    wasmetal_core__DOT___035706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035801_;
    wasmetal_core__DOT___035801_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035805_;
    wasmetal_core__DOT___035805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035809_;
    wasmetal_core__DOT___035809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035814_;
    wasmetal_core__DOT___035814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035825_;
    wasmetal_core__DOT___035825_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043364_;
    wasmetal_core__DOT___043364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043365_;
    wasmetal_core__DOT___043365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043366_;
    wasmetal_core__DOT___043366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043387_;
    wasmetal_core__DOT___043387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043388_;
    wasmetal_core__DOT___043388_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043389_;
    wasmetal_core__DOT___043389_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043428_;
    wasmetal_core__DOT___043428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043429_;
    wasmetal_core__DOT___043429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043430_;
    wasmetal_core__DOT___043430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043452_;
    wasmetal_core__DOT___043452_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043453_;
    wasmetal_core__DOT___043453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043454_;
    wasmetal_core__DOT___043454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043494_;
    wasmetal_core__DOT___043494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043495_;
    wasmetal_core__DOT___043495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043516_;
    wasmetal_core__DOT___043516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043517_;
    wasmetal_core__DOT___043517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043518_;
    wasmetal_core__DOT___043518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043753_;
    wasmetal_core__DOT___043753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043754_;
    wasmetal_core__DOT___043754_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043755_;
    wasmetal_core__DOT___043755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043777_;
    wasmetal_core__DOT___043777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043778_;
    wasmetal_core__DOT___043778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043779_;
    wasmetal_core__DOT___043779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043820_;
    wasmetal_core__DOT___043820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043821_;
    wasmetal_core__DOT___043821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043844_;
    wasmetal_core__DOT___043844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043845_;
    wasmetal_core__DOT___043845_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048080_;
    wasmetal_core__DOT___048080_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048081_;
    wasmetal_core__DOT___048081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048092_;
    wasmetal_core__DOT___048092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048093_;
    wasmetal_core__DOT___048093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048094_;
    wasmetal_core__DOT___048094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048095_;
    wasmetal_core__DOT___048095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048096_;
    wasmetal_core__DOT___048096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048101_;
    wasmetal_core__DOT___048101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048102_;
    wasmetal_core__DOT___048102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048103_;
    wasmetal_core__DOT___048103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048105_;
    wasmetal_core__DOT___048105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048106_;
    wasmetal_core__DOT___048106_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048107_;
    wasmetal_core__DOT___048107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048162_;
    wasmetal_core__DOT___048162_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048217_;
    wasmetal_core__DOT___048217_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048218_;
    wasmetal_core__DOT___048218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048219_;
    wasmetal_core__DOT___048219_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048224_;
    wasmetal_core__DOT___048224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048225_;
    wasmetal_core__DOT___048225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048227_;
    wasmetal_core__DOT___048227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048228_;
    wasmetal_core__DOT___048228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048229_;
    wasmetal_core__DOT___048229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048251_;
    wasmetal_core__DOT___048251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048252_;
    wasmetal_core__DOT___048252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048253_;
    wasmetal_core__DOT___048253_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048254_;
    wasmetal_core__DOT___048254_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048255_;
    wasmetal_core__DOT___048255_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048268_;
    wasmetal_core__DOT___048268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048936_;
    wasmetal_core__DOT___048936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048938_;
    wasmetal_core__DOT___048938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048939_;
    wasmetal_core__DOT___048939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048940_;
    wasmetal_core__DOT___048940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050077_;
    wasmetal_core__DOT___050077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056300_;
    wasmetal_core__DOT___056300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056707_;
    wasmetal_core__DOT___056707_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056934_;
    wasmetal_core__DOT___056934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056935_;
    wasmetal_core__DOT___056935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056936_;
    wasmetal_core__DOT___056936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056949_;
    wasmetal_core__DOT___056949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056971_;
    wasmetal_core__DOT___056971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057033_;
    wasmetal_core__DOT___057033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057064_;
    wasmetal_core__DOT___057064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057206_;
    wasmetal_core__DOT___057206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057214_;
    wasmetal_core__DOT___057214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057296_;
    wasmetal_core__DOT___057296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057421_;
    wasmetal_core__DOT___057421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057427_;
    wasmetal_core__DOT___057427_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057612_;
    wasmetal_core__DOT___057612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058379_;
    wasmetal_core__DOT___058379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058393_;
    wasmetal_core__DOT___058393_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058422_;
    wasmetal_core__DOT___058422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059226_;
    wasmetal_core__DOT___059226_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059229_;
    wasmetal_core__DOT___059229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059230_;
    wasmetal_core__DOT___059230_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059232_;
    wasmetal_core__DOT___059232_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071843_;
    wasmetal_core__DOT___071843_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127643___O;
    wasmetal_core__DOT____Vcellout___127643___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127660___O;
    wasmetal_core__DOT____Vcellout___127660___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127692___CO;
    wasmetal_core__DOT____Vcellout___127692___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128782___O;
    wasmetal_core__DOT____Vcellout___128782___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128783___O;
    wasmetal_core__DOT____Vcellout___128783___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128784___O;
    wasmetal_core__DOT____Vcellout___128784___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128785___O;
    wasmetal_core__DOT____Vcellout___128785___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128786___O;
    wasmetal_core__DOT____Vcellout___128786___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___O;
    wasmetal_core__DOT____Vcellout___128787___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___CO;
    wasmetal_core__DOT____Vcellout___128787___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1c23bbd1__0;
    __VdfgTmp_h1c23bbd1__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3a48ed75__0;
    __VdfgTmp_h3a48ed75__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf115889b__0;
    __VdfgTmp_hf115889b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h13ac9eb3__0;
    __VdfgTmp_h13ac9eb3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h859eb527__0;
    __VdfgTmp_h859eb527__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7fda4de5__0;
    __VdfgTmp_h7fda4de5__0 = 0;
    CData/*2:0*/ __VdfgTmp_h385c50c6__0;
    __VdfgTmp_h385c50c6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h06108119__0;
    __VdfgTmp_h06108119__0 = 0;
    CData/*4:0*/ __VdfgTmp_h00a84c57__0;
    __VdfgTmp_h00a84c57__0 = 0;
    CData/*2:0*/ __VdfgTmp_h32160e17__0;
    __VdfgTmp_h32160e17__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc24ed5a6__0;
    __VdfgTmp_hc24ed5a6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3be775f9__0;
    __VdfgTmp_h3be775f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h35fc6168__0;
    __VdfgTmp_h35fc6168__0 = 0;
    CData/*2:0*/ __VdfgTmp_h267c01fb__0;
    __VdfgTmp_h267c01fb__0 = 0;
    CData/*1:0*/ __VdfgTmp_h38f8e813__0;
    __VdfgTmp_h38f8e813__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4954f743__0;
    __VdfgTmp_h4954f743__0 = 0;
    CData/*1:0*/ __VdfgTmp_h57c36911__0;
    __VdfgTmp_h57c36911__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb49f8759__0;
    __VdfgTmp_hb49f8759__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2e6695c3__0;
    __VdfgTmp_h2e6695c3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2242a82b__0;
    __VdfgTmp_h2242a82b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1785588f__0;
    __VdfgTmp_h1785588f__0 = 0;
    // Body
    wasmetal_core__DOT___043516_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024189_;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024320_;
    }
    wasmetal_core__DOT___043364_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043753_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O)))));
    wasmetal_core__DOT___043387_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043777_ = (1U & (0x8001U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___057064_ = (1U & (IData)((0xf00bb00ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___056872_ = (1U & (0xfdd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024872_));
    wasmetal_core__DOT___043428_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)))));
    wasmetal_core__DOT___043452_ = (1U & (0x4002U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024621_));
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035794_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)))) {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
    } else {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035795_) 
           & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127676___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024511_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___024511_)
                 ? (IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024455_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___024511_)
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128782___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035794_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035793_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035821_)))));
    wasmetal_core__DOT___035825_ = ((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                    & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057276_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde86d559__0))))))));
    wasmetal_core__DOT___012358_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024256_) {
        wasmetal_core__DOT___024194_ = wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024325_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
    } else {
        wasmetal_core__DOT___024194_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
        wasmetal_core__DOT___024325_ = wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024256_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024189_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127659___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024256_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5b180012__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7b799034__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024320_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127724___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           ^ (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024872_)))));
    wasmetal_core__DOT___024876_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___048081_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128782___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035794_))));
    wasmetal_core__DOT___048096_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035796_))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035797_) 
           & (IData)(wasmetal_core__DOT___035825_));
    wasmetal_core__DOT____Vcellout___127643___O = ((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(wasmetal_core__DOT___024194_)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024194_)));
    wasmetal_core__DOT___043820_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043844_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043494_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043517_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT____Vcellout___127660___O = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___024256_))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)
                                                       : (IData)(wasmetal_core__DOT___024325_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024325_)));
    wasmetal_core__DOT___043365_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043754_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043388_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043778_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->__VdfgTmp_hc4dae929__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                    >> 2U)));
    wasmetal_core__DOT____Vcellout___127692___CO = 
        ((((1U & (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127692___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024511_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha0636656__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024621_)));
    wasmetal_core__DOT___048107_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035798_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___043821_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                       >> 2U)))))));
    wasmetal_core__DOT___043845_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043495_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043518_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043366_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043389_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043779_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043755_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc4dae929__0)))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           & (IData)(wasmetal_core__DOT___024876_));
    wasmetal_core__DOT___043430_ = (1U & (0xffe0U >> 
                                          ((8U & (IData)(wasmetal_core__DOT____Vcellout___127692___CO)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 2U) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043429_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043454_ = (1U & (0x1004U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                  << 1U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___043453_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035772_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___043801_ = (1U & ((IData)(wasmetal_core__DOT___043845_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043844_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043843_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043842_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043841_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043840_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043839_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043838_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043837_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043836_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043835_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043834_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043853_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043852_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043851_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043850_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043849_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043848_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043847_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043846_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043823_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043824_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043825_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043826_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043827_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043828_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043829_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043810_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043811_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043812_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043813_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043814_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043815_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043816_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043817_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043818_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043819_))
                                                    : (IData)(wasmetal_core__DOT___043820_))
                                                   : (IData)(wasmetal_core__DOT___043821_)));
    vlSelf->wasmetal_core__DOT___043475_ = (1U & ((IData)(wasmetal_core__DOT___043518_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043517_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043516_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043515_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043514_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043513_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043512_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043511_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043510_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043509_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043508_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043507_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043525_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043524_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043523_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043522_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043521_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043520_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043519_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043497_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043498_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043499_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043500_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043501_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043502_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043484_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043485_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043486_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043487_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043488_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043489_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043490_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043491_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043492_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043493_))
                                                    : (IData)(wasmetal_core__DOT___043494_))
                                                   : (IData)(wasmetal_core__DOT___043495_)));
    vlSelf->wasmetal_core__DOT___043346_ = (1U & ((IData)(wasmetal_core__DOT___043389_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043388_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043387_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043386_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043385_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043384_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043383_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043382_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043381_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043380_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043379_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043378_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043396_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043395_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043394_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043393_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043392_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043391_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043390_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043368_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043369_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043370_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043371_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043372_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043373_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043355_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043356_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043357_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043358_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043359_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043360_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043361_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043362_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043363_))
                                                     : (IData)(wasmetal_core__DOT___043364_))
                                                    : (IData)(wasmetal_core__DOT___043365_))
                                                   : (IData)(wasmetal_core__DOT___043366_)));
    vlSelf->wasmetal_core__DOT___043735_ = (1U & ((IData)(wasmetal_core__DOT___043779_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043778_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043777_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043776_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043775_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043774_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043773_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043772_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043771_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043770_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043769_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043768_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043787_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043786_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043785_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043784_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043783_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043782_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043781_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043780_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hb920cb05__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043757_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043758_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043759_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043760_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043761_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043762_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043763_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043744_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043745_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043746_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043747_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043748_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043749_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043750_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043751_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043752_))
                                                     : (IData)(wasmetal_core__DOT___043753_))
                                                    : (IData)(wasmetal_core__DOT___043754_))
                                                   : (IData)(wasmetal_core__DOT___043755_)));
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___043410_ = (1U & ((IData)(wasmetal_core__DOT___043454_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043453_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043452_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043451_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043450_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043449_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043448_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043447_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043446_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043445_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043444_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043443_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043461_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043460_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043459_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043458_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043457_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043456_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043455_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | (7U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043432_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043433_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043434_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043435_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043436_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043437_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043419_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043420_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043421_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043422_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043423_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043424_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043425_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043426_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043427_))
                                                     : (IData)(wasmetal_core__DOT___043428_))
                                                    : (IData)(wasmetal_core__DOT___043429_))
                                                   : (IData)(wasmetal_core__DOT___043430_)));
    wasmetal_core__DOT____Vcellout___128783___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035798_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035797_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035825_)))));
    wasmetal_core__DOT___035801_ = ((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                    & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___056936_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___056949_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___057206_ = (1U & (0xcc0035U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O))))))));
    wasmetal_core__DOT___056935_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043475_)))));
    vlSelf->wasmetal_core__DOT___057477_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057489_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057339_ = (1U & (IData)(
                                                         (0xff00fff0f0eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057332_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___043735_))))))))))));
    vlSelf->wasmetal_core__DOT___057348_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012594_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056062_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 1U)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057282_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___057125_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056997_ = (1U & (IData)(
                                                         (0xcfcffcee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056993_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056941_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055964_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O))))))))));
    vlSelf->wasmetal_core__DOT___056954_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010053_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O))))))))));
    vlSelf->wasmetal_core__DOT___056841_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056881_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((0xf3faU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                                                >> 2U)))))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056684_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056696_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___011275_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___010379_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3fa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056318_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O)) 
                                                                              | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056411_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x774477775f505f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O))))))))));
    vlSelf->wasmetal_core__DOT___056512_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    wasmetal_core__DOT___057427_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                              >> 2U))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___012513_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xf044U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xee22fa0a00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012502_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000005533ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))));
    wasmetal_core__DOT___057214_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___013161_ = (1U & ((0xf3fa0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xcc35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                                >> 3U)))))))))))) 
                                                  & (IData)(
                                                            (0x57f757f755ff7777ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((0xfef0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057400_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057413_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057435_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057333_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057197_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O))))))))));
    vlSelf->wasmetal_core__DOT___057190_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O))))))))));
    wasmetal_core__DOT___056971_ = (1U & (IData)((0xf000f0000ddddULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                >> 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056791_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056808_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                             >> 2U))))))))));
    wasmetal_core__DOT___056707_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aa0f0f00000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xcc35U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 2U)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___056754_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___011255_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 1U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___056574_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 1U)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___056581_ = (1U & (IData)(
                                                         (0xf0f000000bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056578_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0fff0ffff2222ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056576_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___056471_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xf000f0000bbbbULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___043801_))))))))))
                                                   : 
                                                  (0xbbbb0fffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010904_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011068_))))))));
    vlSelf->wasmetal_core__DOT___056493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))))))))));
    vlSelf->wasmetal_core__DOT___056518_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O))))))))));
    vlSelf->wasmetal_core__DOT___057618_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___057612_ = (1U & (IData)((0x33aa0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                              >> 3U)))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___013023_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aaf0f000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xeU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 3U))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___013177_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 3U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___056934_ = (1U & (0xd0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    vlSelf->wasmetal_core__DOT___056297_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    wasmetal_core__DOT___048219_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128783___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035798_))));
    wasmetal_core__DOT___048218_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035773_))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035774_) 
           & (IData)(wasmetal_core__DOT___035801_));
    vlSelf->wasmetal_core__DOT___012896_ = (1U & (IData)(
                                                         (0xf0f0f0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfdd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                             ? 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))
                                                                             : 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))));
    vlSelf->wasmetal_core__DOT___012512_ = (1U & (IData)(
                                                         (0x1111000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057214_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009712_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010378_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))));
    wasmetal_core__DOT___024881_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           ^ (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024876_)))));
    vlSelf->wasmetal_core__DOT___056981_ = (1U & (IData)(
                                                         (0xccaa00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ffffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056972_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___056971_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdd11f505U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056213_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f00ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                >> 3U))))))))))))))));
    vlSelf->wasmetal_core__DOT___056712_ = (1U & (IData)(
                                                         (0xff00bb00ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056706_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057626_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff1000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057559_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                              ? 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))
                                                                              : 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))))))))))));
    wasmetal_core__DOT___057421_ = (1U & (0xd0U >> 
                                          (((IData)(wasmetal_core__DOT___056934_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                    >> 2U))))));
    __VdfgTmp_h267c01fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___056935_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___056934_)));
    vlSelf->wasmetal_core__DOT___012481_ = (1U & (IData)(
                                                         (0xff00b000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057206_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056934_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    vlSelf->wasmetal_core__DOT___057510_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___012971_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 2U))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                          >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012604_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___057296_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                              >> 1U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___057120_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012359_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O))))))));
    wasmetal_core__DOT___057033_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                               >> 3U))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012317_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012331_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056836_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___011685_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056680_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056691_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xccfe0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 1U))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___056403_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___010381_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcfcffcee00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O))))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O))))))));
    wasmetal_core__DOT___056300_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___013083_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035775_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013010_ = (1U & ((~ 
                                                   (0x10U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0xf0f0000000eeULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                             << 3U) 
                                                                            | (((IData)(
                                                                                (((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                                                >> 3U) 
                                                                                ^ (IData)(wasmetal_core__DOT___024881_))) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                                                >> 3U))))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xee22fa0a00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056134_))))))))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(wasmetal_core__DOT___013023_))
                                                      : (IData)(
                                                                (0xf0fff3fff0fff5ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___013023_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hcfb94f0b__0))))))))));
    wasmetal_core__DOT___012357_ = (1U & (IData)((0xf0f033aa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x1d1d0f55U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___056207_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)) 
                                                               | (1U 
                                                                  & (0xcc35U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)))))))))))))));
    vlSelf->wasmetal_core__DOT___057073_ = (1U & (IData)(
                                                         (0xff00f000ff00ee00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057064_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc0035U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                                                >> 3U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)))))))))))));
    vlSelf->wasmetal_core__DOT___057423_ = (1U & (IData)(
                                                         (0xff00e000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056935_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___056940_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056936_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    vlSelf->wasmetal_core__DOT___056953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056949_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        if (vlSelf->wasmetal_core__DOT___010378_) {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___012971_)));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (1U >> (IData)(wasmetal_core__DOT___012317_)));
        } else {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (0xb0U >> (((IData)(wasmetal_core__DOT___012971_) 
                                  << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                   >> 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (0xbU >> (((IData)(wasmetal_core__DOT___012317_) 
                                 << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                  >> 2U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
        }
    } else if (vlSelf->wasmetal_core__DOT___010378_) {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___012971_)));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___012317_)));
    } else {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (0xe00U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012971_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb6e1260e__0))));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012317_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012316_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012315_))))));
    }
    vlSelf->wasmetal_core__DOT___057299_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057295_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057040_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057031_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057030_)))))))));
    vlSelf->wasmetal_core__DOT___010076_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056299_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035776_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012354_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009691_)) 
                                                  & (IData)(
                                                            (0xfff0fffeff00ff00ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___012359_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___012358_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___012357_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012356_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))));
    wasmetal_core__DOT____Vcellout___128784___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035776_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035775_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035774_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035801_)))));
    wasmetal_core__DOT___035805_ = ((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                    & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048095_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035774_))));
    wasmetal_core__DOT___048080_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035776_))));
    wasmetal_core__DOT___048102_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128784___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035775_))));
    wasmetal_core__DOT___048101_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035777_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035778_) 
           & (IData)(wasmetal_core__DOT___035805_));
    wasmetal_core__DOT___048939_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048102_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048095_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048219_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035797_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128783___O))))))));
    wasmetal_core__DOT___048253_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048218_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048080_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048101_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___048106_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048102_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048101_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035779_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035780_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128785___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035779_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035778_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035805_)))));
    wasmetal_core__DOT___035809_ = ((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                    & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048217_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128785___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035779_))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035783_) 
           & (IData)(wasmetal_core__DOT___035809_));
    wasmetal_core__DOT___048228_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___048106_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___048096_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048219_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048218_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048217_)))))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035784_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035785_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128786___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035783_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035809_)))));
    wasmetal_core__DOT___035814_ = ((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                    & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048103_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035783_))));
    wasmetal_core__DOT___048094_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035785_))));
    wasmetal_core__DOT___048093_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128786___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035784_))));
    wasmetal_core__DOT___048092_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035786_))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035787_) 
           & (IData)(wasmetal_core__DOT___035814_));
    wasmetal_core__DOT___048105_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048095_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048094_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048093_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048092_))))));
    wasmetal_core__DOT___048225_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035788_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035789_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT____Vcellout___128787___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___035790_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128787___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035790_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035789_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035788_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035787_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___035814_)));
    wasmetal_core__DOT___048162_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048107_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048106_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048105_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___048081_) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___048080_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___035793_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(wasmetal_core__DOT____Vcellout___128782___O)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                                   >> 2U)) 
                                                               | (IData)(wasmetal_core__DOT___048103_)))))))));
    wasmetal_core__DOT___048936_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035787_))));
    wasmetal_core__DOT___048251_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035789_))));
    wasmetal_core__DOT___048224_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128787___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035788_))));
    wasmetal_core__DOT___071843_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035790_))));
    vlSelf->wasmetal_core__DOT___005697_ = (1U & (IData)(
                                                         (0x80008000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___048162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048160_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048159_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048158_)))))))));
    wasmetal_core__DOT___035706_ = (1U & (0x4bU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035681_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048162_)))));
    wasmetal_core__DOT___048252_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048251_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___048094_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                               >> 2U)))))));
    wasmetal_core__DOT___048940_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048939_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048253_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128787___CO)) 
                                                         | (((IData)(wasmetal_core__DOT___048251_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___048224_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___048936_)))))))));
    wasmetal_core__DOT___048227_ = (1U & (0x10U >> 
                                          (((IData)(wasmetal_core__DOT___048225_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___048093_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048224_)))));
    wasmetal_core__DOT___048254_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___048253_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048252_))));
    vlSelf->wasmetal_core__DOT___007130_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048940_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006408_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006407_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfdd5af20__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035707_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035682_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048938_ = (1U & (0x80U >> 
                                          (((IData)(wasmetal_core__DOT___048252_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xdULL 
                                                         >> 
                                                         ((0x20U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                              << 2U)) 
                                                          | (((IData)(wasmetal_core__DOT___048936_) 
                                                              << 4U) 
                                                             | (((IData)(wasmetal_core__DOT___048103_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___048217_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035778_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(wasmetal_core__DOT____Vcellout___128785___O))))))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___048227_)))));
    wasmetal_core__DOT___048229_ = (1U & (IData)((0xd000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048228_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048227_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048081_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___048255_ = (1U & (IData)((0xd00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048225_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048254_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048107_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___007129_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048938_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & (IData)(
                                                            (0x80000000ffffffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006392_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h35bc9263__0)) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006192_))))))))));
    vlSelf->wasmetal_core__DOT___035708_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035683_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048938_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___005696_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048229_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006125_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006124_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006123_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006122_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006121_)))))))))));
    wasmetal_core__DOT___035704_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035679_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048229_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048268_ = (1U & (IData)((0xaf3f0f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048255_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h834dc827__0))))))));
    wasmetal_core__DOT___035705_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035680_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048255_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___058404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058403_)))));
    vlSelf->wasmetal_core__DOT___058382_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058380_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    vlSelf->wasmetal_core__DOT___058381_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005693_)))));
    wasmetal_core__DOT___058379_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0))));
    vlSelf->wasmetal_core__DOT___058374_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h088d475b__0))));
    vlSelf->__VdfgTmp_h2d64090c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h980f95b2__0));
    vlSelf->wasmetal_core__DOT___058373_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006485_)))));
    vlSelf->wasmetal_core__DOT___058372_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hefac2d69__0))))));
    vlSelf->wasmetal_core__DOT___050074_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005692_)))));
    vlSelf->wasmetal_core__DOT___050075_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    wasmetal_core__DOT___015115_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_he99783ec__0))));
    __VdfgTmp_hb49f8759__0 = ((2U & ((0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006615_)))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
    __VdfgTmp_hc24ed5a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    __VdfgTmp_h32160e17__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035704_) ? (IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035679_));
    vlSelf->wasmetal_core__DOT___005695_ = (1U & (IData)(
                                                         (0x8000ffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___048268_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048267_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048266_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048265_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048264_)))))))));
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035705_) ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035680_));
    vlSelf->wasmetal_core__DOT___058561_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xccaaf0f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___015115_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___058420_ = (1U & (IData)(
                                                         (0x7777f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058412_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058408_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058379_)))));
    wasmetal_core__DOT___058393_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))));
    vlSelf->wasmetal_core__DOT___058384_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058379_))));
    wasmetal_core__DOT___050077_ = ((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                    & (IData)((0xff00ccccf0f0aaaaULL 
                                               >> (
                                                   (0x20U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006598_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))));
    vlSelf->wasmetal_core__DOT___058376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058373_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058372_)))));
    __VdfgTmp_h1785588f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))));
    __VdfgTmp_h2242a82b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006486_))))));
    vlSelf->wasmetal_core__DOT___015107_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0xfaa330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___015115_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___014966_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0x3500000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_hc24ed5a6__0)))))));
    vlSelf->wasmetal_core__DOT___015076_ = ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                            & (IData)(
                                                      (0x3355f0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x3a00U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h32160e17__0))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))))))));
    vlSelf->wasmetal_core__DOT___058073_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h19cea986__0))))))));
    vlSelf->wasmetal_core__DOT___014540_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006500_)))))))));
    vlSelf->wasmetal_core__DOT___014526_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006280_)))))))));
    vlSelf->wasmetal_core__DOT___014498_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006325_)))))))));
    vlSelf->wasmetal_core__DOT___014484_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006516_)))))))));
    vlSelf->wasmetal_core__DOT___009486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006323_)))))))));
    vlSelf->wasmetal_core__DOT___014464_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006515_)))))))));
    vlSelf->wasmetal_core__DOT___007166_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006530_)))))))));
    vlSelf->wasmetal_core__DOT___007156_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006364_)))))))));
    vlSelf->wasmetal_core__DOT___007146_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006529_)))))))));
    vlSelf->wasmetal_core__DOT___007136_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006363_)))))))));
    vlSelf->wasmetal_core__DOT___014573_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))));
    vlSelf->wasmetal_core__DOT___006284_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006280_))))));
    vlSelf->wasmetal_core__DOT___014570_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006325_))))));
    vlSelf->wasmetal_core__DOT___014514_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006544_)))))))));
    vlSelf->wasmetal_core__DOT___014502_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006416_)))))))));
    vlSelf->wasmetal_core__DOT___014488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006543_)))))))));
    vlSelf->wasmetal_core__DOT___014476_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006415_)))))))));
    vlSelf->wasmetal_core__DOT___009488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006414_)))))))));
    vlSelf->wasmetal_core__DOT___014466_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006542_)))))))));
    vlSelf->wasmetal_core__DOT___014487_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb69d909d__0))))));
    vlSelf->wasmetal_core__DOT___014486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))));
    vlSelf->wasmetal_core__DOT___014528_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006361_)))))))));
    vlSelf->wasmetal_core__DOT___007124_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006528_)))))))));
    vlSelf->wasmetal_core__DOT___014567_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006516_))))));
    vlSelf->wasmetal_core__DOT___014542_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006527_)))))))));
    vlSelf->wasmetal_core__DOT___014558_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006362_)))))))));
    vlSelf->wasmetal_core__DOT___006609_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))));
    wasmetal_core__DOT___014553_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006515_))))));
    wasmetal_core__DOT___014525_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006514_))))));
    wasmetal_core__DOT___014511_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006322_))))));
    wasmetal_core__DOT___014497_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006530_))))));
    wasmetal_core__DOT___014483_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006364_))))));
    wasmetal_core__DOT___014473_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006529_))))));
    wasmetal_core__DOT___009495_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006363_))))));
    wasmetal_core__DOT___006608_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006323_))))));
    vlSelf->wasmetal_core__DOT___006504_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006500_))))));
    vlSelf->wasmetal_core__DOT___009490_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___007168_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006557_)))))))));
    vlSelf->wasmetal_core__DOT___007179_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006413_)))))))));
    vlSelf->wasmetal_core__DOT___007160_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hc24ed5a6__0)))));
    vlSelf->wasmetal_core__DOT___007158_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006441_)))))))));
    vlSelf->wasmetal_core__DOT___007148_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006556_)))))))));
    vlSelf->wasmetal_core__DOT___007138_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))))));
    vlSelf->wasmetal_core__DOT___014517_ = (1U & (IData)(
                                                         (0xf00aa00330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    vlSelf->wasmetal_core__DOT___014516_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006571_)))))))));
    wasmetal_core__DOT___014501_ = (1U & (0x3050000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0))))));
    wasmetal_core__DOT___014500_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006616_)))))))));
    vlSelf->wasmetal_core__DOT___014531_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___014530_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he99783ec__0))))))));
    vlSelf->wasmetal_core__DOT___007126_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006555_)))))))));
    vlSelf->wasmetal_core__DOT___014544_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))))))));
    vlSelf->wasmetal_core__DOT___014556_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006439_)))))))));
    wasmetal_core__DOT___006366_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006362_))))));
    vlSelf->wasmetal_core__DOT___007128_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006568_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005697_))))));
    vlSelf->wasmetal_core__DOT___007186_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006541_)))))))));
    vlSelf->wasmetal_core__DOT___007170_ = (1U & (IData)(
                                                         (0xfaa330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    __VdfgTmp_h00a84c57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                          << 3U) | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)));
    vlSelf->wasmetal_core__DOT___007150_ = (1U & (0x3a000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h32160e17__0)))));
    vlSelf->wasmetal_core__DOT___007140_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
    wasmetal_core__DOT___006532_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006528_))))));
    wasmetal_core__DOT___006365_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006361_))))));
    wasmetal_core__DOT___007155_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006544_))))));
    wasmetal_core__DOT___007145_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006416_))))));
    wasmetal_core__DOT___006572_ = (1U & (IData)((0xff33330f0faaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    wasmetal_core__DOT___007109_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006557_))))));
    wasmetal_core__DOT___007100_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006441_))))));
    wasmetal_core__DOT___007091_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006556_))))));
    wasmetal_core__DOT___007087_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006440_))))));
    wasmetal_core__DOT___007135_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006543_))))));
    wasmetal_core__DOT___006612_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006415_))))));
    wasmetal_core__DOT___007113_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006413_))))));
    wasmetal_core__DOT___007117_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006541_))))));
    wasmetal_core__DOT___006611_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006414_))))));
    wasmetal_core__DOT___007123_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006542_))))));
    wasmetal_core__DOT___006531_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006527_))))));
    wasmetal_core__DOT___006443_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006439_))))));
    vlSelf->wasmetal_core__DOT___006559_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006555_))))));
    wasmetal_core__DOT___006442_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006438_))))));
    vlSelf->wasmetal_core__DOT___007078_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006571_))))));
    wasmetal_core__DOT___007075_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006616_))))));
    wasmetal_core__DOT___007072_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006570_))))));
    wasmetal_core__DOT___006618_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006615_))))));
    wasmetal_core__DOT___007069_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006569_))))));
    vlSelf->wasmetal_core__DOT___006558_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006554_))))));
    if (vlSelf->wasmetal_core__DOT___005696_) {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xc5U >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006568_)))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006616_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006281_))))));
        vlSelf->wasmetal_core__DOT___058072_ = vlSelf->wasmetal_core__DOT___014567_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014497_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___006608_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006501_))))));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___009495_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___006365_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___006531_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___014467_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007149_ = vlSelf->wasmetal_core__DOT___007078_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (IData)(wasmetal_core__DOT___006618_));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (IData)(wasmetal_core__DOT___007069_));
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___006558_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006559_;
    } else {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006571_))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006615_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006569_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006284_));
        vlSelf->wasmetal_core__DOT___058072_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014525_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014483_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006504_));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___006366_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___006532_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___014467_ = vlSelf->wasmetal_core__DOT___006559_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___007149_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___006618_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007069_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (0x30aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006568_))))));
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___007078_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006558_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128771___O 
        = ((((IData)(wasmetal_core__DOT___035706_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035705_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035704_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035701_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035694_ = ((IData)(wasmetal_core__DOT___035706_)
                                             ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___035681_));
    vlSelf->wasmetal_core__DOT___050081_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050077_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006604_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006602_)))))
                                                                          : 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006603_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006601_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050074_)))))))));
    vlSelf->wasmetal_core__DOT___058417_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5300U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058403_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058412_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058394_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058393_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0fccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->__VdfgTmp_hf7593d1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0))))));
    vlSelf->__VdfgTmp_h1a5afed0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0))))));
    vlSelf->__VdfgTmp_h00939515__0 = (((IData)(vlSelf->wasmetal_core__DOT___014487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014486_));
    vlSelf->__VdfgTmp_h9f75ffc3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014525_)
                                         : (IData)(wasmetal_core__DOT___014497_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))))))));
    vlSelf->__VdfgTmp_ha7c43d57__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014483_)
                                         : (IData)(wasmetal_core__DOT___009495_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))))))));
    vlSelf->__VdfgTmp_he4917e71__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___006609_)
                                         : (IData)(wasmetal_core__DOT___006608_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))))))));
    vlSelf->wasmetal_core__DOT___015194_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009490_)))));
    vlSelf->wasmetal_core__DOT___015030_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014468_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014517_))))));
    vlSelf->__VdfgTmp_h2165c3f7__0 = (((IData)(wasmetal_core__DOT___014501_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014500_));
    vlSelf->__VdfgTmp_he4fae0fa__0 = (((IData)(wasmetal_core__DOT___014500_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014501_));
    vlSelf->__VdfgTmp_h4a9651b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014531_));
    vlSelf->wasmetal_core__DOT___014878_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007128_)))));
    vlSelf->wasmetal_core__DOT___015070_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0))))));
    vlSelf->wasmetal_core__DOT___007180_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0)))));
    vlSelf->wasmetal_core__DOT___014949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007150_))));
    vlSelf->wasmetal_core__DOT___014979_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007140_)))));
    vlSelf->__VdfgTmp_h99d13f88__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006322_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006366_)
                                                  : (IData)(wasmetal_core__DOT___006365_)));
    vlSelf->wasmetal_core__DOT___058134_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(wasmetal_core__DOT___006572_)));
    vlSelf->wasmetal_core__DOT___007187_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(wasmetal_core__DOT___006572_));
    vlSelf->__VdfgTmp_h3016d5c6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006514_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006532_)
                                                  : (IData)(wasmetal_core__DOT___006531_)));
    vlSelf->wasmetal_core__DOT___058098_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O))))))));
    vlSelf->wasmetal_core__DOT___058095_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035707_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035694_)
            : (IData)(vlSelf->wasmetal_core__DOT___035682_));
    vlSelf->wasmetal_core__DOT___058423_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h00939515__0)))))));
    wasmetal_core__DOT___058422_ = (1U & (IData)((0xff00f0f011111111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058420_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058072_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058073_)))))))));
    vlSelf->wasmetal_core__DOT___058418_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014541_)))));
    vlSelf->wasmetal_core__DOT___058395_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014485_)))));
    vlSelf->__VdfgTmp_h3f743267__0 = (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0x33330f270f0f331bULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0)))
                                                     : (IData)(
                                                               (0xf0f331b33330f27ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0))))));
    vlSelf->__VdfgTmp_h210df1ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0))))));
    vlSelf->__VdfgTmp_h1e28f3c0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0))))));
    vlSelf->wasmetal_core__DOT___015094_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0)))));
    vlSelf->wasmetal_core__DOT___014632_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048942_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99d13f88__0))))))));
    vlSelf->wasmetal_core__DOT___014659_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007156_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980f95b2__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006284_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014570_))))))))));
    wasmetal_core__DOT___059229_ = (1U & (IData)((0x1ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015070_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014949_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058134_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007170_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014488_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014486_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014487_)))))))));
    __VdfgTmp_h38f8e813__0 = (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014488_));
    wasmetal_core__DOT___015117_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014476_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014477_))))));
    vlSelf->wasmetal_core__DOT___014827_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007146_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014573_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014567_))))))))));
    vlSelf->wasmetal_core__DOT___014757_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007136_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014570_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___006609_))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014498_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014499_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf0f335500000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xccaaf0f0U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058380_)))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014514_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014515_)))))))));
    __VdfgTmp_h4954f743__0 = (((IData)(vlSelf->wasmetal_core__DOT___014515_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014514_));
    if (vlSelf->wasmetal_core__DOT___007129_) {
        if (vlSelf->wasmetal_core__DOT___007130_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014499_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014498_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014484_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014502_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014558_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (IData)(__VdfgTmp_h38f8e813__0)));
        }
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (0x33550f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058372_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058374_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058373_)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014557_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014556_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h00939515__0))));
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (1U >> (1U & (0x1111000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h4954f743__0))))))));
    }
    __VdfgTmp_h06108119__0 = (((IData)(vlSelf->wasmetal_core__DOT___014528_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014529_));
    vlSelf->wasmetal_core__DOT___014792_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007124_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058073_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058072_)))))))));
    __VdfgTmp_h1c23bbd1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007124_));
    __VdfgTmp_h57c36911__0 = (((IData)(vlSelf->wasmetal_core__DOT___014543_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014542_));
    vlSelf->wasmetal_core__DOT___014746_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007166_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h088d475b__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006504_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014573_))))))))));
    vlSelf->wasmetal_core__DOT___014602_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048945_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0x110fU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009489_))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009486_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009487_)))) 
                                                  << 1U)) 
                                           | (1U & 
                                              (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xff00f0f011111111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___009490_)))))));
    wasmetal_core__DOT___015154_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014466_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014467_))))));
    vlSelf->wasmetal_core__DOT___014631_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007178_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007180_)))))));
    __VdfgTmp_h3be775f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007178_));
    __VdfgTmp_h385c50c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007158_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007160_)));
    __VdfgTmp_h3a48ed75__0 = (((IData)(vlSelf->wasmetal_core__DOT___007148_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007150_)));
    vlSelf->__VdfgTmp_hce3e66a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___007139_)))))));
    vlSelf->wasmetal_core__DOT___014756_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007140_)))))));
    __VdfgTmp_h13ac9eb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014556_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014557_));
    __VdfgTmp_h35fc6168__0 = (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007126_));
    if (vlSelf->wasmetal_core__DOT___007130_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0)))));
        if (vlSelf->wasmetal_core__DOT___007129_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014527_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014526_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014541_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014540_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014530_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014516_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014544_))));
        }
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009487_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009486_))))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014465_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014464_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007160_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007156_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007150_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007146_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007136_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007170_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007166_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007187_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h99d13f88__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007128_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_h1c23bbd1__0)))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014477_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014476_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014529_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014528_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009488_)))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014467_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014466_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007158_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007148_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007138_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007168_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___007185_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h4954f743__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h57c36911__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h3be775f9__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h35fc6168__0))));
    }
    __VdfgTmp_hf115889b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007126_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007128_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014545_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014542_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014543_)))))))));
    __VdfgTmp_h7fda4de5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007168_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007170_)));
    __VdfgTmp_h859eb527__0 = (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007185_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007187_)));
    vlSelf->__VdfgTmp_h2ddde49a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058098_));
    vlSelf->__VdfgTmp_hf4c0ee7d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->__VdfgTmp_h283c0448__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->__VdfgTmp_h187f5418__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->wasmetal_core__DOT___058096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035708_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035683_));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d));
    vlSelf->__VdfgTmp_h39f326f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0))))));
    vlSelf->__VdfgTmp_h375bf609__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0))))));
    vlSelf->wasmetal_core__DOT___059231_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059229_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014966_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014979_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014878_)))))))));
    vlSelf->wasmetal_core__DOT___058396_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h00939515__0)) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h38f8e813__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d 
        = (1U & (IData)((0xf0feeee00ff00ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 4U) 
                                                     | (((IData)(wasmetal_core__DOT___015117_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xccccaaaa000f000fULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058384_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058382_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058381_)))))))) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0))))))));
    vlSelf->__VdfgTmp_hb48763c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015117_));
    vlSelf->__VdfgTmp_h22db4e96__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((1U 
                                                >> 
                                                ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xe0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h06108119__0)))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014526_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014527_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf1f100ff00000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058408_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xccaa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x7fff0000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___058382_))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h06108119__0))))))));
    vlSelf->wasmetal_core__DOT___058419_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h57c36911__0))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d));
    vlSelf->__VdfgTmp_hd148b96b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014712_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0))))));
    vlSelf->__VdfgTmp_hf41b4843__0 = (((IData)(wasmetal_core__DOT___015154_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014464_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014465_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff4f400000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0x305U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h19cea986__0)))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___058374_)))))))))));
    vlSelf->__VdfgTmp_h52595424__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015154_));
    vlSelf->__VdfgTmp_h7bf425d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014631_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014632_));
    vlSelf->__VdfgTmp_hc1e22c7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3be775f9__0))))));
    vlSelf->__VdfgTmp_h7328e0ec__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->wasmetal_core__DOT___014658_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->__VdfgTmp_he7d53082__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT___014826_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014756_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014757_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d 
        = (1U & (IData)((0xff0f0feeeeeeeeULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050081_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xeU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h13ac9eb3__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xe0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014559_)))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(__VdfgTmp_h13ac9eb3__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h13ac9eb3__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d 
        = (1U & (IData)((0xff00ffeeee0f0fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___058422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(__VdfgTmp_h35fc6168__0)) 
                                                              << 2U)) 
                                                          | (IData)(__VdfgTmp_h1c23bbd1__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->wasmetal_core__DOT___014791_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->__VdfgTmp_h8020f35b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0))))));
    vlSelf->__VdfgTmp_h5b0d2f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->wasmetal_core__DOT___014745_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->__VdfgTmp_h023f0a12__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___014601_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___058107_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))));
    vlSelf->__VdfgTmp_hc2843286__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h6a8cbae2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h8e2d1d0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h283c0448__0));
    vlSelf->__VdfgTmp_h9949a0e3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h187f5418__0))));
    vlSelf->wasmetal_core__DOT___058106_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058098_))));
    vlSelf->__VdfgTmp_hb1419641__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h187f5418__0));
    vlSelf->__VdfgTmp_h786a2bba__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058096_));
    vlSelf->wasmetal_core__DOT___058099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058096_))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035709_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035709_))));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058395_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058394_))))));
    vlSelf->__VdfgTmp_h7410d216__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0))))));
    vlSelf->__VdfgTmp_h3c2f1975__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058417_))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))));
    vlSelf->__VdfgTmp_hcd6303e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0))))));
    vlSelf->wasmetal_core__DOT___058205_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7328e0ec__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014658_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014659_))));
    vlSelf->wasmetal_core__DOT___058207_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d53082__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014826_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014827_))));
    vlSelf->wasmetal_core__DOT___059242_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (7U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))))));
    vlSelf->__VdfgTmp_h5b356604__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0))))));
    wasmetal_core__DOT___059226_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h52595424__0)))))))))));
    vlSelf->__VdfgTmp_h66dab408__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0))))));
    vlSelf->__VdfgTmp_h943c9679__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0))))));
    vlSelf->wasmetal_core__DOT___059234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014791_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014792_))));
    vlSelf->wasmetal_core__DOT___014590_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8020f35b__0)))));
    vlSelf->wasmetal_core__DOT___058644_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5b0d2f75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014745_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014746_))));
    vlSelf->wasmetal_core__DOT___058203_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h023f0a12__0)))));
    wasmetal_core__DOT___059232_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___005667_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014602_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014602_))));
    vlSelf->__VdfgTmp_hb0ec899f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058107_));
    vlSelf->__VdfgTmp_hfd58f84f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_hc4384494__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_h4352298b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_h730b9e6e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058106_));
    vlSelf->__VdfgTmp_h8cb25dc3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    vlSelf->wasmetal_core__DOT____Vcellout___128772___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035710_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035709_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035708_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035707_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035694_)))));
    vlSelf->wasmetal_core__DOT___035698_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035710_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___035710_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127535___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023345_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058619_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3c2f1975__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127443___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014712_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022588_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___015439_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcd6303e8__0)))));
    wasmetal_core__DOT___059230_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___059226_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___015540_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66dab408__0)))));
    vlSelf->wasmetal_core__DOT___059235_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059232_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058561_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007129_)))))))));
    vlSelf->wasmetal_core__DOT___060217_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0fffff0bbbb8888ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060214_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)))))));
    vlSelf->wasmetal_core__DOT___017801_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0))
                                                    : 
                                                   (0x7f7f7f00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___005666_)))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035711_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035698_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035711_))));
    vlSelf->wasmetal_core__DOT___058562_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023345_));
    vlSelf->wasmetal_core__DOT___058946_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___058940_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___058951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___022588_));
    vlSelf->wasmetal_core__DOT___059233_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059231_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059230_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)))))))))));
    vlSelf->wasmetal_core__DOT___060219_ = (1U & (IData)(
                                                         (0xff4f4444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060218_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060217_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf530U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060214_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11374272__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005670_)))))))));
    vlSelf->__VdfgTmp_hac20e9d0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0));
    vlSelf->__VdfgTmp_h2e648f5f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_hd141341a__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    __VdfgTmp_h2e6695c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d));
    vlSelf->wasmetal_core__DOT___058172_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d))))));
    vlSelf->__VdfgTmp_h66d515d6__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058174_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_hd20fe4de__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)));
    vlSelf->__VdfgTmp_hcbc91db2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035712_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035712_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060654_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060219_))));
    vlSelf->wasmetal_core__DOT___060220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016506_))));
    vlSelf->__VdfgTmp_h372a4d3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd141341a__0));
    vlSelf->wasmetal_core__DOT___058188_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058190_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(__VdfgTmp_h2e6695c3__0)))))));
    vlSelf->wasmetal_core__DOT___058191_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h7751e274__0 = ((2U & ((1U >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058163_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h2e6695c3__0))));
    vlSelf->wasmetal_core__DOT___058183_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058174_)))));
    vlSelf->wasmetal_core__DOT___058175_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h639f1e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058177_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))))));
    vlSelf->wasmetal_core__DOT___058161_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xe0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058171_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128825___S 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)));
    vlSelf->wasmetal_core__DOT___058184_ = (1U & (0x7f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058097_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035702_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035702_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060222_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060220_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    vlSelf->__VdfgTmp_h63b44d2e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058191_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))));
    vlSelf->wasmetal_core__DOT___058189_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7751e274__0))))));
}
