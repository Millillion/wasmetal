#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__17(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__17\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128105___O;
    wasmetal_core__DOT____Vcellout___128105___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___017452_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058852_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127618___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127602___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023904_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d) {
        vlSelf->wasmetal_core__DOT___024031_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024031_ = vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023904_;
    }
    vlSelf->wasmetal_core__DOT___050147_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006632_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050145_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003806_)))))))));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059074_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000140_)))))));
    vlSelf->wasmetal_core__DOT___000131_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000140_));
    vlSelf->wasmetal_core__DOT___057105_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heaf10b4b__0))));
    vlSelf->__VdfgTmp_h4448f15c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010082_));
    if (vlSelf->wasmetal_core__DOT___010085_) {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xfa330000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfff00000eeeeULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8262dffe__0)))))))))))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xeef0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012597_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012596_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0xc5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010081_)))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012598_))));
    }
    vlSelf->__VdfgTmp_h9167c706__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010081_)));
    vlSelf->__VdfgTmp_heef7d961__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h2c387a2e__0));
    vlSelf->wasmetal_core__DOT___059134_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___059162_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127487___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127479___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022885_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) {
        vlSelf->wasmetal_core__DOT___022948_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022948_ = vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022885_;
    }
    vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001569_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128113___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028874_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028873_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028872_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028839_)))));
    vlSelf->wasmetal_core__DOT___028843_ = ((IData)(vlSelf->wasmetal_core__DOT___028875_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___028848_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___028847_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___028877_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___028876_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028464_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028430_)
            : (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->wasmetal_core__DOT___067403_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053116_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___049760_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049753_)))));
    vlSelf->wasmetal_core__DOT___051900_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xff00ff0f0f1111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050514_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050631_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051895_)))))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051898_))))))));
    vlSelf->wasmetal_core__DOT___055082_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x5cU 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((0xf0f5533U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___050629_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053117_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049861_))))))));
    vlSelf->wasmetal_core__DOT___009508_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049861_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049860_))))))));
    vlSelf->wasmetal_core__DOT___051655_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009538_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051647_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051646_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049710_))))))));
    vlSelf->wasmetal_core__DOT___049718_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049709_)))));
    vlSelf->wasmetal_core__DOT___055081_ = (1U & (IData)(
                                                         (0x7fff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff00f0f01111ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051895_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_))))) 
                                                                                << 2U)) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___050632_) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051485_))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))));
    vlSelf->wasmetal_core__DOT___049636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049628_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049627_)))));
    vlSelf->wasmetal_core__DOT___049524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049508_)))));
    vlSelf->wasmetal_core__DOT___049211_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049148_)))));
    vlSelf->wasmetal_core__DOT___050873_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050870_)))));
    vlSelf->wasmetal_core__DOT___065172_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x3fff20003fff3fffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065166_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051841_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xfdf0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065165_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065164_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0fff4400000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051468_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051467_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051466_)))))))))))))));
    vlSelf->wasmetal_core__DOT___036894_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036900_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134172___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036900_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036899_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036898_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036897_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___050823_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050820_)))));
    vlSelf->wasmetal_core__DOT___050864_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050862_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050861_)))));
    vlSelf->wasmetal_core__DOT___064888_ = (1U & (IData)(
                                                         (0xff0f0000bbbb0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051008_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049464_))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051006_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050978_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050904_))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050896_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050731_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050804_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050802_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050801_)))));
    vlSelf->wasmetal_core__DOT___051796_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051329_)))));
    vlSelf->wasmetal_core__DOT___050641_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049716_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050635_)))));
    vlSelf->__VdfgTmp_h36c85254__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049686_) 
                                          << 1U) | 
                                         (1U & (1U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049690_)))));
    vlSelf->wasmetal_core__DOT___049772_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049686_)))));
    vlSelf->wasmetal_core__DOT___051781_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050997_)))));
    vlSelf->wasmetal_core__DOT___050981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049634_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050979_)))));
    vlSelf->__VdfgTmp_hd9ae5f1a__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050784_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051295_)));
    vlSelf->wasmetal_core__DOT___051297_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050784_)))));
    vlSelf->wasmetal_core__DOT___051867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051865_))));
    vlSelf->wasmetal_core__DOT___053193_ = (1U & (0xac00U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051865_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xaaccf0f0U 
                                                            >> 
                                                            ((4U 
                                                              & ((IData)(
                                                                         (0x5555cccc0f0fff00ULL 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049483_)))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((0xf0faaccU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xaaaaccccf0f0ff00ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051765_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051116_)))));
    vlSelf->wasmetal_core__DOT___050067_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049522_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050065_)))));
    vlSelf->wasmetal_core__DOT___051104_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049476_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051101_)))));
    vlSelf->wasmetal_core__DOT___051753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051059_)))));
    vlSelf->wasmetal_core__DOT___051063_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049209_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051060_)))));
    vlSelf->wasmetal_core__DOT___051048_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049326_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051045_)))));
    vlSelf->wasmetal_core__DOT___051619_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049523_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049509_))))));
    vlSelf->wasmetal_core__DOT___051709_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049806_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049802_)))));
    vlSelf->wasmetal_core__DOT___049809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> 
                                                                   (1U 
                                                                    & (0x35U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049806_)))));
    vlSelf->wasmetal_core__DOT___050865_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050863_))));
    vlSelf->wasmetal_core__DOT___051370_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050862_)))));
    vlSelf->wasmetal_core__DOT___051554_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050872_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050871_))))));
    vlSelf->wasmetal_core__DOT___050874_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050872_))));
    vlSelf->wasmetal_core__DOT___051743_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050702_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050698_)))));
    vlSelf->wasmetal_core__DOT___050705_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049714_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050702_)))));
    vlSelf->wasmetal_core__DOT___053129_ = (1U & (IData)(
                                                         (0x7f7f7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053121_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053120_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))));
    vlSelf->wasmetal_core__DOT___009537_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049717_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049710_)))));
    vlSelf->wasmetal_core__DOT___049719_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049717_))));
    vlSelf->wasmetal_core__DOT___051438_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051423_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))));
    vlSelf->wasmetal_core__DOT___051587_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049210_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049148_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051583_))))))));
    vlSelf->wasmetal_core__DOT___049212_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049210_))));
    vlSelf->wasmetal_core__DOT___051693_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049754_)))));
    vlSelf->wasmetal_core__DOT___049761_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))))))))))));
    vlSelf->wasmetal_core__DOT___051350_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050803_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050802_)))));
    vlSelf->wasmetal_core__DOT___050805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050803_))));
    vlSelf->wasmetal_core__DOT___051527_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))));
    vlSelf->wasmetal_core__DOT___053657_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050821_)))));
    vlSelf->wasmetal_core__DOT___051722_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049894_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049891_)))));
    vlSelf->wasmetal_core__DOT___049896_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049630_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049894_)))));
    vlSelf->wasmetal_core__DOT___065506_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x30f0200030f030fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052623_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049578_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049577_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049576_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050542_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050899_))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051782_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051789_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052629_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052628_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049665_))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___051634_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049628_)))));
    vlSelf->wasmetal_core__DOT___049637_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049635_))));
    vlSelf->wasmetal_core__DOT___051641_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->wasmetal_core__DOT___049694_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049692_))));
    vlSelf->__VdfgTmp_h07886821__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (4U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050717_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050713_)));
    vlSelf->wasmetal_core__DOT___050720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050717_)))));
    vlSelf->wasmetal_core__DOT___053387_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053373_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050877_))))))))))));
    vlSelf->__VdfgTmp_hd604be0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050876_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051544_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050876_)))));
    vlSelf->__VdfgTmp_h32fdaf9b__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (8U 
                                                >> 
                                                (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049781_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049777_)));
    vlSelf->wasmetal_core__DOT___049784_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049781_)))));
    vlSelf->wasmetal_core__DOT___050817_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050815_))));
    vlSelf->wasmetal_core__DOT___051359_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050814_)))));
    vlSelf->wasmetal_core__DOT___065400_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___051992_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051991_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052000_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051999_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->__VdfgTmp_hc485c507__0 = (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051101_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051100_))))));
    vlSelf->__VdfgTmp_h8235f0ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049478_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051605_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049478_)))));
    vlSelf->wasmetal_core__DOT___053724_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049874_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049871_))))));
    vlSelf->wasmetal_core__DOT___049877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049874_)))));
    vlSelf->wasmetal_core__DOT___050837_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050835_))));
    vlSelf->wasmetal_core__DOT___051513_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050834_)))));
    vlSelf->wasmetal_core__DOT___009497_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xbfff0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055066_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049668_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xff55ccf0U 
                                                               >> 
                                                               ((0x10U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                    << 4U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052624_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3784db21__0))))))))));
    vlSelf->__VdfgTmp_h0f76403b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049667_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051623_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049667_)))));
    vlSelf->__VdfgTmp_ha03a7afa__0 = ((2U & ((0xacU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051696_));
    vlSelf->wasmetal_core__DOT___049740_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049321_)))))))))))));
    vlSelf->__VdfgTmp_h45934da4__0 = (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050807_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___049731_)))));
    vlSelf->wasmetal_core__DOT___051339_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050807_)))));
    vlSelf->wasmetal_core__DOT___051420_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051407_)))))))));
    vlSelf->__VdfgTmp_hd506ed16__0 = (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051045_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051044_))))));
    vlSelf->wasmetal_core__DOT___049329_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049327_))));
    vlSelf->wasmetal_core__DOT___051574_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049290_)))));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028119_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 6U)));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026485_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031051_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    if (vlSelf->wasmetal_core__DOT___011101_) {
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8ae31ec8__0))))))));
        vlSelf->wasmetal_core__DOT___012448_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012394_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___012395_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (0xccaafff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfffff0f0ff001111ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012721_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((0xffaaccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012717_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012718_)))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0x11f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012722_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012719_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___012720_)))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011593_))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012642_)))))));
        vlSelf->wasmetal_core__DOT___012448_ = (1U 
                                                & (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xcaU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h224cdee6__0))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xaaaaf0f000ffccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h30784950__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010949_)))))))))))))));
    }
    if (vlSelf->wasmetal_core__DOT___011103_) {
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))))))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011954_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                  ? 
                                                                 (2U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x55330fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0))))
                                                                  : 
                                                                 (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h39b11875__0)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___011407_))))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011955_))))));
    }
    vlSelf->wasmetal_core__DOT___011460_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056618_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011538_))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011539_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011540_))
                                                                                 : 
                                                                                (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h06746976__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeeeeeee00000fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056616_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056615_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                & (IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f5f0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : 
                                                                                (0xfff01111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010332_)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha8472195__0))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010722_)))))))));
    vlSelf->wasmetal_core__DOT___056985_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056903_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f555500ff3333ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0)) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0)))))))))))));
    vlSelf->wasmetal_core__DOT___072167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072148_))));
    vlSelf->wasmetal_core__DOT___072165_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072148_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0))))));
    vlSelf->__VdfgTmp_h39564552__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x69969669U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x96U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072175_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))));
    vlSelf->wasmetal_core__DOT___072198_ = (1U & (IData)(
                                                         (0x7117177117717117ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072181_)))))))));
    vlSelf->wasmetal_core__DOT___072208_ = (1U & (IData)(
                                                         (0x22aabbfabbf022aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072177_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072193_)))))))));
    vlSelf->wasmetal_core__DOT___072194_ = (1U & (IData)(
                                                         (0x17e8e817e81717e8ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072177_)))))))));
    vlSelf->wasmetal_core__DOT___057030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaaff0f0c0f0cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057025_))))))))))));
    vlSelf->wasmetal_core__DOT___057587_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3af565ab__0))));
    vlSelf->wasmetal_core__DOT___057553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h3af565ab__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128548___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010044_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010022_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033452_)))));
    vlSelf->wasmetal_core__DOT___033480_ = ((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___012449_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057172_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaa33f0f0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012400_)))))))))))))));
    vlSelf->wasmetal_core__DOT___012315_ = (1U & (IData)(
                                                         (0xaaaacccc000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___012329_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___013076_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))));
    vlSelf->__VdfgTmp_h5b3d01ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he499e9e8__0))));
    vlSelf->wasmetal_core__DOT___057660_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x10U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057540_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___011102_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x33550f0f00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013103_)))))))))))))));
    vlSelf->wasmetal_core__DOT___057633_ = (1U & (IData)(
                                                         (0xff00f8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1100f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013144_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013142_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013143_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057630_)))))))));
    vlSelf->wasmetal_core__DOT___066100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057343_))));
    vlSelf->wasmetal_core__DOT___012316_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___056947_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca77b771__0))));
    vlSelf->wasmetal_core__DOT___012330_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___057552_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))));
    vlSelf->wasmetal_core__DOT___012895_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057445_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011101_))))));
    vlSelf->wasmetal_core__DOT___012811_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057390_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               & (IData)(
                                                                         (0xf0f3333ff005555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011889_))))))))) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h03a652de__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012799_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012845_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012828_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012826_))))))));
    vlSelf->__VdfgTmp_h2ddf0adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 2U) | ((2U 
                                                  & ((0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011954_)))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011103_)));
    vlSelf->wasmetal_core__DOT___067824_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hef87eb38__0))));
    vlSelf->__VdfgTmp_hbeb24dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___056779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056780_));
    vlSelf->wasmetal_core__DOT___056747_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x1f00U 
                                                                 >> 
                                                                 ((8U 
                                                                   & (((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                                       & (IData)(
                                                                                (0xfffff8f8ffffff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011900_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011898_))))))))) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h1d24e3fc__0)))))))))));
    vlSelf->wasmetal_core__DOT___056384_ = (1U & (IData)(
                                                         (0xccaa0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056382_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))))));
    vlSelf->wasmetal_core__DOT___056462_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))));
    vlSelf->__VdfgTmp_h187b70d7__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012392_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___012474_));
    vlSelf->wasmetal_core__DOT___065320_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065290_))));
    vlSelf->wasmetal_core__DOT___056790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf077U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))))));
    vlSelf->wasmetal_core__DOT___012054_ = (1U & (0xf0088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))));
    vlSelf->wasmetal_core__DOT___065917_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___057031_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___013159_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & (IData)(
                                                      (0xff00ff33f5f5f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))))))));
    vlSelf->wasmetal_core__DOT___057559_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___012608_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff3355550f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___057381_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h417b846d__0))))))));
    vlSelf->wasmetal_core__DOT___011093_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->wasmetal_core__DOT___011296_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___011792_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011305_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011799_)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___011798_))));
    vlSelf->wasmetal_core__DOT___012072_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___011798_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011799_)
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010789_)))))));
    vlSelf->wasmetal_core__DOT___011088_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010789_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010794_))));
    vlSelf->wasmetal_core__DOT___011432_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010794_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011315_)));
    vlSelf->wasmetal_core__DOT___011791_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011315_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011804_)));
    vlSelf->wasmetal_core__DOT___012071_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011804_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010822_)));
    vlSelf->wasmetal_core__DOT___011431_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010821_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010816_))))))));
    vlSelf->wasmetal_core__DOT___011087_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010822_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010821_)));
    vlSelf->wasmetal_core__DOT___012070_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010671_))));
    vlSelf->wasmetal_core__DOT___056366_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010671_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010670_)));
    vlSelf->wasmetal_core__DOT___056592_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011323_)));
    vlSelf->wasmetal_core__DOT___056715_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011323_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011812_)));
    vlSelf->wasmetal_core__DOT___056890_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011812_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010696_)));
    vlSelf->wasmetal_core__DOT___056591_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010695_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010690_))))))));
    vlSelf->wasmetal_core__DOT___056365_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010696_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010695_)));
    vlSelf->wasmetal_core__DOT___013057_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010428_))));
    vlSelf->wasmetal_core__DOT___010406_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010427_)));
    vlSelf->wasmetal_core__DOT___011332_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010427_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011339_)));
    vlSelf->wasmetal_core__DOT___012780_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011339_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011820_)));
    vlSelf->wasmetal_core__DOT___013056_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011820_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010456_)));
    vlSelf->wasmetal_core__DOT___010405_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010456_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010455_)));
    vlSelf->wasmetal_core__DOT___011331_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010455_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011343_)));
    vlSelf->wasmetal_core__DOT___012779_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011343_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011824_)));
    vlSelf->wasmetal_core__DOT___013055_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011824_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010484_)));
    vlSelf->wasmetal_core__DOT___010404_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010483_)));
    vlSelf->wasmetal_core__DOT___011330_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010483_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011347_)));
    vlSelf->wasmetal_core__DOT___012778_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011347_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011828_)));
    vlSelf->wasmetal_core__DOT___057389_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xefffffffecccccccULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))))))));
    vlSelf->__VdfgTmp_hfce8a752__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))));
    vlSelf->wasmetal_core__DOT___012531_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? (IData)(
                                                                (0xfcfcfafafff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010423_))))));
    vlSelf->wasmetal_core__DOT___011329_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xffccffaafff0fff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))));
    vlSelf->wasmetal_core__DOT___010403_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010512_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010506_))))))));
    vlSelf->wasmetal_core__DOT___012105_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010512_)));
    vlSelf->wasmetal_core__DOT___069249_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___011743_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___012106_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010604_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010407_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___011783_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___011910_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056744_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))));
    vlSelf->wasmetal_core__DOT___011081_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011084_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011046_)))))))));
    vlSelf->__VdfgTmp_he19177ad__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011045_)))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011044_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf110000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf000f33335555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056447_) 
                                                                              << 3U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                & (IData)(
                                                                                (0x333355550f0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011084_))))))));
    vlSelf->wasmetal_core__DOT___012216_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h358fed79__0)))))));
    vlSelf->__VdfgTmp_h95aabd6f__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011301_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf10000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011557_))))))));
    vlSelf->__VdfgTmp_h7a970221__0 = (((IData)(vlSelf->wasmetal_core__DOT___012941_) 
                                       << 2U) | ((2U 
                                                  & ((0xf400U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfff00000eeeeULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb67239de__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff1ff00ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                                          << 3U)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0)))))))));
    vlSelf->__VdfgTmp_hb6e1260e__0 = ((4U & ((IData)(
                                                     (0xf0fff4400000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((IData)(
                                                                         (0xfff00000eeeeULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                                 << 3U)) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                                            ? 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (0xbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012990_)))
                                                                            : 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012992_))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012991_))))))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012983_))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb67239de__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___012969_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010084_)));
    vlSelf->__VdfgTmp_ha5e2ba13__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0))));
    vlSelf->wasmetal_core__DOT___012602_ = (1U & (0xccaa0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057306_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7487032b__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012685_)))))));
    vlSelf->wasmetal_core__DOT___057257_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xf00eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7487032b__0))))))));
    vlSelf->wasmetal_core__DOT___067676_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011764_))))));
    vlSelf->wasmetal_core__DOT___011732_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011764_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056645_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056647_)))))))));
    vlSelf->wasmetal_core__DOT___011684_ = (1U & (IData)(
                                                         (0xccccaaaa00f000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056648_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056647_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056635_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056634_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056645_)))))))));
    vlSelf->wasmetal_core__DOT___056689_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056647_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056648_)))))))));
    vlSelf->__VdfgTmp_hf72e2656__0 = (((IData)(vlSelf->wasmetal_core__DOT___056481_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056480_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056479_)));
    vlSelf->wasmetal_core__DOT___072201_ = (1U & (IData)(
                                                         (0xb22b2bb22bb2b22bULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072180_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->__VdfgTmp_h1399f995__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x9669699669969669ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___072180_)))))))))));
    vlSelf->wasmetal_core__DOT___072202_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072180_))))));
    vlSelf->wasmetal_core__DOT___068071_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6fa80fa__0))));
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006029_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013786_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054068_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054072_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054076_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054080_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028640_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028606_)
            : (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->wasmetal_core__DOT____Vcellout___128131___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029083_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029082_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029081_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029080_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029047_)))));
    vlSelf->wasmetal_core__DOT___029051_ = ((IData)(vlSelf->wasmetal_core__DOT___029083_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___029056_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___029055_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___029085_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___029084_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028952_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028918_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001536_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001536_)
            : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128105___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028743_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028742_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028772_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028771_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028738_)))));
    vlSelf->wasmetal_core__DOT___028710_ = ((IData)(vlSelf->wasmetal_core__DOT___028743_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT____Vcellout___127885___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026665_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026664_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026726_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026725_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026660_)))));
    vlSelf->wasmetal_core__DOT___026600_ = ((IData)(vlSelf->wasmetal_core__DOT___026665_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___045241_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045217_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070684_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___045244_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045220_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070689_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127936___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027135_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027134_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027196_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027195_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027130_)))));
    vlSelf->wasmetal_core__DOT___027070_ = ((IData)(vlSelf->wasmetal_core__DOT___027135_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026593_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001382_));
    vlSelf->wasmetal_core__DOT___044969_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___044945_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070787_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___044972_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___044948_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070792_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127919___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026934_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026996_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026995_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026930_)))));
    vlSelf->wasmetal_core__DOT___026870_ = ((IData)(vlSelf->wasmetal_core__DOT___026935_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT____Vcellout___127902___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hce5538fe__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5011624a__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026795_)))));
    vlSelf->wasmetal_core__DOT___026735_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5538fe__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___030095_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b36f4b3__0)))));
    vlSelf->wasmetal_core__DOT___030223_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b36f4b3__0)))));
    vlSelf->wasmetal_core__DOT___030094_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf4f36877__0)))));
    vlSelf->wasmetal_core__DOT___030222_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf4f36877__0)))));
    vlSelf->wasmetal_core__DOT___030124_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0642a572__0)))));
    vlSelf->wasmetal_core__DOT___030284_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0642a572__0)))));
    vlSelf->wasmetal_core__DOT___030123_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25bc616c__0)))));
    vlSelf->wasmetal_core__DOT___030283_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25bc616c__0)))));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001536_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128232___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030122_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030121_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030120_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030119_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030086_)))));
    vlSelf->wasmetal_core__DOT___030090_ = ((IData)(vlSelf->wasmetal_core__DOT___030122_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128246___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030282_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030281_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030276_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030265_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030190_)))));
    vlSelf->wasmetal_core__DOT___030218_ = ((IData)(vlSelf->wasmetal_core__DOT___030282_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT___063123_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063120_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063119_)))))));
    vlSelf->wasmetal_core__DOT___063129_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063126_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063125_)))))));
    vlSelf->wasmetal_core__DOT___063135_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063131_)))))));
    vlSelf->wasmetal_core__DOT___063141_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063138_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063137_)))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028316_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028251_));
    vlSelf->wasmetal_core__DOT___044870_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027473_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027436_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027396_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127435___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hbc1c04e5__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022565_)))));
    vlSelf->wasmetal_core__DOT___022506_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___012165_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33aa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6365363__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056914_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5550fff003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056964_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056968_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012262_)))))))));
    vlSelf->wasmetal_core__DOT___012620_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057288_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcf5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012642_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   (0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___011631_))))
                                                                    : 
                                                                   (0xfeeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011632_) 
                                                                         << 2U) 
                                                                        | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                             & (IData)(
                                                                                (0xccccaaaaf0f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf0faf0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056425_)))))))))))))))))))
                                                      : 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_ha0e20209__0)))))));
    vlSelf->__VdfgTmp_hde86d559__0 = ((2U & ((IData)(
                                                     (0xa0a0f0f00ff00ccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeeeULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xaaaacccc00f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012991_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057264_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (IData)(vlSelf->__VdfgTmp_h6b93e166__0))));
    vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___024031_));
    vlSelf->__VdfgTmp_h8e8edf3a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_h674d61dd__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_haa9bafe9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hc2de3b41__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018857_ = (1U & (IData)(
                                                         (0xfffeffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5565504__0))))))));
    vlSelf->wasmetal_core__DOT___017414_ = ((0x80000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___048930_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048929_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x80000000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0x8000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed5eddc9__0))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000131_));
    vlSelf->wasmetal_core__DOT___012356_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x55fc0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012029_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012028_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))))))))))));
    vlSelf->wasmetal_core__DOT___067544_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4448f15c__0))));
    vlSelf->wasmetal_core__DOT___056316_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___056492_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf400U 
                                                         >> (IData)(vlSelf->__VdfgTmp_heef7d961__0))))));
    vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022948_));
    vlSelf->__VdfgTmp_h7e209046__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_he1214f4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_he2a95d7a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hae3fb8cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT____Vcellout___128649___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001581_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001569_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001537_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001525_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034349_)))));
    vlSelf->wasmetal_core__DOT___034353_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001581_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028876_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028843_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028465_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->wasmetal_core__DOT___051928_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051696_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->wasmetal_core__DOT___064460_ = (1U & (IData)(
                                                         (0xff00ff00ff007000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055082_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055081_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___049540_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049523_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134173___O 
        = ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))) 
           ^ ((((4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                & (IData)(vlSelf->wasmetal_core__DOT___036894_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036894_)));
    vlSelf->wasmetal_core__DOT___064906_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064736_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___063848_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063844_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042224_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048361_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048349_)))))))));
    vlSelf->__VdfgTmp_h60159710__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d)));
    vlSelf->wasmetal_core__DOT___051839_ = (1U & (IData)(
                                                         (0x33aa0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051833_)))))))));
    vlSelf->wasmetal_core__DOT___050831_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050822_))))));
    vlSelf->wasmetal_core__DOT___051801_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051796_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051795_)))))));
    vlSelf->wasmetal_core__DOT___053820_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051796_)))));
    vlSelf->wasmetal_core__DOT___051332_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051330_)))));
    vlSelf->wasmetal_core__DOT___051802_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h36c85254__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf78fffffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                         | (2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                               << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___053823_ = (1U & (0x55cc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h36c85254__0))));
    vlSelf->wasmetal_core__DOT___051322_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049772_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051321_)))));
    vlSelf->wasmetal_core__DOT___050655_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049772_))));
    vlSelf->wasmetal_core__DOT___051792_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051781_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051780_)))))));
    vlSelf->wasmetal_core__DOT___053816_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051781_)))));
    vlSelf->wasmetal_core__DOT___066957_ = (1U & (IData)(
                                                         (0xbf00bfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050983_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050982_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050981_)))))))));
    vlSelf->wasmetal_core__DOT___051293_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051291_)))));
    vlSelf->wasmetal_core__DOT___051793_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xffaaffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h937c72cf__0)))))))))));
    vlSelf->wasmetal_core__DOT___009513_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0))));
    vlSelf->__VdfgTmp_h70db4808__0 = (((IData)(vlSelf->wasmetal_core__DOT___051297_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051295_)))));
    vlSelf->wasmetal_core__DOT___051873_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051867_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051866_)))))));
    vlSelf->wasmetal_core__DOT___066210_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff55ccf0U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051995_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2966b870__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x30f0200030f030fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053628_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xa300U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f5533U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050060_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049538_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051867_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xbfff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054849_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049479_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051776_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051765_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051764_)))))));
    vlSelf->wasmetal_core__DOT___053810_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051765_)))));
    vlSelf->wasmetal_core__DOT___051119_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051117_)))));
    vlSelf->wasmetal_core__DOT___066876_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051104_))));
    vlSelf->__VdfgTmp_ha2491a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___051104_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051100_)))));
    vlSelf->wasmetal_core__DOT___051761_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051753_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051752_)))))));
    vlSelf->wasmetal_core__DOT___053528_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051753_)))));
    vlSelf->wasmetal_core__DOT___009523_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051062_)))));
    vlSelf->wasmetal_core__DOT___066803_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066798_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066797_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057736_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051048_))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->__VdfgTmp_h34f15f45__0 = (((IData)(vlSelf->wasmetal_core__DOT___051048_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051044_)))));
    vlSelf->wasmetal_core__DOT___053912_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053910_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x6eU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051617_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___051716_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051709_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051708_)))))));
    vlSelf->wasmetal_core__DOT___053712_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051709_)))));
    vlSelf->wasmetal_core__DOT___053729_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x550f3300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050895_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___049809_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0880000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)))))))))));
    vlSelf->wasmetal_core__DOT___049821_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049808_)))));
    vlSelf->wasmetal_core__DOT___051823_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050864_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051817_)))))));
    vlSelf->wasmetal_core__DOT___051660_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050864_)))));
    vlSelf->wasmetal_core__DOT___051373_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051369_)))));
    vlSelf->wasmetal_core__DOT___053904_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe0001ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___051854_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050873_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051849_)))))));
    vlSelf->wasmetal_core__DOT___050880_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050873_)))));
    vlSelf->wasmetal_core__DOT___051748_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051743_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051742_)))))));
    vlSelf->wasmetal_core__DOT___053798_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051743_)))));
    vlSelf->wasmetal_core__DOT___066713_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050705_))));
    vlSelf->wasmetal_core__DOT___050710_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050704_)))));
    vlSelf->wasmetal_core__DOT___065636_ = (1U & (IData)(
                                                         (0x4f4f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053129_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7000000077ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053125_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049685_)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0faaccU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049846_))))))))))))));
    vlSelf->wasmetal_core__DOT___053702_ = (1U & ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))
                                                   ? 
                                                  (0x800faffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009538_))))))
                                                   : 
                                                  (0x400055ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009537_))))))));
    vlSelf->wasmetal_core__DOT___009509_ = (1U & (IData)(
                                                         (0xa0f00ff00ff33ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((8U 
                                                                      >> 
                                                                      ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049719_))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049833_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049720_)))))))))));
    vlSelf->wasmetal_core__DOT___049723_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049718_)))));
    vlSelf->wasmetal_core__DOT___053908_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053906_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf32aU 
                                                                         >> 
                                                                         ((0xcU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051584_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051587_)))))))));
    vlSelf->wasmetal_core__DOT___051862_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049211_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051857_)))))));
    vlSelf->wasmetal_core__DOT___049245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049211_)))));
    vlSelf->wasmetal_core__DOT___051703_ = (1U & (IData)(
                                                         (0x55cc0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051460_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051692_)))))))));
    vlSelf->wasmetal_core__DOT___053704_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051460_)))));
    vlSelf->wasmetal_core__DOT___055414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049761_))));
    vlSelf->wasmetal_core__DOT___049769_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049760_)))));
    vlSelf->wasmetal_core__DOT___051807_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051804_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051803_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051350_)))))))));
    vlSelf->wasmetal_core__DOT___051355_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051349_)))));
    vlSelf->wasmetal_core__DOT___051814_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050804_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051809_)))))));
    vlSelf->wasmetal_core__DOT___065733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065729_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065725_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x20003fff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052738_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050808_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0553300000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051591_))))))))))))));
    vlSelf->wasmetal_core__DOT___050858_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050804_)))));
    vlSelf->wasmetal_core__DOT___051739_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051722_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051721_)))))));
    vlSelf->wasmetal_core__DOT___053720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051722_)))));
    vlSelf->wasmetal_core__DOT___066627_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049896_))));
    vlSelf->wasmetal_core__DOT___049902_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049895_)))));
    vlSelf->wasmetal_core__DOT___053396_ = (1U & (IData)(
                                                         (0xffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053391_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051634_)))))))));
    vlSelf->wasmetal_core__DOT___051638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051633_)))));
    vlSelf->wasmetal_core__DOT___051886_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049636_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051880_)))))));
    vlSelf->wasmetal_core__DOT___009499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049637_))));
    vlSelf->wasmetal_core__DOT___049651_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049636_)))));
    vlSelf->wasmetal_core__DOT___051656_ = (1U & (IData)(
                                                         (0x8000cfff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 1U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051641_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048562_)))))))));
    vlSelf->wasmetal_core__DOT___053579_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051641_))));
    vlSelf->__VdfgTmp_hc669ea30__0 = (((IData)(vlSelf->wasmetal_core__DOT___049694_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->wasmetal_core__DOT___051749_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07886821__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff7f80ffffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U))))))))))))))));
    vlSelf->wasmetal_core__DOT___053802_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h07886821__0))));
    vlSelf->wasmetal_core__DOT___050722_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050720_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050719_)))));
    vlSelf->wasmetal_core__DOT___053531_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050720_))));
    vlSelf->wasmetal_core__DOT___066011_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053387_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053385_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050874_)))))))));
    vlSelf->wasmetal_core__DOT___051855_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd604be0c__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xffe01fffffffffffULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))))))))));
    vlSelf->wasmetal_core__DOT___050879_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd604be0c__0))));
    vlSelf->wasmetal_core__DOT___051546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051543_)))));
    vlSelf->wasmetal_core__DOT___052610_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051544_))));
    vlSelf->wasmetal_core__DOT___051717_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa3fU 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h6af6bfd0__0))))))))))));
    vlSelf->wasmetal_core__DOT___053716_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0))));
    vlSelf->__VdfgTmp_hc6a436e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049784_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049777_)))));
    vlSelf->wasmetal_core__DOT___065832_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065828_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((4U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050637_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050601_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x7f7f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065823_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20003fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065824_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050812_)))))))))))))))));
    vlSelf->__VdfgTmp_h6383fd4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050814_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049775_))))))));
    vlSelf->wasmetal_core__DOT___067183_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf3ffa200f3fff3ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067176_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067175_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051359_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000dd00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067179_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049526_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))))))))));
    vlSelf->__VdfgTmp_h56ff1f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051359_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049775_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051777_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((0xd0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xa300000U 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf722c8bb__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d)))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc485c507__0))))));
    vlSelf->wasmetal_core__DOT___053809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc485c507__0))));
    vlSelf->wasmetal_core__DOT___051874_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfd7fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h808d3d88__0))))))))));
    vlSelf->wasmetal_core__DOT___049482_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0))));
    vlSelf->wasmetal_core__DOT___053185_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051605_))));
    vlSelf->__VdfgTmp_h49696f4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051605_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___055205_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053722_))))));
    vlSelf->__VdfgTmp_h2cfc9ba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049877_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049871_)))));
    vlSelf->wasmetal_core__DOT___065922_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053220_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053219_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff80ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053206_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050837_))))))))))));
    vlSelf->__VdfgTmp_h0a242e26__0 = (((IData)(vlSelf->wasmetal_core__DOT___050837_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050834_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049869_))))))));
    vlSelf->wasmetal_core__DOT___067261_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xbfbb3f333f33ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 5U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053654_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051985_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051513_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0aacc00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050829_))))))))))))));
    vlSelf->__VdfgTmp_h28bc3512__0 = (((IData)(vlSelf->wasmetal_core__DOT___051513_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049869_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051887_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0f76403b__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h073e4ce8__0)))))))))));
    vlSelf->wasmetal_core__DOT___049676_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0f76403b__0))));
    vlSelf->__VdfgTmp_h4d7ec491__0 = (((IData)(vlSelf->wasmetal_core__DOT___051623_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051704_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2558491__0)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))))))));
    vlSelf->wasmetal_core__DOT___053708_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))));
    vlSelf->__VdfgTmp_hae9934f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___049740_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))));
    vlSelf->wasmetal_core__DOT___051815_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45934da4__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfa3fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0))))))))));
    vlSelf->__VdfgTmp_hfed11520__0 = ((2U & ((0x55ccf0ffU 
                                              >> ((0x18U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 3U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h45934da4__0))) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0)))));
    vlSelf->__VdfgTmp_h19298f26__0 = (((IData)(vlSelf->wasmetal_core__DOT___051339_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049731_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051437_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051420_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051419_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051418_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))));
    vlSelf->wasmetal_core__DOT___053527_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))));
    vlSelf->wasmetal_core__DOT___066110_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->__VdfgTmp_h0de2f8d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049290_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___067404_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067403_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f010f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051574_))))))))))));
    vlSelf->__VdfgTmp_h0d8fe922__0 = (((IData)(vlSelf->wasmetal_core__DOT___051574_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128043___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028120_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028119_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028118_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028117_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028084_)))));
    vlSelf->wasmetal_core__DOT___028088_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028120_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 7U)));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026455_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128143___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029130_)))));
    vlSelf->wasmetal_core__DOT___029134_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128326___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031052_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031051_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031050_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031049_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031016_)))));
    vlSelf->wasmetal_core__DOT___031020_ = ((IData)(vlSelf->wasmetal_core__DOT___031052_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT___056626_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)
                                                   ? (IData)(
                                                             (0x33335555f0f0f0ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011460_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011458_))))))))
                                                   : 
                                                  (0xabU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011460_))))));
    vlSelf->wasmetal_core__DOT___036627_ = (1U & (0xd400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0))))))));
    vlSelf->wasmetal_core__DOT___072217_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->wasmetal_core__DOT___072212_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->__VdfgTmp_ha7d2f4a8__0 = ((2U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                             << 1U)) 
                                      | (1U & (0x71U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_))))));
    vlSelf->wasmetal_core__DOT___072199_ = (1U & (0x69U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_)))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033480_));
    vlSelf->wasmetal_core__DOT___056951_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056947_))))));
    vlSelf->wasmetal_core__DOT___012280_ = (1U & (IData)(
                                                         (0x1111ff000f0fffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057014_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057012_)))))))));
    vlSelf->wasmetal_core__DOT___056938_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012330_))));
    vlSelf->wasmetal_core__DOT___013081_ = (1U & (IData)(
                                                         (0xff00bbbbf0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057587_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))))))));
    vlSelf->wasmetal_core__DOT___057554_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013184_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    vlSelf->__VdfgTmp_hc7be7ce5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056749_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056747_)));
    vlSelf->__VdfgTmp_hcb4b0ef5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056463_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056462_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056461_)));
    vlSelf->wasmetal_core__DOT___066292_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->wasmetal_core__DOT___013077_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->__VdfgTmp_hcfb94f0b__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057558_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_))))));
    vlSelf->__VdfgTmp_hc60fc2d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011792_))));
    vlSelf->wasmetal_core__DOT___056767_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011792_)))));
    vlSelf->__VdfgTmp_h75e79c91__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012072_)))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012219_))))));
    vlSelf->wasmetal_core__DOT___057163_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011044_)))));
    vlSelf->wasmetal_core__DOT___011572_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011432_))))));
    vlSelf->wasmetal_core__DOT___057454_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h417b846d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011791_)))))))));
    vlSelf->wasmetal_core__DOT___011795_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011791_))))));
    vlSelf->wasmetal_core__DOT___057663_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012219_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012071_)))))))));
    vlSelf->wasmetal_core__DOT___012224_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012071_))))));
    vlSelf->wasmetal_core__DOT___011428_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011431_)))))))));
    vlSelf->wasmetal_core__DOT___011130_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011087_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->__VdfgTmp_hca83bd04__0 = (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011087_));
    vlSelf->wasmetal_core__DOT___056892_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012070_)))))))));
    vlSelf->wasmetal_core__DOT___012607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056592_)))))))));
    vlSelf->wasmetal_core__DOT___057380_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056715_)))))))));
    vlSelf->wasmetal_core__DOT___011908_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012781_)))))))));
    vlSelf->wasmetal_core__DOT___057627_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056890_)))))))));
    vlSelf->wasmetal_core__DOT___011293_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056591_)))))))));
    vlSelf->wasmetal_core__DOT___012256_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013057_)))))))));
    vlSelf->wasmetal_core__DOT___012387_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011087_)))))))));
    vlSelf->wasmetal_core__DOT___012558_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011332_)))))))));
    vlSelf->wasmetal_core__DOT___012808_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012780_)))))))));
    vlSelf->wasmetal_core__DOT___013034_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013056_)))))))));
    vlSelf->wasmetal_core__DOT___011079_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->wasmetal_core__DOT___011425_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011331_)))))))));
    vlSelf->wasmetal_core__DOT___011780_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012779_)))))))));
    vlSelf->wasmetal_core__DOT___012213_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))))));
    vlSelf->wasmetal_core__DOT___012405_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->__VdfgTmp_h2fb7cfc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011330_));
    vlSelf->__VdfgTmp_h3c43f86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___012779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012778_));
    vlSelf->wasmetal_core__DOT___012782_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010508_)
                                                      ? (IData)(
                                                                (0xefffffffffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0)))
                                                      : (IData)(
                                                                (0xecccccccccccccccULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0))))));
    vlSelf->__VdfgTmp_h140002d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___011330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011329_));
    vlSelf->__VdfgTmp_hb3a32b8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010403_));
    vlSelf->__VdfgTmp_hdaecee48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012105_));
    vlSelf->wasmetal_core__DOT___057246_ = (1U & (0xcaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___010396_))))))))));
    vlSelf->wasmetal_core__DOT___012407_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010403_)))))))));
    vlSelf->wasmetal_core__DOT___012214_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012105_)))))))));
    vlSelf->wasmetal_core__DOT___011781_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012778_)))))))));
    vlSelf->__VdfgTmp_hd9ebd9b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012531_)));
    vlSelf->wasmetal_core__DOT___057090_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010403_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___056891_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012105_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))));
    vlSelf->wasmetal_core__DOT___056771_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012778_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___011294_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011330_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011329_))))))));
    vlSelf->wasmetal_core__DOT___011091_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010404_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010403_))))))));
    vlSelf->wasmetal_core__DOT___057577_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012105_))))))));
    vlSelf->wasmetal_core__DOT___067960_ = (1U & (0xf1U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff00fff100000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h18f44539__0))));
    vlSelf->__VdfgTmp_h90d51bf1__0 = (((IData)(vlSelf->wasmetal_core__DOT___057504_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057468_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012980_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xff00fff1ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))))));
    vlSelf->wasmetal_core__DOT___036841_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x69U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127558___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006051_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006058_)))) 
           ^ (((IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023497_)))));
    vlSelf->wasmetal_core__DOT___023449_ = ((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                            & (IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127575___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h097d2f7b__0))) 
           ^ (((IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023618_)))));
    vlSelf->wasmetal_core__DOT___023570_ = ((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                            & (IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028641_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029084_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029051_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028953_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001568_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001568_)
            : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045369_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128105___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___045381_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___128105___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045368_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___045380_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028744_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028710_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___045016_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)))))))))));
    vlSelf->wasmetal_core__DOT___045040_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->__VdfgTmp_h77f7c585__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054071_)))));
    vlSelf->wasmetal_core__DOT___045335_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052138_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052506_)))))))));
    vlSelf->wasmetal_core__DOT___045347_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052506_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052138_)))))))));
    vlSelf->wasmetal_core__DOT___045334_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052416_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052417_)))))))));
    vlSelf->wasmetal_core__DOT___045346_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052137_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052417_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052416_)))))))));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026666_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026600_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___054348_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054342_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054344_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027136_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027070_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026563_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001414_));
    vlSelf->wasmetal_core__DOT___054347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054343_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054345_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026936_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026870_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___045921_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052398_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052476_)))))))));
    vlSelf->wasmetal_core__DOT___045933_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___045920_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052557_)))))))));
    vlSelf->wasmetal_core__DOT___045932_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052556_)))))))));
    vlSelf->wasmetal_core__DOT___045403_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had3e30f3__0)))))));
    vlSelf->wasmetal_core__DOT___045402_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf21c6828__0)))))));
    vlSelf->wasmetal_core__DOT___045415_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___045414_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___045875_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003484_))))))));
    vlSelf->wasmetal_core__DOT___045899_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003484_)))))))));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026735_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001568_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___065053_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030123_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030090_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030283_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030218_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
}
