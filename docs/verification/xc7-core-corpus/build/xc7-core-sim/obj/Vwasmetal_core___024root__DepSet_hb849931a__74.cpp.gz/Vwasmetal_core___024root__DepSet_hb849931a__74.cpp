#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__47(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__47\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___016528_;
    wasmetal_core__DOT___016528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016529_;
    wasmetal_core__DOT___016529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016541_;
    wasmetal_core__DOT___016541_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016747_;
    wasmetal_core__DOT___016747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016748_;
    wasmetal_core__DOT___016748_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016893_;
    wasmetal_core__DOT___016893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016904_;
    wasmetal_core__DOT___016904_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016935_;
    wasmetal_core__DOT___016935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016936_;
    wasmetal_core__DOT___016936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016937_;
    wasmetal_core__DOT___016937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016938_;
    wasmetal_core__DOT___016938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016944_;
    wasmetal_core__DOT___016944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016963_;
    wasmetal_core__DOT___016963_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016975_;
    wasmetal_core__DOT___016975_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016993_;
    wasmetal_core__DOT___016993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016996_;
    wasmetal_core__DOT___016996_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017007_;
    wasmetal_core__DOT___017007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017023_;
    wasmetal_core__DOT___017023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017034_;
    wasmetal_core__DOT___017034_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017045_;
    wasmetal_core__DOT___017045_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017056_;
    wasmetal_core__DOT___017056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017091_;
    wasmetal_core__DOT___017091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017102_;
    wasmetal_core__DOT___017102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017118_;
    wasmetal_core__DOT___017118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017128_;
    wasmetal_core__DOT___017128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017131_;
    wasmetal_core__DOT___017131_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017146_;
    wasmetal_core__DOT___017146_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017962_;
    wasmetal_core__DOT___017962_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017964_;
    wasmetal_core__DOT___017964_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017970_;
    wasmetal_core__DOT___017970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017993_;
    wasmetal_core__DOT___017993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017996_;
    wasmetal_core__DOT___017996_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018026_;
    wasmetal_core__DOT___018026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018027_;
    wasmetal_core__DOT___018027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018041_;
    wasmetal_core__DOT___018041_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018042_;
    wasmetal_core__DOT___018042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018043_;
    wasmetal_core__DOT___018043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018111_;
    wasmetal_core__DOT___018111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018112_;
    wasmetal_core__DOT___018112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018206_;
    wasmetal_core__DOT___018206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018212_;
    wasmetal_core__DOT___018212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018213_;
    wasmetal_core__DOT___018213_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018214_;
    wasmetal_core__DOT___018214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018215_;
    wasmetal_core__DOT___018215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018324_;
    wasmetal_core__DOT___018324_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018358_;
    wasmetal_core__DOT___018358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018359_;
    wasmetal_core__DOT___018359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018360_;
    wasmetal_core__DOT___018360_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018361_;
    wasmetal_core__DOT___018361_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018362_;
    wasmetal_core__DOT___018362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018363_;
    wasmetal_core__DOT___018363_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018366_;
    wasmetal_core__DOT___018366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018367_;
    wasmetal_core__DOT___018367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018463_;
    wasmetal_core__DOT___018463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018464_;
    wasmetal_core__DOT___018464_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018525_;
    wasmetal_core__DOT___018525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018673_;
    wasmetal_core__DOT___018673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018702_;
    wasmetal_core__DOT___018702_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018705_;
    wasmetal_core__DOT___018705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018713_;
    wasmetal_core__DOT___018713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018714_;
    wasmetal_core__DOT___018714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018764_;
    wasmetal_core__DOT___018764_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018795_;
    wasmetal_core__DOT___018795_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018796_;
    wasmetal_core__DOT___018796_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___018893_;
    wasmetal_core__DOT___018893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019040_;
    wasmetal_core__DOT___019040_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019129_;
    wasmetal_core__DOT___019129_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019164_;
    wasmetal_core__DOT___019164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019193_;
    wasmetal_core__DOT___019193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058565_;
    wasmetal_core__DOT___058565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058566_;
    wasmetal_core__DOT___058566_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058569_;
    wasmetal_core__DOT___058569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058570_;
    wasmetal_core__DOT___058570_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058572_;
    wasmetal_core__DOT___058572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058573_;
    wasmetal_core__DOT___058573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058576_;
    wasmetal_core__DOT___058576_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058577_;
    wasmetal_core__DOT___058577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058578_;
    wasmetal_core__DOT___058578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058579_;
    wasmetal_core__DOT___058579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058583_;
    wasmetal_core__DOT___058583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058587_;
    wasmetal_core__DOT___058587_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058588_;
    wasmetal_core__DOT___058588_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058592_;
    wasmetal_core__DOT___058592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058595_;
    wasmetal_core__DOT___058595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058600_;
    wasmetal_core__DOT___058600_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058601_;
    wasmetal_core__DOT___058601_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058603_;
    wasmetal_core__DOT___058603_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058616_;
    wasmetal_core__DOT___058616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058617_;
    wasmetal_core__DOT___058617_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058626_;
    wasmetal_core__DOT___058626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058627_;
    wasmetal_core__DOT___058627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058633_;
    wasmetal_core__DOT___058633_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058634_;
    wasmetal_core__DOT___058634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058637_;
    wasmetal_core__DOT___058637_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058638_;
    wasmetal_core__DOT___058638_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058653_;
    wasmetal_core__DOT___058653_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058654_;
    wasmetal_core__DOT___058654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058657_;
    wasmetal_core__DOT___058657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058658_;
    wasmetal_core__DOT___058658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058662_;
    wasmetal_core__DOT___058662_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058663_;
    wasmetal_core__DOT___058663_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059257_;
    wasmetal_core__DOT___059257_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059258_;
    wasmetal_core__DOT___059258_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059263_;
    wasmetal_core__DOT___059263_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059264_;
    wasmetal_core__DOT___059264_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059267_;
    wasmetal_core__DOT___059267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059268_;
    wasmetal_core__DOT___059268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059269_;
    wasmetal_core__DOT___059269_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059270_;
    wasmetal_core__DOT___059270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059271_;
    wasmetal_core__DOT___059271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059273_;
    wasmetal_core__DOT___059273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059275_;
    wasmetal_core__DOT___059275_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059276_;
    wasmetal_core__DOT___059276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059279_;
    wasmetal_core__DOT___059279_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059280_;
    wasmetal_core__DOT___059280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059283_;
    wasmetal_core__DOT___059283_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059284_;
    wasmetal_core__DOT___059284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059287_;
    wasmetal_core__DOT___059287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059288_;
    wasmetal_core__DOT___059288_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059289_;
    wasmetal_core__DOT___059289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059290_;
    wasmetal_core__DOT___059290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059295_;
    wasmetal_core__DOT___059295_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059296_;
    wasmetal_core__DOT___059296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059297_;
    wasmetal_core__DOT___059297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059298_;
    wasmetal_core__DOT___059298_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059299_;
    wasmetal_core__DOT___059299_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059300_;
    wasmetal_core__DOT___059300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059301_;
    wasmetal_core__DOT___059301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059302_;
    wasmetal_core__DOT___059302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059303_;
    wasmetal_core__DOT___059303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059304_;
    wasmetal_core__DOT___059304_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059305_;
    wasmetal_core__DOT___059305_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059306_;
    wasmetal_core__DOT___059306_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059307_;
    wasmetal_core__DOT___059307_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059308_;
    wasmetal_core__DOT___059308_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059309_;
    wasmetal_core__DOT___059309_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059310_;
    wasmetal_core__DOT___059310_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059359_;
    wasmetal_core__DOT___059359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059362_;
    wasmetal_core__DOT___059362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059365_;
    wasmetal_core__DOT___059365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059366_;
    wasmetal_core__DOT___059366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059367_;
    wasmetal_core__DOT___059367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059369_;
    wasmetal_core__DOT___059369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059371_;
    wasmetal_core__DOT___059371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059404_;
    wasmetal_core__DOT___059404_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059407_;
    wasmetal_core__DOT___059407_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059414_;
    wasmetal_core__DOT___059414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059451_;
    wasmetal_core__DOT___059451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059454_;
    wasmetal_core__DOT___059454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059455_;
    wasmetal_core__DOT___059455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059456_;
    wasmetal_core__DOT___059456_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059457_;
    wasmetal_core__DOT___059457_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059458_;
    wasmetal_core__DOT___059458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059459_;
    wasmetal_core__DOT___059459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059460_;
    wasmetal_core__DOT___059460_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059461_;
    wasmetal_core__DOT___059461_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059527_;
    wasmetal_core__DOT___059527_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059529_;
    wasmetal_core__DOT___059529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059530_;
    wasmetal_core__DOT___059530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059531_;
    wasmetal_core__DOT___059531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059532_;
    wasmetal_core__DOT___059532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059566_;
    wasmetal_core__DOT___059566_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060271_;
    wasmetal_core__DOT___060271_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060343_;
    wasmetal_core__DOT___060343_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060348_;
    wasmetal_core__DOT___060348_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060367_;
    wasmetal_core__DOT___060367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060387_;
    wasmetal_core__DOT___060387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060459_;
    wasmetal_core__DOT___060459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060492_;
    wasmetal_core__DOT___060492_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060506_;
    wasmetal_core__DOT___060506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060520_;
    wasmetal_core__DOT___060520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060534_;
    wasmetal_core__DOT___060534_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060536_;
    wasmetal_core__DOT___060536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060548_;
    wasmetal_core__DOT___060548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060562_;
    wasmetal_core__DOT___060562_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060591_;
    wasmetal_core__DOT___060591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060595_;
    wasmetal_core__DOT___060595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060600_;
    wasmetal_core__DOT___060600_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060602_;
    wasmetal_core__DOT___060602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060620_;
    wasmetal_core__DOT___060620_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060628_;
    wasmetal_core__DOT___060628_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060637_;
    wasmetal_core__DOT___060637_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060642_;
    wasmetal_core__DOT___060642_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134161___O;
    wasmetal_core__DOT____Vcellout___134161___O = 0;
    CData/*1:0*/ __VdfgTmp_he878b3a8__0;
    __VdfgTmp_he878b3a8__0 = 0;
    CData/*3:0*/ __VdfgTmp_he904009c__0;
    __VdfgTmp_he904009c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4e5aac03__0;
    __VdfgTmp_h4e5aac03__0 = 0;
    CData/*3:0*/ __VdfgTmp_h0ef48b5f__0;
    __VdfgTmp_h0ef48b5f__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc59fb841__0;
    __VdfgTmp_hc59fb841__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha18a5876__0;
    __VdfgTmp_ha18a5876__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc47a2f1f__0;
    __VdfgTmp_hc47a2f1f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6ec83bdc__0;
    __VdfgTmp_h6ec83bdc__0 = 0;
    CData/*3:0*/ __VdfgTmp_h00d59987__0;
    __VdfgTmp_h00d59987__0 = 0;
    CData/*5:0*/ __VdfgTmp_h4b0290b7__0;
    __VdfgTmp_h4b0290b7__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c9be8e1__0;
    __VdfgTmp_h0c9be8e1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h601cb0b3__0;
    __VdfgTmp_h601cb0b3__0 = 0;
    CData/*2:0*/ __VdfgTmp_hce4bc968__0;
    __VdfgTmp_hce4bc968__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3e19c29d__0;
    __VdfgTmp_h3e19c29d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h893f43f0__0;
    __VdfgTmp_h893f43f0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h96788d86__0;
    __VdfgTmp_h96788d86__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd32c8afd__0;
    __VdfgTmp_hd32c8afd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbbb73552__0;
    __VdfgTmp_hbbb73552__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc303443c__0;
    __VdfgTmp_hc303443c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h61eefee9__0;
    __VdfgTmp_h61eefee9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9e4f981d__0;
    __VdfgTmp_h9e4f981d__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha5bd917e__0;
    __VdfgTmp_ha5bd917e__0 = 0;
    CData/*1:0*/ __VdfgTmp_h91143f30__0;
    __VdfgTmp_h91143f30__0 = 0;
    CData/*1:0*/ __VdfgTmp_h503e256d__0;
    __VdfgTmp_h503e256d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0260a162__0;
    __VdfgTmp_h0260a162__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4919b5b1__0;
    __VdfgTmp_h4919b5b1__0 = 0;
    CData/*5:0*/ __VdfgTmp_h23858478__0;
    __VdfgTmp_h23858478__0 = 0;
    CData/*5:0*/ __VdfgTmp_haf2ded6f__0;
    __VdfgTmp_haf2ded6f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8e246f46__0;
    __VdfgTmp_h8e246f46__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb715052c__0;
    __VdfgTmp_hb715052c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcdaab3df__0;
    __VdfgTmp_hcdaab3df__0 = 0;
    CData/*1:0*/ __VdfgTmp_haab05145__0;
    __VdfgTmp_haab05145__0 = 0;
    CData/*1:0*/ __VdfgTmp_h56c348e9__0;
    __VdfgTmp_h56c348e9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h688967d3__0;
    __VdfgTmp_h688967d3__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd2bf41e9__0;
    __VdfgTmp_hd2bf41e9__0 = 0;
    CData/*1:0*/ __VdfgTmp_he14d8a41__0;
    __VdfgTmp_he14d8a41__0 = 0;
    CData/*1:0*/ __VdfgTmp_h34e522da__0;
    __VdfgTmp_h34e522da__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8aa93d8f__0;
    __VdfgTmp_h8aa93d8f__0 = 0;
    CData/*3:0*/ __VdfgTmp_h7d28918f__0;
    __VdfgTmp_h7d28918f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h82ac78d0__0;
    __VdfgTmp_h82ac78d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb9827f61__0;
    __VdfgTmp_hb9827f61__0 = 0;
    CData/*2:0*/ __VdfgTmp_h410ade1c__0;
    __VdfgTmp_h410ade1c__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1a2fc46e__0;
    __VdfgTmp_h1a2fc46e__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbcaa6c53__0;
    __VdfgTmp_hbcaa6c53__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc22a8b6b__0;
    __VdfgTmp_hc22a8b6b__0 = 0;
    CData/*1:0*/ __VdfgTmp_haf319b6f__0;
    __VdfgTmp_haf319b6f__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbcab3842__0;
    __VdfgTmp_hbcab3842__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5f7368b7__0;
    __VdfgTmp_h5f7368b7__0 = 0;
    CData/*4:0*/ __VdfgTmp_hffd611b4__0;
    __VdfgTmp_hffd611b4__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf9874a1f__0;
    __VdfgTmp_hf9874a1f__0 = 0;
    CData/*1:0*/ __VdfgTmp_he893b9f2__0;
    __VdfgTmp_he893b9f2__0 = 0;
    // Body
    wasmetal_core__DOT___018026_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017087_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0))))))));
    wasmetal_core__DOT___016893_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058605_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha74c2851__0))))))));
    wasmetal_core__DOT___018027_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017068_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he029cbf7__0))))))));
    wasmetal_core__DOT___016904_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057886_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hfa9cb9e8__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h06719132__0))))))));
    wasmetal_core__DOT___016996_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016995_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb9ae5421__0))))))));
    wasmetal_core__DOT___017007_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017006_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))))));
    wasmetal_core__DOT___017045_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058642_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd520545b__0))))))));
    wasmetal_core__DOT___017056_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057848_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058646_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h1c39cb98__0))))))));
    wasmetal_core__DOT___017091_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057839_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058656_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h398f740d__0))))))));
    wasmetal_core__DOT___017102_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                                  ? 
                                                                 (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h54a2cb2f__0)))))
                                                                  : 
                                                                 (2U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017113_)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h19c83299__0))))))));
    wasmetal_core__DOT___017118_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058660_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h776da2e2__0))))))));
    wasmetal_core__DOT___017128_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057866_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058661_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb1e20b97__0))))))));
    wasmetal_core__DOT___016993_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057821_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058632_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h11dd3326__0))))))));
    wasmetal_core__DOT___016975_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057863_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058631_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h0184ff22__0))))))));
    wasmetal_core__DOT___016944_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xa0cU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057816_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058622_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd10ddd3a__0))))))));
    wasmetal_core__DOT___016963_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058625_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057794_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h1c77e7ba__0))))))));
    wasmetal_core__DOT___017023_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058639_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057776_))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9d72ac71__0))))))));
    wasmetal_core__DOT___017034_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057784_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h01fee3b7__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc6f109bf__0))))))));
    wasmetal_core__DOT___017131_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                                  ? 
                                                                 (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h192fc191__0)))))
                                                                  : 
                                                                 (2U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017141_)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf8652348__0))))))));
    wasmetal_core__DOT___017146_ = (1U & (IData)((0xf3f5f0f0f0f0f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x4400f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057797_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058664_)))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h5ad561b8__0))))))));
    wasmetal_core__DOT____Vcellout___134161___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___036802_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128844___O))))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__1__KET__)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eencode64__02ein__05b62__05d)) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___134161___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___036796_)))));
    vlSelf->wasmetal_core__DOT___060576_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060489_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O))))));
    vlSelf->wasmetal_core__DOT___060503_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060517_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060545_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O))))));
    vlSelf->wasmetal_core__DOT___060559_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060531_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134159___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___060591_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134160___O) 
                                                          >> 3U))))));
    vlSelf->wasmetal_core__DOT___019177_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036802_)))));
    wasmetal_core__DOT___018041_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017160_));
    wasmetal_core__DOT___018360_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017160_));
    wasmetal_core__DOT___018043_ = (1U & (IData)((0x3f005500000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))))));
    wasmetal_core__DOT___018713_ = (1U & (IData)((0x3f55000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))))));
    wasmetal_core__DOT___018361_ = (1U & (0x3f0055U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0586459d__0)))));
    wasmetal_core__DOT___017970_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016542_)
                                           ? ((~ (IData)(vlSelf->wasmetal_core__DOT___016587_)) 
                                              & (0x1fffU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6047dcd2__0)))))
                                           : (0x13U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016538_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016537_))))));
    vlSelf->__VdfgTmp_h80e75d17__0 = (((IData)(vlSelf->wasmetal_core__DOT___016537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016536_));
    wasmetal_core__DOT___016541_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016575_));
    wasmetal_core__DOT___059257_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016575_));
    wasmetal_core__DOT___059258_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016641_));
    wasmetal_core__DOT___016529_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016641_));
    wasmetal_core__DOT___016528_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016652_));
    vlSelf->wasmetal_core__DOT___059261_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016652_));
    vlSelf->wasmetal_core__DOT___059262_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016609_));
    wasmetal_core__DOT___058565_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016609_));
    vlSelf->wasmetal_core__DOT___059259_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016629_));
    wasmetal_core__DOT___058566_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016629_));
    vlSelf->wasmetal_core__DOT___059260_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___016689_));
    wasmetal_core__DOT___058572_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016689_));
    wasmetal_core__DOT___058573_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016699_));
    wasmetal_core__DOT___059264_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016699_));
    wasmetal_core__DOT___059263_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016656_));
    wasmetal_core__DOT___058569_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016656_));
    wasmetal_core__DOT___058570_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016677_));
    __VdfgTmp_he14d8a41__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016677_)) 
                               << 1U) | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                         & (IData)(vlSelf->wasmetal_core__DOT___016734_)));
    wasmetal_core__DOT___058578_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016734_));
    wasmetal_core__DOT___059362_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017999_));
    wasmetal_core__DOT___059275_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___017999_));
    __VdfgTmp_h34e522da__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___018005_)) 
                               << 1U) | (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                               & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016848_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7617577__0))))))))));
    wasmetal_core__DOT___058579_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016744_));
    wasmetal_core__DOT___059268_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016744_));
    __VdfgTmp_h96788d86__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016781_)) 
                               << 1U) | (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                               & (IData)(
                                                         (0xcfffafffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc66d6698__0))))))))));
    wasmetal_core__DOT___059267_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016703_));
    wasmetal_core__DOT___058576_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016703_));
    wasmetal_core__DOT___058577_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016723_));
    wasmetal_core__DOT___059270_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016723_));
    wasmetal_core__DOT___058588_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016757_));
    wasmetal_core__DOT___059269_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016757_));
    wasmetal_core__DOT___058587_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016769_));
    wasmetal_core__DOT___059276_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016769_));
    wasmetal_core__DOT___058595_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016825_));
    wasmetal_core__DOT___059280_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016825_));
    wasmetal_core__DOT___058592_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016814_));
    wasmetal_core__DOT___059279_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016814_));
    wasmetal_core__DOT___059366_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018011_));
    wasmetal_core__DOT___059287_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018011_));
    wasmetal_core__DOT___059367_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018012_));
    wasmetal_core__DOT___059290_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018012_));
    wasmetal_core__DOT___058603_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016860_));
    wasmetal_core__DOT___059284_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016860_));
    wasmetal_core__DOT___059283_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016871_));
    wasmetal_core__DOT___058600_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016871_));
    wasmetal_core__DOT___058601_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___016882_));
    wasmetal_core__DOT___059298_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___018026_));
    __VdfgTmp_h8aa93d8f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                & (IData)(vlSelf->wasmetal_core__DOT___016882_)) 
                               << 1U) | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                         & (IData)(wasmetal_core__DOT___016893_)));
    wasmetal_core__DOT___058617_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016893_));
    wasmetal_core__DOT___059371_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___018027_));
    wasmetal_core__DOT___059296_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___018027_));
    wasmetal_core__DOT___058616_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016904_));
    wasmetal_core__DOT___059288_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016904_));
    wasmetal_core__DOT___058637_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016996_));
    wasmetal_core__DOT___059303_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016996_));
    wasmetal_core__DOT___058638_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017007_));
    wasmetal_core__DOT___059309_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017007_));
    wasmetal_core__DOT___059289_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017045_));
    wasmetal_core__DOT___058654_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017045_));
    wasmetal_core__DOT___059297_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017056_));
    wasmetal_core__DOT___058653_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017056_));
    wasmetal_core__DOT___059295_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017091_));
    wasmetal_core__DOT___058658_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017091_));
    wasmetal_core__DOT___059301_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017102_));
    wasmetal_core__DOT___058657_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017102_));
    wasmetal_core__DOT___059302_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017118_));
    wasmetal_core__DOT___058662_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017118_));
    wasmetal_core__DOT___059300_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017128_));
    wasmetal_core__DOT___058663_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017128_));
    wasmetal_core__DOT___059305_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016993_));
    wasmetal_core__DOT___058634_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016993_));
    wasmetal_core__DOT___059299_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016975_));
    wasmetal_core__DOT___058633_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016975_));
    wasmetal_core__DOT___059306_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016944_));
    wasmetal_core__DOT___058626_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016944_));
    wasmetal_core__DOT___059304_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___016963_));
    wasmetal_core__DOT___058627_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___016963_));
    wasmetal_core__DOT___059310_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017023_));
    wasmetal_core__DOT___018358_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017023_));
    wasmetal_core__DOT___059308_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017034_));
    wasmetal_core__DOT___018359_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017034_));
    wasmetal_core__DOT___059307_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017131_));
    wasmetal_core__DOT___018362_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017131_));
    wasmetal_core__DOT___018042_ = ((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                    & (IData)(wasmetal_core__DOT___017146_));
    wasmetal_core__DOT___018363_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                    & (IData)(wasmetal_core__DOT___017146_));
    vlSelf->wasmetal_core__DOT___060607_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___134161___O))))));
    wasmetal_core__DOT___060620_ = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134161___O) 
                                                          >> 1U))))));
    vlSelf->wasmetal_core__DOT___060631_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059224_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134161___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060581_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0fff1100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060576_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    wasmetal_core__DOT___060492_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060489_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005830_)))))))));
    wasmetal_core__DOT___060506_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060503_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 1U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005896_)))))))));
    wasmetal_core__DOT___060520_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060517_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 2U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))))));
    wasmetal_core__DOT___060548_ = (1U & (IData)((0x5550ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060545_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060543_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d)))))))));
    wasmetal_core__DOT___060562_ = (1U & (IData)((0x5550ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060559_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060557_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 1U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d)))))))));
    wasmetal_core__DOT___060534_ = (1U & (IData)((0xaaa0ccc0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060531_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xf3f5U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127589___O) 
                                                                                >> 3U))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005962_)))))))));
    wasmetal_core__DOT___060595_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060591_))));
    vlSelf->wasmetal_core__DOT___017951_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4cc4790a__0))))));
    vlSelf->wasmetal_core__DOT___018511_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb1afd8c5__0))))));
    vlSelf->wasmetal_core__DOT___059649_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f559dac__0))))));
    vlSelf->wasmetal_core__DOT___018585_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfccc26d7__0))))));
    vlSelf->wasmetal_core__DOT___018663_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h23178df2__0))))));
    vlSelf->wasmetal_core__DOT___018812_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44d9a03d__0))))));
    vlSelf->wasmetal_core__DOT___018829_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc66d6698__0))))));
    vlSelf->wasmetal_core__DOT___018847_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc9aeb4c0__0))))));
    vlSelf->wasmetal_core__DOT___018867_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfbf01d74__0))))));
    vlSelf->wasmetal_core__DOT___018897_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd7617577__0))))));
    vlSelf->wasmetal_core__DOT___018193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019177_))));
    vlSelf->wasmetal_core__DOT___018266_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h52207b53__0))))));
    vlSelf->wasmetal_core__DOT___018946_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1813ebc7__0))))));
    vlSelf->wasmetal_core__DOT___060162_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha74c2851__0))))));
    vlSelf->wasmetal_core__DOT___019000_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3bf6c465__0))))));
    vlSelf->wasmetal_core__DOT___018101_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6047dcd2__0)))));
    vlSelf->wasmetal_core__DOT___018390_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he0d8c702__0))))));
    vlSelf->wasmetal_core__DOT___018622_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6fb1c908__0))))));
    vlSelf->wasmetal_core__DOT___018695_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdbda1ab6__0))))));
    vlSelf->wasmetal_core__DOT___018757_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hefec7bb7__0))))));
    vlSelf->wasmetal_core__DOT___018776_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b17c158__0))))));
    vlSelf->wasmetal_core__DOT___018789_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h83a58712__0))))));
    vlSelf->wasmetal_core__DOT___018878_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5865698c__0))))));
    vlSelf->wasmetal_core__DOT___018913_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h72106b67__0))))));
    vlSelf->wasmetal_core__DOT___018444_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h04ff9270__0))))));
    vlSelf->wasmetal_core__DOT___018424_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h27d7faf5__0))))));
    vlSelf->wasmetal_core__DOT___019070_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0))))));
    wasmetal_core__DOT___060387_ = (1U & (0x35000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))));
    vlSelf->wasmetal_core__DOT___016501_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xbbbbf0ffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___058217_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128828___O) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058218_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h605612ae__0))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058563_)))))));
    vlSelf->wasmetal_core__DOT___018737_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2d6cb346__0))))));
    vlSelf->wasmetal_core__DOT___019026_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h98ad354c__0))))));
    vlSelf->wasmetal_core__DOT___060411_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc6f109bf__0))))));
    vlSelf->wasmetal_core__DOT___018325_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc5bb64fc__0))))));
    wasmetal_core__DOT___060348_ = (1U & (0x35000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd10ddd3a__0))))));
    vlSelf->wasmetal_core__DOT___018984_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06719132__0))))));
    vlSelf->wasmetal_core__DOT___018216_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018713_)))));
    __VdfgTmp_h0260a162__0 = (((IData)(wasmetal_core__DOT___018360_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018361_));
    wasmetal_core__DOT___018366_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018361_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018360_))));
    vlSelf->wasmetal_core__DOT___016531_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016532_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   ((2U 
                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                         & (IData)(
                                                                   (0xafffcfffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___016587_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016585_))))))))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xc0a0f0f0f0f0f0f0ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((IData)(
                                                                                (0xf0f0f000aaccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058562_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128842___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))))))))) 
                                                                                << 2U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h4cc4790a__0))))))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016542_)
                                                    ? 
                                                   (7U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___016541_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016538_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h80e75d17__0))))
                                                    : 
                                                   (1U 
                                                    >> (IData)(wasmetal_core__DOT___016541_)))));
    vlSelf->__VdfgTmp_h48e9ec96__0 = (((IData)(wasmetal_core__DOT___016529_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016528_));
    wasmetal_core__DOT___059407_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___059262_)))));
    vlSelf->wasmetal_core__DOT___016530_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058566_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058565_))));
    __VdfgTmp_h0c9be8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___059260_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059259_)));
    wasmetal_core__DOT___059527_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058566_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058565_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058572_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058573_)))))))));
    vlSelf->__VdfgTmp_h2402eec7__0 = (((IData)(wasmetal_core__DOT___058573_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058572_));
    wasmetal_core__DOT___059404_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___059263_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___059264_)))));
    wasmetal_core__DOT___059273_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___059264_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___059263_)))));
    __VdfgTmp_ha5bd917e__0 = (((IData)(wasmetal_core__DOT___058569_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058570_));
    vlSelf->wasmetal_core__DOT___059494_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059263_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059264_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he14d8a41__0))))))));
    __VdfgTmp_h3e19c29d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (IData)(__VdfgTmp_he14d8a41__0));
    vlSelf->__VdfgTmp_hca806a32__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (IData)(__VdfgTmp_h34e522da__0));
    __VdfgTmp_h91143f30__0 = (((IData)(wasmetal_core__DOT___058578_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058579_));
    __VdfgTmp_hce4bc968__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___059268_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___059267_)));
    __VdfgTmp_h9e4f981d__0 = (((IData)(wasmetal_core__DOT___058576_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058577_));
    vlSelf->wasmetal_core__DOT___059409_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___059269_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059270_)))));
    __VdfgTmp_h601cb0b3__0 = (((IData)(wasmetal_core__DOT___059270_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059269_));
    __VdfgTmp_hc59fb841__0 = (((IData)(wasmetal_core__DOT___058588_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058587_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016798_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h83a58712__0)))))))) 
                                           << 1U) | 
                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                           & (IData)(vlSelf->wasmetal_core__DOT___016781_)))));
    vlSelf->wasmetal_core__DOT___059491_ = (1U & (IData)(
                                                         (0xfff000001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059276_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059275_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h96788d86__0))))))));
    wasmetal_core__DOT___017996_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___059276_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___059275_)))));
    vlSelf->wasmetal_core__DOT___059408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___059275_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059276_)))));
    wasmetal_core__DOT___059456_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058591_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058592_) 
                                                             << 2U) 
                                                            | ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                                 & (IData)(
                                                                           (0xcfffafffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016824_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbf01d74__0)))))))) 
                                                                << 1U) 
                                                               | ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT___018005_))))))))));
    __VdfgTmp_ha18a5876__0 = (((IData)(wasmetal_core__DOT___058592_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058591_));
    vlSelf->wasmetal_core__DOT___059497_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059279_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059280_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h34e522da__0))))))));
    wasmetal_core__DOT___017993_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___059280_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059279_))));
    __VdfgTmp_h503e256d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058603_));
    vlSelf->__VdfgTmp_hb4648514__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___059284_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059283_)));
    wasmetal_core__DOT___059457_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058603_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058600_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058601_)))))))));
    __VdfgTmp_h4e5aac03__0 = (((IData)(wasmetal_core__DOT___058601_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058600_));
    vlSelf->wasmetal_core__DOT___059498_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059283_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059284_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h8aa93d8f__0))))))));
    vlSelf->__VdfgTmp_h64bc71ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (IData)(__VdfgTmp_h8aa93d8f__0));
    wasmetal_core__DOT___059531_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058601_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058600_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058617_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058616_)))))))));
    __VdfgTmp_h0ef48b5f__0 = (((IData)(wasmetal_core__DOT___058617_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058616_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016933_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3bf6c465__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___016915_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h98ad354c__0))))))))))));
    vlSelf->__VdfgTmp_hcbc72a24__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___059288_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059287_)));
    wasmetal_core__DOT___016935_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___058638_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___058637_))));
    __VdfgTmp_hd32c8afd__0 = (((IData)(wasmetal_core__DOT___059290_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059289_));
    wasmetal_core__DOT___059414_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___059289_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___059290_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___059298_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___059297_)))))));
    wasmetal_core__DOT___059369_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___059367_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___059366_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___058653_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___058654_)))))));
    wasmetal_core__DOT___059529_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059367_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059366_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058654_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058653_)))))))));
    __VdfgTmp_h00d59987__0 = (((IData)(wasmetal_core__DOT___058654_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058653_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017087_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde08d0b2__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017068_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_he029cbf7__0))))))))))));
    vlSelf->__VdfgTmp_h0ef15e16__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059298_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059297_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059296_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059295_))))));
    __VdfgTmp_h6ec83bdc__0 = (((IData)(wasmetal_core__DOT___058658_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058657_));
    wasmetal_core__DOT___018215_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059295_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059296_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059301_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059302_)))))))));
    wasmetal_core__DOT___059460_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058657_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058658_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058662_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058663_)))))))));
    wasmetal_core__DOT___059566_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___059299_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___059300_))));
    vlSelf->__VdfgTmp_h7c31faf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059302_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059301_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___059300_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___059299_))))));
    wasmetal_core__DOT___016936_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___058634_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___058633_)))));
    __VdfgTmp_h23858478__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___058663_) 
                                           << 3U) | 
                                          (((IData)(wasmetal_core__DOT___058662_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___058633_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___058634_))))));
    wasmetal_core__DOT___018214_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059299_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059300_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___059305_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059306_)))))))));
    __VdfgTmp_h82ac78d0__0 = (((IData)(wasmetal_core__DOT___059304_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059303_));
    wasmetal_core__DOT___059461_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058634_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058633_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___058626_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___058627_)))))))));
    wasmetal_core__DOT___016937_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___058627_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___058626_)))));
    __VdfgTmp_h4919b5b1__0 = (((IData)(wasmetal_core__DOT___058626_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___058627_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                            & (IData)(
                                                      (0xcfffafffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016995_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb9ae5421__0)))))))) 
                                           << 1U) | 
                                          (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                 & (IData)(
                                                           (0xcfffafffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017006_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hbf2def73__0))))))))))));
    __VdfgTmp_haab05145__0 = (((IData)(wasmetal_core__DOT___059309_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059310_));
    __VdfgTmp_hc47a2f1f__0 = (((IData)(wasmetal_core__DOT___018358_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018359_));
    __VdfgTmp_hb9827f61__0 = (((IData)(wasmetal_core__DOT___059308_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059307_));
    __VdfgTmp_he893b9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 1U) | (1U & (1U >> 
                                               (((IData)(wasmetal_core__DOT___018041_) 
                                                 << 1U) 
                                                | (IData)(wasmetal_core__DOT___018042_)))));
    __VdfgTmp_hcdaab3df__0 = (((IData)(wasmetal_core__DOT___018042_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018041_));
    vlSelf->wasmetal_core__DOT___018130_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___018359_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018358_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___018362_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018363_)))))))));
    wasmetal_core__DOT___018367_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___018363_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018362_))));
    vlSelf->wasmetal_core__DOT___060611_ = (1U & (0xeU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0fff1100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060607_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    wasmetal_core__DOT___019193_ = (1U & (IData)((0xeee0fff0fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060621_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060620_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006238_)))))))));
    wasmetal_core__DOT___060637_ = (1U & (0xeU >> (
                                                   (4U 
                                                    & ((IData)(
                                                               (0xf0fcf0fa00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O) 
                                                                                >> 2U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060631_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016506_)))));
    vlSelf->wasmetal_core__DOT___060494_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060493_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060492_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060483_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005830_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048718_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060508_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060507_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060500_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005896_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048725_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060522_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbb0bU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060514_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeee00000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048726_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060550_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060549_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x7707U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060542_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xee0e0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048713_)))))))))))))));
    vlSelf->wasmetal_core__DOT___060564_ = (1U & (IData)(
                                                         (0xf1ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060563_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060562_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x7707U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060556_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xee0e0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048711_)))))))))))))));
    wasmetal_core__DOT___060536_ = (1U & (IData)((0xf1ff00ff00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060535_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060534_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xbb0bU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060528_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005962_)))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xeee00000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___048727_)))))))))))))));
    wasmetal_core__DOT___060600_ = (1U & (IData)((0xff00ff00ff00e000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060595_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060594_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xdf0fU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060588_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h74741c3a__0))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0xf7f0000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___060573_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060587_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_he45ddc74__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060478_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfef00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060472_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058466_)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005711_))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x7f7f7f7fffff00ffULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0xff4fffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058665_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hc0c493be__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019074_)))));
    wasmetal_core__DOT___060459_ = (1U & (0x4000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___016500_))))));
    wasmetal_core__DOT___059458_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___018363_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___018362_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h0260a162__0))))))));
    vlSelf->wasmetal_core__DOT___018133_ = (1U & (0xe0000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h0260a162__0))))));
    wasmetal_core__DOT___058583_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h2402eec7__0))));
    wasmetal_core__DOT___059451_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058573_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058572_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_ha5bd917e__0))))))));
    wasmetal_core__DOT___059359_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h91143f30__0))));
    vlSelf->__VdfgTmp_h6136b552__0 = ((2U & ((0xeU 
                                              >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                             << 1U)) 
                                      | (1U & (0xe0U 
                                               >> (IData)(__VdfgTmp_h3e19c29d__0))));
    vlSelf->wasmetal_core__DOT___059449_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058579_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058578_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h9e4f981d__0))))))));
    vlSelf->wasmetal_core__DOT___059492_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059267_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059268_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h601cb0b3__0))))))));
    wasmetal_core__DOT___059271_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h601cb0b3__0))));
    vlSelf->wasmetal_core__DOT___059448_ = (1U & (IData)(
                                                         (0xfff000001111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hc59fb841__0))))));
    vlSelf->wasmetal_core__DOT___016749_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hc59fb841__0))))));
    __VdfgTmp_hb715052c__0 = (((IData)(vlSelf->wasmetal_core__DOT___059409_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___059408_));
    vlSelf->__VdfgTmp_h123a61a4__0 = ((2U & ((IData)(
                                                     (0xf111100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 4U) 
                                                          | (((IData)(wasmetal_core__DOT___058577_) 
                                                              << 3U) 
                                                             | (((IData)(wasmetal_core__DOT___058576_) 
                                                                 << 2U) 
                                                                | (((IData)(wasmetal_core__DOT___058587_) 
                                                                    << 1U) 
                                                                   | (IData)(wasmetal_core__DOT___058588_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf00001111ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059363_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___059362_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_ha18a5876__0)))))))));
    __VdfgTmp_h61eefee9__0 = ((2U & ((1U >> (IData)(__VdfgTmp_ha18a5876__0)) 
                                     << 1U)) | (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___058596_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___058595_)))));
    __VdfgTmp_h893f43f0__0 = ((2U & ((0xeU >> (IData)(__VdfgTmp_h96788d86__0)) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___017993_));
    wasmetal_core__DOT___059530_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058596_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058595_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h503e256d__0))))))));
    wasmetal_core__DOT___059365_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h503e256d__0))));
    vlSelf->wasmetal_core__DOT___018203_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(__VdfgTmp_h96788d86__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(wasmetal_core__DOT___017993_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)))))))))));
    vlSelf->wasmetal_core__DOT___018597_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059457_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059456_))));
    wasmetal_core__DOT___016747_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___058603_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058602_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h4e5aac03__0))))));
    vlSelf->wasmetal_core__DOT___018630_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059497_))));
    wasmetal_core__DOT___059455_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h0ef48b5f__0))))));
    wasmetal_core__DOT___016748_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h0ef48b5f__0))))));
    vlSelf->wasmetal_core__DOT___018865_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xeU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x10U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xe0U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)))))))))));
    __VdfgTmp_h4b0290b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                          << 4U) | 
                                         ((8U & ((0xeU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                                 << 3U)) 
                                          | ((4U & 
                                              ((0xe0U 
                                                >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                               << 2U)) 
                                             | ((2U 
                                                 & ((0xe0U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd32c8afd__0)))))))));
    vlSelf->wasmetal_core__DOT___059496_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059287_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059288_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hd32c8afd__0))))))));
    wasmetal_core__DOT___018702_ = (1U & (IData)((0xff00ff001111f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059414_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___059302_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___059301_))) 
                                                                << 2U)) 
                                                            | (((IData)(wasmetal_core__DOT___059295_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___059296_)))))))));
    __VdfgTmp_h8e246f46__0 = ((4U & ((0xe0U >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0xeU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)) 
                                                    << 1U)) 
                                                | (IData)(wasmetal_core__DOT___059414_)));
    wasmetal_core__DOT___018111_ = (1U & (IData)((0x1111f0f0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059369_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___058616_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___058617_))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h4e5aac03__0))))))));
    wasmetal_core__DOT___059454_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h00d59987__0))))));
    wasmetal_core__DOT___018464_ = (1U & (IData)((0xfff0111100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h00d59987__0))))));
    wasmetal_core__DOT___018463_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h6ec83bdc__0))));
    __VdfgTmp_haf2ded6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___059371_) 
                                           << 3U) | 
                                          ((((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                             & (IData)(wasmetal_core__DOT___018026_)) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h6ec83bdc__0)))));
    __VdfgTmp_hbbb73552__0 = ((2U & ((IData)((0xfff00000eeeeULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h7c31faf3__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfff00000eeee0000ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0ef15e16__0)))));
    wasmetal_core__DOT___018796_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___018214_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___018215_)))));
    __VdfgTmp_h56c348e9__0 = (((IData)(wasmetal_core__DOT___018215_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018214_));
    vlSelf->__VdfgTmp_h6b4dc907__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059306_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059305_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h82ac78d0__0)))));
    vlSelf->wasmetal_core__DOT___018595_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059461_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059460_))));
    wasmetal_core__DOT___059532_ = (1U & (IData)((0xfff000001111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (IData)(__VdfgTmp_h4919b5b1__0))))));
    vlSelf->wasmetal_core__DOT___018129_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h4919b5b1__0))))));
    vlSelf->wasmetal_core__DOT___018701_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059566_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___059306_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___059305_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_haab05145__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_h82ac78d0__0))))))))))));
    wasmetal_core__DOT___018213_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059303_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059304_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_haab05145__0))))))));
    wasmetal_core__DOT___059459_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058638_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___058637_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hc47a2f1f__0))))))));
    wasmetal_core__DOT___016938_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hc47a2f1f__0))));
    wasmetal_core__DOT___018714_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_hb9827f61__0))));
    vlSelf->__VdfgTmp_hde0459ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___059310_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___059309_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hb9827f61__0)))));
    __VdfgTmp_h410ade1c__0 = (((IData)(wasmetal_core__DOT___018043_) 
                               << 2U) | (IData)(__VdfgTmp_he893b9f2__0));
    wasmetal_core__DOT___018212_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059307_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___059308_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_hcdaab3df__0))))))));
    __VdfgTmp_hc303443c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___018043_) 
                                          << 2U) | (IData)(__VdfgTmp_hcdaab3df__0)));
    wasmetal_core__DOT___018673_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016533_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___016532_)
                                               ? (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___018359_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018358_)))
                                               : (IData)(wasmetal_core__DOT___018367_))
                                           : ((~ (IData)(vlSelf->wasmetal_core__DOT___016532_)) 
                                              | (IData)(wasmetal_core__DOT___018366_))));
    __VdfgTmp_he878b3a8__0 = (((IData)(wasmetal_core__DOT___018367_) 
                               << 1U) | (IData)(wasmetal_core__DOT___018366_));
    wasmetal_core__DOT___060628_ = (1U & (IData)((0xf4ff00ff00000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060627_) 
                                                          << 3U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                              & (IData)(
                                                                        (0xf0fffbff00ff00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                              << 4U) 
                                                                             | (((IData)(wasmetal_core__DOT___019193_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017186_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xffffff4f00000f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060618_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048714_))))))))))))))) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xdU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                                               >> 1U))))))))))))));
    wasmetal_core__DOT___060642_ = (1U & (IData)((0xfe000000ffff0000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060637_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x44ff00f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060629_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017171_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___060588_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x101010ffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060571_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                                << 2U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                                                & (IData)(
                                                                                (0xff00ffffff1fffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc204a2d8__0))))))) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058687_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___060541_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134185___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018964_)))))))));
    wasmetal_core__DOT___060602_ = (1U & (0xfdf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___060601_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___060600_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xdU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                                      >> 3U))))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018382_)))))));
    __VdfgTmp_hf9874a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                               << 4U) | (((IData)(wasmetal_core__DOT___060459_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                           << 2U) | 
                                          ((2U & ((4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017158_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___017144_)))))) 
                                                  << 1U)) 
                                           | (1U & 
                                              (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___017155_))))))));
    vlSelf->wasmetal_core__DOT___018782_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018133_))));
    vlSelf->__VdfgTmp_hef484883__0 = (((IData)(wasmetal_core__DOT___058583_) 
                                       << 3U) | ((4U 
                                                  & ((1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___058570_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___058569_)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((0x10U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___058579_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___058578_)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                            << 2U) 
                                                           | (((IData)(wasmetal_core__DOT___058577_) 
                                                               << 1U) 
                                                              | (IData)(wasmetal_core__DOT___058576_))))))));
    vlSelf->wasmetal_core__DOT___018113_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___059359_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xe0U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                << 2U) 
                                                               | (IData)(__VdfgTmp_ha5bd917e__0))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xeU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                   << 2U) 
                                                                  | (((IData)(wasmetal_core__DOT___058588_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___058587_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xe0U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h9e4f981d__0))))))))));
    wasmetal_core__DOT___017964_ = (1U & (IData)((0xfff00000eeeeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xeU 
                                                              >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                             << 3U)) 
                                                         | (((IData)(wasmetal_core__DOT___059273_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xe0U 
                                                                    >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___059271_)))))))));
    vlSelf->wasmetal_core__DOT___018388_ = (1U & (IData)(
                                                         (0xfff0111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059527_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___058570_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___058569_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h91143f30__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h123a61a4__0))))))));
    vlSelf->__VdfgTmp_h712e4a02__0 = (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h61eefee9__0)));
    wasmetal_core__DOT___017962_ = ((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                    & (IData)((0xff00ff33f5f5f0f0ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___017996_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h893f43f0__0))))))));
    vlSelf->wasmetal_core__DOT___018675_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059531_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059530_))));
    wasmetal_core__DOT___018112_ = (1U & (IData)((0xf0f0cccc00aa00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___059365_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059363_) 
                                                                   << 1U) 
                                                                  | (IData)(wasmetal_core__DOT___059362_))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_h61eefee9__0))))))));
    vlSelf->__VdfgTmp_hd61370f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___059496_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h0ef15e16__0)))));
    vlSelf->__VdfgTmp_h2229ca65__0 = ((2U & ((IData)(
                                                     (0xeeeeeeeeff00f0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((0xeU 
                                                                  >> (IData)(__VdfgTmp_h96788d86__0)) 
                                                                 << 3U)) 
                                                             | (((IData)(wasmetal_core__DOT___017993_) 
                                                                 << 2U) 
                                                                | (IData)(__VdfgTmp_hb715052c__0))))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___018702_));
    vlSelf->wasmetal_core__DOT___018561_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h8e246f46__0)))));
    wasmetal_core__DOT___018206_ = (1U & (0xfc0055U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h8e246f46__0)))));
    vlSelf->__VdfgTmp_hd6c2c06b__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 4U) 
                                                          | (((IData)(wasmetal_core__DOT___059451_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeee0000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___016528_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___016529_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___058565_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___058566_)))))))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059449_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___059448_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___059457_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___059456_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___059455_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___059454_))))))))));
    vlSelf->wasmetal_core__DOT___018596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059454_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059455_))));
    __VdfgTmp_he904009c__0 = (((IData)(wasmetal_core__DOT___018463_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                          << 2U) | 
                                         ((2U & ((1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058663_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058662_))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___016532_))));
    vlSelf->wasmetal_core__DOT___018387_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059531_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059530_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___059529_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_haf2ded6f__0))))))))))));
    __VdfgTmp_hbcaa6c53__0 = (((IData)(wasmetal_core__DOT___018111_) 
                               << 1U) | (1U & (1U >> 
                                               ((2U 
                                                 & ((IData)(
                                                            (0xfff00000eeeeULL 
                                                             >> (IData)(__VdfgTmp_h23858478__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> (IData)(__VdfgTmp_haf2ded6f__0))))))));
    vlSelf->wasmetal_core__DOT___018674_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfff00000eeeeULL 
                                                                >> (IData)(__VdfgTmp_haf2ded6f__0))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___059529_))));
    vlSelf->__VdfgTmp_h49ede088__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(__VdfgTmp_haf2ded6f__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> (IData)(__VdfgTmp_h23858478__0)))));
    vlSelf->wasmetal_core__DOT___018489_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(wasmetal_core__DOT___059273_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___059271_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xe0U 
                                                                                >> (IData)(__VdfgTmp_hce4bc968__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0c0f0c0000aaffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___017996_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h893f43f0__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_hbbb73552__0)))))))))));
    __VdfgTmp_haf319b6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                               << 1U) | (1U & (1U >> (IData)(__VdfgTmp_hbbb73552__0))));
    vlSelf->wasmetal_core__DOT___018560_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h56c348e9__0))));
    vlSelf->wasmetal_core__DOT___018629_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfff00000eeeeULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7c31faf3__0)))))));
    __VdfgTmp_hc22a8b6b__0 = ((2U & ((IData)((0xfff00000eeee0000ULL 
                                              >> (IData)(__VdfgTmp_h23858478__0))) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___059532_));
    vlSelf->wasmetal_core__DOT___018780_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018130_)))));
    wasmetal_core__DOT___018525_ = (1U & (IData)((0xffbfbfbfbfULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018130_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___018366_)))))))));
    vlSelf->__VdfgTmp_h5395e72d__0 = (((IData)(wasmetal_core__DOT___018702_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018701_));
    __VdfgTmp_h688967d3__0 = (((IData)(wasmetal_core__DOT___059459_) 
                               << 1U) | (IData)(wasmetal_core__DOT___059458_));
    __VdfgTmp_h7d28918f__0 = (((IData)(wasmetal_core__DOT___018714_) 
                               << 3U) | (((IData)(wasmetal_core__DOT___018713_) 
                                          << 2U) | (IData)(__VdfgTmp_he893b9f2__0)));
    __VdfgTmp_h1a2fc46e__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0xfff00000eeee0000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0))))));
    wasmetal_core__DOT___018893_ = (1U & (0xf40000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h410ade1c__0)))));
    wasmetal_core__DOT___018764_ = (1U & (0xf4000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h410ade1c__0)))));
    wasmetal_core__DOT___018795_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___018212_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018213_)))));
    vlSelf->wasmetal_core__DOT___018562_ = (1U & (0xfff08888U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___018213_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___018212_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___018713_)))))));
    vlSelf->wasmetal_core__DOT___059499_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hc303443c__0))));
    vlSelf->wasmetal_core__DOT___060388_ = (1U & (IData)(
                                                         (0xefffffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060387_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018673_)))))))));
    vlSelf->__VdfgTmp_h64b8144d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___018673_))));
    vlSelf->__VdfgTmp_h4cdeac4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018673_));
    vlSelf->wasmetal_core__DOT___018389_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(__VdfgTmp_h23858478__0))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___059532_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___018673_)))))));
    vlSelf->__VdfgTmp_ha954d544__0 = ((((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                        & (IData)((0xf000fffff4444ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                     << 5U) 
                                                    | (((IData)(wasmetal_core__DOT___016938_) 
                                                        << 4U) 
                                                       | (((IData)(wasmetal_core__DOT___016936_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___016937_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                 << 1U) 
                                                                | (IData)(wasmetal_core__DOT___016935_))))))))) 
                                       << 1U) | (1U 
                                                 & (0x3050000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_he878b3a8__0)))))));
    vlSelf->wasmetal_core__DOT___016516_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_he878b3a8__0))))));
    vlSelf->wasmetal_core__DOT___039859_ = (1U & (IData)(
                                                         (0xfefefefe02fe0202ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___060628_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060620_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___060644_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060643_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___060642_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                                           >> 2U))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018382_)))))));
    vlSelf->wasmetal_core__DOT___039858_ = (1U & (IData)(
                                                         (0xf00ffff2e222e22ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(wasmetal_core__DOT___060602_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___060591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___060479_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf9874a1f__0)))));
    vlSelf->wasmetal_core__DOT___060469_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf9874a1f__0)))));
    vlSelf->wasmetal_core__DOT___060441_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5ad561b8__0))))))))))));
    vlSelf->wasmetal_core__DOT___060447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018782_))));
    if (vlSelf->wasmetal_core__DOT___016534_) {
        vlSelf->wasmetal_core__DOT___016519_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016749_)) 
                                                   & (0xfcfaU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h712e4a02__0))));
        vlSelf->wasmetal_core__DOT___018456_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___016748_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___016747_)))));
    } else {
        vlSelf->wasmetal_core__DOT___016519_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___016748_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___016747_)))));
        vlSelf->wasmetal_core__DOT___018456_ = (1U 
                                                & ((~ (IData)(wasmetal_core__DOT___018464_)) 
                                                   & (0xf0feU 
                                                      >> (IData)(__VdfgTmp_he904009c__0))));
    }
    vlSelf->wasmetal_core__DOT___017953_ = (1U & ((~ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                     & (IData)(
                                                               (0xfef000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hc303443c__0))))))
                                                     ? 
                                                    (1U 
                                                     >> (IData)(vlSelf->wasmetal_core__DOT___016520_))
                                                     : 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___016534_)
                                                      ? 
                                                     (0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_hbbb73552__0))))
                                                      : 
                                                     (0xe0U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xfff00000eeeeULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xfff00000eeee0000ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))))))))))) 
                                                  & (IData)(
                                                            (0xfffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___017964_) 
                                                                     << 3U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                         & (IData)(
                                                                                (0xff0f0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___017970_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___059258_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___059257_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059262_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059261_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0))))))))))) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___017962_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(__VdfgTmp_h4b0290b7__0)))))))))))));
    vlSelf->__VdfgTmp_h38d1dc38__0 = (((IData)(wasmetal_core__DOT___018112_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018111_));
    vlSelf->wasmetal_core__DOT___018633_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd61370f8__0))));
    vlSelf->wasmetal_core__DOT___018422_ = (1U & (IData)(
                                                         (0xf0f0cccc00ff00aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018865_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfff01111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                           << 4U) 
                                                                          | (((IData)(wasmetal_core__DOT___059404_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x10U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6136b552__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2229ca65__0))))))));
    vlSelf->wasmetal_core__DOT___018195_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___016534_)
                                                      ? 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h56c348e9__0)))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___018213_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___018212_)))))
                                                     : 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018216_))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                      ? 
                                                     (0x1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xfff000001111ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((0xe0U 
                                                                                >> (IData)(__VdfgTmp_h3e19c29d__0)) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((0xeU 
                                                                                >> (IData)(__VdfgTmp_hce4bc968__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(__VdfgTmp_hb715052c__0))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfff0111100000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                             << 4U) 
                                                                            | (((IData)(wasmetal_core__DOT___059407_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___059257_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___059258_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> (IData)(__VdfgTmp_h0c9be8e1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(wasmetal_core__DOT___059404_))))))))))))
                                                      : 
                                                     (0xfdfU 
                                                      >> 
                                                      (((IData)(wasmetal_core__DOT___018206_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___018203_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016534_))))))));
    vlSelf->wasmetal_core__DOT___018258_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6c2c06b__0))));
    vlSelf->__VdfgTmp_hb7c93ea5__0 = (((IData)(vlSelf->wasmetal_core__DOT___018596_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018595_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (((IData)(wasmetal_core__DOT___059458_) 
                                                         << 1U) 
                                                        | (IData)(wasmetal_core__DOT___059459_))))));
    vlSelf->__VdfgTmp_h5fa8e6eb__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___016533_)
                                               ? (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___016937_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___016936_))))
                                               : (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___016938_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___016935_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___016532_)))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0fe00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(wasmetal_core__DOT___018464_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_he904009c__0)))))));
    vlSelf->__VdfgTmp_h787c74f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___018674_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016534_));
    vlSelf->wasmetal_core__DOT___018781_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h49ede088__0))));
    vlSelf->__VdfgTmp_h97bdc512__0 = (((IData)(vlSelf->wasmetal_core__DOT___018489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016520_));
    vlSelf->wasmetal_core__DOT___018849_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x11f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___018673_) 
                                                                              << 2U) 
                                                                             | (IData)(__VdfgTmp_hc22a8b6b__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018675_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018674_)))))))));
    vlSelf->wasmetal_core__DOT___018677_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hc22a8b6b__0))));
    vlSelf->wasmetal_core__DOT___060333_ = (1U & (IData)(
                                                         (0xefffefffefffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___018525_)))))))));
    vlSelf->__VdfgTmp_h111e31ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018525_)));
    vlSelf->wasmetal_core__DOT___018915_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___018525_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hbcaa6c53__0))))))));
    vlSelf->wasmetal_core__DOT___018265_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059461_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___059460_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h688967d3__0))))))));
    vlSelf->wasmetal_core__DOT___018599_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h688967d3__0)))));
    vlSelf->wasmetal_core__DOT___018864_ = (1U & (IData)(
                                                         (0xff110000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h7d28918f__0))))));
    vlSelf->wasmetal_core__DOT___018715_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h7d28918f__0))))));
    vlSelf->wasmetal_core__DOT___018899_ = ((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                            & (IData)(
                                                      (0xffff1111fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((IData)(
                                                                       (0xfff00000eeee0000ULL 
                                                                        >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((0xe0U 
                                                                   >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(wasmetal_core__DOT___018893_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_haf319b6f__0))))))));
    vlSelf->__VdfgTmp_he026c2ed__0 = ((2U & ((0xe0U 
                                              >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___018893_));
    vlSelf->wasmetal_core__DOT___019185_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___018764_)))));
    if (vlSelf->wasmetal_core__DOT___016521_) {
        if (vlSelf->wasmetal_core__DOT___016520_) {
            vlSelf->wasmetal_core__DOT___018759_ = 
                (1U & (1U >> ((2U & ((IData)((0xfff00000eeeeULL 
                                              >> (IData)(__VdfgTmp_h4b0290b7__0))) 
                                     << 1U)) | (IData)(wasmetal_core__DOT___017962_))));
            vlSelf->wasmetal_core__DOT___018554_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | ((2U & (
                                                   (0x1111fff0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059408_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___059409_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6136b552__0))))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018203_)))));
            vlSelf->wasmetal_core__DOT___016505_ = 
                (1U & (1U >> ((2U & ((IData)((0xf00001111ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                      << 4U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hef484883__0))))) 
                                     << 1U)) | ((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                & (IData)(
                                                          (0xff00ffeeee0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016531_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016530_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h48e9ec96__0)))))))))));
            vlSelf->wasmetal_core__DOT___018665_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | ((2U & (
                                                   (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h123a61a4__0)) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018675_)))));
        } else {
            vlSelf->wasmetal_core__DOT___018759_ = 
                (1U & (1U >> (IData)(wasmetal_core__DOT___018764_)));
            vlSelf->wasmetal_core__DOT___018554_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___018562_)));
            vlSelf->wasmetal_core__DOT___016505_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h5fa8e6eb__0)));
            vlSelf->wasmetal_core__DOT___018665_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h4cdeac4b__0)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___018759_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016520_)) 
                                                   | (0xdU 
                                                      >> 
                                                      ((4U 
                                                        & ((0xeU 
                                                            >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((1U 
                                                               >> (IData)(__VdfgTmp_hbbb73552__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016534_))))));
        vlSelf->wasmetal_core__DOT___018554_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016520_)) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___018561_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___018560_)))));
        vlSelf->wasmetal_core__DOT___016505_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016519_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016516_))));
        vlSelf->wasmetal_core__DOT___018665_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016520_)) 
                                                   | (0x23U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018677_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___018674_))))));
    }
    vlSelf->__VdfgTmp_h0b565375__0 = ((8U & ((0xeU 
                                              >> (IData)(__VdfgTmp_h1a2fc46e__0)) 
                                             << 3U)) 
                                      | (((IData)(wasmetal_core__DOT___018764_) 
                                          << 2U) | (IData)(__VdfgTmp_haf319b6f__0)));
    vlSelf->__VdfgTmp_hb98c8577__0 = (((IData)(vlSelf->wasmetal_core__DOT___018216_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___018795_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___018796_)));
    vlSelf->wasmetal_core__DOT___018937_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018561_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018560_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018562_)))))));
    vlSelf->wasmetal_core__DOT___018935_ = (1U & ((~ 
                                                   (0x35000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hcacd7e7e__0)))))) 
                                                  & (IData)(
                                                            (0xffff11ffffff0fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018562_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018560_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___018561_))))))))));
    vlSelf->__VdfgTmp_hc40410bb__0 = (((IData)(wasmetal_core__DOT___060348_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018562_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))));
    __VdfgTmp_h5f7368b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018562_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016521_)));
    vlSelf->wasmetal_core__DOT___018831_ = ((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018630_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> 
                                                                      ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ef15e16__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059496_))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018629_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059499_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0)))))))))))))));
    __VdfgTmp_hd2bf41e9__0 = ((2U & ((IData)((0xfff00000eeee0000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hde0459ca__0))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___059499_));
    vlSelf->wasmetal_core__DOT___060396_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060388_))));
    vlSelf->wasmetal_core__DOT___060403_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfcf0faf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058504_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128872___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0335500000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058353_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127505___O) 
                                                                                >> 2U))))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xbfffbfff0000ffffULL 
                                                                       >> 
                                                                       ((0x20U 
                                                                         & ((0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                            << 5U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060398_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h64b8144d__0)))))))))));
    vlSelf->wasmetal_core__DOT___018985_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4cdeac4b__0)))));
    vlSelf->wasmetal_core__DOT___018380_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018388_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018387_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018389_)))))));
    vlSelf->wasmetal_core__DOT___060299_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h19c83299__0))))))))))));
    vlSelf->__VdfgTmp_h86684a6a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018389_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018388_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018387_)));
    vlSelf->__VdfgTmp_h483b6bbc__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018389_));
    wasmetal_core__DOT___019129_ = (1U & (0xe000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_ha954d544__0)))));
    vlSelf->wasmetal_core__DOT___060426_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7f7f7f7fffff00ffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((0xff4fffU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h01fee3b7__0)) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016516_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc0c493be__0)))))))))));
    __VdfgTmp_hffd611b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___060411_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___016516_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___016500_)))));
    vlSelf->wasmetal_core__DOT___039860_ = (1U & (IData)(
                                                         (0xf00ffff2e222e22ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060631_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d)))))))));
    vlSelf->wasmetal_core__DOT___060455_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060441_))));
    vlSelf->wasmetal_core__DOT___060454_ = (1U & (IData)(
                                                         (0xbbb0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060447_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff4fffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x10U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058664_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->wasmetal_core__DOT___059354_ = (1U & (IData)(
                                                         (0x3faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059348_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017953_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058562_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059242_))))))))))));
    vlSelf->wasmetal_core__DOT___018103_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___016534_)
                                                      ? 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h49ede088__0)))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018130_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___018129_)))))
                                                     : 
                                                    (2U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___018133_))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                      ? 
                                                     (0xcfefU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xf0f0ccaa00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___016532_)
                                                                                 ? 
                                                                                (((~ (IData)(vlSelf->wasmetal_core__DOT___016575_)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___016542_)) 
                                                                                & (0xf7fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016538_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016542_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h80e75d17__0)))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h48e9ec96__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016530_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2402eec7__0)))))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___018113_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h38d1dc38__0)))))));
    vlSelf->__VdfgTmp_heeceee13__0 = (((IData)(vlSelf->wasmetal_core__DOT___018422_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016520_));
    vlSelf->wasmetal_core__DOT___059446_ = (1U & (IData)(
                                                         (0xff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059436_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018195_)))))))));
    vlSelf->wasmetal_core__DOT___059447_ = (1U & (IData)(
                                                         (0xf1f1000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018193_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018195_)))))))));
    vlSelf->wasmetal_core__DOT___018948_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb7c93ea5__0)))))));
    vlSelf->wasmetal_core__DOT___018814_ = ((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018597_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb7c93ea5__0)))))));
    vlSelf->wasmetal_core__DOT___018880_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018456_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha954d544__0))))));
    vlSelf->__VdfgTmp_h4809aef4__0 = (((IData)(vlSelf->wasmetal_core__DOT___016516_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5fa8e6eb__0));
    vlSelf->wasmetal_core__DOT___060266_ = (1U & (0xf0440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xfcaa0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018781_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018780_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___018133_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058646_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))));
    vlSelf->__VdfgTmp_hb83be1cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___018133_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018780_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018781_)));
    vlSelf->wasmetal_core__DOT___059990_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059981_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018849_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058590_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_h0c4afb11__0 = (((IData)(vlSelf->wasmetal_core__DOT___018677_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___018674_))));
    vlSelf->wasmetal_core__DOT___060347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060333_))));
    vlSelf->wasmetal_core__DOT___018535_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                    ? 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018113_) 
                                                         << 1U) 
                                                        | (IData)(wasmetal_core__DOT___018112_))))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                      << 2U) 
                                                     | (IData)(__VdfgTmp_hbcaa6c53__0))))
                                                   : 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___016521_)) 
                                                   | (2U 
                                                      >> (IData)(wasmetal_core__DOT___018525_)))));
    vlSelf->wasmetal_core__DOT___018519_ = (1U & ((4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                  & (IData)(
                                                            (0xffdfff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018538_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018537_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018536_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018535_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))))))))));
    wasmetal_core__DOT___060343_ = (1U & (IData)((0xbfbfbfbfffff00ffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0xff4fffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058632_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h111e31ee__0)))))));
    vlSelf->wasmetal_core__DOT___060095_ = (1U & (IData)(
                                                         (0xff4400000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060074_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___060094_ = (1U & ((~ 
                                                   (0x3500U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                 ? 
                                                                (0xc0c5U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he5a4e99b__0))))
                                                                 : 
                                                                (0xc0c5U 
                                                                 >> 
                                                                 ((8U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he5a4e99b__0))))) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xee0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h696b299a__0)))))))))))))))))))) 
                                                  & (IData)(
                                                            (0x33ff55fff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O) 
                                                                                >> 3U))))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018915_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058597_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))))))));
    vlSelf->wasmetal_core__DOT___060285_ = (1U & (0xfffbbbbU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xff4fffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018265_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058649_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))));
    vlSelf->wasmetal_core__DOT___018257_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016520_))));
    __VdfgTmp_hbcab3842__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018265_));
    vlSelf->wasmetal_core__DOT___060361_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018599_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1c77e7ba__0))))))))))));
    wasmetal_core__DOT___060367_ = (1U & (IData)((0xf000444400000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018599_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058625_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->wasmetal_core__DOT___018869_ = ((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                            & (IData)(
                                                      (0xff00ff33f5f5f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018865_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018864_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5395e72d__0))))))));
    vlSelf->__VdfgTmp_hea1c7f12__0 = (((IData)(vlSelf->wasmetal_core__DOT___018864_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018701_)));
    vlSelf->wasmetal_core__DOT___018999_ = (1U & (IData)(
                                                         (0x3355f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018715_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5395e72d__0))))))));
    wasmetal_core__DOT___018705_ = ((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___018715_));
    vlSelf->wasmetal_core__DOT___060073_ = (1U & (IData)(
                                                         (0xf8f800ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060064_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xc000a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018899_)))))))));
    vlSelf->__VdfgTmp_he2b184a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he026c2ed__0)));
    vlSelf->wasmetal_core__DOT___060438_ = (1U & (IData)(
                                                         (0xbbb0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060435_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019185_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff4fffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xa0c0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xff4fffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h192fc191__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_h472f3127__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf8652348__0))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___019185_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___059847_ = (1U & (IData)(
                                                         (0xfefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059837_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018757_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059848_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x7f7f007fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059035_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___018054_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ab499a5__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018759_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058584_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059242_))))))))))));
    wasmetal_core__DOT___019040_ = (1U & (IData)((0xff44f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b565375__0))))));
    vlSelf->wasmetal_core__DOT___018791_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                    ? 
                                                   (0xf4U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___018206_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___018203_))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___018796_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___018795_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___018216_)))));
    vlSelf->wasmetal_core__DOT___059908_ = (1U & (IData)(
                                                         (0xbb0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018789_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059895_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018791_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059909_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059899_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018791_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xca00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    wasmetal_core__DOT___060271_ = ((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                    & ((1U & (0xff4fffU 
                                              >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))
                                        ? (IData)((0xff11fff0ff00ff00ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019073_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb98c8577__0))))))
                                        : (2U >> (IData)(vlSelf->wasmetal_core__DOT___019073_))));
    vlSelf->wasmetal_core__DOT___060120_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018935_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059213_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134207___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018055_)))))))));
    wasmetal_core__DOT___019164_ = (1U & (IData)((0xffff4000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc40410bb__0)))));
    vlSelf->wasmetal_core__DOT___060358_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7f7f7f7fffff00ffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((0xff4fffU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058622_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h5f7368b7__0))))))))));
    vlSelf->wasmetal_core__DOT___018550_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059686_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xff4fffU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018554_)))))));
    vlSelf->__VdfgTmp_hca110094__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hfa0a9622__0))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018554_)));
    vlSelf->wasmetal_core__DOT___059962_ = (1U & (IData)(
                                                         (0xccaa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7fff00007fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059059_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5c50a9b1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017463_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018831_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058589_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059242_))))))))))));
    vlSelf->wasmetal_core__DOT___018962_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hd2bf41e9__0))));
    vlSelf->wasmetal_core__DOT___018632_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hd2bf41e9__0)))));
    if (vlSelf->wasmetal_core__DOT___016520_) {
        if (vlSelf->wasmetal_core__DOT___016521_) {
            vlSelf->wasmetal_core__DOT___018441_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | ((2U & (
                                                   (0xfff0eeeeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                      << 4U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hef484883__0))) 
                                                   << 1U)) 
                                            | (1U & 
                                               (0xfcfaU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___016749_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h712e4a02__0))))))));
            vlSelf->wasmetal_core__DOT___018728_ = 
                (1U & (0x32U >> (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018737_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___016519_)))));
            vlSelf->wasmetal_core__DOT___018775_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h38d1dc38__0))));
            vlSelf->wasmetal_core__DOT___018625_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___059491_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___059492_))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018630_)))));
        } else {
            vlSelf->wasmetal_core__DOT___018441_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___018456_)));
            vlSelf->wasmetal_core__DOT___018728_ = 
                (1U & (0xf0eU >> (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___018737_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h5fa8e6eb__0)))));
            vlSelf->wasmetal_core__DOT___018775_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___018781_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018780_))));
            vlSelf->wasmetal_core__DOT___018625_ = 
                (1U & (0x32U >> (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018633_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018629_)))));
        }
        if (vlSelf->wasmetal_core__DOT___016534_) {
            vlSelf->wasmetal_core__DOT___018587_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___059448_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___059449_))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018596_)))));
            vlSelf->wasmetal_core__DOT___018697_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h2229ca65__0))));
        } else {
            vlSelf->wasmetal_core__DOT___018587_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___018597_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018595_)))));
            vlSelf->wasmetal_core__DOT___018697_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                  << 2U) | ((2U & (
                                                   (0xf1111U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((0xeU 
                                                             >> (IData)(vlSelf->__VdfgTmp_hb4648514__0)) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((0x10U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca806a32__0)) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((0xeU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc72a24__0)) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (0xe0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h64bc71ef__0)))))))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___018701_)))));
        }
        vlSelf->wasmetal_core__DOT___060268_ = (1U 
                                                & (IData)(
                                                          (0xff00ee00ff000fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019070_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hb98c8577__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___018441_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___016521_)) 
                                                   | (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha954d544__0))));
        vlSelf->wasmetal_core__DOT___018728_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___016521_)
                                                    ? 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018737_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016516_))))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___018737_))));
        vlSelf->wasmetal_core__DOT___018775_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018782_)));
        vlSelf->wasmetal_core__DOT___018587_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018599_)));
        vlSelf->wasmetal_core__DOT___060268_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019070_)));
        vlSelf->wasmetal_core__DOT___018697_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___018705_)));
        vlSelf->wasmetal_core__DOT___018625_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___018632_)));
    }
    wasmetal_core__DOT___018324_ = (1U & (IData)((0xfff00000eeee0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (0xfff00000eeeeULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6b4dc907__0))) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xfff00000eeee0000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7c31faf3__0))) 
                                                                << 2U)) 
                                                            | (IData)(__VdfgTmp_hd2bf41e9__0))))))));
    vlSelf->wasmetal_core__DOT___060313_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060299_))));
    vlSelf->wasmetal_core__DOT___059537_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86684a6a__0))));
    vlSelf->wasmetal_core__DOT___060309_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xff4fffU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h483b6bbc__0))));
    vlSelf->wasmetal_core__DOT___019125_ = (1U & (IData)(
                                                         (0xff00101000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(wasmetal_core__DOT___019129_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058661_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_h0d5a6a23__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb1e20b97__0))))) 
                                             << 2U)) 
                                      | (((IData)(wasmetal_core__DOT___019129_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___060427_ = (1U & (IData)(
                                                         (0xffff400000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hffd611b4__0)))));
    vlSelf->wasmetal_core__DOT___060418_ = (1U & (IData)(
                                                         (0xffff4000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hffd611b4__0)))));
    vlSelf->wasmetal_core__DOT___059402_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059394_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xff4fffU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018103_)))))));
    vlSelf->wasmetal_core__DOT___059403_ = (1U & (IData)(
                                                         (0xee0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018101_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059389_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___059390_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018103_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___060145_ = (1U & (0xbbf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018946_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060121_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))));
    vlSelf->wasmetal_core__DOT___018809_ = (1U & (IData)(
                                                         (0xcf45454500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5f3fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0da91de8__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018287_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5030f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hca8853c2__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___059625_ = (1U & (IData)(
                                                         (0xff00b000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059620_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059619_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3050f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcf32a2f0__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018441_)))))))));
    vlSelf->__VdfgTmp_hd6ad4dda__0 = (((IData)(vlSelf->wasmetal_core__DOT___018441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_));
    vlSelf->wasmetal_core__DOT___060048_ = (1U & (IData)(
                                                         (0xff4400000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060024_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018880_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___060047_ = (1U & ((~ (IData)(
                                                             (0xf0f335500000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf400U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O))))))))))))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ac6c849__0))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ac6c849__0)))))))))))) 
                                                  & (IData)(
                                                            (0x33ff55fff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O) 
                                                                                >> 1U))))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018880_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058594_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))))))));
    vlSelf->wasmetal_core__DOT___059821_ = (1U & (0xf0f000bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059810_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018728_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h52593617__0))))));
    vlSelf->wasmetal_core__DOT___059256_ = (1U & (IData)(
                                                         (0xee0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016501_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059219_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059218_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___018055_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059255_ = (1U & (IData)(
                                                         (0x3faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016505_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc050000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059231_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015094_)))))))))))))));
    vlSelf->wasmetal_core__DOT___019022_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019026_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1100f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h4809aef4__0))))))))));
    vlSelf->wasmetal_core__DOT___060240_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___016520_)
                                                      ? (IData)(
                                                                (0xff00ff11ff00fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___019026_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h4809aef4__0))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019026_)))));
    vlSelf->wasmetal_core__DOT___019021_ = (1U & (0xf0440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x11f00000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h4809aef4__0)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058612_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))));
    vlSelf->__VdfgTmp_h0dcf7bd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016519_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4809aef4__0))));
    vlSelf->wasmetal_core__DOT___059880_ = (1U & (IData)(
                                                         (0xfefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059869_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018775_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059881_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059868_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((0xca00U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018775_)))))))));
    vlSelf->wasmetal_core__DOT___019058_ = (1U & ((~ 
                                                   (0x35000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1c39cb98__0)))))) 
                                                  & (IData)(
                                                            (0xffff11ffffff0fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb83be1cf__0))))))));
    vlSelf->wasmetal_core__DOT___059768_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xfffff44400000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___018683_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058996_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5030f0f0f0f0f0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h842e8acf__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xff4fffU 
                                                              >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018665_))))));
    vlSelf->wasmetal_core__DOT___060205_ = (1U & ((0x4f00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060018_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134163___O) 
                                                              >> 2U)) 
                                                          | (1U 
                                                             & (0xb0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd43f4c44__0))))))) 
                                                  & (IData)(
                                                            (0xff0fff0fff00ffddULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018980_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & (((~ 
                                                                             (8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___057886_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___060166_)))) 
                                                                            & (IData)(
                                                                                (0xfffdfff0fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018677_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018985_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h787c74f0__0)))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & (((~ (IData)(vlSelf->wasmetal_core__DOT___016506_)) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___018985_)
                                                                                 ? (IData)(
                                                                                (0xffff0000ffffff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018984_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0c4afb11__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___018984_)))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xfff1ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060189_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060188_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fdf0f000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060182_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006215_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002635_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x111f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002635_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060346_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060343_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0f0335500000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058349_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127504___O) 
                                                                                >> 2U))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00bb00ff000f00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128871___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27b7e067__0))))))))))))));
    vlSelf->__VdfgTmp_h8b14a16b__0 = (((IData)(vlSelf->wasmetal_core__DOT___018258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018257_));
    vlSelf->__VdfgTmp_hebb22cad__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he029cbf7__0))))) 
                                             << 2U)) 
                                      | ((2U & ((8U 
                                                 >> (IData)(__VdfgTmp_hbcab3842__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___019084_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hbcab3842__0))))));
    vlSelf->wasmetal_core__DOT___060371_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060361_))));
    vlSelf->wasmetal_core__DOT___060370_ = (1U & (0xff4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060367_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060366_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xc0aU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058502_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128872___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059716_ = (1U & (0x3faf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059707_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018587_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf80000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                       << 3U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hd9e83ce6__0)))))))))));
    vlSelf->wasmetal_core__DOT___060023_ = (1U & (IData)(
                                                         (0xccaa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018869_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058593_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059242_))))))))))));
    vlSelf->wasmetal_core__DOT___060314_ = (1U & (0xf4000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hea1c7f12__0)))));
    vlSelf->wasmetal_core__DOT___018423_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hea1c7f12__0)))));
    vlSelf->wasmetal_core__DOT___060233_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018999_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___058613_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___059242_))))))))))));
    vlSelf->__VdfgTmp_h36195b83__0 = (((IData)(vlSelf->wasmetal_core__DOT___018999_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_));
    vlSelf->wasmetal_core__DOT___019178_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___018705_))));
    vlSelf->wasmetal_core__DOT___019144_ = (1U & (0xf0440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xe000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))));
    vlSelf->__VdfgTmp_h8574a487__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0184ff22__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xe000U 
                                                 >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___018480_ = (1U & ((4U 
                                                   >> 
                                                   ((2U 
                                                     & ((4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)
                                                           ? 
                                                          (0xf0f3355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & (((IData)(vlSelf->wasmetal_core__DOT___005713_)
                                                                        ? 
                                                                       (0xcc40U 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___018507_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___018495_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___018505_)))))
                                                                        : (IData)(
                                                                                (0xff00ff00bf103333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018507_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018495_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018505_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___018503_))))))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___018495_))))))
                                                           : 
                                                          (1U 
                                                           >> 
                                                           (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xee0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128864___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h98e96722__0))))))))))))))))))))) 
                                                  & (IData)(
                                                            (0xfffdfff00ff00ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___018492_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0xe00U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he2b184a7__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018490_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((0xff4fffU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h97bdc512__0)))))))));
    vlSelf->wasmetal_core__DOT___060439_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h472f3127__0))));
    vlSelf->__VdfgTmp_hde7231b3__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd520545b__0))))) 
                                             << 2U)) 
                                      | (((IData)(wasmetal_core__DOT___019040_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___060253_ = ((0xff4fffU 
                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                            & (IData)(wasmetal_core__DOT___019040_));
    vlSelf->wasmetal_core__DOT___060281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060268_))));
    vlSelf->wasmetal_core__DOT___060280_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___060271_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060270_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00ff00bbbb0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127517___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h787befb5__0))))))))))))));
    vlSelf->wasmetal_core__DOT___060359_ = ((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                            & (IData)(
                                                      (0xffffffba30303030ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019044_) 
                                                         << 5U) 
                                                        | (((IData)(wasmetal_core__DOT___019164_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019163_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x7fff7fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057816_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h5f7368b7__0)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xff0a3303ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                                                                >> 3U)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___018548_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca110094__0))));
    vlSelf->wasmetal_core__DOT___018971_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018633_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018962_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018629_)))))))));
    vlSelf->wasmetal_core__DOT___060373_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018632_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb9ae5421__0))))))))))));
    vlSelf->wasmetal_core__DOT___060382_ = (1U & (IData)(
                                                         (0xf000444400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018632_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h2932eeac__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->wasmetal_core__DOT___060294_ = (1U & (IData)(
                                                         (0xffffffefefefefULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xff4fffU 
                                                                >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(wasmetal_core__DOT___018324_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058656_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_hcce87b8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___018324_));
    vlSelf->__VdfgTmp_hcd2a3fe0__0 = (((IData)(wasmetal_core__DOT___018324_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059494_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016532_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016533_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059262_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059261_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059259_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059260_)))))))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___059492_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___059491_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff00000eeeeULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___016534_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059498_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059497_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd61370f8__0))))))))));
    vlSelf->wasmetal_core__DOT___059560_ = (1U & (IData)(
                                                         (0xffaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059536_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059535_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___060312_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060309_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060308_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058345_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127518___O) 
                                                                                >> 2U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf3f50000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058499_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O) 
                                                                                >> 2U))))))))))))))));
    vlSelf->wasmetal_core__DOT___059624_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018444_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xff1fU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___059605_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018055_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017462_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h75b7aca4__0))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd6ad4dda__0))))));
    vlSelf->wasmetal_core__DOT___059814_ = (1U & ((0xff4fffU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                  & (IData)(
                                                            (0xff1111f0f00000ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h0dcf7bd7__0)))));
    vlSelf->wasmetal_core__DOT___060267_ = ((IData)(vlSelf->wasmetal_core__DOT___019019_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___018382_)
                                                ? (1U 
                                                   >> 
                                                   (1U 
                                                    & ((~ 
                                                        (8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057848_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___060166_)))) 
                                                       & (IData)(
                                                                 (0x11ffffff0fffffffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___016521_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb83be1cf__0)))))))))
                                                : (0xfff10000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019060_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xff0a3303ff0fff0fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                                                                >> 2U)))))))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___019058_))))))));
    vlSelf->wasmetal_core__DOT___059484_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018266_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8b14a16b__0))))));
    vlSelf->__VdfgTmp_hbe486143__0 = (((IData)(vlSelf->wasmetal_core__DOT___019084_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018382_));
    vlSelf->wasmetal_core__DOT___019113_ = (1U & (IData)(
                                                         (0xff00101000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060314_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058660_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_h90e4968a__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h776da2e2__0))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___060314_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___018413_ = (1U & (0xfdfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018423_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016503_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_heeceee13__0))))));
    vlSelf->__VdfgTmp_h69485153__0 = (((IData)(vlSelf->wasmetal_core__DOT___018423_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___018422_)));
    vlSelf->wasmetal_core__DOT___060232_ = (1U & (IData)(
                                                         (0xbb00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019000_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060219_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h36195b83__0))))))));
    vlSelf->__VdfgTmp_ha04c1ce6__0 = (((IData)(vlSelf->wasmetal_core__DOT___019178_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0x3500U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9d72ac71__0))))))));
    vlSelf->wasmetal_core__DOT___059795_ = (1U & (IData)(
                                                         (0xfefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059785_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018695_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018697_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059796_ = (1U & (IData)(
                                                         (0xfff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059784_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018697_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058574_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->wasmetal_core__DOT___060257_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde7231b3__0))));
    vlSelf->wasmetal_core__DOT___060256_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060253_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060252_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058342_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127517___O) 
                                                                                >> 1U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128884___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha19857b4__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___060179_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060170_) 
                                                                  << 3U) 
                                                                 | ((((0xff4fffU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT___018971_)) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a828198__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059236_)))))))));
    vlSelf->__VdfgTmp_he1a5145e__0 = (((IData)(vlSelf->wasmetal_core__DOT___018971_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016500_));
    vlSelf->wasmetal_core__DOT___060386_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060373_))));
    vlSelf->wasmetal_core__DOT___060385_ = (1U & (IData)(
                                                         (0xf444ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060382_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058503_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128872___O) 
                                                                                >> 1U)))))))))))))));
    vlSelf->wasmetal_core__DOT___059742_ = (1U & (IData)(
                                                         (0xee0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018622_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5312148__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___018625_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016500_)))))))));
    vlSelf->wasmetal_core__DOT___059743_ = (1U & (IData)(
                                                         (0xfff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059733_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xff4fffU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018625_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb3aa193a__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059242_)))))))));
    vlSelf->__VdfgTmp_h48d141d4__0 = ((4U & ((0x35000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___019177_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016574_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014592_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h398f740d__0))))) 
                                             << 2U)) 
                                      | ((2U & ((8U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hcce87b8a__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___016500_)));
    vlSelf->wasmetal_core__DOT___019098_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060166_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057839_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcce87b8a__0))))));
    vlSelf->__VdfgTmp_h7ad6ad5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hcd2a3fe0__0));
    vlSelf->wasmetal_core__DOT___018412_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016500_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018424_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h69485153__0)))))));
    vlSelf->wasmetal_core__DOT___060178_ = (1U & (IData)(
                                                         (0xbb0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060162_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060156_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he1a5145e__0))))))));
    vlSelf->__VdfgTmp_h688dcf01__0 = (((IData)(vlSelf->wasmetal_core__DOT___019098_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018382_));
    vlSelf->wasmetal_core__DOT___059515_ = (1U & ((IData)(
                                                          (0xf0ff11ff00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___059505_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019194_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x111f0000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013701_)))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)) 
                                                                              & (IData)(
                                                                                (0xc0f0ddff00005555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___018274_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3835a6cf__0))))))))))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___018325_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___016506_))
                                                      : (IData)(
                                                                (0xffffff11ffffff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___016520_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016506_) 
                                                                      << 4U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h7ad6ad5d__0))))))));
    vlSelf->wasmetal_core__DOT___018418_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018412_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018411_))));
}
