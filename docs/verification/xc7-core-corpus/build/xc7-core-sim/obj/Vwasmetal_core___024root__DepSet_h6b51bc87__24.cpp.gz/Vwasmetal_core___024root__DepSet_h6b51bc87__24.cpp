#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__22(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__22\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006814_;
    wasmetal_core__DOT___006814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006815_;
    wasmetal_core__DOT___006815_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006817_;
    wasmetal_core__DOT___006817_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016172_;
    wasmetal_core__DOT___016172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016227_;
    wasmetal_core__DOT___016227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016229_;
    wasmetal_core__DOT___016229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016247_;
    wasmetal_core__DOT___016247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016261_;
    wasmetal_core__DOT___016261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016262_;
    wasmetal_core__DOT___016262_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016273_;
    wasmetal_core__DOT___016273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016274_;
    wasmetal_core__DOT___016274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016281_;
    wasmetal_core__DOT___016281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016311_;
    wasmetal_core__DOT___016311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016312_;
    wasmetal_core__DOT___016312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016314_;
    wasmetal_core__DOT___016314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016358_;
    wasmetal_core__DOT___016358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016368_;
    wasmetal_core__DOT___016368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016385_;
    wasmetal_core__DOT___016385_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016488_;
    wasmetal_core__DOT___016488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016489_;
    wasmetal_core__DOT___016489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016490_;
    wasmetal_core__DOT___016490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022709_;
    wasmetal_core__DOT___022709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043038_;
    wasmetal_core__DOT___043038_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043042_;
    wasmetal_core__DOT___043042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045276_;
    wasmetal_core__DOT___045276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045277_;
    wasmetal_core__DOT___045277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045278_;
    wasmetal_core__DOT___045278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045300_;
    wasmetal_core__DOT___045300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045301_;
    wasmetal_core__DOT___045301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045302_;
    wasmetal_core__DOT___045302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045480_;
    wasmetal_core__DOT___045480_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045481_;
    wasmetal_core__DOT___045481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045482_;
    wasmetal_core__DOT___045482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045504_;
    wasmetal_core__DOT___045504_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045505_;
    wasmetal_core__DOT___045505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045506_;
    wasmetal_core__DOT___045506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___046641_;
    wasmetal_core__DOT___046641_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054468_;
    wasmetal_core__DOT___054468_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___054472_;
    wasmetal_core__DOT___054472_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057774_;
    wasmetal_core__DOT___057774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058429_;
    wasmetal_core__DOT___058429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058431_;
    wasmetal_core__DOT___058431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058442_;
    wasmetal_core__DOT___058442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058446_;
    wasmetal_core__DOT___058446_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058476_;
    wasmetal_core__DOT___058476_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058481_;
    wasmetal_core__DOT___058481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058482_;
    wasmetal_core__DOT___058482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058495_;
    wasmetal_core__DOT___058495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058536_;
    wasmetal_core__DOT___058536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058537_;
    wasmetal_core__DOT___058537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058544_;
    wasmetal_core__DOT___058544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058713_;
    wasmetal_core__DOT___058713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058735_;
    wasmetal_core__DOT___058735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058844_;
    wasmetal_core__DOT___058844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059104_;
    wasmetal_core__DOT___059104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059127_;
    wasmetal_core__DOT___059127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059133_;
    wasmetal_core__DOT___059133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059180_;
    wasmetal_core__DOT___059180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059181_;
    wasmetal_core__DOT___059181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059190_;
    wasmetal_core__DOT___059190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059194_;
    wasmetal_core__DOT___059194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059195_;
    wasmetal_core__DOT___059195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059977_;
    wasmetal_core__DOT___059977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062998_;
    wasmetal_core__DOT___062998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062999_;
    wasmetal_core__DOT___062999_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127476___O;
    wasmetal_core__DOT____Vcellout___127476___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hb9735979__0;
    __VdfgTmp_hb9735979__0 = 0;
    CData/*1:0*/ __VdfgTmp_haf03c95c__0;
    __VdfgTmp_haf03c95c__0 = 0;
    CData/*3:0*/ __VdfgTmp_hf7f66e14__0;
    __VdfgTmp_hf7f66e14__0 = 0;
    CData/*1:0*/ __VdfgTmp_h103fe912__0;
    __VdfgTmp_h103fe912__0 = 0;
    CData/*2:0*/ __VdfgTmp_h27477f57__0;
    __VdfgTmp_h27477f57__0 = 0;
    CData/*1:0*/ __VdfgTmp_h88996eeb__0;
    __VdfgTmp_h88996eeb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9b9f3ff__0;
    __VdfgTmp_hc9b9f3ff__0 = 0;
    CData/*4:0*/ __VdfgTmp_h7386a859__0;
    __VdfgTmp_h7386a859__0 = 0;
    CData/*2:0*/ __VdfgTmp_h352b51f3__0;
    __VdfgTmp_h352b51f3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3d212b86__0;
    __VdfgTmp_h3d212b86__0 = 0;
    CData/*4:0*/ __VdfgTmp_hcfc69af2__0;
    __VdfgTmp_hcfc69af2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h19f5d4dc__0;
    __VdfgTmp_h19f5d4dc__0 = 0;
    CData/*4:0*/ __VdfgTmp_hdfa5ed14__0;
    __VdfgTmp_hdfa5ed14__0 = 0;
    CData/*1:0*/ __VdfgTmp_h84de2564__0;
    __VdfgTmp_h84de2564__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4c4dfcd4__0;
    __VdfgTmp_h4c4dfcd4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hafce6df8__0;
    __VdfgTmp_hafce6df8__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha692919d__0;
    __VdfgTmp_ha692919d__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6980ace__0;
    __VdfgTmp_he6980ace__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2de7cdff__0;
    __VdfgTmp_h2de7cdff__0 = 0;
    CData/*3:0*/ __VdfgTmp_h4fc19847__0;
    __VdfgTmp_h4fc19847__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9598b43__0;
    __VdfgTmp_hf9598b43__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbced8ce8__0;
    __VdfgTmp_hbced8ce8__0 = 0;
    CData/*3:0*/ __VdfgTmp_h1b5253bd__0;
    __VdfgTmp_h1b5253bd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb7173042__0;
    __VdfgTmp_hb7173042__0 = 0;
    CData/*3:0*/ __VdfgTmp_hbbab100a__0;
    __VdfgTmp_hbbab100a__0 = 0;
    CData/*3:0*/ __VdfgTmp_h90b76d4b__0;
    __VdfgTmp_h90b76d4b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8c714845__0;
    __VdfgTmp_h8c714845__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5bac664e__0;
    __VdfgTmp_h5bac664e__0 = 0;
    CData/*2:0*/ __VdfgTmp_h84b4ffe6__0;
    __VdfgTmp_h84b4ffe6__0 = 0;
    CData/*5:0*/ __VdfgTmp_h7bed2ca0__0;
    __VdfgTmp_h7bed2ca0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c980b03__0;
    __VdfgTmp_h9c980b03__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___027100_ = ((IData)(vlSelf->wasmetal_core__DOT___027165_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d));
    wasmetal_core__DOT___045482_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045506_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071382_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071381_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071380_))))))));
    wasmetal_core__DOT___045278_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((4U 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045302_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071445_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071444_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071443_))))))));
    wasmetal_core__DOT___045480_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071374_))))))));
    wasmetal_core__DOT___045504_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071376_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071375_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071374_)))))))));
    wasmetal_core__DOT___045481_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071377_))))))));
    wasmetal_core__DOT___045505_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071379_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071378_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071377_)))))))));
    wasmetal_core__DOT___045276_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071437_))))))));
    wasmetal_core__DOT___045300_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071439_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071438_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071437_)))))))));
    wasmetal_core__DOT___045277_ = (1U & (IData)((0xfea8ea80ea80ea80ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((0xcU 
                                                          & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071440_))))))));
    wasmetal_core__DOT___045301_ = (1U & (IData)((0x66006600000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071442_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071441_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & VL_SHIFTR_III(32,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127874___CO), 3U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___071440_)))))))));
    vlSelf->wasmetal_core__DOT___044960_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___044936_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070837_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054389_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070836_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127926___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026965_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026964_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026963_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026962_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026896_)))));
    vlSelf->wasmetal_core__DOT___026900_ = ((IData)(vlSelf->wasmetal_core__DOT___026965_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___072262_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052690_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052689_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127909___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h877e6c65__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h218f194f__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026761_)))));
    vlSelf->wasmetal_core__DOT___026765_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h877e6c65__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128253___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030249_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030248_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030247_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030246_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030181_)))));
    vlSelf->wasmetal_core__DOT___030185_ = ((IData)(vlSelf->wasmetal_core__DOT___030249_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d));
    vlSelf->wasmetal_core__DOT___044867_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)))))))))));
    vlSelf->wasmetal_core__DOT___044891_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3d4d4e87__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d))))))));
    vlSelf->__VdfgTmp_h93b91d72__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027427_));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027363_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b37__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127442___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022477_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022476_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022532_)))));
    vlSelf->wasmetal_core__DOT___022536_ = ((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___022709_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022713_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___022713_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127460___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022713_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022700_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022699_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022698_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022705_)))));
    wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023759_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d));
    wasmetal_core__DOT___058844_ = (1U & (0xf8U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                                       >> 3U)))))));
    vlSelf->__VdfgTmp_hfcfdf45d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_));
    vlSelf->__VdfgTmp_h43b7a5ac__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_hf7bb201a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_h2307c8f1__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127615___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023895_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024022_;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__;
    }
    __VdfgTmp_h3d212b86__0 = (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016219_));
    __VdfgTmp_h19f5d4dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___006889_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006888_));
    __VdfgTmp_haf03c95c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016232_));
    __VdfgTmp_h88996eeb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016255_));
    __VdfgTmp_h84de2564__0 = (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                               << 1U) | (1U & (IData)(
                                                      (0xf5f3f0f000000000ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))));
    __VdfgTmp_hc9b9f3ff__0 = ((2U & ((IData)((0xf5f3f0f0ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___006887_));
    vlSelf->wasmetal_core__DOT___017945_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048950_))));
    vlSelf->wasmetal_core__DOT___014612_ = (1U & (0xf0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017896_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___058544_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017895_))));
    vlSelf->wasmetal_core__DOT___052585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___051319_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017895_)))));
    __VdfgTmp_hb9735979__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                     << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                 << 2U) 
                                                | ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017896_))));
    vlSelf->wasmetal_core__DOT___058438_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058494_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0x4fU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))))))));
    vlSelf->wasmetal_core__DOT___058492_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    & (0x700000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))))));
    vlSelf->wasmetal_core__DOT___058468_ = ((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                            & (IData)(
                                                      (0xfff0fff0ffff4444ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016255_)))))))));
    wasmetal_core__DOT___016281_ = (1U & ((~ (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 2U) 
                                              & (IData)(
                                                        (0xb000000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                           << 5U) 
                                                          | ((0x10U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                 << 4U)) 
                                                             | ((8U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))))) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006829_)
                                              ? (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))
                                              : (0xfcfaU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006942_))))))));
    vlSelf->wasmetal_core__DOT___016313_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006891_))));
    vlSelf->wasmetal_core__DOT___016301_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h363b6dc6__0)))));
    vlSelf->wasmetal_core__DOT___016242_ = (1U & (0xa0003U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___016222_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    wasmetal_core__DOT___016311_ = (1U & (0x55fcU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0xf5f3f0f0ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006889_))))));
    wasmetal_core__DOT___016314_ = (1U & (IData)((0xaa00ff0f0f0c0cULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016257_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016258_)))))))));
    vlSelf->wasmetal_core__DOT___016220_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016288_)))))))));
    vlSelf->wasmetal_core__DOT___016302_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016232_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006890_)))))));
    vlSelf->wasmetal_core__DOT___016248_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016188_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf5f3f0f000000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016191_)))))));
    wasmetal_core__DOT___016229_ = (1U & (0x70000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | ((8U 
                                                  & ((0x4fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                     << 3U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h96af251d__0))))));
    wasmetal_core__DOT___016262_ = (1U & (0xf0faaccU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058425_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016289_)))))));
    wasmetal_core__DOT___016261_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h04c27d81__0))))))));
    vlSelf->wasmetal_core__DOT___016240_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006942_)))))))));
    wasmetal_core__DOT___016274_ = (1U & (IData)((0xf0faaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016290_)))))))));
    wasmetal_core__DOT___006815_ = (1U & (IData)((0x111111110000ff0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016377_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016376_)))))))));
    vlSelf->wasmetal_core__DOT___016241_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    vlSelf->wasmetal_core__DOT___016221_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h04c27d81__0)))));
    wasmetal_core__DOT___016273_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006829_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006942_))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006941_)))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                               ? (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___006943_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___006947_))));
    wasmetal_core__DOT___016247_ = (1U & (0xf0f000eeU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006829_)))))));
    wasmetal_core__DOT___016227_ = (1U & (IData)((0xaaaacccc000f000fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016376_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016375_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___016171_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058424_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016256_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h161c803b__0))))))));
    vlSelf->wasmetal_core__DOT___005689_ = (1U & ((1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))
                                                   ? 
                                                  (0x331030U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))))))
                                                   : (IData)(
                                                             (0x3000f0002000a00ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))))))));
    wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022804_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))));
    vlSelf->wasmetal_core__DOT___022809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    wasmetal_core__DOT___059127_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))))));
    vlSelf->wasmetal_core__DOT___022807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))))));
    wasmetal_core__DOT___059104_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059089_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059088_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)))))))))));
    wasmetal_core__DOT___059195_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059191_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)))))))))));
    vlSelf->wasmetal_core__DOT___022806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059180_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))))));
    wasmetal_core__DOT___059190_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128641___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034320_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034319_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034318_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034317_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034379_)))));
    vlSelf->wasmetal_core__DOT___034384_ = ((IData)(vlSelf->wasmetal_core__DOT___034320_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033447_));
    vlSelf->wasmetal_core__DOT____Vcellout___127565___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003809_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006400_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023475_)))));
    vlSelf->wasmetal_core__DOT___023479_ = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127582___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013712_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0db23397__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023596_)))));
    vlSelf->wasmetal_core__DOT___023600_ = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071297_))));
    vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026697_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026630_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___054402_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054404_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054400_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027167_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027100_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d));
    vlSelf->wasmetal_core__DOT___045469_ = ((IData)(vlSelf->wasmetal_core__DOT___045515_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045514_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045512_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045511_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045510_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045509_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045508_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045507_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045506_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045505_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045504_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045503_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045523_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045522_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045521_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045520_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045519_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045518_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045517_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045516_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045513_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045502_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045478_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045489_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045492_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045493_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045494_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045495_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045496_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045497_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045498_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045499_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045479_))
                                                          : (IData)(wasmetal_core__DOT___045480_))
                                                         : (IData)(wasmetal_core__DOT___045481_))
                                                        : (IData)(wasmetal_core__DOT___045482_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045483_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045484_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045485_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045486_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045487_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045488_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045490_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045491_));
    vlSelf->wasmetal_core__DOT___045265_ = ((IData)(vlSelf->wasmetal_core__DOT___045311_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045310_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045308_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045307_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045306_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045305_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045304_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045303_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___045302_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___045301_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___045300_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045299_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045319_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045318_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045317_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045316_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045315_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045314_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045313_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045312_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045309_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045298_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045274_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045285_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045288_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045289_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045290_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045291_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045292_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045293_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045294_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045295_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045275_))
                                                          : (IData)(wasmetal_core__DOT___045276_))
                                                         : (IData)(wasmetal_core__DOT___045277_))
                                                        : (IData)(wasmetal_core__DOT___045278_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045279_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045280_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045281_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045282_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045283_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045284_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045286_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045287_));
    vlSelf->wasmetal_core__DOT___054401_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054403_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054397_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026967_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026900_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___045863_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                  << 3U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc8d209ec__0))))));
    vlSelf->wasmetal_core__DOT___045887_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004388_)))))))));
    vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026765_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034486_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030250_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030185_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d));
    vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027364_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b38__05d));
    vlSelf->__VdfgTmp_h85d5ffaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h85c84d1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h850cecd0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)));
    vlSelf->wasmetal_core__DOT___023199_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022476_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O))))));
    vlSelf->wasmetal_core__DOT___023197_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022478_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023196_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022479_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 3U))))));
    vlSelf->__VdfgTmp_h85009285__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022536_));
    vlSelf->wasmetal_core__DOT____Vcellout___127461___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                 ? (IData)(wasmetal_core__DOT___022709_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)) 
               << 1U) | (IData)(wasmetal_core__DOT___022709_)));
    vlSelf->wasmetal_core__DOT___043037_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043041_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                             >> 1U))))))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127597___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023757_)))) 
           ^ (((IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023693_)))));
    vlSelf->wasmetal_core__DOT___023697_ = ((IData)(vlSelf->wasmetal_core__DOT___023760_)
                                             ? (IData)(wasmetal_core__DOT___127597___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d));
    vlSelf->wasmetal_core__DOT___017451_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058845_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005955_)))))))));
    vlSelf->wasmetal_core__DOT___058899_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))))));
    vlSelf->wasmetal_core__DOT___023765_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    vlSelf->wasmetal_core__DOT___058873_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d))));
    wasmetal_core__DOT___058713_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0))))));
    vlSelf->wasmetal_core__DOT___023764_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d))));
    vlSelf->wasmetal_core__DOT___058898_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0))))))));
    vlSelf->wasmetal_core__DOT___058752_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058741_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)))))))))));
    vlSelf->wasmetal_core__DOT___023762_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d))));
    vlSelf->wasmetal_core__DOT___058897_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0))))))));
    wasmetal_core__DOT___058735_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058730_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058729_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127631___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___023761_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d))));
    wasmetal_core__DOT___006814_ = (1U & (IData)((0x11111111f0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_haf03c95c__0))))))));
    __VdfgTmp_h352b51f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                               << 2U) | (IData)(__VdfgTmp_h88996eeb__0));
    if (vlSelf->wasmetal_core__DOT___006891_) {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016190_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf5f3f0f000000000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h934029c5__0))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016188_))))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006887_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf5f3f0f0ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h934029c5__0)))))))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x450fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016256_))))));
    } else {
        vlSelf->wasmetal_core__DOT___016173_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016191_)))));
        vlSelf->wasmetal_core__DOT___006816_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006889_)))));
        vlSelf->wasmetal_core__DOT___016249_ = (1U 
                                                & (0x32ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h352b51f3__0))));
    }
    wasmetal_core__DOT___016172_ = (1U & (0x302fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h88996eeb__0)))));
    vlSelf->wasmetal_core__DOT___016277_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016192_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h84de2564__0))))));
    vlSelf->wasmetal_core__DOT___016267_ = (1U & (0xee0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006890_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hc9b9f3ff__0))))));
    vlSelf->wasmetal_core__DOT___060224_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017945_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134186___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___017895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                        << 2U) | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036988_)))));
    vlSelf->wasmetal_core__DOT___036992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017895_)) 
                                                  | (IData)(wasmetal_core__DOT___134186___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___016496_ = (1U & (0x10000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 4U)) 
                                                   | (((IData)(wasmetal_core__DOT___058544_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT___016474_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058544_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005711_)))));
    vlSelf->wasmetal_core__DOT___058557_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___036996_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052585_))))));
    vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051319_)))));
    vlSelf->wasmetal_core__DOT___051320_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016255_)))));
    wasmetal_core__DOT___057774_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051319_))));
    vlSelf->wasmetal_core__DOT___005688_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 1U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___005687_ = (1U & (IData)(
                                                         (0xdf5dcc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hb9735979__0))))));
    vlSelf->wasmetal_core__DOT___058516_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058470_))));
    vlSelf->wasmetal_core__DOT___058515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058492_))));
    vlSelf->__VdfgTmp_h4af9777a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h2327e099__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058468_));
    vlSelf->wasmetal_core__DOT___058451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___016281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->__VdfgTmp_h8d40b9ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_));
    vlSelf->wasmetal_core__DOT___016357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016301_))));
    vlSelf->wasmetal_core__DOT___058441_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___058440_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006820_)))));
    vlSelf->wasmetal_core__DOT___058444_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016262_))));
    vlSelf->wasmetal_core__DOT___016250_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016261_)))
                                                : (0xf0f5533U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016262_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3d212b86__0)))))));
    vlSelf->wasmetal_core__DOT___016336_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016261_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3d212b86__0))))));
    __VdfgTmp_hafce6df8__0 = (((IData)(wasmetal_core__DOT___016261_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016262_));
    __VdfgTmp_h4c4dfcd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8655efce__0))))));
    vlSelf->wasmetal_core__DOT___058448_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016274_))));
    __VdfgTmp_hbced8ce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___006815_));
    __VdfgTmp_h7386a859__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016240_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    wasmetal_core__DOT___016312_ = (1U & (0xcdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___006888_)))));
    if (vlSelf->wasmetal_core__DOT___006818_) {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h3d212b86__0))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006889_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_hc9b9f3ff__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016273_))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016312_));
    } else {
        vlSelf->wasmetal_core__DOT___016315_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h84de2564__0)))));
        vlSelf->wasmetal_core__DOT___016228_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006891_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___006890_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(__VdfgTmp_haf03c95c__0))));
        vlSelf->wasmetal_core__DOT___016268_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___016274_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h19f5d4dc__0))))));
        vlSelf->wasmetal_core__DOT___016300_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006820_)) 
                                                & (IData)(wasmetal_core__DOT___016311_));
    }
    vlSelf->wasmetal_core__DOT___016348_ = (1U & (IData)(
                                                         (0xff00aaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h3d212b86__0))))))));
    vlSelf->__VdfgTmp_hb91597d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016220_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016219_)))));
    vlSelf->wasmetal_core__DOT___016342_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___016273_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h19f5d4dc__0))))));
    __VdfgTmp_he6980ace__0 = (((IData)(wasmetal_core__DOT___016273_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016274_));
    __VdfgTmp_h8c714845__0 = (((IData)(wasmetal_core__DOT___016314_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___016247_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016313_)));
    vlSelf->__VdfgTmp_hf4bdf179__0 = (((IData)(wasmetal_core__DOT___016247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    vlSelf->__VdfgTmp_hce0a7704__0 = (((IData)(wasmetal_core__DOT___016314_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h64b5570f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016247_));
    vlSelf->__VdfgTmp_h31cd2dad__0 = (((IData)(wasmetal_core__DOT___016227_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006818_));
    __VdfgTmp_hb7173042__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 1U) | (IData)(wasmetal_core__DOT___016227_));
    vlSelf->wasmetal_core__DOT____Vcellout___127475___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022804_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022803_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022802_)))) 
           ^ (((IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022770_)))));
    vlSelf->wasmetal_core__DOT___022774_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022805_)
                                                   ? (IData)(wasmetal_core__DOT___127475___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))));
    wasmetal_core__DOT___059133_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059127_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059126_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127494___O) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)))))))))));
    vlSelf->wasmetal_core__DOT___059163_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059105_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059104_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127487___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127489___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbed85956__0))))))))))))));
    wasmetal_core__DOT___059181_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059180_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059179_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)))))))))));
    wasmetal_core__DOT___059194_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___059190_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059189_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)))))))))));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034321_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034384_));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050111_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127563___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005855_))))));
    vlSelf->wasmetal_core__DOT___050095_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003809_))))));
    vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023479_));
    vlSelf->wasmetal_core__DOT___013826_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002034_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002030_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___013761_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___013756_ = (1U & (IData)(
                                                         (0x111511151115333fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002027_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127582___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023600_));
    vlSelf->wasmetal_core__DOT___071299_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071298_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d)))))))));
    wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026698_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT___070737_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027168_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d));
    vlSelf->__VdfgTmp_hf5578d4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___045469_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___045321_));
    vlSelf->wasmetal_core__DOT___062972_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___062970_)))))));
    __VdfgTmp_h103fe912__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044280_));
    vlSelf->wasmetal_core__DOT___052691_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052644_))));
    __VdfgTmp_hf7f66e14__0 = (((IData)(vlSelf->wasmetal_core__DOT___045265_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)));
    vlSelf->wasmetal_core__DOT___070840_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135428___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046636_)))));
    wasmetal_core__DOT___046641_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128657___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034487_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034540_)))));
    vlSelf->wasmetal_core__DOT___034545_ = ((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030251_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d));
    wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127960___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027365_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027364_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027363_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027362_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027296_)))));
    vlSelf->wasmetal_core__DOT___027300_ = ((IData)(vlSelf->wasmetal_core__DOT___027365_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b39__05d));
    vlSelf->__VdfgTmp_haeb15d33__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h85009285__0)));
    vlSelf->__VdfgTmp_hbca1455c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h85009285__0)))));
    wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022481_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___051266_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))))));
    vlSelf->wasmetal_core__DOT___024134_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___002961_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                         >> 3U)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d;
        vlSelf->wasmetal_core__DOT___023899_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023899_ = vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___058724_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058714_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058713_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)))))))))));
    vlSelf->wasmetal_core__DOT___058751_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058736_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058735_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023697_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d));
    vlSelf->__VdfgTmp_h94e3de73__0 = (((IData)(wasmetal_core__DOT___006815_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___006814_));
    vlSelf->wasmetal_core__DOT___058489_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & (IData)(
                                                      (0xcdf0000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h352b51f3__0)))))));
    vlSelf->__VdfgTmp_h8cd41eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016172_));
    vlSelf->__VdfgTmp_h10570a51__0 = (((IData)(wasmetal_core__DOT___016172_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016171_));
    vlSelf->wasmetal_core__DOT___058469_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___006814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006818_)))));
    vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036992_)));
    vlSelf->wasmetal_core__DOT___060165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058557_))));
    vlSelf->wasmetal_core__DOT___018964_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                           << 5U)) 
                                                                       | ((0x1cU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                              << 1U)) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___058544_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036996_)))))));
    vlSelf->wasmetal_core__DOT___057797_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017831_))));
    vlSelf->wasmetal_core__DOT___017141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017849_))));
    vlSelf->wasmetal_core__DOT___057784_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016258_))));
    vlSelf->wasmetal_core__DOT___057776_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017829_))));
    vlSelf->wasmetal_core__DOT___017017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017821_))));
    vlSelf->wasmetal_core__DOT___057811_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0))))));
    vlSelf->wasmetal_core__DOT___057794_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017910_))));
    vlSelf->wasmetal_core__DOT___057816_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8599270c__0))))));
    vlSelf->wasmetal_core__DOT___057821_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017874_))));
    vlSelf->wasmetal_core__DOT___057863_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xefU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))))));
    vlSelf->wasmetal_core__DOT___057866_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017887_))));
    vlSelf->wasmetal_core__DOT___057872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017888_))));
    vlSelf->wasmetal_core__DOT___017113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057877_))));
    vlSelf->wasmetal_core__DOT___057839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057838_))));
    vlSelf->wasmetal_core__DOT___057854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006947_))));
    vlSelf->wasmetal_core__DOT___057844_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006941_))));
    vlSelf->wasmetal_core__DOT___057848_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006943_))));
    vlSelf->wasmetal_core__DOT___057882_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006942_))));
    vlSelf->wasmetal_core__DOT___057892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016288_))));
    vlSelf->wasmetal_core__DOT___057895_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016290_))));
    vlSelf->wasmetal_core__DOT___057886_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___057774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016289_))));
    vlSelf->wasmetal_core__DOT___057924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057774_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058516_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058515_))));
    vlSelf->__VdfgTmp_h307b9eba__0 = (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)))))));
    vlSelf->wasmetal_core__DOT___058487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2327e099__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006819_)))));
    vlSelf->wasmetal_core__DOT___058445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016392_ = (1U & (IData)(
                                                         (0xf5f0f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hafce6df8__0))))))));
    vlSelf->wasmetal_core__DOT___058455_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->wasmetal_core__DOT___016316_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hafce6df8__0)))));
    vlSelf->__VdfgTmp_hecea8d31__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h4c4dfcd4__0)));
    vlSelf->wasmetal_core__DOT___016299_ = (1U & (0x110f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h4c4dfcd4__0)))));
    vlSelf->wasmetal_core__DOT___058449_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006820_))));
    vlSelf->wasmetal_core__DOT___016331_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h7386a859__0)))));
    vlSelf->wasmetal_core__DOT___016354_ = ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                ? (IData)(wasmetal_core__DOT___016312_)
                                                : (IData)(wasmetal_core__DOT___016311_)));
    vlSelf->wasmetal_core__DOT___016328_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb91597d0__0)))));
    vlSelf->wasmetal_core__DOT___058502_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___006814_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbced8ce8__0)))));
    vlSelf->wasmetal_core__DOT___016325_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_he6980ace__0)))));
    vlSelf->__VdfgTmp_h0d217f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he6980ace__0)));
    vlSelf->wasmetal_core__DOT___058511_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0x33aa0f0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->wasmetal_core__DOT___058475_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0x3300aa000f0000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h8c714845__0)))))));
    vlSelf->__VdfgTmp_h6fab7a0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce0a7704__0));
    if (vlSelf->wasmetal_core__DOT___006820_) {
        vlSelf->wasmetal_core__DOT___016278_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___016281_)));
        vlSelf->wasmetal_core__DOT___058456_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_)))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___016278_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006818_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016219_))))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006891_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016191_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___016190_))))));
        vlSelf->wasmetal_core__DOT___058456_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   & (0x53U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0)))));
    }
    vlSelf->__VdfgTmp_h76f112be__0 = (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h64b5570f__0));
    vlSelf->wasmetal_core__DOT___058427_ = (1U & ((~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                        ? 
                                                       (2U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___016242_))
                                                        : 
                                                       (0xf0fff11U 
                                                        >> (IData)(__VdfgTmp_h7386a859__0))))) 
                                                  & (IData)(
                                                            (0xfff0fff0ff00ffddULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))))))));
    vlSelf->wasmetal_core__DOT___058463_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016228_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hb7173042__0))))))));
    vlSelf->__VdfgTmp_h4bc72baa__0 = (((IData)(wasmetal_core__DOT___016229_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    vlSelf->__VdfgTmp_hdd3525a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                       << 2U) | (IData)(__VdfgTmp_hb7173042__0));
    vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022806_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022774_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hd540c232__0))));
    vlSelf->wasmetal_core__DOT___059164_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059135_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059134_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059133_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127492___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O)) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059188_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059182_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059181_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)))))))))));
    vlSelf->wasmetal_core__DOT___059199_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059195_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059194_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059193_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h607e9020__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0)))))))))));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034322_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___045029_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045005_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054193_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071297_))))));
    wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026699_)
            ? (IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___070739_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070738_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027169_)
            ? (IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d));
    vlSelf->wasmetal_core__DOT___053595_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052578_)))))))));
    vlSelf->wasmetal_core__DOT___052707_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5578d4c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052703_))));
    vlSelf->wasmetal_core__DOT___054475_ = (1U & (IData)(
                                                         (0x3000a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->insn_valid) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->done) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_h103fe912__0)))))))))));
    wasmetal_core__DOT___062998_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((1U 
                                                         >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))));
    vlSelf->wasmetal_core__DOT___053593_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    wasmetal_core__DOT___054468_ = (1U & (0x10U >> 
                                          ((4U & ((1U 
                                                   >> (IData)(__VdfgTmp_h103fe912__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052644_)))));
    vlSelf->wasmetal_core__DOT___019774_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h103fe912__0))))));
    vlSelf->wasmetal_core__DOT___053594_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))))));
    vlSelf->wasmetal_core__DOT___052692_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052691_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___044280_)))))));
    vlSelf->wasmetal_core__DOT___070842_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070841_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026969_)
            ? (IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h483290db__0)))
            ? (IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___030258_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))))));
    vlSelf->wasmetal_core__DOT___030257_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___030256_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))))));
    vlSelf->wasmetal_core__DOT___030255_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135428___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))))));
    wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___046641_));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034488_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034545_));
    wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030252_)
            ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127976___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
           ^ (((IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127976___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027427_)))));
    vlSelf->wasmetal_core__DOT___027431_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127976___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063300_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063302_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063304_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063306_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128369___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128457___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027367_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027300_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b40__05d));
    vlSelf->wasmetal_core__DOT___023198_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0)))
                                                   : 
                                                  (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0))));
    wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022482_) 
           & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127635___O 
        = ((6U | (IData)(vlSelf->wasmetal_core__DOT___024134_)) 
           ^ (0xeU & ((- (IData)((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___024134_))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___014610_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___002961_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))))));
    vlSelf->wasmetal_core__DOT___000132_ = ((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                            & (IData)(
                                                      (0x7fffffffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h15b2e0c0__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127632___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024022_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024026_ = vlSelf->wasmetal_core__DOT___127632___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023899_;
    }
    wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127616___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127616___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023895_)))));
    __VdfgTmp_h84b4ffe6__0 = (((IData)(vlSelf->wasmetal_core__DOT___006816_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    __VdfgTmp_hcfc69af2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))));
    __VdfgTmp_ha692919d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h94e3de73__0));
    vlSelf->wasmetal_core__DOT___058514_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058489_))));
    vlSelf->wasmetal_core__DOT___058543_ = (1U & (IData)(
                                                         (0x7fffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058489_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2327e099__0))))))));
    wasmetal_core__DOT___058495_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___016250_)) 
                                          & (IData)(
                                                    (0xff00ffeefff0fff0ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0)))))))));
    __VdfgTmp_h5bac664e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016249_));
    vlSelf->wasmetal_core__DOT___058503_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (0x3333f0f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                : (0x40U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0)))));
    __VdfgTmp_h2de7cdff__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    __VdfgTmp_hbbab100a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0)));
    __VdfgTmp_h27477f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___016173_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h10570a51__0));
    vlSelf->wasmetal_core__DOT___058488_ = (1U & (IData)(
                                                         (0xff33f0aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016342_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058448_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058469_)))))))));
    vlSelf->wasmetal_core__DOT___058471_ = (1U & (IData)(
                                                         (0xffffcc55f0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016268_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058469_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058468_)))))))));
    wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036996_)) 
                 | (IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060582_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134186___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    vlSelf->wasmetal_core__DOT___016503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018964_))));
    vlSelf->wasmetal_core__DOT___060166_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018964_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___036996_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))));
    vlSelf->wasmetal_core__DOT___058484_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf4bdf179__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016336_)))))))));
    vlSelf->wasmetal_core__DOT___016492_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058494_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___006821_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0x3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                      : 
                                                     (0xf0fafcfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___016392_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hce0a7704__0))))))));
    wasmetal_core__DOT___058476_ = (1U & (0xf100U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___016315_))))));
    wasmetal_core__DOT___016385_ = (1U & (IData)((0x11000f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))));
    wasmetal_core__DOT___058482_ = (1U & (IData)((0xf3f300fa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___016228_)))))))));
    __VdfgTmp_hf9598b43__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___016331_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016228_)));
    vlSelf->wasmetal_core__DOT___058473_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016300_))));
    vlSelf->wasmetal_core__DOT___058490_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016281_)))
                                                   : 
                                                  (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016348_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))));
    vlSelf->wasmetal_core__DOT___058491_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058489_)))));
    vlSelf->wasmetal_core__DOT___058480_ = (1U & (IData)(
                                                         (0xf3f300fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058502_))));
    vlSelf->wasmetal_core__DOT___058450_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016342_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016267_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___006814_))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hbced8ce8__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b12__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058449_))))));
    vlSelf->wasmetal_core__DOT___058477_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006816_))))));
    wasmetal_core__DOT___016368_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    wasmetal_core__DOT___006817_ = (1U & (0x5030000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h0d217f15__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058511_))));
    vlSelf->wasmetal_core__DOT___058505_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                ? (0x33a0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016315_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___016313_)))))
                                                : (0x5300U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0)))));
    wasmetal_core__DOT___058429_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                          & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                              ? (0xff00fff1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                              : (0xcdU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016250_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016249_)))))));
    vlSelf->wasmetal_core__DOT___058466_ = (1U & (IData)(
                                                         (0xf1f100ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016249_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h76f112be__0)))))));
    vlSelf->__VdfgTmp_h99986d68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058427_));
    vlSelf->__VdfgTmp_h1bc2f6b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058463_));
    vlSelf->wasmetal_core__DOT___058465_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016242_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016241_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006888_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016240_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058463_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    wasmetal_core__DOT___016488_ = (1U & (0xf4000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))));
    wasmetal_core__DOT___058481_ = (1U & (IData)((0xb00ff00ff00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0)))))));
    __VdfgTmp_h4fc19847__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_h4bc72baa__0));
    __VdfgTmp_h90b76d4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___016301_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    __VdfgTmp_h1b5253bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___016354_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_hdd3525a7__0));
    wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022807_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0))));
    vlSelf->wasmetal_core__DOT___059204_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059199_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x700000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059188_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___059187_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___059186_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___059164_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059163_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059162_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059146_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___059145_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127490___O)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127491___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5308e2ff__0)))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051507_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))))))))));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034323_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128556___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033447_)))));
    vlSelf->wasmetal_core__DOT___033451_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128556___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127877___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026700_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026699_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026698_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026697_)))) 
           ^ (((IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127877___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026630_)))));
    vlSelf->wasmetal_core__DOT___026635_ = ((IData)(vlSelf->wasmetal_core__DOT___026700_)
                                             ? (IData)(wasmetal_core__DOT___127877___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT___045233_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___045209_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070739_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070738_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127928___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027170_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027169_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027168_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027167_)))) 
           ^ (((IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127928___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027100_)))));
    vlSelf->wasmetal_core__DOT___027105_ = ((IData)(vlSelf->wasmetal_core__DOT___027170_)
                                             ? (IData)(wasmetal_core__DOT___127928___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d));
    vlSelf->wasmetal_core__DOT___053509_ = (1U & (IData)(
                                                         (0xefff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052707_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_hf7f66e14__0))))));
    wasmetal_core__DOT___062999_ = (1U & (IData)((0xf100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062966_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___062998_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h57a1bcce__0))))))));
    vlSelf->wasmetal_core__DOT___063435_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052849_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___054468_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h44c20413__0))))));
    vlSelf->wasmetal_core__DOT___054469_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___054468_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053592_))));
    vlSelf->wasmetal_core__DOT___052697_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052692_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_hf7f66e14__0))));
    vlSelf->wasmetal_core__DOT___044961_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___044937_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070842_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070841_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127911___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026970_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026969_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026968_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026967_)))) 
           ^ (((IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127911___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026900_)))));
    vlSelf->wasmetal_core__DOT___026905_ = ((IData)(vlSelf->wasmetal_core__DOT___026970_)
                                             ? (IData)(wasmetal_core__DOT___127911___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127894___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h483290db__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127894___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026765_)))));
    vlSelf->wasmetal_core__DOT___026770_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)))
                                             ? (IData)(wasmetal_core__DOT___127894___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034489_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128254___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030253_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030252_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030251_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030250_)))) 
           ^ (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128254___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030185_)))));
    vlSelf->wasmetal_core__DOT___030189_ = ((IData)(vlSelf->wasmetal_core__DOT___030253_)
                                             ? (IData)(wasmetal_core__DOT___128254___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d));
    vlSelf->wasmetal_core__DOT___044847_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)))))))))));
    vlSelf->wasmetal_core__DOT___044871_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h93b91d72__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127975___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    vlSelf->__VdfgTmp_h8c284b8e__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027431_));
    vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b41__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127428___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022480_)))) 
           ^ (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127428___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022536_)))));
    vlSelf->wasmetal_core__DOT___022541_ = ((IData)(vlSelf->wasmetal_core__DOT___022483_) 
                                            & (IData)(wasmetal_core__DOT___127428___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060213_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013805_)))));
    vlSelf->__VdfgTmp_h1b3b7d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014610_)))));
    vlSelf->wasmetal_core__DOT___057769_ = (1U & (0xccdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005683_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005681_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)) 
                                                  & (IData)(
                                                            (0x33333300f3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O) 
                                                                              >> 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___005677_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000132_)) 
                                                  & (IData)(
                                                            (0xfff3f3f7ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O) 
                                                                     << 4U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                                                >> 2U)))))))))));
    vlSelf->wasmetal_core__DOT___051268_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000131_))))));
    vlSelf->wasmetal_core__DOT___017816_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000132_))));
    __VdfgTmp_h7bed2ca0__0 = (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000131_) 
                                          << 4U) | 
                                         ((8U & ((0x4fU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                 << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                 << 1U) 
                                                | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                                      >> 2U)))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024026_;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023764_)
            ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d));
    vlSelf->__VdfgTmp_he93f6ca8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005955_));
    vlSelf->__VdfgTmp_h263b1cf5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005788_));
    vlSelf->__VdfgTmp_h7a46858f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005889_));
    vlSelf->__VdfgTmp_h0afc15e4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005795_));
    vlSelf->wasmetal_core__DOT___058506_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h84b4ffe6__0)))))));
    vlSelf->wasmetal_core__DOT___058508_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hcfc69af2__0)))));
    vlSelf->wasmetal_core__DOT___058497_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___016268_))
                                                : (0xf0f53300U 
                                                   >> (IData)(__VdfgTmp_hcfc69af2__0))));
    vlSelf->wasmetal_core__DOT___016486_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_ha692919d__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058514_))));
    vlSelf->wasmetal_core__DOT___058496_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058495_))));
    vlSelf->wasmetal_core__DOT___016491_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT___058485_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5bac664e__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058503_))));
    vlSelf->wasmetal_core__DOT___058452_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016348_)))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___016277_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___016171_))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h8cd41eba__0))))));
    vlSelf->wasmetal_core__DOT___058540_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058449_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b13__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058451_))))));
    vlSelf->wasmetal_core__DOT___016487_ = (1U & (0x53000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h2de7cdff__0)))));
    vlSelf->wasmetal_core__DOT___058472_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf0f500003300ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_hbbab100a__0))))));
    __VdfgTmp_hdfa5ed14__0 = (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                               << 4U) | (IData)(__VdfgTmp_hbbab100a__0));
    vlSelf->wasmetal_core__DOT___058459_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h27477f57__0)))))));
    wasmetal_core__DOT___016489_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                              & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                  ? 
                                                 (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___016222_))
                                                  : 
                                                 (0xf0fff11U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb91597d0__0))))) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h27477f57__0))))))));
    vlSelf->__VdfgTmp_h32c10bb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___058488_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058487_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058471_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134187___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036996_) 
                        << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)
                 ? (IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02eencode_promote__02ein__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___134187___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134187___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036992_)))));
    vlSelf->__VdfgTmp_hb0235e8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___016504_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016503_));
    vlSelf->wasmetal_core__DOT___018963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019037_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019050_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019079_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___019120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT___060393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016492_))));
    vlSelf->wasmetal_core__DOT___060014_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058476_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d 
        = (1U & (0xe1U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058476_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058475_)))));
    vlSelf->wasmetal_core__DOT___058434_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016299_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016302_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h31cd2dad__0)))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016301_)))));
    vlSelf->wasmetal_core__DOT___058499_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058434_))));
    vlSelf->__VdfgTmp_h45a50d9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058434_)));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058491_))));
    wasmetal_core__DOT___016490_ = (1U & ((~ (IData)(wasmetal_core__DOT___006817_)) 
                                          & (IData)(
                                                    (0xfff0fff0ffaaffccULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                             << 3U) 
                                                            | (IData)(__VdfgTmp_h84b4ffe6__0))))))));
    vlSelf->wasmetal_core__DOT___051562_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                      ? 
                                                     (0xcdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___006817_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                      : 
                                                     (0xf0f0f5f3U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006817_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h94e3de73__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058505_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b15__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058455_))))));
    vlSelf->wasmetal_core__DOT___058435_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016316_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016316_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___016315_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0xacU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6fab7a0a__0))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h8d40b9ee__0)))));
    vlSelf->__VdfgTmp_h9e4b4f68__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058435_));
    wasmetal_core__DOT___058446_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                               ? (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016336_)))
                                               : (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76f112be__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                              & (1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___016249_))))));
    vlSelf->wasmetal_core__DOT___058447_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058446_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058445_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->__VdfgTmp_h9aa3e645__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058466_)))));
    vlSelf->wasmetal_core__DOT___058467_ = (1U & (IData)(
                                                         (0x5505cc0cff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058466_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058444_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->__VdfgTmp_ha5a16447__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h99986d68__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058465_))));
    vlSelf->wasmetal_core__DOT___058512_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___016488_))));
    vlSelf->__VdfgTmp_h696b299a__0 = (((IData)(wasmetal_core__DOT___058481_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058482_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(wasmetal_core__DOT___058482_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058481_)))));
    vlSelf->wasmetal_core__DOT___058510_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf1f1ff0000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058474_ = ((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                            & (IData)(
                                                      (0xf1f10000ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 4U) 
                                                           | (IData)(__VdfgTmp_h90b76d4b__0))))));
    vlSelf->wasmetal_core__DOT___058493_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (2U 
                                                   >> (IData)(wasmetal_core__DOT___016385_))
                                                : (IData)(
                                                          (0xffffff00fffffff1ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                             << 5U) 
                                                            | (((IData)(wasmetal_core__DOT___016385_) 
                                                                << 4U) 
                                                               | (IData)(__VdfgTmp_h1b5253bd__0)))))));
    wasmetal_core__DOT___016358_ = (1U & (0xff00fff1U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h1b5253bd__0))));
    if (vlSelf->wasmetal_core__DOT___006819_) {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___016268_))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016325_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006816_)))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016248_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016336_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h64b5570f__0))))));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016328_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___016173_)))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006820_)
                                                    ? 
                                                   (0x32U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 2U) 
                                                     | (((IData)(wasmetal_core__DOT___016368_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___006816_))))
                                                    : 
                                                   (0xf0f0a0cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                         << 3U) 
                                                        | (((IData)(wasmetal_core__DOT___016368_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h94e3de73__0)))))));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0x32U 
                                                   >> (IData)(__VdfgTmp_hf9598b43__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xcdU 
                                                 >> (IData)(__VdfgTmp_hf9598b43__0))));
        wasmetal_core__DOT___058431_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___016278_)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(wasmetal_core__DOT___016358_));
    } else {
        vlSelf->wasmetal_core__DOT___058430_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                   & (0xf0f53300U 
                                                      >> (IData)(__VdfgTmp_hcfc69af2__0))));
        vlSelf->wasmetal_core__DOT___058436_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_ha692919d__0))));
        vlSelf->wasmetal_core__DOT___058501_ = (1U 
                                                & (0xbU 
                                                   >> (IData)(__VdfgTmp_h5bac664e__0)));
        vlSelf->wasmetal_core__DOT___058439_ = (1U 
                                                & (0xacffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                     << 3U) 
                                                    | (IData)(__VdfgTmp_h2de7cdff__0))));
        vlSelf->wasmetal_core__DOT___058457_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___016368_)));
        vlSelf->wasmetal_core__DOT___058500_ = (1U 
                                                & (0xbffU 
                                                   >> (IData)(__VdfgTmp_h4fc19847__0)));
        wasmetal_core__DOT___058442_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                              & (0xf400U 
                                                 >> (IData)(__VdfgTmp_h4fc19847__0))));
        wasmetal_core__DOT___058431_ = (1U & (0xf0accffU 
                                              >> (IData)(__VdfgTmp_hdfa5ed14__0)));
        vlSelf->wasmetal_core__DOT___058454_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006821_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___016357_));
    }
    wasmetal_core__DOT____Vcellout___127476___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___022809_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___022807_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___022806_))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___022809_)
                                                          ? (IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7695852b__0))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___127476___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127476___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022774_)))));
    vlSelf->wasmetal_core__DOT___059548_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005745_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059585_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h916673f4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___059834_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059863_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h686e5d09__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059950_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005855_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059511_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005921_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127470___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___018685_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h360b04fb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127472___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059896_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc4a2ed9e__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127473___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060008_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060038_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060062_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060087_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060107_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127475___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    wasmetal_core__DOT___059977_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((1U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059635_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hedc0f726__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059657_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbed85956__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059923_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127474___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059610_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he0f48724__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127471___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059210_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005731_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127469___O)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034324_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034323_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034322_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034321_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034384_)))));
    vlSelf->wasmetal_core__DOT___034388_ = ((IData)(vlSelf->wasmetal_core__DOT___034324_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033451_));
    vlSelf->wasmetal_core__DOT____Vcellout___127553___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006092_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005982_)))) 
           ^ (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127553___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023479_)))));
    vlSelf->wasmetal_core__DOT___023484_ = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                            & (IData)(wasmetal_core__DOT___127553___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127570___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013666_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h41b1ef3d__0))) 
           ^ (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127570___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023600_)))));
    vlSelf->wasmetal_core__DOT___023605_ = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                                            & (IData)(wasmetal_core__DOT___127570___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___071303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071302_))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026701_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026635_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___054408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054410_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027171_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027105_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d));
    vlSelf->wasmetal_core__DOT___063001_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063000_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053019_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___062999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h99cee8a1__0)))))))))));
    wasmetal_core__DOT___054472_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___054469_))));
    vlSelf->wasmetal_core__DOT___072278_ = (1U & (0xbf00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x4000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072276_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053491_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053476_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053422_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051228_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053499_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053014_))))));
    vlSelf->wasmetal_core__DOT___054407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054405_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054411_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026905_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->wasmetal_core__DOT___045865_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had3e30f3__0)))))));
    vlSelf->wasmetal_core__DOT___045864_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf21c6828__0)))))));
    vlSelf->wasmetal_core__DOT___045889_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___045888_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127894___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127909___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026770_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034490_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030255_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030189_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d));
    vlSelf->wasmetal_core__DOT___044848_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044872_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8c284b8e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127976___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d))))))));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b42__05d));
    vlSelf->__VdfgTmp_h9bddaa79__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 1U)));
    vlSelf->__VdfgTmp_h9c9f5aae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h9be9fa04__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)));
    vlSelf->wasmetal_core__DOT___023195_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022480_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O))))));
    vlSelf->wasmetal_core__DOT___023194_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___023193_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022482_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            >> 2U))))));
    __VdfgTmp_h9c980b03__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022541_));
    vlSelf->wasmetal_core__DOT___060214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060213_))));
    vlSelf->wasmetal_core__DOT___057772_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057769_))));
    vlSelf->__VdfgTmp_hff203b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___051319_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057769_));
    wasmetal_core__DOT___043038_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x4fU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___024134_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051266_)))))))));
    vlSelf->wasmetal_core__DOT___017813_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002961_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051268_)))));
    wasmetal_core__DOT___043042_ = (1U & ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))
                                           ? ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (0x104U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000132_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017895_)))))
                                               : (IData)(
                                                         (0xc000100c0003200ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))
                                           : ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127461___O))
                                               ? (IData)(
                                                         (0xc000004c00000c8ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0)))
                                               : (IData)(
                                                         (0xc000400c000c800ULL 
                                                          >> (IData)(__VdfgTmp_h7bed2ca0__0))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127617___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127598___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023765_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023764_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023762_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023761_)))) 
           ^ (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127598___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023697_)))));
    vlSelf->wasmetal_core__DOT___023702_ = ((IData)(vlSelf->wasmetal_core__DOT___023765_)
                                             ? (IData)(wasmetal_core__DOT___127598___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d));
    vlSelf->wasmetal_core__DOT___058796_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))))));
    vlSelf->wasmetal_core__DOT___023769_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he93f6ca8__0))));
    vlSelf->wasmetal_core__DOT___058807_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))))));
    vlSelf->wasmetal_core__DOT___023768_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h263b1cf5__0))));
    vlSelf->wasmetal_core__DOT___023767_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a46858f__0))));
    vlSelf->wasmetal_core__DOT___058866_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d))));
    vlSelf->wasmetal_core__DOT___058789_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127632___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))))));
    vlSelf->wasmetal_core__DOT___023766_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0afc15e4__0))));
    vlSelf->__VdfgTmp_hb5f365d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058506_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058508_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058497_))));
    vlSelf->wasmetal_core__DOT___058533_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058430_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058429_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b4__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058430_))));
    vlSelf->__VdfgTmp_h7cadd68e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016486_));
    vlSelf->wasmetal_core__DOT___058478_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058477_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->wasmetal_core__DOT___058534_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058435_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058436_))))));
    vlSelf->__VdfgTmp_hcb1f4515__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058436_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058496_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016491_))));
    vlSelf->__VdfgTmp_h0a35847a__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058501_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058484_)))));
    vlSelf->__VdfgTmp_h49fa4f4c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016487_));
    vlSelf->__VdfgTmp_h98e96722__0 = (((IData)(vlSelf->wasmetal_core__DOT___058439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006821_));
    vlSelf->__VdfgTmp_h8bfce2cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058439_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016278_))))));
    vlSelf->wasmetal_core__DOT___058509_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & (IData)(
                                                      (0xf0f5330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___006819_) 
                                                         << 5U) 
                                                        | (IData)(__VdfgTmp_hdfa5ed14__0)))));
    vlSelf->wasmetal_core__DOT___058507_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058459_))));
    vlSelf->wasmetal_core__DOT___058461_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0f0553300000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006820_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006818_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___016222_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___016221_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016219_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006891_)))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___016220_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058459_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006821_)))));
    vlSelf->__VdfgTmp_ha19857b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016489_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x1eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h32c10bb5__0))));
    vlSelf->wasmetal_core__DOT___060612_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060165_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134187___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___018964_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058499_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058457_))));
    vlSelf->wasmetal_core__DOT___016482_ = ((IData)(vlSelf->wasmetal_core__DOT___016492_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___016491_)) 
                                               & (IData)(
                                                         (0x1000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___016490_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016489_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016488_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016487_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016486_))))))))));
    vlSelf->__VdfgTmp_h718e5977__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016490_));
    vlSelf->__VdfgTmp_h15403f4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051562_));
    vlSelf->__VdfgTmp_h459e7eca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9e4b4f68__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b11__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058447_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058467_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058512_))));
    wasmetal_core__DOT___058536_ = (1U & (0xeU >> (
                                                   ((IData)(wasmetal_core__DOT___058476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058475_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h696b299a__0)))));
    vlSelf->__VdfgTmp_h27b7e067__0 = (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058500_));
    vlSelf->wasmetal_core__DOT___058542_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058446_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058445_)))))));
    vlSelf->wasmetal_core__DOT___058443_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058442_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058441_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058438_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058510_))));
    wasmetal_core__DOT___058537_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016278_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058473_))))));
    vlSelf->wasmetal_core__DOT___058538_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058490_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058492_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058489_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d 
        = (1U & (0xf40bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))));
    vlSelf->wasmetal_core__DOT___058504_ = ((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___006819_)
                                                ? (IData)(wasmetal_core__DOT___016358_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___016357_)));
    vlSelf->wasmetal_core__DOT___060134_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd540c232__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127476___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059202_)))))))));
    vlSelf->wasmetal_core__DOT___060158_ = (1U & (IData)(
                                                         (0xf0fcf0faULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5f0989ee__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060190_ = (1U & (IData)(
                                                         (0xf0fcf0fa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h7695852b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127476___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059979_ = (1U & (IData)(
                                                         (0xffff44f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___059977_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059205_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___059201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005770_)))))))));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034325_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034388_));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___049002_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005982_))));
    vlSelf->wasmetal_core__DOT___050100_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127565___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___006734_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27384d82__0)))));
    vlSelf->wasmetal_core__DOT___050093_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006092_))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023484_));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023605_));
    vlSelf->wasmetal_core__DOT___071304_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071303_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026702_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___070742_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070747_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027172_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127929___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d));
    vlSelf->wasmetal_core__DOT___022439_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128904___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022450_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128905___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022461_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128906___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128907___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022465_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128908___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022466_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128909___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022467_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128910___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022468_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128911___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022469_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128912___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022470_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128913___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022440_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128914___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022441_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128915___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022442_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128916___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022443_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128917___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022444_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128918___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022445_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128919___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022446_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128920___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022447_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128921___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022448_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128922___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022449_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128923___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022451_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128924___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022452_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128925___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022453_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128926___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022454_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128927___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022455_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128928___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022456_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128929___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022457_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128930___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022458_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128931___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022459_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128932___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022460_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128933___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022462_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128934___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___022463_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054474_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf72c75d5__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___054472_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128935___Q) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054471_)))))))));
    vlSelf->wasmetal_core__DOT___046015_ = (1U & (0xefff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072278_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053071_)))))));
    vlSelf->wasmetal_core__DOT___070845_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070850_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026972_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127912___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127895___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135429___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___046641_)))));
    vlSelf->wasmetal_core__DOT___046645_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)) 
                                            & (IData)(wasmetal_core__DOT___135429___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128658___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034488_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034545_)))));
    vlSelf->wasmetal_core__DOT___034549_ = ((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030256_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128240___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d));
    vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127960___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127977___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127945___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027370_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027369_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027367_)))) 
           ^ (((IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127945___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027300_)))));
    vlSelf->wasmetal_core__DOT___027305_ = ((IData)(vlSelf->wasmetal_core__DOT___027370_)
                                             ? (IData)(wasmetal_core__DOT___127945___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b43__05d));
    vlSelf->__VdfgTmp_hf628d2c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h9c980b03__0)));
    vlSelf->__VdfgTmp_h04d557bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006058_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_h9c980b03__0)))));
    vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022485_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127429___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017834_ = (1U & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hff203b22__0)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                      ? 
                                                     (0x355fcaaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017840_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017838_))))))
                                                      : 
                                                     (9U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002473_))))));
    vlSelf->wasmetal_core__DOT___043035_ = ((IData)(wasmetal_core__DOT___043042_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043041_)
                                                 ? 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___043040_)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___043036_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043037_))
                                             : (IData)(wasmetal_core__DOT___043038_));
    vlSelf->wasmetal_core__DOT___059072_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043041_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043040_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043042_)))));
    vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127633___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127599___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023766_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023702_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb5f365d2__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058478_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b8__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcb1f4515__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0a35847a__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))));
    vlSelf->__VdfgTmp_h963234d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058480_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0)))));
    vlSelf->wasmetal_core__DOT___058535_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h98e96722__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (0xf10eU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058440_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h8bfce2cf__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058509_))));
    vlSelf->wasmetal_core__DOT___016481_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058497_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058427_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058431_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058495_)))))));
    vlSelf->wasmetal_core__DOT___058498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT___058432_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006821_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058431_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058507_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058461_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    vlSelf->__VdfgTmp_hadae8e7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha19857b4__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h718e5977__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h27b7e067__0))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b10__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058443_))));
    vlSelf->wasmetal_core__DOT___016472_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058537_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058536_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058461_)))))))));
    vlSelf->wasmetal_core__DOT___016483_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058505_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058503_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058502_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058504_))));
    vlSelf->wasmetal_core__DOT___058541_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x11000fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b14__05d 
        = (1U & (0xf807U >> (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x11000fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0))))))));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034326_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128542___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049002_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127553___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006695_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006676_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050094_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050093_)))))))));
    vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127554___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127571___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___045030_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___045006_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071302_))))));
    vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026703_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127878___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___070744_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070743_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
}
