#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__10(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__10\n"); );
    // Body
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__callee_base__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__callee_base__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__control_base__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__result_arity__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eneg_r = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eis_rem = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___052877_) {
            vlSelf->wasmetal_core__DOT__callee_base__05b31__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b30__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b29__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b28__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b27__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b26__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b25__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b24__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b23__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b22__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b21__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b20__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b19__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b18__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b17__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b16__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b15__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b14__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b13__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b12__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b11__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b10__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b9__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b8__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b7__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b6__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b5__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b4__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b3__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b2__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b1__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__callee_base__05b0__05d 
                = (1U & (0xf088U >> (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                      << 3U) | ((4U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d))))));
        }
        if (vlSelf->wasmetal_core__DOT___019782_) {
            vlSelf->wasmetal_core__DOT__control_base__05b31__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x15U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b30__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x14U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b29__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x13U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b28__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x12U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b27__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x11U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b26__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0x10U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b25__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b24__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xfU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b23__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xeU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b22__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xdU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b21__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xcU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b20__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xbU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b19__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 0xaU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b18__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 9U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b17__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 8U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b16__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b15__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 7U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b14__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 6U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b13__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 5U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b12__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 4U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b11__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 3U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b10__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 2U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b9__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                     >> 1U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b8__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b7__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                            >> 4U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b6__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3fU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b5__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3eU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b4__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3dU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b3__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3cU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b2__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3bU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b1__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x3aU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d))))));
            vlSelf->wasmetal_core__DOT__control_base__05b0__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x39U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d))))));
        }
        if (vlSelf->wasmetal_core__DOT___019780_) {
            vlSelf->wasmetal_core__DOT__result_arity__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x1eU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x31U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x1cU)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                                    >> 5U))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x1dU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x30U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x18U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2cU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x1bU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2fU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x1aU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2eU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x19U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2dU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xfU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x24U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x17U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2bU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x16U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x2aU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x15U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x29U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x14U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x28U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x13U)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                                    >> 4U))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x12U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x27U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x11U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x26U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0x10U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x25U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b7__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 6U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1cU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xeU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x23U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xdU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x22U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xcU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x21U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xbU)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x20U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 0xaU)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 9U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1fU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 8U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1eU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 7U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1dU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b6__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 5U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1bU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b5__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 4U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x1aU)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b4__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 3U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x19U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b3__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x18U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b2__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__parity) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b1__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & vlSelf->function_results) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x17U)))))));
            vlSelf->wasmetal_core__DOT__result_arity__05b0__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                    << 2U) | ((2U & 
                                               (vlSelf->function_results 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e1.__PVT__data 
                                                            >> 0x16U)))))));
        }
        if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))) {
            vlSelf->wasmetal_core__DOT__divider__02eneg_r 
                = vlSelf->wasmetal_core__DOT__divider__02esign_a;
            vlSelf->wasmetal_core__DOT__divider__02eis_rem 
                = vlSelf->wasmetal_core__DOT__divider__02eremainder_op;
        }
    }
    vlSelf->wasmetal_core__DOT___053740_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d))));
    vlSelf->result_count = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128935___Q) 
                             << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128934___Q) 
                                           << 0x1eU) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128933___Q) 
                                              << 0x1dU) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128932___Q) 
                                                 << 0x1cU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128931___Q) 
                                                    << 0x1bU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128930___Q) 
                                                       << 0x1aU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128929___Q) 
                                                          << 0x19U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128928___Q) 
                                                             << 0x18U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128927___Q) 
                                                                << 0x17U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128926___Q) 
                                                                   << 0x16U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128925___Q) 
                                                                      << 0x15U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128924___Q) 
                                                                         << 0x14U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128923___Q) 
                                                                            << 0x13U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128922___Q) 
                                                                               << 0x12U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128921___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128920___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128919___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128918___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128917___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128916___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128915___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128914___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128913___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128912___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128911___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128910___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128909___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128908___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128907___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128906___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128905___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128904___Q))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h2f7c3620__0 = (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)));
    vlSelf->__VdfgTmp_hf90c45d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d));
    vlSelf->wasmetal_core__DOT___052872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__check_type) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->type_matches))));
    vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d));
    vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d));
    vlSelf->__VdfgTmp_heb1fb9b9__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d));
    vlSelf->wasmetal_core__DOT___053739_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d))));
    vlSelf->wasmetal_core__DOT___053742_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d))));
    vlSelf->__VdfgTmp_he3290929__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d));
    vlSelf->wasmetal_core__DOT___044214_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)))))))));
    vlSelf->__VdfgTmp_ha5b552f8__0 = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d));
    vlSelf->__VdfgTmp_h63180e3e__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d))));
    vlSelf->wasmetal_core__DOT___053745_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d))));
    vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___052934_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___029245_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d))));
    vlSelf->wasmetal_core__DOT___065583_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045609_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___052942_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d))));
    vlSelf->wasmetal_core__DOT___052930_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026189_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d))));
    vlSelf->wasmetal_core__DOT___045608_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045607_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044210_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d));
    vlSelf->wasmetal_core__DOT___044209_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d));
    vlSelf->wasmetal_core__DOT___052944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___052929_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d))));
    vlSelf->wasmetal_core__DOT___029244_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d))));
    vlSelf->wasmetal_core__DOT___026188_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__frames_memory__02e0__02e0__ADDRBWRADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d) 
                       << 0xeU) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                    << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                                                 << 0xcU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                                    << 0xbU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) 
                                                       << 0xaU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                                          << 9U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) 
                                                             << 8U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d) 
                                                                << 7U) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                                                  << 6U))))))))));
    vlSelf->__VdfgTmp_h5a9aeb48__0 = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d));
    vlSelf->wasmetal_core__DOT___052924_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d))))))))))));
    vlSelf->wasmetal_core__DOT___045606_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045605_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045604_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___029242_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d))));
    vlSelf->wasmetal_core__DOT___026186_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d))));
    vlSelf->wasmetal_core__DOT___052954_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d))));
    vlSelf->wasmetal_core__DOT___052921_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___029241_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026185_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d))));
    vlSelf->wasmetal_core__DOT___052928_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___029240_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d))));
    vlSelf->wasmetal_core__DOT___026184_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d))));
    vlSelf->wasmetal_core__DOT___052932_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052931_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d));
    if (vlSelf->wasmetal_core__DOT___019810_) {
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b3__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT__simd_integer__02erunning) {
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b96__05d 
            = vlSelf->wasmetal_core__DOT___021216_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b93__05d 
            = vlSelf->wasmetal_core__DOT___021213_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b92__05d 
            = vlSelf->wasmetal_core__DOT___021212_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b91__05d 
            = vlSelf->wasmetal_core__DOT___021211_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b90__05d 
            = vlSelf->wasmetal_core__DOT___021210_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b88__05d 
            = vlSelf->wasmetal_core__DOT___021207_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b80__05d 
            = vlSelf->wasmetal_core__DOT___021199_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b78__05d 
            = vlSelf->wasmetal_core__DOT___021196_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b75__05d 
            = vlSelf->wasmetal_core__DOT___021193_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b72__05d 
            = vlSelf->wasmetal_core__DOT___021190_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b110__05d 
            = vlSelf->wasmetal_core__DOT___021113_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b109__05d 
            = vlSelf->wasmetal_core__DOT___021111_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b108__05d 
            = vlSelf->wasmetal_core__DOT___021110_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b104__05d 
            = vlSelf->wasmetal_core__DOT___021106_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b77__05d 
            = vlSelf->wasmetal_core__DOT___021195_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b76__05d 
            = vlSelf->wasmetal_core__DOT___021194_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b74__05d 
            = vlSelf->wasmetal_core__DOT___021192_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b64__05d 
            = vlSelf->wasmetal_core__DOT___021181_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b102__05d 
            = vlSelf->wasmetal_core__DOT___021104_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b67__05d 
            = vlSelf->wasmetal_core__DOT___021184_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b66__05d 
            = vlSelf->wasmetal_core__DOT___021183_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b103__05d 
            = vlSelf->wasmetal_core__DOT___021105_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b95__05d 
            = vlSelf->wasmetal_core__DOT___021215_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b87__05d 
            = vlSelf->wasmetal_core__DOT___021206_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b85__05d 
            = vlSelf->wasmetal_core__DOT___021204_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b83__05d 
            = vlSelf->wasmetal_core__DOT___021202_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b79__05d 
            = vlSelf->wasmetal_core__DOT___021197_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b44__05d 
            = vlSelf->wasmetal_core__DOT___021159_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b30__05d 
            = vlSelf->wasmetal_core__DOT___021144_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b26__05d 
            = vlSelf->wasmetal_core__DOT___021139_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b119__05d 
            = vlSelf->wasmetal_core__DOT___021122_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b117__05d 
            = vlSelf->wasmetal_core__DOT___021120_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b115__05d 
            = vlSelf->wasmetal_core__DOT___021118_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b111__05d 
            = vlSelf->wasmetal_core__DOT___021114_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b107__05d 
            = vlSelf->wasmetal_core__DOT___021109_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b106__05d 
            = vlSelf->wasmetal_core__DOT___021108_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b101__05d 
            = vlSelf->wasmetal_core__DOT___021103_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b94__05d 
            = vlSelf->wasmetal_core__DOT___021214_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b86__05d 
            = vlSelf->wasmetal_core__DOT___021205_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b82__05d 
            = vlSelf->wasmetal_core__DOT___021201_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b118__05d 
            = vlSelf->wasmetal_core__DOT___021121_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b114__05d 
            = vlSelf->wasmetal_core__DOT___021117_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b59__05d 
            = vlSelf->wasmetal_core__DOT___021175_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b14__05d 
            = vlSelf->wasmetal_core__DOT___021126_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b11__05d 
            = vlSelf->wasmetal_core__DOT___021123_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b98__05d 
            = vlSelf->wasmetal_core__DOT___021218_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b62__05d 
            = vlSelf->wasmetal_core__DOT___021179_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b58__05d 
            = vlSelf->wasmetal_core__DOT___021174_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b54__05d 
            = vlSelf->wasmetal_core__DOT___021170_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b112__05d 
            = vlSelf->wasmetal_core__DOT___021115_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b45__05d 
            = vlSelf->wasmetal_core__DOT___021160_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b31__05d 
            = vlSelf->wasmetal_core__DOT___021145_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b29__05d 
            = vlSelf->wasmetal_core__DOT___021142_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b28__05d 
            = vlSelf->wasmetal_core__DOT___021141_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b27__05d 
            = vlSelf->wasmetal_core__DOT___021140_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b24__05d 
            = vlSelf->wasmetal_core__DOT___021137_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b23__05d 
            = vlSelf->wasmetal_core__DOT___021136_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b21__05d 
            = vlSelf->wasmetal_core__DOT___021134_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b19__05d 
            = vlSelf->wasmetal_core__DOT___021131_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b16__05d 
            = vlSelf->wasmetal_core__DOT___021128_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b60__05d 
            = vlSelf->wasmetal_core__DOT___021177_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b47__05d 
            = vlSelf->wasmetal_core__DOT___021162_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b43__05d 
            = vlSelf->wasmetal_core__DOT___021158_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b40__05d 
            = vlSelf->wasmetal_core__DOT___021155_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b37__05d 
            = vlSelf->wasmetal_core__DOT___021151_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b15__05d 
            = vlSelf->wasmetal_core__DOT___021127_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b8__05d 
            = vlSelf->wasmetal_core__DOT___021209_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b22__05d 
            = vlSelf->wasmetal_core__DOT___021135_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b18__05d 
            = vlSelf->wasmetal_core__DOT___021130_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b63__05d 
            = vlSelf->wasmetal_core__DOT___021180_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b34__05d 
            = vlSelf->wasmetal_core__DOT___021148_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b13__05d 
            = vlSelf->wasmetal_core__DOT___021125_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b10__05d 
            = vlSelf->wasmetal_core__DOT___021112_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b46__05d 
            = vlSelf->wasmetal_core__DOT___021161_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b42__05d 
            = vlSelf->wasmetal_core__DOT___021157_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b38__05d 
            = vlSelf->wasmetal_core__DOT___021152_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b61__05d 
            = vlSelf->wasmetal_core__DOT___021178_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b50__05d 
            = vlSelf->wasmetal_core__DOT___021166_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b39__05d 
            = vlSelf->wasmetal_core__DOT___021153_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b12__05d 
            = vlSelf->wasmetal_core__DOT___021124_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b48__05d 
            = vlSelf->wasmetal_core__DOT___021163_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b32__05d 
            = vlSelf->wasmetal_core__DOT___021146_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b55__05d 
            = vlSelf->wasmetal_core__DOT___021171_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b53__05d 
            = vlSelf->wasmetal_core__DOT___021169_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b51__05d 
            = vlSelf->wasmetal_core__DOT___021167_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b56__05d 
            = vlSelf->wasmetal_core__DOT___021172_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b0__05d 
            = vlSelf->wasmetal_core__DOT___021101_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b4__05d 
            = vlSelf->wasmetal_core__DOT___021165_;
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b1__05d 
            = (1U & ((1U & (IData)((0x44ff0fff00000000ULL 
                                    >> (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                         << 5U) | (IData)(vlSelf->__VdfgTmp_hd96f769d__0)))))
                      ? ((IData)(vlSelf->wasmetal_core__DOT___019434_) 
                         | (IData)((0xffffffffffff8000ULL 
                                    >> (((IData)(vlSelf->wasmetal_core__DOT___019447_) 
                                         << 5U) | (IData)(vlSelf->__VdfgTmp_h64a0b4b6__0)))))
                      : ((IData)(vlSelf->wasmetal_core__DOT___019434_) 
                         | (0x8000U >> (IData)(vlSelf->__VdfgTmp_h64a0b4b6__0)))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b116__05d 
            = (1U & (IData)((0xf0faf0fcf0f0f0f0ULL 
                             >> ((0x20U & ((4U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 4U)) 
                                    | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 2U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT___071714_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b100__05d 
            = (1U & (IData)((0xf0fafcf0f0f0f0f0ULL 
                             >> ((0x20U & ((4U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x18U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 3U)) 
                                    | (((IData)(vlSelf->wasmetal_core__DOT___071711_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0)))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b84__05d 
            = (1U & (IData)((0xfafcf0f0f0f0f0f0ULL 
                             >> ((0x20U & ((4U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x18U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 3U)) 
                                    | (((IData)(vlSelf->wasmetal_core__DOT___071708_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0)))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b20__05d 
            = (1U & (IData)((0xfafcf0f0f0f0f0f0ULL 
                             >> ((0x20U & ((8U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x18U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 3U)) 
                                    | (((IData)(vlSelf->wasmetal_core__DOT___071653_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0)))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b36__05d 
            = (1U & (IData)((0xf0fafcf0f0f0f0f0ULL 
                             >> ((0x20U & ((8U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x18U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 3U)) 
                                    | (((IData)(vlSelf->wasmetal_core__DOT___071678_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0)))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b7__05d 
            = (1U & (0x8fU >> (((IData)(vlSelf->wasmetal_core__DOT___071620_) 
                                << 2U) | ((2U & ((8U 
                                                  >> 
                                                  (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___071619_)))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b6__05d 
            = (1U & (0x8fU >> (((IData)(vlSelf->wasmetal_core__DOT___071615_) 
                                << 2U) | ((2U & ((8U 
                                                  >> 
                                                  (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___071614_)))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b52__05d 
            = (1U & (IData)((0xf0faf0fcf0f0f0f0ULL 
                             >> ((0x20U & ((8U >> (3U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      >> 2U))) 
                                           << 5U)) 
                                 | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 4U)) 
                                    | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                              << 2U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT___071691_) 
                                           << 2U) | (IData)(vlSelf->__VdfgTmp_hc2641342__0))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b71__05d 
            = (1U & (IData)((0xff44fff0ff00ff00ULL 
                             >> ((0x30U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___071706_) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___071619_) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((0x10U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019551_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h91551c13__0))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                        >> 1U)))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b69__05d 
            = (1U & (IData)((0xf0fafcf0f0f0f0f0ULL 
                             >> ((0x38U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___071702_) 
                                     << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___071608_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0x10U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___019542_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h91551c13__0))))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b5__05d 
            = (1U & (0x80ffU >> ((8U & ((IData)((0xbb00f000ff00ffULL 
                                                 >> 
                                                 ((0x20U 
                                                   & ((4U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                        << 1U)) 
                                                      << 5U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___071607_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd96f769d__0))))) 
                                        << 3U)) | (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071608_))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b68__05d 
            = (1U & ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))
                      ? (IData)((0xffff1010ffffff00ULL 
                                 >> ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                               << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___019592_) 
                                         << 4U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019591_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019590_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5035dc07__0)))))))
                      : (2U >> (IData)(vlSelf->wasmetal_core__DOT___019592_))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b70__05d 
            = (1U & (IData)((0xff44fff0ff00ff00ULL 
                             >> ((0x30U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___071704_) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___071614_) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((0x100U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019503_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h91551c13__0))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                        >> 1U)))))))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b2__05d 
            = (1U & ((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                    << 1U) | (1U & (IData)(
                                                           (0xf0f0f050f0f0f030ULL 
                                                            >> 
                                                            ((0x10U 
                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                 << 4U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h121bab2f__0))))))))
                      ? (IData)((0xffffffffffffff80ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___019451_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___019456_) 
                                                 << 4U) 
                                                | (IData)(vlSelf->__VdfgTmp_h286ec9e0__0)))))
                      : (0xff80U >> (((IData)(vlSelf->wasmetal_core__DOT___019451_) 
                                      << 3U) | (IData)(vlSelf->__VdfgTmp_h286ec9e0__0)))));
        vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b3__05d 
            = (1U & (0xfffff444U >> (((IData)(vlSelf->wasmetal_core__DOT___071599_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___071598_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x10ff0000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                             << 4U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___071584_) 
                                                               << 2U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf3f5U 
                                                            >> 
                                                            ((4U 
                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                 << 2U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019443_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___019441_)))))))))));
    }
    vlSelf->wasmetal_core__DOT___029239_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026183_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029238_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026182_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d))));
    vlSelf->__VdfgTmp_he45fe6bb__0 = (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    vlSelf->wasmetal_core__DOT___029237_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d))));
    vlSelf->wasmetal_core__DOT___026181_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d))));
    vlSelf->wasmetal_core__DOT___029236_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026180_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d))));
    vlSelf->wasmetal_core__DOT___029235_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d))));
    vlSelf->wasmetal_core__DOT___026179_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d))));
    vlSelf->wasmetal_core__DOT___029406_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029403_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029405_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d))));
    vlSelf->wasmetal_core__DOT___045952_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___045964_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___029399_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d))));
    vlSelf->wasmetal_core__DOT___029402_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d))));
    vlSelf->wasmetal_core__DOT___029401_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029234_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026178_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d))));
    vlSelf->wasmetal_core__DOT___029400_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d))));
    vlSelf->wasmetal_core__DOT___045961_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___045973_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___029233_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d))));
    vlSelf->wasmetal_core__DOT___026177_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d))));
    vlSelf->wasmetal_core__DOT___029389_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d))));
    vlSelf->wasmetal_core__DOT___029398_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d))));
    vlSelf->wasmetal_core__DOT___045972_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___029397_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d))));
    vlSelf->wasmetal_core__DOT___029231_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026175_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029396_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d))));
    vlSelf->wasmetal_core__DOT___029395_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d))));
    vlSelf->wasmetal_core__DOT___045959_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___045971_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___029394_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d))));
    vlSelf->wasmetal_core__DOT___029392_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029230_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d))));
    vlSelf->wasmetal_core__DOT___026174_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029391_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029390_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d))));
    vlSelf->wasmetal_core__DOT___029411_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029388_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d))));
    vlSelf->wasmetal_core__DOT___029387_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d))));
    vlSelf->wasmetal_core__DOT___045958_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___045970_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___029229_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d))));
    vlSelf->wasmetal_core__DOT___026173_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d))));
    vlSelf->wasmetal_core__DOT___029386_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029385_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029384_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029383_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d))));
    vlSelf->wasmetal_core__DOT___029413_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d))));
    vlSelf->wasmetal_core__DOT___029228_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026172_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIPBDIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIPADIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029412_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029410_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029409_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d))));
    vlSelf->wasmetal_core__DOT___029408_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d))));
    vlSelf->wasmetal_core__DOT___029407_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d))));
    vlSelf->wasmetal_core__DOT___029404_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d))));
    vlSelf->wasmetal_core__DOT___029393_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029382_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d))));
    vlSelf->wasmetal_core__DOT___029227_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d))));
    vlSelf->wasmetal_core__DOT___026171_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d))));
    vlSelf->wasmetal_core__DOT___045957_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___045969_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___029226_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d))));
    vlSelf->wasmetal_core__DOT___026170_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d))));
    vlSelf->wasmetal_core__DOT___029225_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d))));
    vlSelf->wasmetal_core__DOT___026169_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d))));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040002_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040003_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040004_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040005_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040015_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040000_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039992_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039991_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039990_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039979_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039980_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039981_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039982_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039963_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039968_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039986_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039987_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039988_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039989_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040001_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039984_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039977_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039976_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039975_));
    vlSelf->__VdfgTmp_h950b0747__0 = (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    vlSelf->wasmetal_core__DOT___029224_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d))));
    vlSelf->wasmetal_core__DOT___026168_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d))));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039964_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039965_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039966_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039967_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039948_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039953_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039971_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039972_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039973_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039974_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039985_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039969_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039962_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039961_));
    vlSelf->wasmetal_core__DOT___045968_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___029223_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d))));
    vlSelf->wasmetal_core__DOT___026167_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d))));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039960_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039949_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039950_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039951_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039952_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039932_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039938_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039956_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039957_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039958_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039959_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039970_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039954_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039947_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039946_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039945_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039933_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039934_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039936_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039937_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039917_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039922_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039941_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039942_));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039998_));
    vlSelf->wasmetal_core__DOT___029222_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d))));
    vlSelf->wasmetal_core__DOT___026166_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d))));
    vlSelf->wasmetal_core__DOT___029252_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d))));
    vlSelf->wasmetal_core__DOT___026196_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d))));
    vlSelf->wasmetal_core__DOT___045955_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___045967_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___029251_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d))));
    vlSelf->wasmetal_core__DOT___026195_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029250_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d))));
    vlSelf->wasmetal_core__DOT___026194_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029249_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d))));
    vlSelf->wasmetal_core__DOT___026193_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d))));
    vlSelf->wasmetal_core__DOT___045954_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___045966_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___029248_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d))));
    vlSelf->wasmetal_core__DOT___026192_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d))));
    vlSelf->wasmetal_core__DOT___029247_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d))));
    vlSelf->wasmetal_core__DOT___026191_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
            << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                          << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                        << 0x1dU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                         << 0x1cU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                            << 0x1bU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                               << 0x1aU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                  << 0x19U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                     << 0x18U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                        << 0x17U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                           << 0x16U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                              << 0x15U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                 << 0x14U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                    << 0x13U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                       << 0x12U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                          << 0x11U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                             << 0x10U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                                << 0xfU) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__divider__02eneg_q = 
        ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040039_));
    vlSelf->wasmetal_core__DOT___052006_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b115__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b114__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b113__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b103__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b102__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___052021_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b83__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b82__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b81__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b71__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b70__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b64__05d)))))))));
    vlSelf->wasmetal_core__DOT___052009_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b91__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b90__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b69__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b68__05d)))))))));
    vlSelf->wasmetal_core__DOT___052005_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b85__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b79__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b78__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___052022_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b123__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b122__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b107__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b106__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___052010_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b127__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b126__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b125__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b124__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b121__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b120__05d)))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__24(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__24\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___043972_;
    wasmetal_core__DOT___043972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043973_;
    wasmetal_core__DOT___043973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043978_;
    wasmetal_core__DOT___043978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043986_;
    wasmetal_core__DOT___043986_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043987_;
    wasmetal_core__DOT___043987_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043992_;
    wasmetal_core__DOT___043992_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044000_;
    wasmetal_core__DOT___044000_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044001_;
    wasmetal_core__DOT___044001_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044006_;
    wasmetal_core__DOT___044006_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044014_;
    wasmetal_core__DOT___044014_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044015_;
    wasmetal_core__DOT___044015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044020_;
    wasmetal_core__DOT___044020_ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___053275_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data) 
                                                               << 3U)) 
                                                           | ((4U 
                                                               & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__parity) 
                                                                  << 1U)) 
                                                              | (3U 
                                                                 & (IData)(
                                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                            >> 0xcU))))))));
    vlSelf->wasmetal_core__DOT___053278_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(
                                                                       (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                        >> 0xeU)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__parity) 
                                                                     << 1U)) 
                                                                 | (3U 
                                                                    & (IData)(
                                                                              (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                                               >> 0xaU)))))))));
    vlSelf->wasmetal_core__DOT___053276_ = (1U & (1U 
                                                  >> 
                                                  ((6U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                                >> 8U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__parity)))));
    vlSelf->wasmetal_core__DOT___053274_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__parity) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                           >> 6U)) 
                                                                  << 3U)) 
                                                              | ((6U 
                                                                  & ((IData)(
                                                                             (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                                              >> 0xcU)) 
                                                                     << 1U)) 
                                                                 | (1U 
                                                                    & (IData)(
                                                                              (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                                               >> 7U)))))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050264_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051188_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccff00f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___051184_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051172_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0f8ff227__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed4d342a__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28f7b227__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050125_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b062dd4__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1cca9b8e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6d54506a__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051180_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8dc4790b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd508e470__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd7287eb7__0))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xf0f0aaaaff00ccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___051148_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050665_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h420e04a5__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7de567cd__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60282e5c__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050746_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7bd28ecf__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f25bbf3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h211ae39f__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051127_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h473eb647__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1387689e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce46baf__0))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccff00f0f0ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051168_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051156_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f9812e4__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he052d4e7__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63b8fe6d__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051160_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfc797c55__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bfa6f09__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc793c4ac__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051164_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hff3ab0b7__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea78939d__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e3eac18__0)))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050264_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051098_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccff00f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050995_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050969_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43fa682b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b1aa625__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbdf51c76__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050991_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7982dd07__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40722c77__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad4ffc8__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050973_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1157f8a3__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f14f02d__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h768acb46__0))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xf0f0aaaaff00ccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___051094_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050908_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8834afb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h210ef7f0__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ab327aa__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050914_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18020398__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51560923__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8901ecaf__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051090_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28b8e598__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51b306d7__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b58ae94__0))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccff00f0f0ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050894_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050890_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf4526f03__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1968304e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6d99021a__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050783_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbc99fdd__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee5ebf6d__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7d1b01d9__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050779_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h38f4df47__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69f02119__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h872406d5__0)))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b1__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b7__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b5__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b2__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b3__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b0__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b6__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b4__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b21__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b31__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b27__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b20__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b19__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b18__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b16__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b26__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b24__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b15__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b14__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b10__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b17__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b29__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b22__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b30__05d 
        = (1U & (0xcaU >> (IData)(vlSelf->__VdfgTmp_he7cea807__0)));
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b8__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b25__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b23__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b28__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b9__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b13__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b12__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d;
    vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b11__05d 
        = vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d;
    vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050965_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___072255_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccf0f0ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___072235_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051482_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b87__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b86__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b85__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b84__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b88__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b92__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051478_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b99__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b98__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b96__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b106__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b104__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b110__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b109__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b108__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051472_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b119__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b118__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b116__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b122__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b121__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b120__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b126__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b125__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b124__05d)))))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___072227_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051400_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b143__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b142__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b141__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b140__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b131__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b130__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b129__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b128__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b135__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b134__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b133__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b132__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051465_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b160__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b171__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b170__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b169__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b168__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b172__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050567_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b183__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b182__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b181__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b180__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b187__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b186__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b185__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b184__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b191__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b190__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b189__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b188__05d)))))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccf0f0ff00ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051396_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050593_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b215__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b214__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b213__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b212__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b216__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b220__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051392_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b227__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b226__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b225__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b224__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b235__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b234__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b233__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b232__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b239__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b238__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b237__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b236__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051388_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b247__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b246__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b245__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b244__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b251__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b250__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b249__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b248__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b255__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b254__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b253__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b252__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__element_sizes__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050264_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050032_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccff00f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___049988_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049976_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b76__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b64__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b68__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049980_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b103__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b102__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b101__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b100__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b106__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b104__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b110__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b109__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b108__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049984_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b115__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b114__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b113__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b112__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b122__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b121__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b120__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b126__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b125__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b124__05d)))))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xf0f0aaaaff00ccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050008_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050000_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b183__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b182__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b181__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b180__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b187__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b186__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b185__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b184__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b191__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b190__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b189__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b188__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049996_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b135__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b134__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b133__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b132__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b139__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b138__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b137__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b136__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b143__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b142__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b141__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b140__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050004_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b144__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b152__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b156__05d)))))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccff00f0f0ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050028_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050016_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b196__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b203__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b202__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b201__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b200__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b204__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050020_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b239__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b238__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b237__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b236__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b227__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b226__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b225__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b224__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b231__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b230__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b229__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b228__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050024_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b243__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b242__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b241__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b240__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b251__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b250__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b249__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b248__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b255__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b254__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b253__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b252__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050264_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050252_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccff00f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050248_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050244_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b79__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b78__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b77__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b76__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b67__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b65__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b64__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b71__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b70__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b69__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b68__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050236_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b103__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b102__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b101__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b100__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b106__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b104__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b110__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b109__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b108__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050240_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b115__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b114__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b113__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b112__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b122__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b121__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b120__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b126__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b125__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b124__05d)))))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xf0f0aaaaff00ccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050208_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050196_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b183__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b182__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b181__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b180__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b187__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b186__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b185__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b184__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b191__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b190__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b189__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b188__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049912_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b135__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b134__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b133__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b132__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b139__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b138__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b137__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b136__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b143__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b142__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b141__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b140__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050204_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b147__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b146__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b145__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b144__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b155__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b154__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b153__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b152__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b159__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b158__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b157__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b156__05d)))))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccff00f0f0ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050228_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050220_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b199__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b198__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b197__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b196__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b203__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b202__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b201__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b200__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b207__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b206__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b205__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b204__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050216_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b239__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b238__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b237__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b236__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b227__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b226__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b225__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b224__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b231__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b230__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b229__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b228__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050212_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b243__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b242__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b241__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b240__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b251__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b250__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b249__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b248__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b255__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b254__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b253__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b252__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__table_sizes__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050965_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050775_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccf0f0ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050763_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050682_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef41fa97__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h947ab6b4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h71547b26__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050673_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ec6b47d__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h40722c77__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad4ffc8__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050669_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8555f3e8__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f14f02d__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h768acb46__0))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050654_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050646_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8901ecaf__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0a192e7e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18020398__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050618_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc66bf11b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h47e0de34__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6286ac7f__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050614_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8834afb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h210ef7f0__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ab327aa__0))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccf0f0ff00ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050771_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050597_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc408f28d__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb35a5f1__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3885fdb9__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050589_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee5ebf6d__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcafe333f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbc99fdd__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050560_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h236ea405__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69f02119__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h872406d5__0)))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050965_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051686_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccf0f0ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___049419_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049411_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8443bfe__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36e63769__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbcd45513__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049407_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6e193d9b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1cca9b8e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6d54506a__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049415_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h79496643__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd508e470__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd7287eb7__0))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___051603_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048531_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h211ae39f__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3eb04205__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7bd28ecf__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049908_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73f4a931__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1aa87dc1__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h964144cd__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051599_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h420e04a5__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7de567cd__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60282e5c__0))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccf0f0ff00ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051682_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h139eafce__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7f628da__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2a57136__0))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051670_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bfa6f09__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he25b67d8__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfc797c55__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051674_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h89ddcfc9__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea78939d__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e3eac18__0)))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b31__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b30__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b29__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b28__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b27__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b26__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b25__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b24__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b24__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b23__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b22__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b21__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b20__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b19__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b18__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b17__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b16__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b15__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b14__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b13__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b12__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b11__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b10__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b10__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b9__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b8__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b7__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b6__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b5__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b4__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b3__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b2__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b1__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d;
    vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b0__05d 
        = vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b5__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b5__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b4__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b4__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b3__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b3__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b2__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b2__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b1__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b0__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b5__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b5__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b4__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b4__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b3__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b3__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b2__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b2__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b1__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b0__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b5__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b5__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b4__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b4__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b3__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b3__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b2__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b2__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b1__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b0__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b5__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b5__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b4__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b4__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b3__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b3__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b2__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b2__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b1__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b0__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b29__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054540_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128531___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b28__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054538_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128531___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b27__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054536_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128530___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b26__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054534_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128530___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b25__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054532_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128530___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b24__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054530_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128530___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b23__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054528_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128529___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b22__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054526_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128529___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b21__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054524_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128529___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b20__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054522_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128529___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b19__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054520_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128528___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b18__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054518_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128528___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b17__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054516_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128528___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b16__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054514_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128528___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b15__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054512_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128527___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b14__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054510_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128527___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b13__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054508_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128527___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b12__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054506_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128527___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b10__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b10__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b9__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b9__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b8__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b8__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b7__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b7__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b6__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b6__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b29__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054540_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b28__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054538_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b27__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054536_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b26__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054534_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b25__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054532_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b24__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054530_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b23__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054528_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b22__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054526_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b21__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054524_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b20__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054522_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b19__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054520_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b18__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054518_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b17__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054516_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b16__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054514_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b15__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054512_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b14__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054510_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b13__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054508_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b12__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054506_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b10__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b10__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b9__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b9__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b8__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b8__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b7__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b7__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b6__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b6__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b29__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054540_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128523___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b28__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054538_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128523___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b27__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054536_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128522___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b26__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054534_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128522___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b25__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054532_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128522___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b24__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054530_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128522___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b23__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054528_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128521___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b22__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054526_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128521___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b21__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054524_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128521___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b20__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054522_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128521___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b19__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054520_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128520___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b18__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054518_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128520___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b17__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054516_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128520___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b16__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054514_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128520___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b15__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054512_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128519___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b14__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054510_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128519___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b13__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054508_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128519___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b12__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054506_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128519___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b10__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b10__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b9__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b9__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b8__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b8__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b7__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b7__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b6__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b6__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b29__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054540_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128608___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b28__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054538_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128608___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b27__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054536_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128607___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b26__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054534_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128607___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b25__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054532_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128607___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b24__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054530_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128607___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b23__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054528_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128606___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b22__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054526_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128606___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b21__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054524_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128606___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b20__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054522_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128606___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b19__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054520_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128605___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b18__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054518_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128605___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b17__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054516_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128605___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b16__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054514_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128605___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b15__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054512_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128604___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b14__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054510_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128604___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b13__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054508_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128604___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b12__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054506_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128604___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b10__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b10__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b9__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b9__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b8__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b8__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b7__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b7__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b6__05d 
        = vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b6__05d;
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054504_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128526___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054504_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054504_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128518___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054504_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128603___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050965_) 
                         << 1U) | (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053472_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xaaaaccccf0f0ff00ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050583_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050575_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b87__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b86__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b85__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b84__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b88__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b92__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050571_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b99__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b98__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b96__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b107__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b106__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b104__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b110__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b109__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b108__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050491_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b119__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b118__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b116__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b123__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b122__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b121__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b120__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b127__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b126__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b125__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b124__05d)))))))))))))))))))))))) 
                                                               << 2U)) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___051459_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051447_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b143__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b142__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b141__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b140__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b131__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b130__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b129__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b128__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b135__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b134__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b133__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b132__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051455_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b160__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b171__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b170__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b169__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b168__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b172__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051451_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b183__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b182__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b181__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b180__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b187__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b186__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b185__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b184__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b191__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b190__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b189__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b188__05d)))))))))))))))))))))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xaaaaccccf0f0ff00ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053468_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053464_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b215__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b214__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b213__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b212__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b216__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b220__05d)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053460_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b227__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b226__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b225__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b224__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b235__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b234__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b233__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b232__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b239__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b238__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b237__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b236__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053456_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b247__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b246__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b245__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b244__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b251__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b250__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b249__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b248__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b255__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b254__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b253__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b252__05d))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053279_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053276_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053275_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053274_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                                >> 0xaU)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                                                >> 5U))))))))));
    wasmetal_core__DOT___044001_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b18__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b21__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b23__05d)))))))));
    wasmetal_core__DOT___044000_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___043973_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b18__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b20__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b23__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b21__05d)))))))));
    wasmetal_core__DOT___043972_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___044015_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b20__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b21__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b18__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b23__05d)))))))));
    wasmetal_core__DOT___044014_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___043987_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b21__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b20__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b22__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b18__05d)))))))));
    wasmetal_core__DOT___043986_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___044006_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___043978_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___044020_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___043992_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___043997_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b27__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b26__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b28__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b25__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b24__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b29__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___044001_) 
                                               & ((IData)(wasmetal_core__DOT___044000_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___044006_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___043969_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b25__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b24__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b29__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b28__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b27__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b26__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___043973_) 
                                               & ((IData)(wasmetal_core__DOT___043972_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___043978_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___044011_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b25__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b24__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b29__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b28__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b27__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b26__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___044015_) 
                                               & ((IData)(wasmetal_core__DOT___044014_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___044020_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___043983_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b24__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b27__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b28__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b26__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b25__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b29__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___043987_) 
                                               & ((IData)(wasmetal_core__DOT___043986_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___043992_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d))))));
}
