#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__47(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__47\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___063853_;
    wasmetal_core__DOT___063853_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063866_;
    wasmetal_core__DOT___063866_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063928_;
    wasmetal_core__DOT___063928_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063969_;
    wasmetal_core__DOT___063969_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064474_;
    wasmetal_core__DOT___064474_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064481_;
    wasmetal_core__DOT___064481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064517_;
    wasmetal_core__DOT___064517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064739_;
    wasmetal_core__DOT___064739_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064740_;
    wasmetal_core__DOT___064740_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064745_;
    wasmetal_core__DOT___064745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064749_;
    wasmetal_core__DOT___064749_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064908_;
    wasmetal_core__DOT___064908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064909_;
    wasmetal_core__DOT___064909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064910_;
    wasmetal_core__DOT___064910_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064916_;
    wasmetal_core__DOT___064916_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065054_;
    wasmetal_core__DOT___065054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065057_;
    wasmetal_core__DOT___065057_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065067_;
    wasmetal_core__DOT___065067_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065069_;
    wasmetal_core__DOT___065069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065181_;
    wasmetal_core__DOT___065181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065182_;
    wasmetal_core__DOT___065182_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065183_;
    wasmetal_core__DOT___065183_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065193_;
    wasmetal_core__DOT___065193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065295_;
    wasmetal_core__DOT___065295_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065296_;
    wasmetal_core__DOT___065296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065297_;
    wasmetal_core__DOT___065297_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065312_;
    wasmetal_core__DOT___065312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065415_;
    wasmetal_core__DOT___065415_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065416_;
    wasmetal_core__DOT___065416_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065430_;
    wasmetal_core__DOT___065430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065615_;
    wasmetal_core__DOT___065615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065618_;
    wasmetal_core__DOT___065618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065626_;
    wasmetal_core__DOT___065626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065704_;
    wasmetal_core__DOT___065704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065706_;
    wasmetal_core__DOT___065706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065714_;
    wasmetal_core__DOT___065714_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065806_;
    wasmetal_core__DOT___065806_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065808_;
    wasmetal_core__DOT___065808_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065816_;
    wasmetal_core__DOT___065816_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065902_;
    wasmetal_core__DOT___065902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065904_;
    wasmetal_core__DOT___065904_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065912_;
    wasmetal_core__DOT___065912_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065941_;
    wasmetal_core__DOT___065941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065942_;
    wasmetal_core__DOT___065942_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065946_;
    wasmetal_core__DOT___065946_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066086_;
    wasmetal_core__DOT___066086_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066087_;
    wasmetal_core__DOT___066087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066091_;
    wasmetal_core__DOT___066091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066128_;
    wasmetal_core__DOT___066128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066130_;
    wasmetal_core__DOT___066130_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066280_;
    wasmetal_core__DOT___066280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066284_;
    wasmetal_core__DOT___066284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066287_;
    wasmetal_core__DOT___066287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066318_;
    wasmetal_core__DOT___066318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066322_;
    wasmetal_core__DOT___066322_ = 0;
    // Body
    vlSelf->__VdfgTmp_ha304a668__0 = ((2U & ((IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                      >> 0x21U)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___072025_));
    wasmetal_core__DOT___065941_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0xcU)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128234___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0xcU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128248___O))))));
    wasmetal_core__DOT___066086_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0xdU)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128234___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0xdU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128248___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___065615_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 8U)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128233___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 8U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128247___O))))));
    wasmetal_core__DOT___065806_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0xaU)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128233___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0xaU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128247___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___065704_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 9U)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128233___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 9U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128247___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___065902_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0xbU)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128233___O)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0xbU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128247___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___065415_ = (1U & (IData)((0x77707770777ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128246___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 7U)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                             >> 7U)))))))))));
    wasmetal_core__DOT___066128_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0xeU)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128234___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0xeU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128248___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___066318_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 0x10U)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128235___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                                >> 0x10U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128249___O))))));
    wasmetal_core__DOT___065181_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065180_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065179_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 5U)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                         >> 5U)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h27b70ff4__0))))))));
    wasmetal_core__DOT___066280_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                           >> 0xfU)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048357_))))));
    wasmetal_core__DOT___065054_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065052_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065051_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 4U)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                         >> 4U)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h27b70ff4__0))))))));
    wasmetal_core__DOT___065295_ = (1U & (IData)((0x77707770777ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                >> 6U)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134184___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048350_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                             >> 6U)))))))))));
    wasmetal_core__DOT___064908_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064906_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064905_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 3U)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                         >> 3U)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h27b70ff4__0))))))));
    wasmetal_core__DOT___064474_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064472_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064471_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 1U)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                         >> 1U)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h27b70ff4__0))))))));
    wasmetal_core__DOT___064739_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064737_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064736_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 2U)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum 
                                                                         >> 2U)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h27b70ff4__0))))))));
    wasmetal_core__DOT___063853_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063848_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042284_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134232_.__PVT__alu_sum) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___048318_))))))))))));
    wasmetal_core__DOT___065942_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065941_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001524_)))))))));
    wasmetal_core__DOT___066087_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___066086_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001536_)))))))));
    wasmetal_core__DOT___065618_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065615_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001369_)))))))));
    wasmetal_core__DOT___065808_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065806_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001413_)))))))));
    wasmetal_core__DOT___065706_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065704_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001381_)))))))));
    wasmetal_core__DOT___065904_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065902_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001425_)))))))));
    wasmetal_core__DOT___065416_ = (1U & (0xbbb00000U 
                                          >> (((IData)(wasmetal_core__DOT___065415_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___063949_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O) 
                                                           >> 2U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048334_)))))));
    wasmetal_core__DOT___066130_ = (1U & (IData)((0xdf0f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065616_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___066128_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065614_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063857_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___001568_)))))))));
    wasmetal_core__DOT___066322_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066318_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___065182_ = (1U & (0xbbb0000U 
                                          >> (((IData)(wasmetal_core__DOT___065181_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128246___O) 
                                                        << 1U)) 
                                                    | ((2U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048334_)))))));
    wasmetal_core__DOT___066284_ = (1U & (IData)((0x45cf00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066280_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065607_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128248___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128234___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h058312bf__0))))))));
    wasmetal_core__DOT___065057_ = (1U & (IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065054_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065053_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128246___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha091cfd4__0))))))));
    wasmetal_core__DOT___065296_ = (1U & (0xbbb0000U 
                                          >> (((IData)(wasmetal_core__DOT___065295_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128246___O)) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O) 
                                                           >> 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048334_)))))));
    wasmetal_core__DOT___064909_ = (1U & (IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064908_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064907_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128239___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha091cfd4__0))))))));
    wasmetal_core__DOT___064481_ = (1U & (0xe0U >> 
                                          ((4U & ((IData)(
                                                          (0x2a3f00000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___064474_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064473_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128239___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha091cfd4__0))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___063930_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___063860_)))));
    wasmetal_core__DOT___064740_ = (1U & (IData)((0x2a3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064739_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064738_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128239___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha091cfd4__0))))))));
    wasmetal_core__DOT___063866_ = (1U & (IData)((0xa000f0c0f000f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063859_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xd00000000000000ULL 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___063853_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063852_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063851_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128239___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019396_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O))))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___065946_ = (1U & (0xc88f0000U 
                                          >> (((IData)(wasmetal_core__DOT___065942_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))));
    wasmetal_core__DOT___066091_ = (1U & (0xc88f0000U 
                                          >> (((IData)(wasmetal_core__DOT___066087_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))));
    wasmetal_core__DOT___065626_ = (1U & (IData)((0xc88f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065618_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065617_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))))));
    wasmetal_core__DOT___065816_ = (1U & (IData)((0xc88f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065808_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065807_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))))));
    wasmetal_core__DOT___065714_ = (1U & (IData)((0xc88f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065706_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065705_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))))));
    wasmetal_core__DOT___065912_ = (1U & (IData)((0xc88f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065904_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065903_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))))));
    wasmetal_core__DOT___065430_ = (1U & (0xd0U >> 
                                          ((4U & ((IData)(
                                                          (0xbf33030300000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___065416_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063856_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x3f15000000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___065414_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065413_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065412_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___050361_)))));
    vlSelf->wasmetal_core__DOT___066144_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xc88f00000000ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___066130_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066129_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb4ec291e__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066135_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048372_)))));
    vlSelf->wasmetal_core__DOT___066329_ = (1U & (IData)(
                                                         (0xe00000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066322_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066316_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066315_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066314_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    wasmetal_core__DOT___065183_ = (1U & (IData)((0xbf0f330300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065182_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063859_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___066287_ = (1U & (IData)((0x40ff000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066284_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___065610_)))))))));
    wasmetal_core__DOT___065067_ = (1U & (IData)((0x5f4c00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065057_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065056_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((9U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___065055_)))))))));
    wasmetal_core__DOT___065297_ = (1U & (IData)((0xbf0f330300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065296_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063859_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___064910_ = (1U & (IData)((0xa0ccc0ff00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064909_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))))));
    wasmetal_core__DOT___064517_ = (1U & (IData)((0xbf00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064481_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064480_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064479_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h824f53a5__0))))))));
    wasmetal_core__DOT___064745_ = (1U & (0xbf00U >> 
                                          ((8U & ((IData)(
                                                          (0xa0ccc0ff00000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___064740_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h824f53a5__0)))));
    wasmetal_core__DOT___063928_ = (1U & (IData)((0xdf00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063866_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063865_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063864_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063863_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x1fU 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063861_)))))))));
    vlSelf->wasmetal_core__DOT___065954_ = (1U & (IData)(
                                                         (0x3f1500000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065946_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065945_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x1fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065944_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065943_)))))))));
    vlSelf->wasmetal_core__DOT___066099_ = (1U & (IData)(
                                                         (0x3f1500000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066091_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066090_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x1fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066089_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066088_)))))))));
    vlSelf->wasmetal_core__DOT___065630_ = (1U & (IData)(
                                                         (0xaaaf222300000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065626_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x1fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065625_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___065622_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065623_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064476_)))))))));
    vlSelf->wasmetal_core__DOT___065820_ = (1U & (IData)(
                                                         (0xaaaf222300000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065816_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x1fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065815_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___065812_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065813_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064476_)))))))));
    vlSelf->wasmetal_core__DOT___065718_ = (1U & (IData)(
                                                         (0xaaaf222300000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065714_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x1fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065713_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___065710_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065711_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064476_)))))))));
    vlSelf->wasmetal_core__DOT___065916_ = (1U & (IData)(
                                                         (0xaaaf222300000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065912_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x1fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065911_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___065908_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065909_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064476_)))))))));
    vlSelf->wasmetal_core__DOT___065432_ = (1U & (IData)(
                                                         (0x3f1500000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065430_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065429_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x1fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064477_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___065426_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065427_)))))))));
    wasmetal_core__DOT___065193_ = (1U & (0xee0e0000U 
                                          >> (((IData)(wasmetal_core__DOT___065183_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048355_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063929_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___063946_)))))));
    vlSelf->wasmetal_core__DOT___066291_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066287_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066286_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3f15000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066279_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066278_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066277_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066272_)))))))));
    wasmetal_core__DOT___065069_ = (1U & (IData)((0x45cf454500000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065067_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065055_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0x3f15000000000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065064_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065063_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065062_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___065065_)))))))));
    wasmetal_core__DOT___065312_ = (1U & (0xd0U >> 
                                          ((4U & ((IData)(
                                                          (0xbfbfbf0000000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___065297_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063860_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063947_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___063929_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h10a668fa__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048354_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0x3f15000000000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___065304_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065303_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065302_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___050361_)))));
    wasmetal_core__DOT___064916_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0xb000ff00ff00ff00ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                             << 5U) 
                                                            | ((0x10U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h0791be06__0)) 
                                                                   << 4U)) 
                                                               | (((IData)(wasmetal_core__DOT___064910_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___064911_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048341_)))));
    vlSelf->wasmetal_core__DOT___064525_ = (1U & (IData)(
                                                         (0x1fff00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064517_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064516_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064515_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)))))));
    wasmetal_core__DOT___064749_ = (1U & (IData)((0x4fff00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064745_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064744_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x4fff00ff00000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h00f9b844__0))))))))))))))));
    wasmetal_core__DOT___063969_ = (1U & (IData)((0x700ff00ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063929_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___063928_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048269_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10a668fa__0)))))))))));
    vlSelf->wasmetal_core__DOT___065206_ = (1U & (IData)(
                                                         (0xdf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065193_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065192_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065191_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063929_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h10a668fa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048344_)))))))));
    vlSelf->wasmetal_core__DOT___065086_ = (1U & (IData)(
                                                         (0x3f0fff5f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065069_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h10a668fa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048342_)))))))));
    vlSelf->wasmetal_core__DOT___065319_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065312_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x1fU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___065294_))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064477_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___065309_))))))))));
    vlSelf->wasmetal_core__DOT___064934_ = (1U & (IData)(
                                                         (0xcf4500000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064916_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064915_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x1fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3f15000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064900_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064899_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064898_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064913_)))))))));
    vlSelf->wasmetal_core__DOT___064764_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064748_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064747_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063838_)))))))));
    vlSelf->wasmetal_core__DOT___064002_ = (1U & (IData)(
                                                         (0x3f5f000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063969_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063968_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063965_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048382_)))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__48(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__48\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___066408_;
    wasmetal_core__DOT___066408_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066533_;
    wasmetal_core__DOT___066533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066607_;
    wasmetal_core__DOT___066607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066609_;
    wasmetal_core__DOT___066609_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066655_;
    wasmetal_core__DOT___066655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066777_;
    wasmetal_core__DOT___066777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066857_;
    wasmetal_core__DOT___066857_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066859_;
    wasmetal_core__DOT___066859_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066901_;
    wasmetal_core__DOT___066901_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066975_;
    wasmetal_core__DOT___066975_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066978_;
    wasmetal_core__DOT___066978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066982_;
    wasmetal_core__DOT___066982_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067080_;
    wasmetal_core__DOT___067080_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067082_;
    wasmetal_core__DOT___067082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067087_;
    wasmetal_core__DOT___067087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067158_;
    wasmetal_core__DOT___067158_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067160_;
    wasmetal_core__DOT___067160_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067165_;
    wasmetal_core__DOT___067165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067199_;
    wasmetal_core__DOT___067199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067201_;
    wasmetal_core__DOT___067201_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067206_;
    wasmetal_core__DOT___067206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067317_;
    wasmetal_core__DOT___067317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067318_;
    wasmetal_core__DOT___067318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067321_;
    wasmetal_core__DOT___067321_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067347_;
    wasmetal_core__DOT___067347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067348_;
    wasmetal_core__DOT___067348_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067351_;
    wasmetal_core__DOT___067351_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067459_;
    wasmetal_core__DOT___067459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067460_;
    wasmetal_core__DOT___067460_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067462_;
    wasmetal_core__DOT___067462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067485_;
    wasmetal_core__DOT___067485_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067486_;
    wasmetal_core__DOT___067486_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067487_;
    wasmetal_core__DOT___067487_ = 0;
    // Body
    wasmetal_core__DOT___066408_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128235___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128249___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___066533_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128235___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 1U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128249___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___066655_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128236___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 3U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128250___O))))));
    wasmetal_core__DOT___066777_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128236___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 4U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128250___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___066901_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                << 3U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128236___O)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 6U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128250___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___067317_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128238___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 0xbU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128252___O))))));
    wasmetal_core__DOT___066607_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                << 3U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128235___O)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 2U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128249___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___067459_ = (1U & (0xd0U >> 
                                          ((4U & ((IData)(
                                                          (0x77707770777ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128252___O) 
                                                                << 3U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 0xdU)))))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128238___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___066857_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128236___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 5U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128250___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___066975_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128237___O) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 7U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128251___O))))));
    wasmetal_core__DOT___067347_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128238___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 0xcU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128252___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___067485_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048357_))))));
    wasmetal_core__DOT___067080_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128237___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 8U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128251___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___067158_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128237___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 9U)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128251___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___067199_ = (1U & (0x70U >> 
                                          ((4U & ((IData)(
                                                          (0x707770777077ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                << 3U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128237___O)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134230_.__PVT__alu_sum 
                                                                                >> 0xaU)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048357_)))))))) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128251___O) 
                                                    >> 3U))))));
    vlSelf->wasmetal_core__DOT___066414_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066409_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___066408_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___066539_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066534_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___066533_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___066661_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066656_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___066655_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___066783_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066778_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___066777_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___066907_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066902_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___066901_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d)))))))));
    wasmetal_core__DOT___067318_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067317_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___066609_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___067460_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067459_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___066859_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066857_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___066978_ = (1U & (IData)((0xd000000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066976_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___066975_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___066407_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d)))))))));
    wasmetal_core__DOT___067348_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067347_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___067486_ = (1U & (IData)((0x45cf00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067485_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065607_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128252___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128238___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h058312bf__0))))))));
    wasmetal_core__DOT___067082_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067080_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___067160_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067158_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___067201_ = (1U & (IData)((0xbf33030300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067199_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066282_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063857_)))))))));
    wasmetal_core__DOT___067321_ = (1U & (0xe0000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___067318_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))));
    vlSelf->wasmetal_core__DOT___066615_ = (1U & (IData)(
                                                         (0xe00000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066609_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066604_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066603_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063950_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    wasmetal_core__DOT___067462_ = (1U & (0xe0000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___067460_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))));
    vlSelf->wasmetal_core__DOT___066865_ = (1U & (IData)(
                                                         (0xe00000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066859_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066855_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066854_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066853_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063952_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    wasmetal_core__DOT___066982_ = (1U & (0xfb0000U 
                                          >> (((IData)(wasmetal_core__DOT___066978_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___066977_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___067351_ = (1U & (0xe0000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___067348_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063937_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))));
    wasmetal_core__DOT___067487_ = (1U & (IData)((0xa0ccc0ff00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067486_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065612_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h652beeee__0))))))));
    wasmetal_core__DOT___067087_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067082_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xf080f0f0f0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067078_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067077_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067076_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((9U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd856a856__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    wasmetal_core__DOT___067165_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067160_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xf080f0f0f0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067156_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067155_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067154_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063931_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    wasmetal_core__DOT___067206_ = (1U & (IData)((0xe00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067201_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066321_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xf080f0f0f0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067197_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067196_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067195_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___063932_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063860_)))))))));
    vlSelf->wasmetal_core__DOT___067324_ = (1U & (0xbbb00000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067320_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3f15000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___067315_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067314_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067467_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067462_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067461_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066140_)))))));
    vlSelf->wasmetal_core__DOT___066985_ = (1U & (0xfcfa0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066982_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065622_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf0f0ccaaU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066325_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066652_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___066980_)))))))))))));
    vlSelf->wasmetal_core__DOT___067354_ = (1U & (0xbbb00000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067351_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067350_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3f15000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___067345_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067344_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067343_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067491_ = (1U & (IData)(
                                                         (0xf100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067488_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___067487_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066283_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he88617ec__0))))))));
    vlSelf->wasmetal_core__DOT___067089_ = (1U & (IData)(
                                                         (0xfcfa00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067086_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065710_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066405_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066774_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067084_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067167_ = (1U & (IData)(
                                                         (0xfcfa00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067165_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067164_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065812_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066531_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066861_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067162_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067208_ = (1U & (IData)(
                                                         (0xfcfa00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065908_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066612_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067203_)))))))))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__49(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__49\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019299_;
    wasmetal_core__DOT___019299_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019347_;
    wasmetal_core__DOT___019347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019426_;
    wasmetal_core__DOT___019426_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019440_;
    wasmetal_core__DOT___019440_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019442_;
    wasmetal_core__DOT___019442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019449_;
    wasmetal_core__DOT___019449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019455_;
    wasmetal_core__DOT___019455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019459_;
    wasmetal_core__DOT___019459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019469_;
    wasmetal_core__DOT___019469_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019473_;
    wasmetal_core__DOT___019473_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019493_;
    wasmetal_core__DOT___019493_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019504_;
    wasmetal_core__DOT___019504_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019505_;
    wasmetal_core__DOT___019505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019527_;
    wasmetal_core__DOT___019527_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019530_;
    wasmetal_core__DOT___019530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019546_;
    wasmetal_core__DOT___019546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019549_;
    wasmetal_core__DOT___019549_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019569_;
    wasmetal_core__DOT___019569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019573_;
    wasmetal_core__DOT___019573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033584_;
    wasmetal_core__DOT___033584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033588_;
    wasmetal_core__DOT___033588_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033592_;
    wasmetal_core__DOT___033592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033597_;
    wasmetal_core__DOT___033597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033601_;
    wasmetal_core__DOT___033601_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033606_;
    wasmetal_core__DOT___033606_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033611_;
    wasmetal_core__DOT___033611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033615_;
    wasmetal_core__DOT___033615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033618_;
    wasmetal_core__DOT___033618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033619_;
    wasmetal_core__DOT___033619_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033620_;
    wasmetal_core__DOT___033620_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033621_;
    wasmetal_core__DOT___033621_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033622_;
    wasmetal_core__DOT___033622_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033623_;
    wasmetal_core__DOT___033623_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033624_;
    wasmetal_core__DOT___033624_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033625_;
    wasmetal_core__DOT___033625_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033626_;
    wasmetal_core__DOT___033626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033627_;
    wasmetal_core__DOT___033627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033628_;
    wasmetal_core__DOT___033628_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033629_;
    wasmetal_core__DOT___033629_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033630_;
    wasmetal_core__DOT___033630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033631_;
    wasmetal_core__DOT___033631_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033632_;
    wasmetal_core__DOT___033632_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033633_;
    wasmetal_core__DOT___033633_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033634_;
    wasmetal_core__DOT___033634_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033635_;
    wasmetal_core__DOT___033635_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033636_;
    wasmetal_core__DOT___033636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033637_;
    wasmetal_core__DOT___033637_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033638_;
    wasmetal_core__DOT___033638_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033639_;
    wasmetal_core__DOT___033639_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033640_;
    wasmetal_core__DOT___033640_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033641_;
    wasmetal_core__DOT___033641_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033642_;
    wasmetal_core__DOT___033642_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033643_;
    wasmetal_core__DOT___033643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033644_;
    wasmetal_core__DOT___033644_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033645_;
    wasmetal_core__DOT___033645_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033646_;
    wasmetal_core__DOT___033646_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033647_;
    wasmetal_core__DOT___033647_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033648_;
    wasmetal_core__DOT___033648_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033649_;
    wasmetal_core__DOT___033649_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033650_;
    wasmetal_core__DOT___033650_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033651_;
    wasmetal_core__DOT___033651_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033652_;
    wasmetal_core__DOT___033652_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036656_;
    wasmetal_core__DOT___036656_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036674_;
    wasmetal_core__DOT___036674_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036678_;
    wasmetal_core__DOT___036678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036679_;
    wasmetal_core__DOT___036679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036683_;
    wasmetal_core__DOT___036683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036690_;
    wasmetal_core__DOT___036690_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037045_;
    wasmetal_core__DOT___037045_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037049_;
    wasmetal_core__DOT___037049_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037053_;
    wasmetal_core__DOT___037053_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037058_;
    wasmetal_core__DOT___037058_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037062_;
    wasmetal_core__DOT___037062_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037067_;
    wasmetal_core__DOT___037067_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037071_;
    wasmetal_core__DOT___037071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037075_;
    wasmetal_core__DOT___037075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037076_;
    wasmetal_core__DOT___037076_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037080_;
    wasmetal_core__DOT___037080_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037096_;
    wasmetal_core__DOT___037096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037099_;
    wasmetal_core__DOT___037099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037100_;
    wasmetal_core__DOT___037100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037101_;
    wasmetal_core__DOT___037101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037102_;
    wasmetal_core__DOT___037102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037103_;
    wasmetal_core__DOT___037103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037104_;
    wasmetal_core__DOT___037104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037105_;
    wasmetal_core__DOT___037105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037106_;
    wasmetal_core__DOT___037106_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037107_;
    wasmetal_core__DOT___037107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037108_;
    wasmetal_core__DOT___037108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037109_;
    wasmetal_core__DOT___037109_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037110_;
    wasmetal_core__DOT___037110_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037111_;
    wasmetal_core__DOT___037111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037112_;
    wasmetal_core__DOT___037112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037113_;
    wasmetal_core__DOT___037113_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037114_;
    wasmetal_core__DOT___037114_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037115_;
    wasmetal_core__DOT___037115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037116_;
    wasmetal_core__DOT___037116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037117_;
    wasmetal_core__DOT___037117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037118_;
    wasmetal_core__DOT___037118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037119_;
    wasmetal_core__DOT___037119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037120_;
    wasmetal_core__DOT___037120_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037121_;
    wasmetal_core__DOT___037121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037122_;
    wasmetal_core__DOT___037122_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037123_;
    wasmetal_core__DOT___037123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037124_;
    wasmetal_core__DOT___037124_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037125_;
    wasmetal_core__DOT___037125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037126_;
    wasmetal_core__DOT___037126_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037128_;
    wasmetal_core__DOT___037128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037129_;
    wasmetal_core__DOT___037129_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037130_;
    wasmetal_core__DOT___037130_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037131_;
    wasmetal_core__DOT___037131_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037132_;
    wasmetal_core__DOT___037132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037133_;
    wasmetal_core__DOT___037133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037134_;
    wasmetal_core__DOT___037134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061520_;
    wasmetal_core__DOT___061520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061521_;
    wasmetal_core__DOT___061521_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061523_;
    wasmetal_core__DOT___061523_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061524_;
    wasmetal_core__DOT___061524_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061525_;
    wasmetal_core__DOT___061525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061526_;
    wasmetal_core__DOT___061526_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061528_;
    wasmetal_core__DOT___061528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061529_;
    wasmetal_core__DOT___061529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061530_;
    wasmetal_core__DOT___061530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061531_;
    wasmetal_core__DOT___061531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061532_;
    wasmetal_core__DOT___061532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061533_;
    wasmetal_core__DOT___061533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061534_;
    wasmetal_core__DOT___061534_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061535_;
    wasmetal_core__DOT___061535_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061537_;
    wasmetal_core__DOT___061537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061538_;
    wasmetal_core__DOT___061538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061539_;
    wasmetal_core__DOT___061539_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061540_;
    wasmetal_core__DOT___061540_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061541_;
    wasmetal_core__DOT___061541_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061542_;
    wasmetal_core__DOT___061542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061543_;
    wasmetal_core__DOT___061543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061544_;
    wasmetal_core__DOT___061544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061545_;
    wasmetal_core__DOT___061545_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061546_;
    wasmetal_core__DOT___061546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061547_;
    wasmetal_core__DOT___061547_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061548_;
    wasmetal_core__DOT___061548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061549_;
    wasmetal_core__DOT___061549_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061550_;
    wasmetal_core__DOT___061550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061551_;
    wasmetal_core__DOT___061551_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061552_;
    wasmetal_core__DOT___061552_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061554_;
    wasmetal_core__DOT___061554_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061555_;
    wasmetal_core__DOT___061555_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061556_;
    wasmetal_core__DOT___061556_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061557_;
    wasmetal_core__DOT___061557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061558_;
    wasmetal_core__DOT___061558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061559_;
    wasmetal_core__DOT___061559_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061560_;
    wasmetal_core__DOT___061560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061561_;
    wasmetal_core__DOT___061561_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061562_;
    wasmetal_core__DOT___061562_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061565_;
    wasmetal_core__DOT___061565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061566_;
    wasmetal_core__DOT___061566_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061567_;
    wasmetal_core__DOT___061567_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061568_;
    wasmetal_core__DOT___061568_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061569_;
    wasmetal_core__DOT___061569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061570_;
    wasmetal_core__DOT___061570_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061571_;
    wasmetal_core__DOT___061571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061572_;
    wasmetal_core__DOT___061572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061573_;
    wasmetal_core__DOT___061573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061574_;
    wasmetal_core__DOT___061574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061575_;
    wasmetal_core__DOT___061575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061576_;
    wasmetal_core__DOT___061576_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061577_;
    wasmetal_core__DOT___061577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061578_;
    wasmetal_core__DOT___061578_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061579_;
    wasmetal_core__DOT___061579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061580_;
    wasmetal_core__DOT___061580_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061581_;
    wasmetal_core__DOT___061581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061583_;
    wasmetal_core__DOT___061583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061640_;
    wasmetal_core__DOT___061640_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061664_;
    wasmetal_core__DOT___061664_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061713_;
    wasmetal_core__DOT___061713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061716_;
    wasmetal_core__DOT___061716_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061717_;
    wasmetal_core__DOT___061717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061728_;
    wasmetal_core__DOT___061728_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061729_;
    wasmetal_core__DOT___061729_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061730_;
    wasmetal_core__DOT___061730_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061731_;
    wasmetal_core__DOT___061731_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061732_;
    wasmetal_core__DOT___061732_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061733_;
    wasmetal_core__DOT___061733_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061734_;
    wasmetal_core__DOT___061734_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061735_;
    wasmetal_core__DOT___061735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061736_;
    wasmetal_core__DOT___061736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061737_;
    wasmetal_core__DOT___061737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061739_;
    wasmetal_core__DOT___061739_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061740_;
    wasmetal_core__DOT___061740_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061741_;
    wasmetal_core__DOT___061741_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061742_;
    wasmetal_core__DOT___061742_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061743_;
    wasmetal_core__DOT___061743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061744_;
    wasmetal_core__DOT___061744_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061745_;
    wasmetal_core__DOT___061745_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061746_;
    wasmetal_core__DOT___061746_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061747_;
    wasmetal_core__DOT___061747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061748_;
    wasmetal_core__DOT___061748_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061749_;
    wasmetal_core__DOT___061749_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061750_;
    wasmetal_core__DOT___061750_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061751_;
    wasmetal_core__DOT___061751_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061752_;
    wasmetal_core__DOT___061752_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061753_;
    wasmetal_core__DOT___061753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061754_;
    wasmetal_core__DOT___061754_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061792_;
    wasmetal_core__DOT___061792_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061807_;
    wasmetal_core__DOT___061807_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061808_;
    wasmetal_core__DOT___061808_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061809_;
    wasmetal_core__DOT___061809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061818_;
    wasmetal_core__DOT___061818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061819_;
    wasmetal_core__DOT___061819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061820_;
    wasmetal_core__DOT___061820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061821_;
    wasmetal_core__DOT___061821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061822_;
    wasmetal_core__DOT___061822_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061823_;
    wasmetal_core__DOT___061823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061824_;
    wasmetal_core__DOT___061824_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061825_;
    wasmetal_core__DOT___061825_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061826_;
    wasmetal_core__DOT___061826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061827_;
    wasmetal_core__DOT___061827_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061829_;
    wasmetal_core__DOT___061829_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061864_;
    wasmetal_core__DOT___061864_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061879_;
    wasmetal_core__DOT___061879_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061880_;
    wasmetal_core__DOT___061880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061886_;
    wasmetal_core__DOT___061886_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061887_;
    wasmetal_core__DOT___061887_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061888_;
    wasmetal_core__DOT___061888_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061889_;
    wasmetal_core__DOT___061889_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061890_;
    wasmetal_core__DOT___061890_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061891_;
    wasmetal_core__DOT___061891_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061892_;
    wasmetal_core__DOT___061892_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061893_;
    wasmetal_core__DOT___061893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061894_;
    wasmetal_core__DOT___061894_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061895_;
    wasmetal_core__DOT___061895_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061897_;
    wasmetal_core__DOT___061897_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061926_;
    wasmetal_core__DOT___061926_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061936_;
    wasmetal_core__DOT___061936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061947_;
    wasmetal_core__DOT___061947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061948_;
    wasmetal_core__DOT___061948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061949_;
    wasmetal_core__DOT___061949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061957_;
    wasmetal_core__DOT___061957_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061958_;
    wasmetal_core__DOT___061958_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061959_;
    wasmetal_core__DOT___061959_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061960_;
    wasmetal_core__DOT___061960_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061982_;
    wasmetal_core__DOT___061982_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062006_;
    wasmetal_core__DOT___062006_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062008_;
    wasmetal_core__DOT___062008_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062009_;
    wasmetal_core__DOT___062009_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062017_;
    wasmetal_core__DOT___062017_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062018_;
    wasmetal_core__DOT___062018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062019_;
    wasmetal_core__DOT___062019_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062020_;
    wasmetal_core__DOT___062020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062043_;
    wasmetal_core__DOT___062043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062069_;
    wasmetal_core__DOT___062069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062070_;
    wasmetal_core__DOT___062070_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062076_;
    wasmetal_core__DOT___062076_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062077_;
    wasmetal_core__DOT___062077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062078_;
    wasmetal_core__DOT___062078_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062079_;
    wasmetal_core__DOT___062079_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062101_;
    wasmetal_core__DOT___062101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062125_;
    wasmetal_core__DOT___062125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062126_;
    wasmetal_core__DOT___062126_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062127_;
    wasmetal_core__DOT___062127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062130_;
    wasmetal_core__DOT___062130_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062131_;
    wasmetal_core__DOT___062131_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062132_;
    wasmetal_core__DOT___062132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062133_;
    wasmetal_core__DOT___062133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062172_;
    wasmetal_core__DOT___062172_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062183_;
    wasmetal_core__DOT___062183_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062192_;
    wasmetal_core__DOT___062192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064003_;
    wasmetal_core__DOT___064003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064016_;
    wasmetal_core__DOT___064016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064528_;
    wasmetal_core__DOT___064528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064542_;
    wasmetal_core__DOT___064542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064765_;
    wasmetal_core__DOT___064765_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064773_;
    wasmetal_core__DOT___064773_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064937_;
    wasmetal_core__DOT___064937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065087_;
    wasmetal_core__DOT___065087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065088_;
    wasmetal_core__DOT___065088_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065209_;
    wasmetal_core__DOT___065209_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065318_;
    wasmetal_core__DOT___065318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065321_;
    wasmetal_core__DOT___065321_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065431_;
    wasmetal_core__DOT___065431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065627_;
    wasmetal_core__DOT___065627_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065715_;
    wasmetal_core__DOT___065715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065717_;
    wasmetal_core__DOT___065717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065817_;
    wasmetal_core__DOT___065817_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065913_;
    wasmetal_core__DOT___065913_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065915_;
    wasmetal_core__DOT___065915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065947_;
    wasmetal_core__DOT___065947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066092_;
    wasmetal_core__DOT___066092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066137_;
    wasmetal_core__DOT___066137_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066147_;
    wasmetal_core__DOT___066147_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066264_;
    wasmetal_core__DOT___066264_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066290_;
    wasmetal_core__DOT___066290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066294_;
    wasmetal_core__DOT___066294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066328_;
    wasmetal_core__DOT___066328_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066333_;
    wasmetal_core__DOT___066333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066417_;
    wasmetal_core__DOT___066417_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066542_;
    wasmetal_core__DOT___066542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066614_;
    wasmetal_core__DOT___066614_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066618_;
    wasmetal_core__DOT___066618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071577_;
    wasmetal_core__DOT___071577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071579_;
    wasmetal_core__DOT___071579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071581_;
    wasmetal_core__DOT___071581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071600_;
    wasmetal_core__DOT___071600_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071621_;
    wasmetal_core__DOT___071621_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071661_;
    wasmetal_core__DOT___071661_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071670_;
    wasmetal_core__DOT___071670_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071683_;
    wasmetal_core__DOT___071683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071692_;
    wasmetal_core__DOT___071692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071699_;
    wasmetal_core__DOT___071699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071712_;
    wasmetal_core__DOT___071712_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071715_;
    wasmetal_core__DOT___071715_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128557___O;
    wasmetal_core__DOT____Vcellout___128557___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128558___O;
    wasmetal_core__DOT____Vcellout___128558___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128559___O;
    wasmetal_core__DOT____Vcellout___128559___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128560___O;
    wasmetal_core__DOT____Vcellout___128560___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128561___O;
    wasmetal_core__DOT____Vcellout___128561___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128562___O;
    wasmetal_core__DOT____Vcellout___128562___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128563___O;
    wasmetal_core__DOT____Vcellout___128563___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128564___O;
    wasmetal_core__DOT____Vcellout___128564___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128565___O;
    wasmetal_core__DOT____Vcellout___128565___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134192___O;
    wasmetal_core__DOT____Vcellout___134192___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134193___O;
    wasmetal_core__DOT____Vcellout___134193___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134194___O;
    wasmetal_core__DOT____Vcellout___134194___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134197___O;
    wasmetal_core__DOT____Vcellout___134197___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134198___O;
    wasmetal_core__DOT____Vcellout___134198___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134199___O;
    wasmetal_core__DOT____Vcellout___134199___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134200___O;
    wasmetal_core__DOT____Vcellout___134200___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134201___O;
    wasmetal_core__DOT____Vcellout___134201___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134202___O;
    wasmetal_core__DOT____Vcellout___134202___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134203___O;
    wasmetal_core__DOT____Vcellout___134203___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134204___O;
    wasmetal_core__DOT____Vcellout___134204___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134205___O;
    wasmetal_core__DOT____Vcellout___134205___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___128557___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128557___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128557___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128557___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128557___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128557___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128558___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128558___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128558___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128558___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128558___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128558___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128559___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128559___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128559___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128559___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128559___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128559___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128560___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128560___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128560___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128560___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128560___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128560___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128561___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128561___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128561___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128561___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128561___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128561___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128562___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128562___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128562___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128562___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128562___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128562___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128563___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128563___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128563___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128563___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128563___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128563___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128564___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128564___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128564___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128564___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128564___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128564___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128565___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128565___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128565___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128565___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134192___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134192___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134192___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134192___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134197___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134197___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134197___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134197___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134197___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134197___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134198___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134198___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134198___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134198___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134198___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134198___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134199___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134199___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134199___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134199___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134199___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134199___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134200___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134200___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134200___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134200___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134200___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134200___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134201___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134201___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134201___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134201___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134201___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134201___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134202___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134202___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134202___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134202___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134202___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134202___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134203___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134203___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134203___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134203___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134203___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134203___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134204___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134204___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134204___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134204___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134204___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134204___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_h2f47e533__0;
    __VdfgTmp_h2f47e533__0 = 0;
    CData/*3:0*/ __VdfgTmp_hd02ee603__0;
    __VdfgTmp_hd02ee603__0 = 0;
    CData/*3:0*/ __VdfgTmp_h395e4cca__0;
    __VdfgTmp_h395e4cca__0 = 0;
    CData/*3:0*/ __VdfgTmp_ha8d7477f__0;
    __VdfgTmp_ha8d7477f__0 = 0;
    CData/*3:0*/ __VdfgTmp_h95f10a6b__0;
    __VdfgTmp_h95f10a6b__0 = 0;
    CData/*3:0*/ __VdfgTmp_haffe2bfa__0;
    __VdfgTmp_haffe2bfa__0 = 0;
    CData/*3:0*/ __VdfgTmp_he7f15d64__0;
    __VdfgTmp_he7f15d64__0 = 0;
    CData/*2:0*/ __VdfgTmp_h55174494__0;
    __VdfgTmp_h55174494__0 = 0;
    CData/*3:0*/ __VdfgTmp_h63303194__0;
    __VdfgTmp_h63303194__0 = 0;
    CData/*3:0*/ __VdfgTmp_hb346f79b__0;
    __VdfgTmp_hb346f79b__0 = 0;
    CData/*3:0*/ __VdfgTmp_h33d05e2b__0;
    __VdfgTmp_h33d05e2b__0 = 0;
    CData/*3:0*/ __VdfgTmp_h02a10d87__0;
    __VdfgTmp_h02a10d87__0 = 0;
    CData/*3:0*/ __VdfgTmp_h24a95b4c__0;
    __VdfgTmp_h24a95b4c__0 = 0;
    CData/*2:0*/ __VdfgTmp_h723ba500__0;
    __VdfgTmp_h723ba500__0 = 0;
    CData/*3:0*/ __VdfgTmp_h3f11249e__0;
    __VdfgTmp_h3f11249e__0 = 0;
    CData/*3:0*/ __VdfgTmp_h30d3a8cd__0;
    __VdfgTmp_h30d3a8cd__0 = 0;
    CData/*3:0*/ __VdfgTmp_hd5c02faf__0;
    __VdfgTmp_hd5c02faf__0 = 0;
    CData/*3:0*/ __VdfgTmp_hae36b2b4__0;
    __VdfgTmp_hae36b2b4__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf6708f22__0;
    __VdfgTmp_hf6708f22__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5fbd0010__0;
    __VdfgTmp_h5fbd0010__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8d260ac4__0;
    __VdfgTmp_h8d260ac4__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha5f5bbd8__0;
    __VdfgTmp_ha5f5bbd8__0 = 0;
    CData/*3:0*/ __VdfgTmp_h84e9cef1__0;
    __VdfgTmp_h84e9cef1__0 = 0;
    CData/*3:0*/ __VdfgTmp_h701da795__0;
    __VdfgTmp_h701da795__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3d2a1d35__0;
    __VdfgTmp_h3d2a1d35__0 = 0;
    CData/*3:0*/ __VdfgTmp_h3a3f8f7c__0;
    __VdfgTmp_h3a3f8f7c__0 = 0;
    CData/*3:0*/ __VdfgTmp_hdb3e6697__0;
    __VdfgTmp_hdb3e6697__0 = 0;
    CData/*2:0*/ __VdfgTmp_hda8f659f__0;
    __VdfgTmp_hda8f659f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8aa7a601__0;
    __VdfgTmp_h8aa7a601__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha144d05d__0;
    __VdfgTmp_ha144d05d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0671f08e__0;
    __VdfgTmp_h0671f08e__0 = 0;
    CData/*4:0*/ __VdfgTmp_ha99d4fb3__0;
    __VdfgTmp_ha99d4fb3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h726ed473__0;
    __VdfgTmp_h726ed473__0 = 0;
    CData/*3:0*/ __VdfgTmp_hd1d61f29__0;
    __VdfgTmp_hd1d61f29__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd80661ae__0;
    __VdfgTmp_hd80661ae__0 = 0;
    CData/*4:0*/ __VdfgTmp_h8d3bd609__0;
    __VdfgTmp_h8d3bd609__0 = 0;
    CData/*1:0*/ __VdfgTmp_h61d5ae24__0;
    __VdfgTmp_h61d5ae24__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2b420f71__0;
    __VdfgTmp_h2b420f71__0 = 0;
    CData/*2:0*/ __VdfgTmp_h721c040d__0;
    __VdfgTmp_h721c040d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h82a6b2ca__0;
    __VdfgTmp_h82a6b2ca__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5377cf96__0;
    __VdfgTmp_h5377cf96__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfa01dcbd__0;
    __VdfgTmp_hfa01dcbd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd8faebc1__0;
    __VdfgTmp_hd8faebc1__0 = 0;
    CData/*2:0*/ __VdfgTmp_hde999c4c__0;
    __VdfgTmp_hde999c4c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h17c622b5__0;
    __VdfgTmp_h17c622b5__0 = 0;
    CData/*5:0*/ __VdfgTmp_h25eab54d__0;
    __VdfgTmp_h25eab54d__0 = 0;
    CData/*5:0*/ __VdfgTmp_h04a610c4__0;
    __VdfgTmp_h04a610c4__0 = 0;
    CData/*2:0*/ __VdfgTmp_had4dbc64__0;
    __VdfgTmp_had4dbc64__0 = 0;
    CData/*2:0*/ __VdfgTmp_h9fff0999__0;
    __VdfgTmp_h9fff0999__0 = 0;
    CData/*2:0*/ __VdfgTmp_h9ef2838e__0;
    __VdfgTmp_h9ef2838e__0 = 0;
    CData/*2:0*/ __VdfgTmp_h20c23734__0;
    __VdfgTmp_h20c23734__0 = 0;
    CData/*2:0*/ __VdfgTmp_h023feeff__0;
    __VdfgTmp_h023feeff__0 = 0;
    CData/*1:0*/ __VdfgTmp_h39713683__0;
    __VdfgTmp_h39713683__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc8ee1f3d__0;
    __VdfgTmp_hc8ee1f3d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h22641916__0;
    __VdfgTmp_h22641916__0 = 0;
    CData/*3:0*/ __VdfgTmp_h3dfe793c__0;
    __VdfgTmp_h3dfe793c__0 = 0;
    CData/*2:0*/ __VdfgTmp_h9a698786__0;
    __VdfgTmp_h9a698786__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2c5953fc__0;
    __VdfgTmp_h2c5953fc__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc46d7186__0;
    __VdfgTmp_hc46d7186__0 = 0;
    CData/*2:0*/ __VdfgTmp_hda29c68f__0;
    __VdfgTmp_hda29c68f__0 = 0;
    CData/*1:0*/ __VdfgTmp_hecb49b12__0;
    __VdfgTmp_hecb49b12__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3b474bf2__0;
    __VdfgTmp_h3b474bf2__0 = 0;
    // Body
    wasmetal_core__DOT___033645_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x22U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O)))));
    wasmetal_core__DOT___033644_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x21U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O)))));
    wasmetal_core__DOT___033643_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x20U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___033642_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1fU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___033641_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1eU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___033639_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1dU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O)))));
    wasmetal_core__DOT___033638_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1cU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___033637_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1bU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___033636_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x1aU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___033635_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x19U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O)))));
    wasmetal_core__DOT___033634_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x18U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___033633_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x17U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___033632_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x16U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___033631_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x15U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O)))));
    wasmetal_core__DOT___033630_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x14U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___033628_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x13U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___033627_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x12U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___033626_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x11U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O)))));
    wasmetal_core__DOT___033625_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0x10U))))));
    wasmetal_core__DOT___033624_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xfU))))));
    wasmetal_core__DOT___033623_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___033622_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___033621_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___033620_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___033619_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___033652_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___033651_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___033650_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___033649_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___033648_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___033647_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___033646_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___033640_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___033629_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___033618_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135195_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum)))));
    wasmetal_core__DOT___128557___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___033618_)) 
                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum)));
    wasmetal_core__DOT___128557___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033629_)
                  ? (IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT___128557___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033640_)
                  ? (IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 2U))));
    wasmetal_core__DOT____Vcellout___128557___O = (
                                                   (((IData)(wasmetal_core__DOT___033646_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033640_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033629_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033618_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    wasmetal_core__DOT___033611_ = (1U & ((IData)(wasmetal_core__DOT___033646_)
                                           ? (IData)(wasmetal_core__DOT___128557___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                      >> 3U))));
    wasmetal_core__DOT___036656_ = (1U & (IData)((0xf4000bff0bfff400ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcb4b0ef5__0)))))));
    wasmetal_core__DOT___036678_ = (1U & (IData)((0xf4000bff0bfff400ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                >> 2U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc7be7ce5__0)))))));
    __VdfgTmp_h2f47e533__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 3U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012165_))));
    __VdfgTmp_hd02ee603__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 1U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056626_))));
    wasmetal_core__DOT___128558___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033647_)
                  ? (IData)(wasmetal_core__DOT___033611_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 4U))));
    wasmetal_core__DOT___037128_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (0x4545ff00ffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(
                                                                              (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                               >> 2U)) 
                                                                      << 4U)) 
                                                                  | ((8U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                                         << 1U)) 
                                                                     | ((4U 
                                                                         & ((0xeU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0)) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056747_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___056749_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x4bb4U 
                                                       >> (IData)(__VdfgTmp_h2f47e533__0))))));
    wasmetal_core__DOT___037120_ = (1U & (0xbbff440U 
                                          >> (((IData)(wasmetal_core__DOT___036678_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_hd02ee603__0))));
    wasmetal_core__DOT___037109_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (0x4545ff00ffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum) 
                                                                      << 4U)) 
                                                                  | ((8U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128557___O) 
                                                                         << 3U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056462_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056461_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___056463_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x4bb4U 
                                                       >> (IData)(__VdfgTmp_hd02ee603__0))))));
    wasmetal_core__DOT___128558___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033648_)
                  ? (IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___134192___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___037109_)) 
                 & (0x4bb4U >> (IData)(__VdfgTmp_hd02ee603__0))));
    wasmetal_core__DOT___128558___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033649_)
                  ? (IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 6U))));
    wasmetal_core__DOT___134192___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___037120_) ? (IData)(wasmetal_core__DOT___134192___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036678_));
    wasmetal_core__DOT____Vcellout___128558___O = (
                                                   (((IData)(wasmetal_core__DOT___033650_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033649_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033648_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033647_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033611_)))));
    wasmetal_core__DOT___033615_ = (1U & ((IData)(wasmetal_core__DOT___033650_)
                                           ? (IData)(wasmetal_core__DOT___128558___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                      >> 7U))));
    wasmetal_core__DOT____Vcellout___134192___O = (
                                                   (((IData)(wasmetal_core__DOT___037128_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037120_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037109_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036656_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134192___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | ((IData)(wasmetal_core__DOT___134192___DOT__CO__BRA__1__KET__) 
                                                       << 2U)));
    wasmetal_core__DOT___037076_ = (1U & ((IData)(wasmetal_core__DOT___037128_)
                                           ? (IData)(wasmetal_core__DOT___134192___DOT__CO__BRA__2__KET__)
                                           : (0x4bb4U 
                                              >> (IData)(__VdfgTmp_h2f47e533__0))));
    __VdfgTmp_h395e4cca__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 7U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128558___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013108_))));
    __VdfgTmp_ha8d7477f__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 6U)) 
                                     << 3U)) | ((4U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___128558___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012811_))));
    __VdfgTmp_h95f10a6b__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 5U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128558___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012620_))));
    __VdfgTmp_haffe2bfa__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 4U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128558___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012448_))));
    wasmetal_core__DOT___128559___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033651_)
                  ? (IData)(wasmetal_core__DOT___033615_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 8U))));
    wasmetal_core__DOT___061560_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134192___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 1U)))))))));
    wasmetal_core__DOT___061561_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134192___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 2U)))))))));
    wasmetal_core__DOT___061562_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134192___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 3U)))))))));
    wasmetal_core__DOT___037132_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h395e4cca__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_ha8d7477f__0))));
    wasmetal_core__DOT___037131_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_ha8d7477f__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h95f10a6b__0))));
    wasmetal_core__DOT___037130_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h95f10a6b__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_haffe2bfa__0))));
    wasmetal_core__DOT___037129_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_haffe2bfa__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h2f47e533__0))));
    wasmetal_core__DOT___128559___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033652_)
                  ? (IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 9U))));
    wasmetal_core__DOT___061565_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061562_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061561_)))));
    wasmetal_core__DOT___134197___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037129_)
                  ? (IData)(wasmetal_core__DOT___037076_)
                  : (0x4bb4U >> (IData)(__VdfgTmp_haffe2bfa__0))));
    wasmetal_core__DOT___128559___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033619_)
                  ? (IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 0xaU))));
    wasmetal_core__DOT___134197___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037130_)
                  ? (IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h95f10a6b__0))));
    wasmetal_core__DOT____Vcellout___128559___O = (
                                                   (((IData)(wasmetal_core__DOT___033620_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033619_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033652_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033651_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033615_)))));
    wasmetal_core__DOT___033584_ = (1U & ((IData)(wasmetal_core__DOT___033620_)
                                           ? (IData)(wasmetal_core__DOT___128559___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                      >> 0xbU))));
    wasmetal_core__DOT___134197___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037131_)
                  ? (IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__1__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_ha8d7477f__0))));
    wasmetal_core__DOT___036690_ = (1U & (IData)((0xf4000bff0bfff400ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                >> 8U)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128559___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf72e2656__0)))))));
    __VdfgTmp_he7f15d64__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xbU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128559___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___056987_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfaf3ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___056985_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h5b3d01ff__0)))))))))));
    __VdfgTmp_h55174494__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xaU)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128559___O) 
                                                    >> 1U)) 
                                                | (1U 
                                                   & (0xf400U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he54a047f__0))))));
    __VdfgTmp_h63303194__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 9U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128559___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011549_))));
    wasmetal_core__DOT___128560___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033621_)
                  ? (IData)(wasmetal_core__DOT___033584_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 0xcU))));
    wasmetal_core__DOT____Vcellout___134197___O = (
                                                   (((IData)(wasmetal_core__DOT___037132_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037131_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037130_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037129_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037076_)))));
    wasmetal_core__DOT___037096_ = (1U & ((IData)(wasmetal_core__DOT___037132_)
                                           ? (IData)(wasmetal_core__DOT___134197___DOT__CO__BRA__2__KET__)
                                           : (0x4bb4U 
                                              >> (IData)(__VdfgTmp_h395e4cca__0))));
    wasmetal_core__DOT___037133_ = (1U & (0xbbff440U 
                                          >> (((IData)(wasmetal_core__DOT___036690_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h395e4cca__0))));
    wasmetal_core__DOT___037100_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_he7f15d64__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_h55174494__0))));
    wasmetal_core__DOT___037099_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x96U 
                                                   >> (IData)(__VdfgTmp_h55174494__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h63303194__0))));
    wasmetal_core__DOT___037134_ = (1U & (9U >> ((2U 
                                                  & ((0x4bb4U 
                                                      >> (IData)(__VdfgTmp_h63303194__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x4545ff00ffffffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                 << 5U) 
                                                                | ((0x10U 
                                                                    & ((IData)(
                                                                               (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                                >> 8U)) 
                                                                       << 4U)) 
                                                                   | ((8U 
                                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128559___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056480_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056479_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___056481_))))))))))));
    wasmetal_core__DOT___128560___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033622_)
                  ? (IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 0xdU))));
    wasmetal_core__DOT___061554_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134197___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 4U)))))))));
    wasmetal_core__DOT___061555_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134197___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 5U)))))))));
    wasmetal_core__DOT___061556_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134197___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 6U)))))))));
    wasmetal_core__DOT___061557_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134197___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 7U)))))))));
    wasmetal_core__DOT___134198___DOT__CO__BRA__0__KET__ 
        = ((IData)(wasmetal_core__DOT___037133_) ? (IData)(wasmetal_core__DOT___037096_)
            : (IData)(wasmetal_core__DOT___036690_));
    wasmetal_core__DOT___128560___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033623_)
                  ? (IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 0xeU))));
    wasmetal_core__DOT___061734_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061554_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061562_)))));
    wasmetal_core__DOT___061559_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061555_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061554_)))));
    wasmetal_core__DOT___061736_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061556_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061555_)))));
    wasmetal_core__DOT___061558_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061557_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061556_)))));
    wasmetal_core__DOT___134198___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037134_)
                  ? (IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h63303194__0))));
    wasmetal_core__DOT____Vcellout___128560___O = (
                                                   (((IData)(wasmetal_core__DOT___033624_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033623_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033622_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033621_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033584_)))));
    wasmetal_core__DOT___033588_ = (1U & ((IData)(wasmetal_core__DOT___033624_)
                                           ? (IData)(wasmetal_core__DOT___128560___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                      >> 0xfU))));
    wasmetal_core__DOT___061566_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061559_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061558_)))));
    wasmetal_core__DOT___134198___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037099_)
                  ? (IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__1__KET__)
                  : (0x96U >> (IData)(__VdfgTmp_h55174494__0))));
    __VdfgTmp_hb346f79b__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xfU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128560___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057635_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfcfaULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___057633_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56d07f21__0))))))))))))));
    __VdfgTmp_h33d05e2b__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xeU)) 
                                     << 3U)) | ((4U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___128560___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057388_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfcfaULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___057386_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012804_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010722_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012934_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012931_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010722_)))))))))))))))))));
    __VdfgTmp_h02a10d87__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xdU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128560___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057322_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0feULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___057320_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2163f181__0)))))))))));
    __VdfgTmp_h24a95b4c__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0xcU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128560___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012449_))));
    wasmetal_core__DOT___128561___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033625_)
                  ? (IData)(wasmetal_core__DOT___033588_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                             >> 0x10U))));
    wasmetal_core__DOT____Vcellout___134198___O = (
                                                   (((IData)(wasmetal_core__DOT___037100_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037099_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037134_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037133_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037096_)))));
    wasmetal_core__DOT___037045_ = (1U & ((IData)(wasmetal_core__DOT___037100_)
                                           ? (IData)(wasmetal_core__DOT___134198___DOT__CO__BRA__2__KET__)
                                           : (0x4bb4U 
                                              >> (IData)(__VdfgTmp_he7f15d64__0))));
    wasmetal_core__DOT___037104_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_hb346f79b__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h33d05e2b__0))));
    wasmetal_core__DOT___037103_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h33d05e2b__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h02a10d87__0))));
    wasmetal_core__DOT___037102_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h02a10d87__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h24a95b4c__0))));
    wasmetal_core__DOT___037101_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h24a95b4c__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_he7f15d64__0))));
    wasmetal_core__DOT___128561___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033626_)
                  ? (IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O)));
    wasmetal_core__DOT___061567_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134198___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 8U)))))))));
    wasmetal_core__DOT___061568_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134198___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 9U)))))))));
    wasmetal_core__DOT___061569_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134198___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xaU)))))))));
    wasmetal_core__DOT___061570_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134198___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xbU)))))))));
    wasmetal_core__DOT___134199___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037101_)
                  ? (IData)(wasmetal_core__DOT___037045_)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h24a95b4c__0))));
    wasmetal_core__DOT___128561___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033627_)
                  ? (IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                     >> 1U)));
    wasmetal_core__DOT___061735_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061567_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061557_)))));
    wasmetal_core__DOT___061572_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061568_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061567_)))));
    wasmetal_core__DOT___061729_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061569_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061568_)))));
    wasmetal_core__DOT___061571_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061570_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061569_)))));
    wasmetal_core__DOT___134199___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037102_)
                  ? (IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h02a10d87__0))));
    wasmetal_core__DOT____Vcellout___128561___O = (
                                                   (((IData)(wasmetal_core__DOT___033628_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033627_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033626_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033625_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033588_)))));
    wasmetal_core__DOT___033592_ = (1U & ((IData)(wasmetal_core__DOT___033628_)
                                           ? (IData)(wasmetal_core__DOT___128561___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                              >> 2U)));
    wasmetal_core__DOT___061737_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061736_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061735_)))));
    wasmetal_core__DOT___061824_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061558_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061572_)))));
    wasmetal_core__DOT___061892_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061735_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061729_)))));
    wasmetal_core__DOT___061580_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061572_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061571_)))));
    wasmetal_core__DOT___134199___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037103_)
                  ? (IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__1__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h33d05e2b__0))));
    __VdfgTmp_h723ba500__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x13U)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128561___O) 
                                                    >> 2U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xf0f3f0fa00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056916_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072012_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072011_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072006_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011869_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056433_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011870_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011379_))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___072009_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___072013_))))))))))))))));
    __VdfgTmp_h3f11249e__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x12U)) 
                                     << 3U)) | ((4U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___128561___O)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011950_))));
    __VdfgTmp_h30d3a8cd__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x11U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128561___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011295_))));
    __VdfgTmp_hd5c02faf__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x10U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128561___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011092_))));
    wasmetal_core__DOT___128562___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033630_)
                  ? (IData)(wasmetal_core__DOT___033592_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                     >> 3U)));
    wasmetal_core__DOT____Vcellout___134199___O = (
                                                   (((IData)(wasmetal_core__DOT___037104_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037103_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037102_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037101_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037045_)))));
    wasmetal_core__DOT___037049_ = (1U & ((IData)(wasmetal_core__DOT___037104_)
                                           ? (IData)(wasmetal_core__DOT___134199___DOT__CO__BRA__2__KET__)
                                           : (0x4bb4U 
                                              >> (IData)(__VdfgTmp_hb346f79b__0))));
    wasmetal_core__DOT___037108_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x96U 
                                                   >> (IData)(__VdfgTmp_h723ba500__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h3f11249e__0))));
    wasmetal_core__DOT___037107_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h3f11249e__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h30d3a8cd__0))));
    wasmetal_core__DOT___037106_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h30d3a8cd__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_hd5c02faf__0))));
    wasmetal_core__DOT___037105_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_hd5c02faf__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_hb346f79b__0))));
    wasmetal_core__DOT___128562___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033631_)
                  ? (IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O)));
    wasmetal_core__DOT___061573_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134199___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xcU)))))))));
    wasmetal_core__DOT___061574_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134199___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xdU)))))))));
    wasmetal_core__DOT___061575_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134199___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xeU)))))))));
    wasmetal_core__DOT___061576_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134199___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0xfU)))))))));
    wasmetal_core__DOT___134200___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037105_)
                  ? (IData)(wasmetal_core__DOT___037049_)
                  : (0x4bb4U >> (IData)(__VdfgTmp_hd5c02faf__0))));
    wasmetal_core__DOT___128562___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033632_)
                  ? (IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                     >> 1U)));
    wasmetal_core__DOT___061728_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061573_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061570_)))));
    wasmetal_core__DOT___061578_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061574_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061573_)))));
    wasmetal_core__DOT___061731_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061575_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061574_)))));
    wasmetal_core__DOT___061577_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061576_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061575_)))));
    wasmetal_core__DOT___134200___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037106_)
                  ? (IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h30d3a8cd__0))));
    wasmetal_core__DOT____Vcellout___128562___O = (
                                                   (((IData)(wasmetal_core__DOT___033633_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033632_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033631_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033630_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033592_)))));
    wasmetal_core__DOT___033597_ = (1U & ((IData)(wasmetal_core__DOT___033633_)
                                           ? (IData)(wasmetal_core__DOT___128562___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                              >> 2U)));
    wasmetal_core__DOT___061733_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061729_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061728_)))));
    wasmetal_core__DOT___061826_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061571_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061578_)))));
    wasmetal_core__DOT___061894_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061728_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061731_)))));
    wasmetal_core__DOT___061579_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061578_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061577_)))));
    wasmetal_core__DOT___134200___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037107_)
                  ? (IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__1__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h3f11249e__0))));
    __VdfgTmp_hae36b2b4__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x17U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128562___O) 
                                                    >> 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057665_))));
    __VdfgTmp_hf6708f22__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x16U)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128562___O) 
                                                    >> 1U)) 
                                                | (1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___057455_))))));
    __VdfgTmp_h5fbd0010__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x15U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128562___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012753_))));
    __VdfgTmp_h8d260ac4__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x14U)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128562___O) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xf0f3f0fa00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012477_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h187b70d7__0))))))))));
    wasmetal_core__DOT___128563___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033634_)
                  ? (IData)(wasmetal_core__DOT___033597_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                     >> 3U)));
    wasmetal_core__DOT___061581_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061580_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061579_)))));
    wasmetal_core__DOT____Vcellout___134200___O = (
                                                   (((IData)(wasmetal_core__DOT___037108_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037107_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037106_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037105_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037049_)))));
    wasmetal_core__DOT___037053_ = (1U & ((IData)(wasmetal_core__DOT___037108_)
                                           ? (IData)(wasmetal_core__DOT___134200___DOT__CO__BRA__2__KET__)
                                           : (0x96U 
                                              >> (IData)(__VdfgTmp_h723ba500__0))));
    wasmetal_core__DOT___037113_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_hae36b2b4__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_hf6708f22__0))));
    wasmetal_core__DOT___037112_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x96U 
                                                   >> (IData)(__VdfgTmp_hf6708f22__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h5fbd0010__0))));
    wasmetal_core__DOT___037111_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h5fbd0010__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_h8d260ac4__0))));
    wasmetal_core__DOT___037110_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x96U 
                                                   >> (IData)(__VdfgTmp_h8d260ac4__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_h723ba500__0))));
    wasmetal_core__DOT___128563___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033635_)
                  ? (IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O)));
    wasmetal_core__DOT___061520_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134200___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                     >> 0x10U)))))))));
    wasmetal_core__DOT___061521_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134200___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O))))))));
    wasmetal_core__DOT___061523_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134200___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___061524_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134200___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___134201___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037110_)
                  ? (IData)(wasmetal_core__DOT___037053_)
                  : (0x96U >> (IData)(__VdfgTmp_h8d260ac4__0))));
    wasmetal_core__DOT___128563___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033636_)
                  ? (IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                     >> 1U)));
    wasmetal_core__DOT___061730_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061520_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061576_)))));
    wasmetal_core__DOT___061526_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061521_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061520_)))));
    wasmetal_core__DOT___061741_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061523_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061521_)))));
    wasmetal_core__DOT___061525_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061524_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061523_)))));
    wasmetal_core__DOT___134201___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037111_)
                  ? (IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h5fbd0010__0))));
    wasmetal_core__DOT____Vcellout___128563___O = (
                                                   (((IData)(wasmetal_core__DOT___033637_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033636_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033635_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033634_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033597_)))));
    wasmetal_core__DOT___033601_ = (1U & ((IData)(wasmetal_core__DOT___033637_)
                                           ? (IData)(wasmetal_core__DOT___128563___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                              >> 2U)));
    wasmetal_core__DOT___061732_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061731_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061730_)))));
    wasmetal_core__DOT___061825_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061577_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061526_)))));
    wasmetal_core__DOT___061893_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061730_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061741_)))));
    wasmetal_core__DOT___061535_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061526_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061525_)))));
    wasmetal_core__DOT___134201___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037112_)
                  ? (IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__1__KET__)
                  : (0x96U >> (IData)(__VdfgTmp_hf6708f22__0))));
    wasmetal_core__DOT___036674_ = (1U & (0xe01f1fe0U 
                                          >> ((0x10U 
                                               & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                           >> 0x1aU)) 
                                                  << 4U)) 
                                              | ((8U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128563___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbeb24dc6__0))))));
    __VdfgTmp_ha5f5bbd8__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x1bU)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128563___O) 
                                                    >> 2U)) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xf0f3f0fa00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056905_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xf0f5555333300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072012_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072014_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072011_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___072009_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___072013_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa759b39__0))))))))))))));
    __VdfgTmp_h84e9cef1__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x19U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128563___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011427_))));
    __VdfgTmp_h701da795__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x18U)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128563___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011129_))));
    wasmetal_core__DOT___128564___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033638_)
                  ? (IData)(wasmetal_core__DOT___033601_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                     >> 3U)));
    wasmetal_core__DOT___061739_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061733_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061732_)))));
    wasmetal_core__DOT___061827_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061826_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061825_)))));
    wasmetal_core__DOT___061895_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061894_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061893_)))));
    wasmetal_core__DOT___061957_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061579_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061535_)))));
    wasmetal_core__DOT____Vcellout___134201___O = (
                                                   (((IData)(wasmetal_core__DOT___037113_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037112_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037111_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037110_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037053_)))));
    wasmetal_core__DOT___037058_ = (1U & ((IData)(wasmetal_core__DOT___037113_)
                                           ? (IData)(wasmetal_core__DOT___134201___DOT__CO__BRA__2__KET__)
                                           : (0x4bb4U 
                                              >> (IData)(__VdfgTmp_hae36b2b4__0))));
    wasmetal_core__DOT___037117_ = (1U & (IData)((0x11f0ffffee0f000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x96U 
                                                        >> (IData)(__VdfgTmp_ha5f5bbd8__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                      >> 0x1aU)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___128563___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbeb24dc6__0))))))));
    wasmetal_core__DOT___037116_ = (1U & (0xbbff440U 
                                          >> (((IData)(wasmetal_core__DOT___036674_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h84e9cef1__0))));
    wasmetal_core__DOT___037115_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h84e9cef1__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_h701da795__0))));
    wasmetal_core__DOT___037114_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h701da795__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_hae36b2b4__0))));
    wasmetal_core__DOT___128564___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033639_)
                  ? (IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O)));
    wasmetal_core__DOT___061528_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134201___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___061529_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134201___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O))))))));
    wasmetal_core__DOT___061530_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134201___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___061531_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134201___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___134202___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037114_)
                  ? (IData)(wasmetal_core__DOT___037058_)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h701da795__0))));
    wasmetal_core__DOT___128564___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033641_)
                  ? (IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                     >> 1U)));
    wasmetal_core__DOT___061740_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061528_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061524_)))));
    wasmetal_core__DOT___061533_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061529_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061528_)))));
    wasmetal_core__DOT___061743_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061530_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061529_)))));
    wasmetal_core__DOT___061532_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061531_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061530_)))));
    wasmetal_core__DOT___134202___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037115_)
                  ? (IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h84e9cef1__0))));
    wasmetal_core__DOT___033606_ = (1U & ((IData)(wasmetal_core__DOT___033642_)
                                           ? (IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__2__KET__)
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                              >> 2U)));
    wasmetal_core__DOT____Vcellout___128564___O = (
                                                   (((IData)(wasmetal_core__DOT___033642_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___033641_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___033639_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033638_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128564___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033601_)))));
    wasmetal_core__DOT___061745_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061741_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061740_)))));
    wasmetal_core__DOT___061819_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061525_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061533_)))));
    wasmetal_core__DOT___061887_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061740_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061743_)))));
    wasmetal_core__DOT___061534_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061533_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061532_)))));
    wasmetal_core__DOT___134202___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___037116_) ? (IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036674_));
    wasmetal_core__DOT___128565___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033643_)
                  ? (IData)(wasmetal_core__DOT___033606_)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                     >> 3U)));
    __VdfgTmp_h3d2a1d35__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x1fU)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128564___O) 
                                                    >> 2U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___072025_)));
    wasmetal_core__DOT___036679_ = (1U & (IData)((0xf1000eff0efff100ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                >> 0x1eU)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128564___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057445_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___057444_)))))))));
    __VdfgTmp_h3a3f8f7c__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x1dU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128564___O) 
                                                    << 1U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012708_))));
    __VdfgTmp_hdb3e6697__0 = ((8U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x1cU)) 
                                     << 3U)) | ((4U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128564___O) 
                                                    << 2U)) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057220_))));
    wasmetal_core__DOT___062017_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061732_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061745_)))));
    wasmetal_core__DOT___062076_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061825_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061819_)))));
    wasmetal_core__DOT___062133_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061893_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061887_)))));
    wasmetal_core__DOT___061552_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061535_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061534_)))));
    wasmetal_core__DOT____Vcellout___134202___O = (
                                                   (((IData)(wasmetal_core__DOT___037117_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037116_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037115_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037114_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037058_)))));
    wasmetal_core__DOT___037062_ = (1U & ((IData)(wasmetal_core__DOT___037117_)
                                           ? (IData)(wasmetal_core__DOT___134202___DOT__CO__BRA__2__KET__)
                                           : (0x96U 
                                              >> (IData)(__VdfgTmp_ha5f5bbd8__0))));
    wasmetal_core__DOT___128565___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___033644_)
                  ? (IData)(wasmetal_core__DOT___128565___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O)));
    wasmetal_core__DOT___037122_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (0x5454ff00ffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(
                                                                              (vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                                                               >> 0x1eU)) 
                                                                      << 4U)) 
                                                                  | ((8U 
                                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128564___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057444_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___057445_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(__VdfgTmp_h3d2a1d35__0))))));
    wasmetal_core__DOT___037121_ = (1U & (0xbbff440U 
                                          >> (((IData)(wasmetal_core__DOT___036679_) 
                                               << 4U) 
                                              | (IData)(__VdfgTmp_h3a3f8f7c__0))));
    wasmetal_core__DOT___037119_ = (1U & (0xbbff440U 
                                          >> ((0x10U 
                                               & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_h3a3f8f7c__0)) 
                                                  << 4U)) 
                                              | (IData)(__VdfgTmp_hdb3e6697__0))));
    wasmetal_core__DOT___037118_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x4bb4U 
                                                   >> (IData)(__VdfgTmp_hdb3e6697__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_ha5f5bbd8__0))));
    wasmetal_core__DOT___061537_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134202___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___061538_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134202___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O))))))));
    wasmetal_core__DOT___061539_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134202___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___061540_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134202___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT____Vcellout___128565___O = (
                                                   ((0xcU 
                                                     & ((- (IData)((IData)(wasmetal_core__DOT___033645_))) 
                                                        << 2U)) 
                                                    | (((IData)(wasmetal_core__DOT___033644_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___033643_))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((IData)(wasmetal_core__DOT___033645_)
                                                          ? (IData)(wasmetal_core__DOT___128565___DOT__CO__BRA__1__KET__)
                                                          : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O)) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___128565___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128565___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___033606_)))));
    wasmetal_core__DOT___134203___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037118_)
                  ? (IData)(wasmetal_core__DOT___037062_)
                  : (0x4bb4U >> (IData)(__VdfgTmp_hdb3e6697__0))));
    wasmetal_core__DOT___061742_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061537_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061531_)))));
    wasmetal_core__DOT___061542_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061538_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061537_)))));
    wasmetal_core__DOT___061747_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061539_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061538_)))));
    wasmetal_core__DOT___061541_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061540_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061539_)))));
    wasmetal_core__DOT___037126_ = (1U & (0x718eU >> 
                                          ((0xcU & (IData)(wasmetal_core__DOT____Vcellout___128565___O)) 
                                           | (IData)(vlSelf->__VdfgTmp_ha304a668__0))));
    wasmetal_core__DOT___036683_ = (1U & (0x96U >> 
                                          ((4U & (IData)(wasmetal_core__DOT____Vcellout___128565___O)) 
                                           | (IData)(vlSelf->__VdfgTmp_ha304a668__0))));
    __VdfgTmp_hda8f659f__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x21U)) 
                                     << 2U)) | ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___128565___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___072025_)));
    __VdfgTmp_h8aa7a601__0 = ((4U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___135196_.__PVT__alu_sum 
                                              >> 0x20U)) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___128565___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___072025_)));
    vlSelf->__VdfgTmp_h99ca88a1__0 = ((4U & ((IData)(wasmetal_core__DOT____Vcellout___128565___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_ha304a668__0));
    wasmetal_core__DOT___134203___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037119_)
                  ? (IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__0__KET__)
                  : (0x4bb4U >> (IData)(__VdfgTmp_h3a3f8f7c__0))));
    wasmetal_core__DOT___061744_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061743_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061742_)))));
    wasmetal_core__DOT___061818_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061532_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061542_)))));
    wasmetal_core__DOT___061886_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061742_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061747_)))));
    wasmetal_core__DOT___061550_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061542_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061541_)))));
    wasmetal_core__DOT___037125_ = (1U & (0x4db2U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128565___O) 
                                                  << 1U)) 
                                           | (IData)(__VdfgTmp_hda8f659f__0))));
    wasmetal_core__DOT___037124_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x96U 
                                                   >> (IData)(__VdfgTmp_hda8f659f__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_h8aa7a601__0))));
    wasmetal_core__DOT___037123_ = (1U & (0x17e8U >> 
                                          ((8U & ((0x96U 
                                                   >> (IData)(__VdfgTmp_h8aa7a601__0)) 
                                                  << 3U)) 
                                           | (IData)(__VdfgTmp_h3d2a1d35__0))));
    wasmetal_core__DOT___134203___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___037121_) ? (IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036679_));
    wasmetal_core__DOT___061753_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061745_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061744_)))));
    wasmetal_core__DOT___061823_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061819_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061818_)))));
    wasmetal_core__DOT___061891_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061887_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061886_)))));
    wasmetal_core__DOT___061959_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061534_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061550_)))));
    wasmetal_core__DOT___037067_ = (1U & ((IData)(wasmetal_core__DOT___037122_)
                                           ? (IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__2__KET__)
                                           : (0x96U 
                                              >> (IData)(__VdfgTmp_h3d2a1d35__0))));
    wasmetal_core__DOT____Vcellout___134203___O = (
                                                   (((IData)(wasmetal_core__DOT___037122_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037121_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037119_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037118_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134203___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037062_)))));
    wasmetal_core__DOT___134204___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037123_)
                  ? (IData)(wasmetal_core__DOT___037067_)
                  : (0x96U >> (IData)(__VdfgTmp_h8aa7a601__0))));
    wasmetal_core__DOT___061543_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134203___O) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___061544_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134203___O) 
                                                        << 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O))))))));
    wasmetal_core__DOT___061545_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___134203___O)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                             >> 1U))))))));
    wasmetal_core__DOT___061546_ = (1U & (0x33550f0fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___134203___O) 
                                                        >> 1U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                             >> 2U))))))));
    wasmetal_core__DOT___134204___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___037124_)
                  ? (IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__0__KET__)
                  : (0x96U >> (IData)(__VdfgTmp_hda8f659f__0))));
    wasmetal_core__DOT___061746_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061543_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061540_)))));
    wasmetal_core__DOT___061548_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061544_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061543_)))));
    wasmetal_core__DOT___061749_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061545_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061544_)))));
    wasmetal_core__DOT___061748_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___061546_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061522_))));
    wasmetal_core__DOT___061547_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061546_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061545_)))));
    wasmetal_core__DOT___134204___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___037125_) ? (IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036683_));
    wasmetal_core__DOT___061751_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061747_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061746_)))));
    wasmetal_core__DOT___061821_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061541_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061548_)))));
    wasmetal_core__DOT___061889_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061746_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061749_)))));
    wasmetal_core__DOT___061888_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___061748_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061527_))));
    wasmetal_core__DOT___061750_ = (1U & (0x5cU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061749_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061748_)))));
    wasmetal_core__DOT___061820_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061547_))));
    wasmetal_core__DOT___061549_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061548_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061547_)))));
    wasmetal_core__DOT____Vcellout___134204___O = (
                                                   (((IData)(wasmetal_core__DOT___037126_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___037125_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___037124_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037123_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___037067_)))));
    wasmetal_core__DOT___037071_ = (1U & ((IData)(wasmetal_core__DOT___037126_)
                                           ? (IData)(wasmetal_core__DOT___134204___DOT__CO__BRA__2__KET__)
                                           : (0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0))));
    wasmetal_core__DOT___062019_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061744_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061751_)))));
    wasmetal_core__DOT___062078_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061818_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061821_)))));
    wasmetal_core__DOT___062131_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061886_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061889_)))));
    wasmetal_core__DOT___061890_ = (1U & (0x5cU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061889_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061888_)))));
    wasmetal_core__DOT___062130_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___061888_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061536_))));
    wasmetal_core__DOT___062018_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061750_))));
    wasmetal_core__DOT___061752_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061751_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061750_)))));
    wasmetal_core__DOT___062077_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___061820_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061536_))));
    wasmetal_core__DOT___061822_ = (1U & (0x5cU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061821_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061820_)))));
    wasmetal_core__DOT___061958_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061549_))));
    wasmetal_core__DOT___061551_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061550_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061549_)))));
    wasmetal_core__DOT___065817_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & (IData)(wasmetal_core__DOT____Vcellout___134204___O)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___065627_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134204___O) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___065715_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134204___O) 
                                                << 1U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___065913_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134204___O) 
                                                >> 1U)) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    if ((1U & (0x7eU >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)))) {
        wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___037071_));
        wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___037075_ = (1U & (IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___037075_));
        wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___037080_ = (1U & (IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__));
        wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___037080_));
        wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___037084_ = (1U 
                                                & (IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___134195___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___037084_));
        vlSelf->wasmetal_core__DOT___134195___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___134195___DOT__CO__BRA__0__KET__));
    } else {
        wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___037075_ = (1U & (0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___037080_ = (1U & (0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        vlSelf->wasmetal_core__DOT___037084_ = (1U 
                                                & (0x96U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        vlSelf->wasmetal_core__DOT___134195___DOT__CO__BRA__0__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
        vlSelf->wasmetal_core__DOT___134195___DOT__CO__BRA__1__KET__ 
            = (1U & (0x96U >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0)));
    }
    wasmetal_core__DOT___061897_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061891_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061890_)))));
    wasmetal_core__DOT___062132_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___062131_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___062130_)))));
    wasmetal_core__DOT___062020_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___062019_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___062018_)))));
    wasmetal_core__DOT___061754_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061753_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061752_)))));
    wasmetal_core__DOT___062079_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___062078_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___062077_)))));
    wasmetal_core__DOT___061829_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061823_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061822_)))));
    wasmetal_core__DOT___061960_ = (1U & (0xc5U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061959_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061958_)))));
    wasmetal_core__DOT___061583_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061552_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061551_)))));
    vlSelf->wasmetal_core__DOT___065818_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061822_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065817_)))));
    vlSelf->wasmetal_core__DOT___065628_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061551_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065627_)))));
    vlSelf->wasmetal_core__DOT___065716_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061752_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065715_)))));
    vlSelf->wasmetal_core__DOT___065914_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061890_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065913_)))));
    wasmetal_core__DOT___061926_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061897_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf0f0aaccU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___061892_) 
                                                                    << 2U) 
                                                                   | (((IData)(wasmetal_core__DOT___061734_) 
                                                                       << 1U) 
                                                                      | (IData)(wasmetal_core__DOT___061736_)))))) 
                                                           << 1U)) 
                                                       | (IData)(wasmetal_core__DOT___061895_)))))));
    __VdfgTmp_ha144d05d__0 = ((2U & ((IData)((0xaaccf0f000000000ULL 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                         << 3U) 
                                                        | (((IData)(wasmetal_core__DOT___062133_) 
                                                            << 2U) 
                                                           | (((IData)(wasmetal_core__DOT___061892_) 
                                                               << 1U) 
                                                              | (IData)(wasmetal_core__DOT___061894_)))))))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___062132_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___061584_)))));
    wasmetal_core__DOT___062043_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xaaccf0f0U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___062017_) 
                                                         << 2U) 
                                                        | (((IData)(wasmetal_core__DOT___061737_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___061733_)))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___062020_)))));
    wasmetal_core__DOT___061792_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xaaccf0f0U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___061739_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xf0f0ccaaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                                                     << 3U) 
                                                                    | (((IData)(wasmetal_core__DOT___061734_) 
                                                                        << 2U) 
                                                                       | (((IData)(wasmetal_core__DOT___061561_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___061560_)))))) 
                                                               << 1U)) 
                                                           | (IData)(wasmetal_core__DOT___061737_)))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___061754_)))));
    wasmetal_core__DOT___062101_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xaaccf0f0U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___062076_) 
                                                         << 2U) 
                                                        | (((IData)(wasmetal_core__DOT___061824_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___061826_)))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___062079_)))));
    wasmetal_core__DOT___061864_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061829_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf0f0aaccU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___061824_) 
                                                                    << 2U) 
                                                                   | (((IData)(wasmetal_core__DOT___061565_) 
                                                                       << 1U) 
                                                                      | (IData)(wasmetal_core__DOT___061559_)))))) 
                                                           << 1U)) 
                                                       | (IData)(wasmetal_core__DOT___061827_)))))));
    wasmetal_core__DOT___061982_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xaaccf0f0U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___061957_) 
                                                         << 2U) 
                                                        | (((IData)(wasmetal_core__DOT___061566_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___061580_)))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___061960_)))));
    wasmetal_core__DOT___061640_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___061583_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xff00ff00f0f01111ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___061536_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061527_) 
                                                                         << 4U) 
                                                                        | (((IData)(wasmetal_core__DOT___061566_) 
                                                                            << 3U) 
                                                                           | (((IData)(wasmetal_core__DOT___061565_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___134192___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061522_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___061560_))))))))))) 
                                                           << 1U)) 
                                                       | (IData)(wasmetal_core__DOT___061581_)))))));
    vlSelf->wasmetal_core__DOT___065819_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065818_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___061827_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___061823_)))))))));
    vlSelf->wasmetal_core__DOT___065629_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065628_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___061581_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___061552_)))))))));
    wasmetal_core__DOT___065717_ = (1U & (IData)((0x335500000f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065716_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___061739_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___061753_)))))))));
    wasmetal_core__DOT___065915_ = (1U & (IData)((0x335500000f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065914_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___061895_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___061891_)))))))));
    wasmetal_core__DOT___064937_ = (1U & (IData)((0xcf8a000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064934_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064933_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xff0fcc0cff0faa0aULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                                << 5U)) 
                                                                             | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064904_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064931_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064929_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064928_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064502_))))))))))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___061926_)))))))));
    wasmetal_core__DOT___061936_ = (1U & (IData)((0xfca800000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061929_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061928_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    ((4U 
                                                                      & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061924_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057044_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056968_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056984_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010538_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010584_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010767_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010886_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010939_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011513_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010989_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011017_)))))))))))))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061688_)))) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___061926_)))))))));
    wasmetal_core__DOT___065431_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha144d05d__0))));
    wasmetal_core__DOT___062172_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_ha144d05d__0))));
    wasmetal_core__DOT___065209_ = (1U & (IData)((0xf3a200000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065206_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065205_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x1fU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___065178_))) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___062043_)))))))));
    wasmetal_core__DOT___062069_ = (1U & (IData)((0xe000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062047_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062046_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062045_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x60U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___062031_)))) 
                                                                << 2U)) 
                                                            | (((IData)(wasmetal_core__DOT___062043_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061519_)))))))));
    wasmetal_core__DOT___064528_ = (1U & (IData)((0x3f2a00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064525_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064524_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064523_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___061792_)))))))));
    wasmetal_core__DOT___061807_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xe000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___061796_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061795_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061794_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((1U 
                                                                          >> 
                                                                          ((2U 
                                                                            & ((0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061778_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfce0919b__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6b3ca0e__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061782_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3e487a94__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2d6a2af__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf785b2f__0)))))))))))))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0x60U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061773_))))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(wasmetal_core__DOT___061792_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061519_)))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060824_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043528_))))));
    wasmetal_core__DOT___065318_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___062101_))));
    wasmetal_core__DOT___062125_ = (1U & (IData)((0xe000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062105_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062104_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062103_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x60U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___062090_)))) 
                                                                << 2U)) 
                                                            | (((IData)(wasmetal_core__DOT___062101_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061519_)))))))));
    wasmetal_core__DOT___064765_ = (1U & (IData)((0xf7f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064764_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064763_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061864_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064747_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064762_)))))))));
    wasmetal_core__DOT___061879_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xe000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___061868_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061867_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___061866_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xff0faa0aff0fcc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060906_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061853_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d87626c__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0)))))))))))))))))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(wasmetal_core__DOT___061864_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061519_)))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060907_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043528_))))));
    wasmetal_core__DOT___065087_ = (1U & (0xb0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___065086_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___065085_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((1U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___061982_))) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065083_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (0x1fU 
                                                             >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)))))))));
    wasmetal_core__DOT___062006_ = (1U & (IData)((0xe000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061986_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061985_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061984_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x60U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___061971_)))) 
                                                                << 2U)) 
                                                            | (((IData)(wasmetal_core__DOT___061982_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061519_)))))))));
    wasmetal_core__DOT___064003_ = (1U & (0xe0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___064002_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___064001_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0x1f00U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((IData)(
                                                                         (0x45cf000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___063822_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063821_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063820_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063785_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063784_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063783_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063772_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8acf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063766_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h633a8051__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003117_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063768_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063767_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdb184deb__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1eef7f72__0)))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x4100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063764_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063763_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063762_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h491e13b5__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x9000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063746_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063745_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063744_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x4100004100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063742_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h39dd035b__0)))))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb12ee9bf__0))))))))))))))))))))))) 
                                                                 << 2U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___053096_))))) 
                                                        << 2U)) 
                                                    | (((IData)(wasmetal_core__DOT___061640_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))));
    wasmetal_core__DOT___061664_ = (1U & (IData)((0x3f2a00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061643_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061642_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x41U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___048443_)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___061640_)))))))));
    vlSelf->wasmetal_core__DOT___065720_ = (1U & (IData)(
                                                         (0xf0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065718_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___065717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002394_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002392_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002393_)))))))));
    vlSelf->wasmetal_core__DOT___065921_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xf0fd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___065916_) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___065915_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002354_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002352_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___002353_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065917_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064012_)))));
    wasmetal_core__DOT____Vcellout___134205___O = (0xfU 
                                                   & ((- (IData)(
                                                                 (1U 
                                                                  & (0x7eU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0))))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___134205___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___037071_))))));
    vlSelf->wasmetal_core__DOT___065048_ = (1U & (IData)(
                                                         (0x35f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064937_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064936_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___057014_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))));
    wasmetal_core__DOT___061947_ = (1U & (0x4f000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___061937_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___061936_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060977_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___043528_)))))));
    vlSelf->wasmetal_core__DOT___065435_ = (1U & (IData)(
                                                         (0xf0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065432_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___065431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002195_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002196_)))))))));
    wasmetal_core__DOT___062183_ = (1U & (IData)((0xd7000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062174_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062173_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___062172_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061706_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048368_)))))))));
    vlSelf->wasmetal_core__DOT___065211_ = (1U & (IData)(
                                                         (0x2a2a2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065209_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd9c0d0dd__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001677_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065207_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))));
    wasmetal_core__DOT___062070_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___062069_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062068_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062067_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xb0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061145_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___043528_)))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfcf0faf00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___062016_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((7U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055606_)))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___019293_)
                                                                      ? 
                                                                     (0x32U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5050f0f003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062013_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127764___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055917_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055979_)))))))))))))))))
                                                                      : 
                                                                     (0xf0f0c08U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019316_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127760___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))))))))))))))))))))));
    wasmetal_core__DOT___064542_ = (1U & (IData)((0x5f4c00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064528_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064527_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xdU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___001900_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001898_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___001899_)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056352_)))))))));
    wasmetal_core__DOT___061808_ = (1U & (IData)((0xf100000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061807_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061806_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061805_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xff0000f8f8ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061722_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f00000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127757___O) 
                                                                                >> 1U))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054798_)))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xff00fff100000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x30f030f000055ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061724_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055950_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127763___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127761___O) 
                                                                                >> 1U))))))))))))))))))))))))));
    wasmetal_core__DOT___065321_ = (1U & (IData)((0xcfaf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065319_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___065318_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___065317_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xf0f0aaccU 
                                                                     >> 
                                                                     ((0x18U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                          << 1U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065315_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064756_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___064758_))))))))))))));
    wasmetal_core__DOT___062126_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___062125_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062124_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062123_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xb0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061238_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___043528_)))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfcf0faf00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___062075_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((7U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055660_)))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___019293_)
                                                                      ? 
                                                                     (0xeU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0xf1U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5050f0f003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062072_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127764___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055990_))))))))))))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___019292_))))
                                                                      : 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT___019304_)
                                                                           ? 
                                                                          (0xeU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hb5edd3cc__0))
                                                                           : 
                                                                          (0xf8U 
                                                                           >> 
                                                                           ((4U 
                                                                             & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127760___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___019336_))))))
                                                                       ? 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___019291_))
                                                                       : 
                                                                      (0xeU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055013_))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127758___O) 
                                                                                >> 2U)))))))))))))))))))))))))));
    wasmetal_core__DOT___064773_ = (1U & (0xf0fd0000U 
                                          >> (((IData)(wasmetal_core__DOT___064765_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___001949_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001947_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001948_)))))));
    wasmetal_core__DOT___061880_ = (1U & (IData)((0xf100000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061879_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061878_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061877_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xfef0U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xf0f00000cc55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055467_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127757___O) 
                                                                                >> 2U))))))))))))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (0xf888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_)))))))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xff00fff100000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x3030f0f005500ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061813_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127763___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019232_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055891_)))))))))))))))))))))))));
    wasmetal_core__DOT___065088_ = (1U & (0xf0fd0000U 
                                          >> (((IData)(wasmetal_core__DOT___065087_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___001252_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001250_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001251_)))))));
    wasmetal_core__DOT___062008_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062007_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___062006_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062005_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xb0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061669_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061066_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___043528_)))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xfcf0faf00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061956_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((7U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055558_)))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT___019293_)
                                                                      ? 
                                                                     (0x32U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5050f0f003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061953_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127764___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055910_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055972_)))))))))))))))))
                                                                      : 
                                                                     (0xf0f0c08U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019311_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127760___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))))))))))))))))))))));
    wasmetal_core__DOT___064016_ = (1U & (0xf0fd0000U 
                                          >> (((IData)(wasmetal_core__DOT___064003_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___001809_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001807_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___001808_)))))));
    wasmetal_core__DOT___061713_ = (1U & (IData)((0xff4f000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061663_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061662_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048376_)))))))));
    wasmetal_core__DOT___065947_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134205___O) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___066137_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & (IData)(wasmetal_core__DOT____Vcellout___134205___O)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___066092_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134205___O) 
                                                << 1U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___066264_ = (1U & (0x44f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___134205___O) 
                                                >> 1U)) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___061948_ = (1U & (IData)((0xf100000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061947_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061946_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061945_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019291_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xff00fff100000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061448_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5050f0f003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061884_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127763___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055903_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055967_)))))))))))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)
                                                                      ? 
                                                                     (0xeU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019292_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xf888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127759___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048325_))))))))))
                                                                      : 
                                                                     (0xf8U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019293_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0f00000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127757___O) 
                                                                                >> 3U))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___019303_)))))))))))))));
    wasmetal_core__DOT___062192_ = (1U & (0xd0000U 
                                          >> (((IData)(wasmetal_core__DOT___062183_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___062182_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0x3300c5U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___043887_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043528_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2edb9803__0))))) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0x555533330f0f00ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___062179_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13e1c0a0__0))))))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007419_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007414_)))))))))))))))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___061711_)))))));
    wasmetal_core__DOT___019426_ = (1U & (IData)((0xffff000000fe0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___062070_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061193_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061191_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061192_)))))))));
    vlSelf->wasmetal_core__DOT___064720_ = (1U & (IData)(
                                                         (0xf0f0f020f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064542_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064541_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064540_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8f6175c0__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2489b5__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063914_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e5c31ac__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h22bd1162__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063912_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5696d37__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h101b2914__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46a92a2b__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063918_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c266aa9__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064523_)))))))))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064538_)))))))));
    wasmetal_core__DOT___061809_ = (1U & (IData)((0xffff000000fe0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061808_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060863_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060861_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060862_)))))))));
    vlSelf->wasmetal_core__DOT___065324_ = (1U & (IData)(
                                                         (0xf0fd00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___065321_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065320_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001740_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001741_)))))))));
    wasmetal_core__DOT___062127_ = (1U & (IData)((0xffff000000fe0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___062126_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061276_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061274_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061275_)))))))));
    vlSelf->wasmetal_core__DOT___064886_ = (1U & (IData)(
                                                         (0xf5f0f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x35f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064774_) 
                                                                                << 5U) 
                                                                                | (((IData)(wasmetal_core__DOT___064773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012001_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011909_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___011910_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064775_)))))))));
    wasmetal_core__DOT___019299_ = (1U & (0xf0fd0000U 
                                          >> (((IData)(wasmetal_core__DOT___061880_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060941_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1772264d__0))))));
    vlSelf->wasmetal_core__DOT___065171_ = (1U & (0x35f0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065088_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057196_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))));
    wasmetal_core__DOT___062009_ = (1U & (IData)((0xffff000000fe0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___062008_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061111_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019229_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061109_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061110_)))))))));
    vlSelf->wasmetal_core__DOT___064019_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___064016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064015_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064014_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064004_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055363_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064004_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064012_)))))))));
    wasmetal_core__DOT___061716_ = (1U & (IData)((0x8acf000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061714_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___061713_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061712_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0x555533330f0f00ffULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061686_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054699_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h91a424ff__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007433_)))))))))))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0f00003355ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055364_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___065948_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061958_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___065947_)))));
    vlSelf->wasmetal_core__DOT___066138_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___062077_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___066137_)))));
    vlSelf->wasmetal_core__DOT___066093_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___062018_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___066092_)))));
    vlSelf->wasmetal_core__DOT___066265_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___062130_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___066264_)))));
    wasmetal_core__DOT___061949_ = (1U & (0xf0fd0000U 
                                          >> (((IData)(wasmetal_core__DOT___061948_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061026_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h167c6955__0))))));
    wasmetal_core__DOT___019347_ = (1U & (IData)((0xf0fd00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___062192_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062191_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061343_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h5501e8f9__0))))))));
    vlSelf->wasmetal_core__DOT___019427_ = (1U & (IData)(
                                                         (0xff00ff00fff4ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___019426_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he998c60f__0)))))));
    vlSelf->wasmetal_core__DOT___040096_ = (1U & (IData)(
                                                         (0x2aea2a2aeaeaeaeaULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___061809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___025133_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b121__05d)))))))));
    wasmetal_core__DOT___019440_ = (1U & (0x4f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___061809_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___025133_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011740_))))));
    vlSelf->wasmetal_core__DOT___040097_ = (1U & (IData)(
                                                         (0x2aea2a2aeaeaeaeaULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___062127_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___025138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b126__05d)))))))));
    wasmetal_core__DOT___019473_ = (1U & (0x4f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___062127_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___025138_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011740_))))));
    if (vlSelf->wasmetal_core__DOT___011740_) {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d 
            = (1U & (1U >> (IData)(wasmetal_core__DOT___019299_)));
        vlSelf->wasmetal_core__DOT___019420_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___019347_)));
    } else {
        vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d 
            = (1U & (IData)((0xff00fffdfff0ffULL >> 
                             (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___019300_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___019299_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h09a23322__0)))))));
        vlSelf->wasmetal_core__DOT___019420_ = (1U 
                                                & (IData)(
                                                          (0xff00fffefff0ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                                << 4U) 
                                                               | (((IData)(wasmetal_core__DOT___019347_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7c6e85dc__0)))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d 
        = (1U & (IData)((0xff00ff00fff4ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___062009_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h58fc10a4__0)))))));
    wasmetal_core__DOT___061717_ = (1U & (IData)((0xf0fd00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___061716_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061715_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060776_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060720_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc5bdda4d__0))))))));
    vlSelf->wasmetal_core__DOT___065953_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0fcf0f500000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065944_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065950_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065079_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065077_)))))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x335500000f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065948_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT___061957_) 
                                                                               << 1U) 
                                                                              | (IData)(wasmetal_core__DOT___061959_))))))))))));
    wasmetal_core__DOT___066147_ = (1U & (0xb0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___066144_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___066143_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(
                                                                (0x335500000f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066138_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT___062076_) 
                                                                               << 1U) 
                                                                              | (IData)(wasmetal_core__DOT___062078_)))))))) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066141_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (0x1fU 
                                                             >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)))))))));
    vlSelf->wasmetal_core__DOT___066098_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0fcf0f500000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___066089_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___066095_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065196_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065194_)))))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x335500000f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066093_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT___062017_) 
                                                                               << 1U) 
                                                                              | (IData)(wasmetal_core__DOT___062019_))))))))))));
    wasmetal_core__DOT___066290_ = (1U & (IData)((0x553300000f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066265_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___062131_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___062133_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b3__05d 
        = (1U & (IData)((0xff00ff00fff4ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___061949_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2a75aa71__0)))))));
    wasmetal_core__DOT___019455_ = ((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___019427_));
    wasmetal_core__DOT___019442_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d))));
    vlSelf->wasmetal_core__DOT___019540_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                                  | (0x5f33U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___019440_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___019443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d))));
    wasmetal_core__DOT___071621_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                          | (0x335fU 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___019473_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d 
        = (1U & (IData)((0xff00ff00fff4ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___061717_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hefffee35__0)))))));
    vlSelf->wasmetal_core__DOT___066149_ = (1U & (IData)(
                                                         (0x2a2a2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066147_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3fe5e3ea__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002151_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066145_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))));
    wasmetal_core__DOT___066294_ = (1U & (0xb0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___066291_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___066290_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(
                                                                (0xf0fcf0f500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                         << 4U)) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___066272_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066271_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065419_)))))))))))) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066288_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (0x1fU 
                                                             >> (IData)(vlSelf->__VdfgTmp_hcf6e1765__0)))))))));
    wasmetal_core__DOT____Vcellout___134193___O = (0xfU 
                                                   & ((- (IData)(
                                                                 (1U 
                                                                  & (0x7eU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0))))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___134193___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___037075_))))));
    vlSelf->wasmetal_core__DOT___019441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b3__05d))));
    wasmetal_core__DOT___019469_ = (1U & (0x5f3fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b3__05d) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d)))));
    wasmetal_core__DOT___019504_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                          | ((~ (IData)(vlSelf->wasmetal_core__DOT___019418_)) 
                                             | (IData)(
                                                       (0x555533330f0f00ffULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b3__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019427_)))))))));
    wasmetal_core__DOT___019493_ = ((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___019420_));
    wasmetal_core__DOT___019459_ = (1U & (0xf5f3U >> 
                                          ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                  << 2U)) 
                                           | (((IData)(wasmetal_core__DOT___019455_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___019473_)))));
    vlSelf->wasmetal_core__DOT___019447_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___019442_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019440_)))));
    vlSelf->wasmetal_core__DOT___019456_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019443_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019442_)))));
    vlSelf->wasmetal_core__DOT___019590_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071621_))));
    wasmetal_core__DOT___071579_ = (1U & (IData)((0xbbbb00000fffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___019440_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_)))))))));
    vlSelf->wasmetal_core__DOT___019541_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d))));
    wasmetal_core__DOT___071600_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                          | (0x335fU 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___019440_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___019550_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                                  | (IData)(
                                                            (0x55ff33ff0f0fffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___019440_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d))))))));
    wasmetal_core__DOT___019505_ = (1U & (IData)((0xf088000000000000ULL 
                                                  >> 
                                                  ((0x10U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 4U)) 
                                                   | (((IData)(wasmetal_core__DOT___019440_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019418_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___066296_ = (1U & (IData)(
                                                         (0x2a2a2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066294_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066293_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002478_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066292_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))));
    vlSelf->wasmetal_core__DOT___066395_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134193___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066521_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___134193___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066309_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134193___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066598_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134193___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    wasmetal_core__DOT___019549_ = ((IData)(vlSelf->wasmetal_core__DOT___034222_) 
                                    | (IData)(wasmetal_core__DOT___019469_));
    vlSelf->wasmetal_core__DOT___021183_ = (1U & (0xbf30U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b66__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          >> 1U)) 
                                                      | ((((1U 
                                                            & (~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))) 
                                                           || (1U 
                                                               & (0xfffeU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                                         | (IData)(wasmetal_core__DOT___019504_))))))) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfffffffa3fffffffULL 
                                                                       >> 
                                                                       ((0x20U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce5a5a6e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___071584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___019493_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))))));
    wasmetal_core__DOT___019530_ = (1U & (0x10000000U 
                                          >> ((8U & 
                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                << 3U)) 
                                              | ((IData)(wasmetal_core__DOT___019493_) 
                                                 << 2U))));
    vlSelf->wasmetal_core__DOT___019551_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___019493_) 
                                                    << 4U) 
                                                   | (8U 
                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                         << 3U)))));
    vlSelf->__VdfgTmp_h121bab2f__0 = (((IData)(wasmetal_core__DOT___019473_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___019493_));
    vlSelf->__VdfgTmp_hf7bd378e__0 = ((4U & ((8U >> (IData)(vlSelf->wasmetal_core__DOT___019541_)) 
                                             << 2U)) 
                                      | (2U & ((1U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___019540_)) 
                                               << 1U)));
    vlSelf->__VdfgTmp_h64a0b4b6__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 3U)) 
                                      | ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                << 1U)) 
                                         | ((2U & (
                                                   (8U 
                                                    >> 
                                                    (3U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                        >> 2U))) 
                                                   << 1U)) 
                                            | (1U & 
                                               (0x80U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019541_)))))));
    __VdfgTmp_h0671f08e__0 = (((IData)(vlSelf->wasmetal_core__DOT___019541_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019540_));
    vlSelf->__VdfgTmp_hc2641342__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___071600_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___019590_));
    vlSelf->wasmetal_core__DOT___019591_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                         | (IData)(wasmetal_core__DOT___071600_))))));
    __VdfgTmp_hd8faebc1__0 = (((IData)(wasmetal_core__DOT___071600_) 
                               << 1U) | (IData)(wasmetal_core__DOT___071621_));
    vlSelf->wasmetal_core__DOT___071598_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019550_))))));
    wasmetal_core__DOT___019449_ = (1U & (0x8000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___019505_)))));
    __VdfgTmp_hecb49b12__0 = (((IData)(wasmetal_core__DOT___019505_) 
                               << 1U) | (IData)(wasmetal_core__DOT___019504_));
    wasmetal_core__DOT___066417_ = (1U & (IData)((0xe00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066414_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066413_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066412_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xf080f0f0f0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___066402_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___066401_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066400_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf0f03355U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___061754_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT___065715_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066395_)))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))))));
    wasmetal_core__DOT___066542_ = (1U & (IData)((0xe00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066539_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066538_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066537_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xf080f0f0f0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___066528_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___066527_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066526_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf0f03355U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___061829_) 
                                                                            << 2U) 
                                                                           | (((IData)(wasmetal_core__DOT___065817_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066521_)))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))))));
    wasmetal_core__DOT___066328_ = (1U & (IData)((0xf0f0000ccaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___061583_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___065627_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___066309_)))))))));
    wasmetal_core__DOT___066614_ = (1U & (IData)((0xf0f0000ccaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___061897_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___065913_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___066598_)))))))));
    __VdfgTmp_h3b474bf2__0 = (((IData)(vlSelf->wasmetal_core__DOT___019550_) 
                               << 1U) | (IData)(wasmetal_core__DOT___019549_));
    vlSelf->__VdfgTmp_hd96f769d__0 = (((IData)(wasmetal_core__DOT___019459_) 
                                       << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___071584_) 
                                                 << 1U));
    vlSelf->wasmetal_core__DOT___071620_ = (1U & (IData)(
                                                         (0xefffefffefffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071618_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071584_) 
                                                                  << 3U) 
                                                                 | (4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                         << 1U)) 
                                                                       << 2U))))))));
    vlSelf->__VdfgTmp_hde6a7e42__0 = ((2U & ((1U >> (IData)(wasmetal_core__DOT___019549_)) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___019530_));
    wasmetal_core__DOT___071699_ = (1U & (IData)((0xf100000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            >> 1U))) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                             << 3U)) 
                                                         | (((IData)(wasmetal_core__DOT___019530_) 
                                                             << 2U) 
                                                            | (IData)(wasmetal_core__DOT___019549_))))))));
    wasmetal_core__DOT___071577_ = (1U & (0xf5f3U >> 
                                          ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h121bab2f__0))));
    vlSelf->wasmetal_core__DOT___019542_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                  & (IData)(
                                                            (0xaa00cc00f0ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___019455_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h121bab2f__0))))));
    vlSelf->wasmetal_core__DOT___019503_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h121bab2f__0))));
    vlSelf->wasmetal_core__DOT___071608_ = (1U & (0x5c000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 4U)) 
                                                   | ((0xcU 
                                                       & ((~ 
                                                           (1U 
                                                            | (2U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                                  << 1U)))) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h0671f08e__0)))));
    __VdfgTmp_hfa01dcbd__0 = ((4U & ((0x5030000U >> 
                                      ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 4U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                           << 2U) | (IData)(__VdfgTmp_hd8faebc1__0)))) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___071642_)));
    __VdfgTmp_h9fff0999__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 2U)) | (IData)(__VdfgTmp_hd8faebc1__0));
    __VdfgTmp_hd1d61f29__0 = ((0xcU & ((~ (1U | (2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                    << 1U)))) 
                                       << 2U)) | (IData)(__VdfgTmp_hd8faebc1__0));
    vlSelf->__VdfgTmp_h286ec9e0__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | ((2U & ((8U 
                                                 >> 
                                                 (3U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     >> 2U))) 
                                                << 1U)) 
                                         | (IData)(wasmetal_core__DOT___019449_)));
    __VdfgTmp_ha99d4fb3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                               << 4U) | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                << 3U)) 
                                         | (IData)(__VdfgTmp_hecb49b12__0)));
    vlSelf->wasmetal_core__DOT___066420_ = (1U & (IData)(
                                                         (0x444445cf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066332_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h51461c8e__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066394_))))))))))));
    vlSelf->wasmetal_core__DOT___066544_ = (1U & (IData)(
                                                         (0x444445cf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066542_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066332_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h85a07a94__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066520_))))))))))));
    wasmetal_core__DOT___066333_ = (1U & (IData)((0xaf8c00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066329_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___066328_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xffcc0faaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065621_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066325_)))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063997_)))))))));
    wasmetal_core__DOT___066618_ = (1U & (IData)((0xaf8c00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066615_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___066614_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xffcc0faaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065907_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066612_)))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___064931_)))))))));
    vlSelf->wasmetal_core__DOT___071619_ = (1U & (IData)(
                                                         (0x5300000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h3b474bf2__0)))))));
    __VdfgTmp_h22641916__0 = ((2U & (((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))
                                       ? (0xffacffffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                               << 4U) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     << 2U)) 
                                                 | (IData)(__VdfgTmp_h3b474bf2__0))))
                                       : (0xf7U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___019551_))))) 
                                     << 1U)) | (1U 
                                                & (0x53U 
                                                   >> 
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb635a29b__0)))));
    __VdfgTmp_h8d3bd609__0 = ((0x18U & ((~ (1U | (2U 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                     << 1U)))) 
                                        << 3U)) | (
                                                   ((IData)(wasmetal_core__DOT___019530_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h3b474bf2__0)));
    __VdfgTmp_h5377cf96__0 = (((IData)(vlSelf->wasmetal_core__DOT___019551_) 
                               << 2U) | (IData)(__VdfgTmp_h3b474bf2__0));
    vlSelf->wasmetal_core__DOT___021184_ = (1U & (IData)(
                                                         (0xfff4ff44ffff0000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b67__05d) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___071699_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf53fU 
                                                                         >> 
                                                                         ((0xcU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd1e6ff3c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071598_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___071615_ = (1U & (IData)(
                                                         (0xffcf0080ffcfffcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071613_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                       << 1U)) 
                                                                     << 2U)) 
                                                                 | (((IData)(wasmetal_core__DOT___071577_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071578_))))))));
    wasmetal_core__DOT___071581_ = (1U & (IData)((0xf0f0f0f0ff55ff33ULL 
                                                  >> 
                                                  ((8U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                       << 3U)) 
                                                   | (((IData)(wasmetal_core__DOT___071577_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019443_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___019455_)))))));
    __VdfgTmp_hc8ee1f3d__0 = ((2U & (((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))
                                       ? (0xffa3ffffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                               << 4U) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                     << 2U)) 
                                                 | (IData)(__VdfgTmp_h0671f08e__0))))
                                       : (0xf7U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___019542_))))) 
                                     << 1U)) | (1U 
                                                & (0x53U 
                                                   >> 
                                                   ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9972469d__0)))));
    __VdfgTmp_h721c040d__0 = (((IData)(vlSelf->wasmetal_core__DOT___019542_) 
                               << 2U) | (IData)(__VdfgTmp_h0671f08e__0));
    __VdfgTmp_h39713683__0 = (((IData)(wasmetal_core__DOT___019504_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019503_));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
        wasmetal_core__DOT___019573_ = (1U & (2U >> 
                                              ((0xcU 
                                                & ((~ 
                                                    (1U 
                                                     | (2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                           << 1U)))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___019503_)))));
        wasmetal_core__DOT___019569_ = (1U & (0xa0003U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                         << 1U)) 
                                                     | (IData)(__VdfgTmp_h39713683__0)))));
    } else {
        wasmetal_core__DOT___019573_ = (1U & (0x50c0000U 
                                              >> ((0x18U 
                                                   & ((~ 
                                                       (1U 
                                                        | (2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                              << 1U)))) 
                                                      << 3U)) 
                                                  | ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                         << 1U)) 
                                                     | (IData)(__VdfgTmp_hecb49b12__0)))));
        wasmetal_core__DOT___019569_ = (1U & (0x2000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                     | (IData)(wasmetal_core__DOT___019505_)))));
    }
    vlSelf->wasmetal_core__DOT___021128_ = (1U & (IData)(
                                                         (0xf7fffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b16__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_hfa01dcbd__0)))))));
    vlSelf->wasmetal_core__DOT___021199_ = (1U & (IData)(
                                                         (0xf7fffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b80__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_hfa01dcbd__0)))))));
    __VdfgTmp_hc46d7186__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 2U)) | (IData)(__VdfgTmp_hfa01dcbd__0));
    wasmetal_core__DOT___071661_ = (1U & (0x5030000U 
                                          >> ((0x18U 
                                               & ((~ 
                                                   (1U 
                                                    | (2U 
                                                       & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                          << 1U)))) 
                                                  << 3U)) 
                                              | (IData)(__VdfgTmp_h9fff0999__0))));
    wasmetal_core__DOT___071670_ = (1U & (0x50003U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                               << 3U) 
                                              | (IData)(__VdfgTmp_h9fff0999__0))));
    __VdfgTmp_h726ed473__0 = ((4U & ((0x53000000U >> 
                                      ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                 << 4U)) 
                                       | (IData)(__VdfgTmp_hd1d61f29__0))) 
                                     << 2U)) | ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___071602_)));
    __VdfgTmp_h61d5ae24__0 = ((2U & ((0x9fU >> (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                 << 2U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))) 
                                     << 1U)) | (1U 
                                                & (0xfacfU 
                                                   >> (IData)(__VdfgTmp_hd1d61f29__0))));
    vlSelf->wasmetal_core__DOT___071614_ = (1U & (IData)(
                                                         (0x5c00000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 4U)) 
                                                           | (IData)(__VdfgTmp_ha99d4fb3__0)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O))) {
        wasmetal_core__DOT___019546_ = (1U & (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                << 3U) 
                                               | ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      << 2U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___019503_)))));
        wasmetal_core__DOT___019527_ = (1U & (0xa0003U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                         << 2U)) 
                                                     | (IData)(__VdfgTmp_h39713683__0)))));
    } else {
        wasmetal_core__DOT___019546_ = (1U & (0x5c000000U 
                                              >> (IData)(__VdfgTmp_ha99d4fb3__0)));
        wasmetal_core__DOT___019527_ = (1U & (IData)(wasmetal_core__DOT___019449_));
    }
    vlSelf->wasmetal_core__DOT___066335_ = (1U & (IData)(
                                                         (0x444445cf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066333_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066332_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf699b114__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066308_))))))))))));
    vlSelf->wasmetal_core__DOT___066620_ = (1U & (IData)(
                                                         (0x444445cf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___066618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066332_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h91cc03bd__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___066597_))))))))))));
    wasmetal_core__DOT____Vcellout___134194___O = (0xfU 
                                                   & ((- (IData)(
                                                                 (1U 
                                                                  & (0x7eU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h99ca88a1__0))))) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___134194___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___037080_))))));
    vlSelf->wasmetal_core__DOT___021153_ = (1U & (0xbf30U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b39__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h22641916__0)))));
    vlSelf->wasmetal_core__DOT___021105_ = (1U & (0xbf30U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b103__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h22641916__0)))));
    __VdfgTmp_h17c622b5__0 = ((2U & ((IData)((0xff1fe0ffffffffffULL 
                                              >> (IData)(vlSelf->__VdfgTmp_he7466e08__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xffff0f0accffffffULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                << 5U)) 
                                                            | (IData)(__VdfgTmp_h8d3bd609__0))))));
    __VdfgTmp_hd80661ae__0 = ((2U & ((0xe01fffffU >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0)) 
                                     << 1U)) | (1U 
                                                & (0xf0accffU 
                                                   >> (IData)(__VdfgTmp_h8d3bd609__0))));
    __VdfgTmp_h82a6b2ca__0 = ((4U & ((IData)((0xf0f0553300000000ULL 
                                              >> ((0x20U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      << 5U)) 
                                                  | ((0x18U 
                                                      & ((~ 
                                                          (1U 
                                                           | (2U 
                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                                 << 1U)))) 
                                                         << 3U)) 
                                                     | (IData)(__VdfgTmp_h5377cf96__0))))) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_h79503a99__0));
    __VdfgTmp_h04a610c4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                               << 5U) | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 4U)) 
                                         | (IData)(__VdfgTmp_h5377cf96__0)));
    vlSelf->wasmetal_core__DOT___021101_ = (1U & (IData)(
                                                         (0x3f33afaaff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b0__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___071581_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xfaf0fcfULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___071579_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                                                << 3U)) 
                                                                                | (((IData)(wasmetal_core__DOT___019442_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019441_))))))))))))));
    vlSelf->wasmetal_core__DOT___021165_ = (1U & (IData)(
                                                         (0xf888fffff888f888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                 << 1U)) 
                                                               << 5U)) 
                                                           | (((IData)(wasmetal_core__DOT___071581_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b4__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7fee7fffffeeffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___071602_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071601_) 
                                                                                << 4U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h891b440b__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___021151_ = (1U & (0xbf30U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b37__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_hc8ee1f3d__0)))));
    vlSelf->wasmetal_core__DOT___021103_ = (1U & (0xbf30U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b101__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_hc8ee1f3d__0)))));
    __VdfgTmp_h2b420f71__0 = ((4U & ((IData)((0xf0f055cc00000000ULL 
                                              >> ((0x20U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                      << 5U)) 
                                                  | ((0x18U 
                                                      & ((~ 
                                                          (1U 
                                                           | (2U 
                                                              & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                                 << 1U)))) 
                                                         << 3U)) 
                                                     | (IData)(__VdfgTmp_h721c040d__0))))) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hce90a299__0));
    __VdfgTmp_h25eab54d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                               << 5U) | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                   << 4U)) 
                                         | (IData)(__VdfgTmp_h721c040d__0)));
    wasmetal_core__DOT___071692_ = ((8U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                  >> 2U))) 
                                    & (IData)(wasmetal_core__DOT___019573_));
    wasmetal_core__DOT___071715_ = ((4U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                  >> 2U))) 
                                    & (IData)(wasmetal_core__DOT___019573_));
    __VdfgTmp_hde999c4c__0 = (((IData)(wasmetal_core__DOT___019505_) 
                               << 2U) | (IData)(__VdfgTmp_h39713683__0));
    vlSelf->wasmetal_core__DOT___021163_ = (1U & (IData)(
                                                         (0xfff7ffff00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b48__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(__VdfgTmp_hc46d7186__0))))));
    vlSelf->wasmetal_core__DOT___021115_ = (1U & (IData)(
                                                         (0xfff7ffff00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b112__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(__VdfgTmp_hc46d7186__0))))));
    vlSelf->wasmetal_core__DOT___021172_ = (1U & (0xffb0f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___071661_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b56__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h35a843b1__0))))));
    __VdfgTmp_had4dbc64__0 = (((IData)(wasmetal_core__DOT___071661_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h35a843b1__0));
    vlSelf->wasmetal_core__DOT___021181_ = (1U & (0xffb0f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___071670_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b64__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc7c7e46f__0))))));
    __VdfgTmp_h023feeff__0 = (((IData)(wasmetal_core__DOT___071670_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hc7c7e46f__0));
    vlSelf->wasmetal_core__DOT___021209_ = (1U & (IData)(
                                                         (0xf7fffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b8__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h726ed473__0)))))));
    vlSelf->wasmetal_core__DOT___021190_ = (1U & (IData)(
                                                         (0xf7fffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b72__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h726ed473__0)))))));
    __VdfgTmp_h3dfe793c__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 2U)) | (IData)(__VdfgTmp_h726ed473__0));
    vlSelf->wasmetal_core__DOT___021124_ = (1U & (IData)(
                                                         (0xdfffffff50000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b12__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h61d5ae24__0))))))));
    vlSelf->wasmetal_core__DOT___021194_ = (1U & (IData)(
                                                         (0xdfffffff50000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b76__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h61d5ae24__0))))))));
    __VdfgTmp_h2c5953fc__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 1U)) | (IData)(__VdfgTmp_h61d5ae24__0));
    __VdfgTmp_h20c23734__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 2U)) | (IData)(__VdfgTmp_h61d5ae24__0));
    wasmetal_core__DOT___071683_ = ((8U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                  >> 2U))) 
                                    & (IData)(wasmetal_core__DOT___019546_));
    wasmetal_core__DOT___071712_ = ((4U >> (3U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                  >> 2U))) 
                                    & (IData)(wasmetal_core__DOT___019546_));
    vlSelf->wasmetal_core__DOT___066643_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134194___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066848_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___134194___O)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066889_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134194___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___066765_ = (1U & (0x44f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054746_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___134194___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007194_))))));
    vlSelf->wasmetal_core__DOT___021131_ = (1U & (0xdfff5000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b19__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(__VdfgTmp_h17c622b5__0))))));
    vlSelf->wasmetal_core__DOT___021202_ = (1U & (0xdfff5000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b83__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(__VdfgTmp_h17c622b5__0))))));
    __VdfgTmp_hda29c68f__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 1U)) | (IData)(__VdfgTmp_h17c622b5__0));
    vlSelf->wasmetal_core__DOT___021123_ = (1U & (IData)(
                                                         (0xdfffffff50000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b11__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hd80661ae__0))))))));
    vlSelf->wasmetal_core__DOT___021193_ = (1U & (IData)(
                                                         (0xdfffffff50000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b75__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hd80661ae__0))))))));
    __VdfgTmp_h9a698786__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 1U)) | (IData)(__VdfgTmp_hd80661ae__0));
    __VdfgTmp_h9ef2838e__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                     << 2U)) | (IData)(__VdfgTmp_hd80661ae__0));
    vlSelf->wasmetal_core__DOT___021127_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b15__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h82a6b2ca__0)))))));
    vlSelf->wasmetal_core__DOT___021197_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b79__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h82a6b2ca__0)))))));
    vlSelf->__VdfgTmp_h4d064793__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 2U)) 
                                      | (IData)(__VdfgTmp_h82a6b2ca__0));
    vlSelf->wasmetal_core__DOT___021180_ = (1U & (0xffe0f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(
                                                                  (0xf0f000005533ULL 
                                                                   >> (IData)(__VdfgTmp_h04a610c4__0))) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b63__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h79503a99__0))))));
    vlSelf->__VdfgTmp_h8e6ac71f__0 = ((4U & ((IData)(
                                                     (0xf0f000005533ULL 
                                                      >> (IData)(__VdfgTmp_h04a610c4__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h79503a99__0));
    vlSelf->__VdfgTmp_h58afe0a4__0 = ((2U & ((IData)(
                                                     (0xfffe01ffffffffffULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79139d38__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xffffaacc0f0fffffULL 
                                                       >> (IData)(__VdfgTmp_h04a610c4__0)))));
    vlSelf->wasmetal_core__DOT___021125_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b13__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h2b420f71__0)))))));
    vlSelf->wasmetal_core__DOT___021195_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b77__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h2b420f71__0)))))));
    vlSelf->__VdfgTmp_hf6ad223a__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 2U)) 
                                      | (IData)(__VdfgTmp_h2b420f71__0));
    vlSelf->wasmetal_core__DOT___021178_ = (1U & (0xffe0f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(
                                                                  (0xf0f0000055ccULL 
                                                                   >> (IData)(__VdfgTmp_h25eab54d__0))) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b61__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hce90a299__0))))));
    vlSelf->__VdfgTmp_hc11340fa__0 = ((4U & ((IData)(
                                                     (0xf0f0000055ccULL 
                                                      >> (IData)(__VdfgTmp_h25eab54d__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hce90a299__0));
    vlSelf->__VdfgTmp_h1681f59c__0 = ((2U & ((IData)(
                                                     (0xfff807ffffffffffULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79139d38__0))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xffffaa330f0fffffULL 
                                                       >> (IData)(__VdfgTmp_h25eab54d__0)))));
    vlSelf->wasmetal_core__DOT___021170_ = (1U & (0xffffef00U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b54__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e77e03a__0))))));
    vlSelf->wasmetal_core__DOT___021121_ = (1U & (0xffffef00U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071715_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b118__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e77e03a__0))))));
    vlSelf->wasmetal_core__DOT___021148_ = (1U & (0xffb0U 
                                                  >> 
                                                  ((((8U 
                                                      >> 
                                                      (3U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          >> 2U))) 
                                                     & (IData)(wasmetal_core__DOT___019527_)) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b34__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071673_))))));
    vlSelf->wasmetal_core__DOT___021218_ = (1U & (0xffb0U 
                                                  >> 
                                                  ((((4U 
                                                      >> 
                                                      (3U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                          >> 2U))) 
                                                     & (IData)(wasmetal_core__DOT___019527_)) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b98__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071673_))))));
    vlSelf->wasmetal_core__DOT___071689_ = ((8U >> 
                                             (3U & 
                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                               >> 2U))) 
                                            & (IData)(wasmetal_core__DOT___019569_));
    vlSelf->wasmetal_core__DOT___071713_ = ((4U >> 
                                             (3U & 
                                              ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                               >> 2U))) 
                                            & (IData)(wasmetal_core__DOT___019569_));
    vlSelf->wasmetal_core__DOT___019508_ = (1U & (IData)(
                                                         (0xaa0033f0000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_hde999c4c__0))))));
    vlSelf->__VdfgTmp_h857afd77__0 = ((0x30U & ((~ 
                                                 (1U 
                                                  | (2U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                        << 1U)))) 
                                                << 4U)) 
                                      | ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                << 3U)) 
                                         | (IData)(__VdfgTmp_hde999c4c__0)));
    vlSelf->__VdfgTmp_h8862745a__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                << 5U)) 
                                      | ((0x18U & (
                                                   (~ 
                                                    (1U 
                                                     | (2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)) 
                                                           << 1U)))) 
                                                   << 3U)) 
                                         | (IData)(__VdfgTmp_hde999c4c__0)));
    vlSelf->wasmetal_core__DOT___021137_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b24__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_had4dbc64__0)))))));
    vlSelf->wasmetal_core__DOT___021207_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b88__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_had4dbc64__0)))))));
    vlSelf->wasmetal_core__DOT___021146_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b32__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h023feeff__0)))))));
    vlSelf->wasmetal_core__DOT___021216_ = (1U & (IData)(
                                                         (0xfbfffffff0000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b96__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h023feeff__0)))))));
    vlSelf->wasmetal_core__DOT___021155_ = (1U & (IData)(
                                                         (0xfff7ffff00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b40__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(__VdfgTmp_h3dfe793c__0))))));
    vlSelf->wasmetal_core__DOT___021106_ = (1U & (IData)(
                                                         (0xfff7ffff00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b104__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (IData)(__VdfgTmp_h3dfe793c__0))))));
    vlSelf->wasmetal_core__DOT___021159_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b44__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h2c5953fc__0)))))));
    vlSelf->wasmetal_core__DOT___021110_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b108__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h2c5953fc__0)))))));
    vlSelf->wasmetal_core__DOT___021141_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b28__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h20c23734__0)))))));
    vlSelf->wasmetal_core__DOT___021177_ = (1U & (0xfdff0500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h20c23734__0)))));
    vlSelf->wasmetal_core__DOT___021212_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b92__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h20c23734__0)))))));
    vlSelf->wasmetal_core__DOT___021152_ = (1U & (IData)(
                                                         (0xffffffff5030f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___071683_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b38__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0be8b807__0))))))));
    vlSelf->wasmetal_core__DOT___021104_ = (1U & (IData)(
                                                         (0xffffffff5030f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___071712_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b102__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0be8b807__0))))))));
    vlSelf->wasmetal_core__DOT___066664_ = (1U & (IData)(
                                                         (0xe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066661_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066660_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066659_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066650_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066649_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066648_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f03355U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___061960_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___065947_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066643_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))))));
    vlSelf->wasmetal_core__DOT___066864_ = (1U & (IData)(
                                                         (0xf0f0000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063999_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___062079_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___066137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066848_)))))))));
    vlSelf->wasmetal_core__DOT___066910_ = (1U & (IData)(
                                                         (0xe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066907_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066905_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066896_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066894_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f03355U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___062132_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___066264_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066889_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))))));
    vlSelf->wasmetal_core__DOT___066786_ = (1U & (IData)(
                                                         (0xe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066783_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066781_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf080f0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066772_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066771_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066770_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f03355U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061584_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061553_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___062020_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___066092_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066765_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063999_)))))))));
    vlSelf->wasmetal_core__DOT___021167_ = (1U & (0xfdff0500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b51__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_hda29c68f__0)))));
    vlSelf->wasmetal_core__DOT___021118_ = (1U & (0xfdff0500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b115__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               >> 2U))) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_hda29c68f__0)))));
    vlSelf->wasmetal_core__DOT___021158_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b43__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h9a698786__0)))))));
    vlSelf->wasmetal_core__DOT___021109_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b107__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h9a698786__0)))))));
    vlSelf->wasmetal_core__DOT___021140_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b27__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h9ef2838e__0)))))));
    vlSelf->wasmetal_core__DOT___021175_ = (1U & (0xfdff0500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019577_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h9ef2838e__0)))));
    vlSelf->wasmetal_core__DOT___021211_ = (1U & (IData)(
                                                         (0xfdffffff05000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b91__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h9ef2838e__0)))))));
}
