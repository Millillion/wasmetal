#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__36(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__36\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___008807_;
    wasmetal_core__DOT___008807_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008826_;
    wasmetal_core__DOT___008826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008882_;
    wasmetal_core__DOT___008882_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008884_;
    wasmetal_core__DOT___008884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008941_;
    wasmetal_core__DOT___008941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008972_;
    wasmetal_core__DOT___008972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008973_;
    wasmetal_core__DOT___008973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009020_;
    wasmetal_core__DOT___009020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009024_;
    wasmetal_core__DOT___009024_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009025_;
    wasmetal_core__DOT___009025_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009026_;
    wasmetal_core__DOT___009026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009049_;
    wasmetal_core__DOT___009049_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009096_;
    wasmetal_core__DOT___009096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009132_;
    wasmetal_core__DOT___009132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009133_;
    wasmetal_core__DOT___009133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009134_;
    wasmetal_core__DOT___009134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009140_;
    wasmetal_core__DOT___009140_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009141_;
    wasmetal_core__DOT___009141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009150_;
    wasmetal_core__DOT___009150_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009151_;
    wasmetal_core__DOT___009151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009152_;
    wasmetal_core__DOT___009152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009168_;
    wasmetal_core__DOT___009168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009243_;
    wasmetal_core__DOT___009243_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009274_;
    wasmetal_core__DOT___009274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009387_;
    wasmetal_core__DOT___009387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009414_;
    wasmetal_core__DOT___009414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009447_;
    wasmetal_core__DOT___009447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009686_;
    wasmetal_core__DOT___009686_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009687_;
    wasmetal_core__DOT___009687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009688_;
    wasmetal_core__DOT___009688_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009689_;
    wasmetal_core__DOT___009689_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009699_;
    wasmetal_core__DOT___009699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009700_;
    wasmetal_core__DOT___009700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009716_;
    wasmetal_core__DOT___009716_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009725_;
    wasmetal_core__DOT___009725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009886_;
    wasmetal_core__DOT___009886_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009896_;
    wasmetal_core__DOT___009896_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009915_;
    wasmetal_core__DOT___009915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010654_;
    wasmetal_core__DOT___010654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010657_;
    wasmetal_core__DOT___010657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010658_;
    wasmetal_core__DOT___010658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055722_;
    wasmetal_core__DOT___055722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055733_;
    wasmetal_core__DOT___055733_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055865_;
    wasmetal_core__DOT___055865_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056103_;
    wasmetal_core__DOT___056103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056139_;
    wasmetal_core__DOT___056139_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056140_;
    wasmetal_core__DOT___056140_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056212_;
    wasmetal_core__DOT___056212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056215_;
    wasmetal_core__DOT___056215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056217_;
    wasmetal_core__DOT___056217_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056218_;
    wasmetal_core__DOT___056218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056268_;
    wasmetal_core__DOT___056268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056270_;
    wasmetal_core__DOT___056270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056354_;
    wasmetal_core__DOT___056354_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056357_;
    wasmetal_core__DOT___056357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056358_;
    wasmetal_core__DOT___056358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056362_;
    wasmetal_core__DOT___056362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056363_;
    wasmetal_core__DOT___056363_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056364_;
    wasmetal_core__DOT___056364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068410_;
    wasmetal_core__DOT___068410_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068805_;
    wasmetal_core__DOT___068805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070517_;
    wasmetal_core__DOT___070517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070518_;
    wasmetal_core__DOT___070518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070526_;
    wasmetal_core__DOT___070526_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070528_;
    wasmetal_core__DOT___070528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070529_;
    wasmetal_core__DOT___070529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070530_;
    wasmetal_core__DOT___070530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070531_;
    wasmetal_core__DOT___070531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070537_;
    wasmetal_core__DOT___070537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070538_;
    wasmetal_core__DOT___070538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070539_;
    wasmetal_core__DOT___070539_ = 0;
    CData/*1:0*/ __VdfgTmp_h242203a7__0;
    __VdfgTmp_h242203a7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h40167917__0;
    __VdfgTmp_h40167917__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3c5f3431__0;
    __VdfgTmp_h3c5f3431__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha336bc52__0;
    __VdfgTmp_ha336bc52__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2b908e25__0;
    __VdfgTmp_h2b908e25__0 = 0;
    CData/*1:0*/ __VdfgTmp_h74811752__0;
    __VdfgTmp_h74811752__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2c715ba9__0;
    __VdfgTmp_h2c715ba9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29905bdd__0;
    __VdfgTmp_h29905bdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8ed306e0__0;
    __VdfgTmp_h8ed306e0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h44cf3d5c__0;
    __VdfgTmp_h44cf3d5c__0 = 0;
    CData/*5:0*/ __VdfgTmp_h2dd5429b__0;
    __VdfgTmp_h2dd5429b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5c89e2df__0;
    __VdfgTmp_h5c89e2df__0 = 0;
    CData/*5:0*/ __VdfgTmp_hc61624da__0;
    __VdfgTmp_hc61624da__0 = 0;
    CData/*3:0*/ __VdfgTmp_h0fbdc802__0;
    __VdfgTmp_h0fbdc802__0 = 0;
    CData/*1:0*/ __VdfgTmp_hca62a78c__0;
    __VdfgTmp_hca62a78c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcb32e64d__0;
    __VdfgTmp_hcb32e64d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ae7f513__0;
    __VdfgTmp_h3ae7f513__0 = 0;
    CData/*2:0*/ __VdfgTmp_h115316d8__0;
    __VdfgTmp_h115316d8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h351522cb__0;
    __VdfgTmp_h351522cb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd28f0b72__0;
    __VdfgTmp_hd28f0b72__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb4d0429b__0;
    __VdfgTmp_hb4d0429b__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb9a1e459__0;
    __VdfgTmp_hb9a1e459__0 = 0;
    CData/*1:0*/ __VdfgTmp_hce268e24__0;
    __VdfgTmp_hce268e24__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4bae57cc__0;
    __VdfgTmp_h4bae57cc__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha28c8f63__0;
    __VdfgTmp_ha28c8f63__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcca0817d__0;
    __VdfgTmp_hcca0817d__0 = 0;
    CData/*1:0*/ __VdfgTmp_had20add3__0;
    __VdfgTmp_had20add3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h9dd569ac__0;
    __VdfgTmp_h9dd569ac__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e20e5e3__0;
    __VdfgTmp_h0e20e5e3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8170c8be__0;
    __VdfgTmp_h8170c8be__0 = 0;
    CData/*3:0*/ __VdfgTmp_h8f2e1370__0;
    __VdfgTmp_h8f2e1370__0 = 0;
    CData/*2:0*/ __VdfgTmp_h738ad7cb__0;
    __VdfgTmp_h738ad7cb__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6f023739__0;
    __VdfgTmp_h6f023739__0 = 0;
    CData/*1:0*/ __VdfgTmp_h41d7b504__0;
    __VdfgTmp_h41d7b504__0 = 0;
    CData/*5:0*/ __VdfgTmp_hc12c3471__0;
    __VdfgTmp_hc12c3471__0 = 0;
    CData/*5:0*/ __VdfgTmp_h5dfa3f6d__0;
    __VdfgTmp_h5dfa3f6d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2115d7e3__0;
    __VdfgTmp_h2115d7e3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0d445bfa__0;
    __VdfgTmp_h0d445bfa__0 = 0;
    // Body
    if (vlSelf->wasmetal_core__DOT___007866_) {
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h94861db4__0)))));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0x3331U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ab3b1fe__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0))));
    } else {
        vlSelf->wasmetal_core__DOT___009067_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008831_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7267e294__0)));
        vlSelf->wasmetal_core__DOT___008859_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009090_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0)));
        vlSelf->wasmetal_core__DOT___009352_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___008900_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h63c4c072__0)));
        vlSelf->wasmetal_core__DOT___009124_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___008929_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1c0cf2d1__0)));
        vlSelf->wasmetal_core__DOT___009017_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he24fa3ba__0)));
        vlSelf->wasmetal_core__DOT___008958_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009367_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f9bc831__0)));
        vlSelf->wasmetal_core__DOT___009380_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___008990_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a5e1d46__0)));
        vlSelf->wasmetal_core__DOT___009034_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0)));
        vlSelf->wasmetal_core__DOT___009101_ = (1U 
                                                & (0xf050f03U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___055575_ = (1U 
                                                & (0xa000cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0dadf452__0)));
        vlSelf->wasmetal_core__DOT___008861_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0)));
    }
    vlSelf->__VdfgTmp_h12f500a7__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h042cd865__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0)))));
    vlSelf->wasmetal_core__DOT___009369_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h70291c6e__0))));
    vlSelf->wasmetal_core__DOT___009382_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h850327e3__0))));
    vlSelf->__VdfgTmp_hd77eff94__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc63fb8c3__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h850327e3__0)))));
    vlSelf->wasmetal_core__DOT___009391_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0))));
    vlSelf->__VdfgTmp_h37c9f429__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                               ? (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7267e294__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb70b394c__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                         & (IData)(
                                                   (0x555533330f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_h950f0cb0__0)))));
    vlSelf->wasmetal_core__DOT___009032_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0))));
    vlSelf->wasmetal_core__DOT___009066_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008832_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdd777bec__0))));
    vlSelf->wasmetal_core__DOT___008858_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009089_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h69785613__0))));
    vlSelf->wasmetal_core__DOT___009351_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___008899_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2c35a4fb__0))));
    vlSelf->wasmetal_core__DOT___009123_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    vlSelf->wasmetal_core__DOT___008928_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf17c2029__0))));
    vlSelf->wasmetal_core__DOT___009204_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb307080d__0))))))));
    if (vlSelf->wasmetal_core__DOT___007854_) {
        vlSelf->wasmetal_core__DOT___009068_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___007866_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008836_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                   | (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h79214203__0))));
        vlSelf->wasmetal_core__DOT___008959_ = (1U 
                                                & (IData)(
                                                          (0x555533330f0f00ffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
        vlSelf->wasmetal_core__DOT___009366_ = (1U 
                                                & (IData)(
                                                          (0xaaaaccccf0f0ff00ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hee6f9dc2__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007866_) {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h5629f5f8__0)));
        } else {
            vlSelf->wasmetal_core__DOT___009068_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
            vlSelf->wasmetal_core__DOT___008836_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6405266c__0)));
        }
        vlSelf->wasmetal_core__DOT___008959_ = 0U;
        vlSelf->wasmetal_core__DOT___009366_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___009218_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___009379_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0xaaaaccccf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___008991_ = ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                            & (IData)(
                                                      (0x555533330f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5618ebf3__0))));
    vlSelf->wasmetal_core__DOT___008932_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0xfff5fff3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9bf7e2f7__0))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008935_))));
    vlSelf->wasmetal_core__DOT___009359_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009358_)))));
    vlSelf->wasmetal_core__DOT___062342_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h890a41f9__0))));
    vlSelf->wasmetal_core__DOT___010627_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h890a41f9__0)))));
    vlSelf->wasmetal_core__DOT___062337_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0))));
    vlSelf->wasmetal_core__DOT___010626_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0)))));
    vlSelf->wasmetal_core__DOT___009349_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009348_)))));
    vlSelf->wasmetal_core__DOT___062422_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009757_))));
    vlSelf->wasmetal_core__DOT___055555_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009757_)))));
    vlSelf->wasmetal_core__DOT___009336_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009335_)))));
    vlSelf->wasmetal_core__DOT___062356_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h792a3800__0))));
    vlSelf->__VdfgTmp_heedd871e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h792a3800__0)));
    vlSelf->wasmetal_core__DOT___062353_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))));
    vlSelf->wasmetal_core__DOT___009868_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))))));
    vlSelf->wasmetal_core__DOT___062327_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0))));
    vlSelf->wasmetal_core__DOT___056271_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0)))));
    vlSelf->wasmetal_core__DOT___062350_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h27200c45__0))));
    vlSelf->__VdfgTmp_h5cf792c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h27200c45__0)));
    vlSelf->wasmetal_core__DOT___062347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32990406__0))));
    vlSelf->wasmetal_core__DOT___056227_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h32990406__0)))));
    vlSelf->wasmetal_core__DOT___062432_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009308_))));
    vlSelf->wasmetal_core__DOT___008808_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009309_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009308_))))));
    vlSelf->wasmetal_core__DOT___062369_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41d1df16__0))));
    vlSelf->wasmetal_core__DOT___062413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009225_))));
    vlSelf->wasmetal_core__DOT___009364_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009363_)))));
    vlSelf->wasmetal_core__DOT___062367_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he74af19b__0)))));
    vlSelf->wasmetal_core__DOT___013087_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he74af19b__0))))));
    vlSelf->wasmetal_core__DOT___009739_ = (1U & (IData)(
                                                         (0xf0f0ff0011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0x555533330f0f00ffULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hae568380__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bfa77b1__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3aac618__0))))))));
    vlSelf->wasmetal_core__DOT___008547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055458_))));
    vlSelf->wasmetal_core__DOT___008844_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055546_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055545_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055549_)))))));
    vlSelf->wasmetal_core__DOT___008971_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055353_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha33784b5__0))))));
    wasmetal_core__DOT___056268_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055744_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055742_)))))));
    vlSelf->wasmetal_core__DOT___009001_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055395_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h63940f3b__0))))));
    wasmetal_core__DOT___009024_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055458_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___009047_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055897_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hddf47e90__0))))));
    vlSelf->wasmetal_core__DOT___055490_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055474_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055472_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055481_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008824_)))))))));
    vlSelf->wasmetal_core__DOT___009698_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb6e33d53__0))))));
    vlSelf->wasmetal_core__DOT___009081_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055547_)))))));
    vlSelf->wasmetal_core__DOT___009094_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055817_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16df2209__0))))));
    wasmetal_core__DOT___009150_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055945_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0)))) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055395_)))))));
    vlSelf->wasmetal_core__DOT___009107_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055924_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e3623a6__0))))));
    vlSelf->wasmetal_core__DOT___010622_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055631_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055630_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa157860__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008920_)))))))));
    wasmetal_core__DOT___009132_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055845_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))));
    vlSelf->wasmetal_core__DOT___008758_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055704_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                               ? 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0))
                                                               : 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055701_)))))));
    vlSelf->wasmetal_core__DOT___055717_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051313_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051934_)))))));
    vlSelf->wasmetal_core__DOT___009139_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055353_)))))));
    vlSelf->wasmetal_core__DOT___055748_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055742_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055391_)))))));
    wasmetal_core__DOT___008882_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055576_))));
    vlSelf->wasmetal_core__DOT___009167_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055884_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___008917_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055626_))));
    vlSelf->wasmetal_core__DOT___009178_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055899_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055897_)))))));
    vlSelf->wasmetal_core__DOT___009197_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055547_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055530_)))))));
    wasmetal_core__DOT___008972_ = (1U & (0x1111fff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055357_)))))));
    vlSelf->wasmetal_core__DOT___009002_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055391_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055389_)))))));
    wasmetal_core__DOT___009025_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055886_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055884_)))))));
    __VdfgTmp_hcb32e64d__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055452_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                              & (IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                   ? 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0))
                                                                   : 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))))))))) 
                                     << 1U)) | (1U 
                                                & (0x110fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                ? 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0))
                                                                : 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa0c0000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)))))))));
    vlSelf->wasmetal_core__DOT___009048_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055899_)))))));
    wasmetal_core__DOT___009699_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055804_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055803_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008856_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___008857_)))))));
    __VdfgTmp_h2c715ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009338_));
    wasmetal_core__DOT___009274_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009353_)))))));
    vlSelf->wasmetal_core__DOT___009095_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
    vlSelf->wasmetal_core__DOT___009108_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009861_)))))));
    wasmetal_core__DOT___009133_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))));
    vlSelf->wasmetal_core__DOT___008757_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055699_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009368_)))))));
    vlSelf->wasmetal_core__DOT___009307_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009381_)))))));
    wasmetal_core__DOT___009140_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
    __VdfgTmp_ha336bc52__0 = (((IData)(vlSelf->wasmetal_core__DOT___009391_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009392_));
    wasmetal_core__DOT___009151_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055947_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h91b07825__0)))) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    wasmetal_core__DOT___009168_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055886_)))))));
    __VdfgTmp_h351522cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___009066_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009067_));
    __VdfgTmp_h8170c8be__0 = (((IData)(vlSelf->wasmetal_core__DOT___009067_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009066_));
    wasmetal_core__DOT___009886_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009017_))))));
    __VdfgTmp_hca62a78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009016_));
    wasmetal_core__DOT___009020_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    __VdfgTmp_h3ae7f513__0 = (((IData)(vlSelf->wasmetal_core__DOT___008859_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008858_));
    __VdfgTmp_hd28f0b72__0 = (((IData)(vlSelf->wasmetal_core__DOT___009089_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009090_));
    __VdfgTmp_h29905bdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009352_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009351_));
    __VdfgTmp_h0e20e5e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008899_));
    vlSelf->__VdfgTmp_h9f78711b__0 = (((IData)(vlSelf->wasmetal_core__DOT___009123_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009124_));
    __VdfgTmp_h115316d8__0 = ((4U & ((IData)((0xf0f0f050f0f0f03ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___009124_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___009123_)));
    __VdfgTmp_h8ed306e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008929_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008928_));
    wasmetal_core__DOT___009447_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xf5f30000U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009034_))))));
    wasmetal_core__DOT___009243_ = (1U & (0xeeeefff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0xf5f30000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009032_)))))));
    vlSelf->wasmetal_core__DOT___056124_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008901_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x35U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb307080d__0)))))))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7bd92bc0__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009465_))))));
    vlSelf->wasmetal_core__DOT___061181_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056124_))));
    vlSelf->__VdfgTmp_h2275929a__0 = (((IData)(vlSelf->wasmetal_core__DOT___056124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    wasmetal_core__DOT___009414_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009351_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009352_)))))))));
    vlSelf->wasmetal_core__DOT___009180_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008835_)))))))));
    vlSelf->wasmetal_core__DOT___056114_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd3ee6e40__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0x33ffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009449_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___008835_))))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009449_)))));
    __VdfgTmp_h2b908e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008831_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008832_)));
    wasmetal_core__DOT___009134_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008959_)))))))));
    wasmetal_core__DOT___008941_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                               ? (0xfeffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                               : (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                          & (IData)(
                                                    (0x1111ffff000fffffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h12f500a7__0)))))))));
    vlSelf->wasmetal_core__DOT___009424_ = (1U & (IData)(
                                                         (0x1f1fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x35U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009367_)))))))));
    __VdfgTmp_h44cf3d5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009367_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009366_));
    vlSelf->wasmetal_core__DOT___056133_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009480_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009478_)))))
                                                    : 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7ca1d027__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009479_))))));
    vlSelf->wasmetal_core__DOT___019284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056133_))));
    vlSelf->wasmetal_core__DOT___056134_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    __VdfgTmp_hb9a1e459__0 = (((IData)(vlSelf->wasmetal_core__DOT___009218_) 
                               << 2U) | ((2U & ((0xf1111U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055701_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055699_)))))) 
                                                << 1U)) 
                                         | (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))))));
    __VdfgTmp_h3c5f3431__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051934_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051932_)))))) 
                                     << 1U)) | (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009379_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009380_))))))));
    __VdfgTmp_h5c89e2df__0 = (((IData)(vlSelf->wasmetal_core__DOT___009380_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009379_));
    __VdfgTmp_hb4d0429b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008932_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009471_));
    __VdfgTmp_ha28c8f63__0 = (((IData)(vlSelf->wasmetal_core__DOT___009459_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008860_)));
    vlSelf->wasmetal_core__DOT___009866_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heedd871e__0))));
    vlSelf->wasmetal_core__DOT___011268_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cf792c3__0))));
    vlSelf->wasmetal_core__DOT___010624_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))))));
    vlSelf->wasmetal_core__DOT___056269_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056268_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055747_)))))))));
    vlSelf->wasmetal_core__DOT___056160_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009024_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056157_)))))))));
    vlSelf->wasmetal_core__DOT___009724_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009132_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008938_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3068c687__0))) 
                                                                                << 1U)) 
                                                                              | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85f1be24__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___008806_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055717_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___007856_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051315_))))))))))));
    vlSelf->wasmetal_core__DOT___008813_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055747_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055744_))))))))))));
    vlSelf->wasmetal_core__DOT___009709_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (IData)(
                                                          (0xff55ffccff0fff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009204_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0x1111000fU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(wasmetal_core__DOT___008882_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))))))
                                                : (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009204_))));
    vlSelf->__VdfgTmp_h9005ae64__0 = (((IData)(vlSelf->wasmetal_core__DOT___008917_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055924_)))));
    vlSelf->__VdfgTmp_h51a98e86__0 = (((IData)(wasmetal_core__DOT___008972_) 
                                       << 1U) | (1U 
                                                 & (0x1111000fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd77eff94__0)))))));
    vlSelf->wasmetal_core__DOT___010058_ = (1U & (IData)(
                                                         (0xfef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x305U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009323_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009322_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x33550f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055457_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055454_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008548_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008547_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x305U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hcb32e64d__0)))))))))))));
    vlSelf->__VdfgTmp_hc9a6e3e5__0 = (((IData)(wasmetal_core__DOT___009699_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009698_));
    vlSelf->__VdfgTmp_hc1f2eefb__0 = ((2U & ((0x11f0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008858_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___008859_))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009699_));
    vlSelf->wasmetal_core__DOT___009080_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055530_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h2c715ba9__0))))));
    vlSelf->__VdfgTmp_h01bf79b3__0 = (((IData)(wasmetal_core__DOT___009133_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008958_)))))));
    vlSelf->wasmetal_core__DOT___061317_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008758_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008757_))))));
    vlSelf->__VdfgTmp_hcfb95646__0 = (((IData)(wasmetal_core__DOT___009140_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008990_)))))));
    vlSelf->__VdfgTmp_hc115db5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (1U 
                                                 & (0x1111fff0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_ha336bc52__0)))))));
    vlSelf->wasmetal_core__DOT___009316_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055389_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_ha336bc52__0))))));
    vlSelf->__VdfgTmp_hea7ff6d4__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009167_));
    vlSelf->__VdfgTmp_hde712649__0 = (((IData)(vlSelf->wasmetal_core__DOT___009048_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))));
    vlSelf->__VdfgTmp_hc3f8840b__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009178_));
    vlSelf->__VdfgTmp_h6b05f1fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                       << 2U) | (IData)(__VdfgTmp_h8170c8be__0));
    vlSelf->wasmetal_core__DOT___056249_ = (1U & ((IData)(
                                                          (0xf3faf0f0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h243a5897__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xccffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xa3U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055738_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009886_)))))))))));
    wasmetal_core__DOT___009387_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                           ? (0x1111fff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009392_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009391_))))))
                                           : (2U >> 
                                              (1U & 
                                               (0x35U 
                                                >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0))))));
    vlSelf->wasmetal_core__DOT___060834_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060828_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___056268_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009002_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009387_)))))))));
    vlSelf->__VdfgTmp_hb35f8ae6__0 = (((IData)(wasmetal_core__DOT___009387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009386_));
    wasmetal_core__DOT___009152_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                           ? (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009163_))))))
                                           : (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0xcaU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)))))));
    vlSelf->wasmetal_core__DOT___011169_ = (1U & ((IData)(
                                                          (0xff0fff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009434_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3eec0328__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009152_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009150_)))))))))));
    vlSelf->wasmetal_core__DOT___009436_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0x1111f0f000ff00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hca62a78c__0))))))));
    if (vlSelf->wasmetal_core__DOT___007846_) {
        wasmetal_core__DOT___008884_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (0xfc55U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf5f30000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009174_)))))));
        wasmetal_core__DOT___009026_ = (1U & (0xeeeefff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((0xf5f30000U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009031_)))))));
        if (vlSelf->wasmetal_core__DOT___007858_) {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb6a6380e__0)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009877_))));
        } else {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008831_))));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h8170c8be__0)));
        }
        wasmetal_core__DOT___009141_ = (1U & (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009146_)))))));
        wasmetal_core__DOT___008973_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (IData)(wasmetal_core__DOT___009020_));
    } else {
        wasmetal_core__DOT___008884_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008901_)));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009175_))));
        wasmetal_core__DOT___009026_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009035_)));
        if (vlSelf->wasmetal_core__DOT___007858_) {
            wasmetal_core__DOT___008826_ = (1U & (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008836_)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009068_)));
        } else {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008835_)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008835_)));
        }
        wasmetal_core__DOT___009141_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009147_))));
        wasmetal_core__DOT___008973_ = (1U & (2U >> 
                                              (1U & 
                                               (0xcaU 
                                                >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0xcaU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)))));
    }
    vlSelf->__VdfgTmp_hde083b18__0 = ((2U & ((0xeU 
                                              >> (IData)(__VdfgTmp_hca62a78c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009163_));
    vlSelf->__VdfgTmp_h2fbb9566__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009020_));
    vlSelf->__VdfgTmp_hc9ff0a4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h3ae7f513__0)));
    vlSelf->__VdfgTmp_h2a535782__0 = ((4U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8b31618a__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___009197_) 
                                          << 1U) | 
                                         (1U & (0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009338_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd28f0b72__0))))))));
    vlSelf->__VdfgTmp_hc69ce2b6__0 = (((IData)(wasmetal_core__DOT___009274_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h29905bdd__0))))));
    vlSelf->__VdfgTmp_hcd20ba92__0 = (((IData)(vlSelf->wasmetal_core__DOT___009095_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h0e20e5e3__0))))));
    vlSelf->__VdfgTmp_hafe541cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                       << 2U) | (IData)(__VdfgTmp_h0e20e5e3__0));
    if (vlSelf->wasmetal_core__DOT___007846_) {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008857_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008856_))));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2c715ba9__0)));
        } else {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h3ae7f513__0)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hd28f0b72__0)));
        }
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009861_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (0xfef0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | (IData)(__VdfgTmp_h115316d8__0)))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008930_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h8ed306e0__0))))));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h5c89e2df__0))))));
        wasmetal_core__DOT___009049_ = (1U & (0xee0fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6b05f1fa__0)))));
        wasmetal_core__DOT___009700_ = (1U & (0xee0fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_hc9ff0a4b__0))));
        wasmetal_core__DOT___009096_ = (1U & (0xfef0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hafe541cd__0)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
        } else {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
        }
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7d874977__0))))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
        wasmetal_core__DOT___009049_ = (1U & (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009069_))));
        wasmetal_core__DOT___009700_ = (1U & (2U >> (IData)(vlSelf->__VdfgTmp_heeb9424e__0)));
        wasmetal_core__DOT___009096_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0xcaU 
                                                     >> (IData)(vlSelf->__VdfgTmp_ha295f108__0))))));
    }
    vlSelf->__VdfgTmp_hf2dd18ce__0 = (((IData)(wasmetal_core__DOT___008884_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009979_));
    vlSelf->__VdfgTmp_h8f3860df__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc3aac618__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))
                                                   : 
                                                  (0xa3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___008882_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___055817_))))))))
                                               : (2U 
                                                  >> (IData)(wasmetal_core__DOT___008884_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_));
    vlSelf->__VdfgTmp_h39a6e1f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009108_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(
                                                                 (0xf0f0f050f0f0f03ULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
    vlSelf->__VdfgTmp_h9555d936__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009419_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      & (IData)(
                                                                (0xfefef0f000ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                            << 3U)) 
                                                                        | (IData)(__VdfgTmp_h115316d8__0))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055921_)))))));
    vlSelf->wasmetal_core__DOT___010650_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                   ? 
                                                  (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1f1fff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(
                                                                                (0xa0000000cULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008929_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009417_))))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009419_))))));
    vlSelf->__VdfgTmp_h6abc2452__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010650_));
    vlSelf->__VdfgTmp_h68679bcf__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008930_)))))) 
                                             << 1U)) 
                                      | (1U & (0x1fU 
                                               >> (
                                                   (8U 
                                                    & ((IData)(
                                                               (0xa0000000cULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h8ed306e0__0))))));
    vlSelf->__VdfgTmp_ha87cf846__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009447_));
    vlSelf->__VdfgTmp_hb37ea0c9__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009396_));
    vlSelf->__VdfgTmp_he49a3989__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009025_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___009024_)));
    vlSelf->__VdfgTmp_h5aef5382__0 = (((IData)(wasmetal_core__DOT___009243_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009025_));
    vlSelf->__VdfgTmp_h3b033656__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055454_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055452_)))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009243_));
    vlSelf->__VdfgTmp_h78ee927d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2275929a__0))));
    vlSelf->wasmetal_core__DOT___061171_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061165_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xccaaf0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___009274_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009414_)))))))));
    vlSelf->wasmetal_core__DOT___069049_ = (1U & (IData)(
                                                         (0xaaff00f0bbbb3030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012329_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056114_)))))))));
    vlSelf->wasmetal_core__DOT___061015_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056114_))));
    vlSelf->__VdfgTmp_hab523f16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056114_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___060982_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___008826_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h792a3800__0))))))));
    vlSelf->wasmetal_core__DOT___010069_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf1111U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055472_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055470_)))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008824_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___055474_)))))))))
                                                : (1U 
                                                   >> (IData)(wasmetal_core__DOT___008826_))));
    vlSelf->__VdfgTmp_haa33114f__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055470_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb6a6380e__0))))) 
                                             << 1U)) 
                                      | (1U & (0x11f0U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h2b908e25__0)))));
    vlSelf->__VdfgTmp_h05b3fc84__0 = (((IData)(vlSelf->wasmetal_core__DOT___009920_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009134_));
    vlSelf->wasmetal_core__DOT___013181_ = (1U & ((IData)(
                                                          (0xff0fff44ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009422_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xaaffccfff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(wasmetal_core__DOT___009134_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009133_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009132_)))))))))));
    vlSelf->__VdfgTmp_he19f1ef5__0 = ((2U & (((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x100U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                              & (IData)(
                                                        (0xfffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009368_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h44cf3d5c__0)))))))) 
                                             << 1U)) 
                                      | (1U & (0xf0f03355U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2fcb0063__0)))))));
    vlSelf->wasmetal_core__DOT___008756_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h44cf3d5c__0)))));
    vlSelf->__VdfgTmp_haa7da8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056134_));
    vlSelf->wasmetal_core__DOT___061327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcc55f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_hb9a1e459__0))))))))));
    vlSelf->wasmetal_core__DOT___009711_ = ((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0x33ffaaff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hb9a1e459__0))))))));
    vlSelf->wasmetal_core__DOT___010035_ = (1U & ((~ (IData)(
                                                             (0xf0f00003355ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009224_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0)))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? 
                                                     (0x3f3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            & (IData)(
                                                                      (0xffff1111fff0fff0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007857_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007856_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007853_))))))))) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051315_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051313_)))))))))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3c5f3431__0)))))));
    vlSelf->wasmetal_core__DOT___009306_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5c89e2df__0)))));
    wasmetal_core__DOT___056103_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                               ? (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008991_)))))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009147_)))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT___009427_))));
    vlSelf->wasmetal_core__DOT___060766_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_heabab031__0)) 
                                                             << 1U)) 
                                                         | (IData)(wasmetal_core__DOT___056103_))))));
    vlSelf->wasmetal_core__DOT___056104_ = (1U & (IData)(
                                                         (0xf000000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heabab031__0))))))));
    vlSelf->wasmetal_core__DOT___055938_ = (1U & ((IData)(
                                                          (0xfff0ff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009427_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf516e409__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009141_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009140_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009139_)))))))))));
    vlSelf->__VdfgTmp_hb80b9598__0 = (((IData)(wasmetal_core__DOT___008973_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___008972_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___008971_)));
    vlSelf->__VdfgTmp_ha0fb8243__0 = (((IData)(vlSelf->wasmetal_core__DOT___009472_) 
                                       << 2U) | (IData)(__VdfgTmp_hb4d0429b__0));
    vlSelf->wasmetal_core__DOT___009211_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hb4d0429b__0)))));
    vlSelf->wasmetal_core__DOT___056168_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0)))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0xccffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009762_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_ha28c8f63__0))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009762_)))));
    vlSelf->wasmetal_core__DOT___056121_ = (1U & (IData)(
                                                         (0xf00000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                          ? 
                                                                         (0x3355f0f0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_ha28c8f63__0))))
                                                                          : 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___009460_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18926335__0))))))));
    vlSelf->wasmetal_core__DOT___019261_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009709_))));
    vlSelf->__VdfgTmp_h8b57d846__0 = (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009709_)));
    vlSelf->wasmetal_core__DOT___056242_ = (1U & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___055359_))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xccffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009967_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h51a98e86__0))))))))));
    vlSelf->wasmetal_core__DOT___055363_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055362_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xcc550f0f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008971_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007854_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055355_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x305U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h51a98e86__0)))))))))));
    vlSelf->wasmetal_core__DOT___056048_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hcb32e64d__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009322_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009323_))))));
    vlSelf->wasmetal_core__DOT___060893_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056048_))));
    vlSelf->__VdfgTmp_h4cbaee21__0 = (((IData)(vlSelf->wasmetal_core__DOT___056048_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->__VdfgTmp_hef18707b__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010058_));
    vlSelf->wasmetal_core__DOT___009758_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1f2eefb__0))));
    vlSelf->wasmetal_core__DOT___056237_ = ((IData)(vlSelf->wasmetal_core__DOT___009935_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xaaffccff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009267_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc1f2eefb__0)))))))));
    vlSelf->wasmetal_core__DOT___010055_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                      ? (IData)(
                                                                (0xfff3fff5fff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009083_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                                                 ? 
                                                                                (0xfcaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009090_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009089_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008861_))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heeb9424e__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009081_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009080_))))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009083_)))));
    __VdfgTmp_h74811752__0 = (((IData)(vlSelf->wasmetal_core__DOT___009080_) 
                               << 1U) | (1U & (0x110fU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009090_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009089_)))))));
    wasmetal_core__DOT___009725_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h01bf79b3__0)))));
    __VdfgTmp_h6f023739__0 = (((IData)(vlSelf->wasmetal_core__DOT___009951_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h01bf79b3__0));
    vlSelf->wasmetal_core__DOT___061323_ = (1U & (IData)(
                                                         (0xff1100000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061317_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061316_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009424_)))))))));
    vlSelf->__VdfgTmp_hcb50dc13__0 = (((IData)(vlSelf->wasmetal_core__DOT___056227_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0x55330f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009139_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha33784b5__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055355_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x305U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcfb95646__0)))))))));
    wasmetal_core__DOT___056270_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hc115db5a__0)))));
    vlSelf->wasmetal_core__DOT___060927_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hea7ff6d4__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->wasmetal_core__DOT___055954_ = ((IData)(vlSelf->wasmetal_core__DOT___009170_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hea7ff6d4__0)))))))));
    vlSelf->wasmetal_core__DOT___056241_ = ((IData)(vlSelf->wasmetal_core__DOT___009962_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaaff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde712649__0)))))))));
    wasmetal_core__DOT___009716_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hde712649__0))));
    vlSelf->wasmetal_core__DOT___061010_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009181_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hc3f8840b__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->wasmetal_core__DOT___055964_ = ((IData)(vlSelf->wasmetal_core__DOT___009181_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009180_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3f8840b__0)))))))));
    vlSelf->wasmetal_core__DOT___009867_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (0x55330f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009178_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hddf47e90__0)) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009870_))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009872_))));
    __VdfgTmp_h8f2e1370__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009402_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xeeee0f0fff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6b05f1fa__0))))))) 
                                           << 1U) | 
                                          (1U & (4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->wasmetal_core__DOT___011267_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h63940f3b__0)) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___009659_))))
                                                    : 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___009150_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___009151_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___009886_)))));
    vlSelf->__VdfgTmp_h739b8454__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011267_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)));
    vlSelf->wasmetal_core__DOT___060849_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009388_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb35f8ae6__0))))))));
    vlSelf->__VdfgTmp_hedda33f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011169_));
    vlSelf->wasmetal_core__DOT___060853_ = (1U & (IData)(
                                                         (0xf0f50000cc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009436_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3dedcb44__0))))))));
    vlSelf->wasmetal_core__DOT___060846_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060840_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055748_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009316_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcc55f0f0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde083b18__0))))))))))))));
    __VdfgTmp_h0fbdc802__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009316_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_hde083b18__0)));
    vlSelf->__VdfgTmp_h55155be3__0 = ((2U & ((0xcfaf0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___009973_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0x3aU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2fbb9566__0))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009972_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056243_ = ((IData)(vlSelf->wasmetal_core__DOT___009973_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0x33ffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009972_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2fbb9566__0)))))))));
    vlSelf->wasmetal_core__DOT___011249_ = (1U & ((IData)(
                                                          (0xfff0ff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009927_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xcaU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)))))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xaaff33fff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009003_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009001_)))))))))));
    vlSelf->wasmetal_core__DOT___011286_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((1U 
                                                             >> 
                                                             ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                & (IData)(
                                                                          (0x555533330f0f00ffULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                     ? 
                                                                    (0x503U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                                     : 
                                                                    (0x503U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___009659_))))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___009001_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___009002_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___009020_)))));
    vlSelf->__VdfgTmp_h2858a73f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010338_)));
    vlSelf->__VdfgTmp_h65ab9fde__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011285_))));
    vlSelf->wasmetal_core__DOT___055410_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    __VdfgTmp_h4bae57cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 2U) | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                   ? 
                                                  (0xee0fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc9ff0a4b__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009091_)))
                                                  : 
                                                 (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009405_))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___056089_)));
    vlSelf->wasmetal_core__DOT___010068_ = (1U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (IData)(
                                                             (0xfff0fff0ffaaffccULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008878_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008877_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbd15e417__0))))))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008810_)) 
                                                     & (IData)(
                                                               (0x33ffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008845_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008844_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055804_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055803_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb6e33d53__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___061051_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061031_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008844_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009197_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009334_)))))))));
    __VdfgTmp_hce268e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___009334_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009333_));
    vlSelf->wasmetal_core__DOT___061099_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009199_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccaa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h2a535782__0))))))))));
    vlSelf->wasmetal_core__DOT___009712_ = ((IData)(vlSelf->wasmetal_core__DOT___009199_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0x33ff55fff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2a535782__0))))))));
    vlSelf->wasmetal_core__DOT___056062_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                   ? 
                                                  (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                                   ? 
                                                                  (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009353_) 
                                                                           << 2U) 
                                                                          | (IData)(__VdfgTmp_h29905bdd__0)))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008901_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009346_))))))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___009349_)));
    vlSelf->__VdfgTmp_hc194321c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056062_));
    vlSelf->wasmetal_core__DOT___010625_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc69ce2b6__0)))));
    vlSelf->__VdfgTmp_hd485fb84__0 = ((2U & ((0xcfaf0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___009940_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009939_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056238_ = ((IData)(vlSelf->wasmetal_core__DOT___009940_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009939_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0)))))))));
    vlSelf->wasmetal_core__DOT___009726_ = (1U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (IData)(
                                                             (0xff33ff55ff0fff0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009275_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h282170d2__0)))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? 
                                                     (0x3fafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009739_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009094_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0)))))));
    wasmetal_core__DOT___009915_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                    & (IData)((0xfefef0f000ff00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hafe541cd__0)))))));
    if (vlSelf->wasmetal_core__DOT___007844_) {
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009026_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009923_)))))));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009414_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009412_)))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1111f0f0ff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h2b908e25__0)))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009400_)))))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008941_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009984_)))))));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009424_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009422_)))))));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3c5f3431__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009224_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0xc000aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008973_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009930_)))))));
        vlSelf->wasmetal_core__DOT___056009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009232_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc115db5a__0)))))));
        vlSelf->wasmetal_core__DOT___010646_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb35f8ae6__0))))));
        vlSelf->wasmetal_core__DOT___056107_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009436_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009434_)))))));
        vlSelf->wasmetal_core__DOT___009910_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009003_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009927_)))))));
        vlSelf->wasmetal_core__DOT___012944_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008921_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009357_)))))));
        vlSelf->wasmetal_core__DOT___056030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009284_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h68679bcf__0)))))));
        vlSelf->wasmetal_core__DOT___010647_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb37ea0c9__0))))));
        vlSelf->wasmetal_core__DOT___056014_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009245_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3b033656__0)))))));
        vlSelf->wasmetal_core__DOT___056018_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_haa33114f__0)))))));
        vlSelf->wasmetal_core__DOT___009907_ = (1U 
                                                & (0xa000cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h05b3fc84__0))))));
        vlSelf->wasmetal_core__DOT___056070_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he19f1ef5__0))))));
        vlSelf->wasmetal_core__DOT___056034_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009295_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008757_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___008756_))))))));
        vlSelf->wasmetal_core__DOT___056057_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_hce268e24__0))))));
        vlSelf->wasmetal_core__DOT___009905_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009915_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009412_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009398_));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009402_)))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009364_));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009425_));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009225_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
        vlSelf->wasmetal_core__DOT___056009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009233_))));
        vlSelf->wasmetal_core__DOT___010646_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009389_));
        vlSelf->wasmetal_core__DOT___056107_ = (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h20f110d2__0)))));
        vlSelf->wasmetal_core__DOT___009910_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009389_));
        vlSelf->wasmetal_core__DOT___012944_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009359_));
        vlSelf->wasmetal_core__DOT___056030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009285_))));
        vlSelf->wasmetal_core__DOT___010647_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009398_));
        vlSelf->wasmetal_core__DOT___056014_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009246_))));
        vlSelf->wasmetal_core__DOT___056018_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009259_))));
        vlSelf->wasmetal_core__DOT___009907_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009425_));
        vlSelf->wasmetal_core__DOT___056070_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009364_));
        vlSelf->wasmetal_core__DOT___056034_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009296_))));
        vlSelf->wasmetal_core__DOT___056057_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009336_));
        vlSelf->wasmetal_core__DOT___009905_ = (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9f90b4cf__0)))));
    }
    vlSelf->wasmetal_core__DOT___061152_ = (1U & (IData)(
                                                         (0xccaa0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009348_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf2dd18ce__0))))))));
    vlSelf->wasmetal_core__DOT___009897_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                         ? 
                                                        (0xcaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf2dd18ce__0)))))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___009349_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                          ? 
                                                         (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008845_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___008878_))))))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___009336_))))));
    vlSelf->__VdfgTmp_hbcde5889__0 = (((IData)(vlSelf->wasmetal_core__DOT___055825_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8f3860df__0)));
    __VdfgTmp_h41d7b504__0 = (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009853_));
    vlSelf->__VdfgTmp_h83e89eb3__0 = ((2U & ((0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h39a6e1f8__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xcc550f0f00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009107_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055636_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009851_))))))))));
    __VdfgTmp_h738ad7cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___009945_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h39a6e1f8__0));
    vlSelf->wasmetal_core__DOT___061265_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9555d936__0))));
    vlSelf->wasmetal_core__DOT___009906_ = (1U & (IData)(
                                                         (0x11000000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9555d936__0))))));
    vlSelf->wasmetal_core__DOT___061253_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009110_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009109_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009107_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009108_))))))))))));
    vlSelf->wasmetal_core__DOT___010033_ = ((IData)(vlSelf->wasmetal_core__DOT___009110_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009109_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009108_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009107_))))))))));
    vlSelf->wasmetal_core__DOT___055839_ = (1U & (0x30005U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                                   ? 
                                                                  (0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008920_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfa157860__0))))))
                                                                   : 
                                                                  (0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055631_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055630_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008917_)))))
                                                                  : 
                                                                 (2U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008921_))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055837_)))))));
    vlSelf->wasmetal_core__DOT___010623_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68679bcf__0)))));
    vlSelf->__VdfgTmp_h6c7838ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___009997_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha87cf846__0));
    vlSelf->__VdfgTmp_hf1710ca9__0 = ((2U & ((IData)(
                                                     (0x55cc0f0f00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009167_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008547_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___056157_)))))))) 
                                             << 1U)) 
                                      | (1U & (0x305U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha87cf846__0))))));
    vlSelf->wasmetal_core__DOT___056111_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? (IData)(wasmetal_core__DOT___009447_)
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___009175_)))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009441_))));
    vlSelf->wasmetal_core__DOT___060935_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h52168cf5__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056111_))))));
    vlSelf->wasmetal_core__DOT___010034_ = (1U & (IData)(
                                                         (0xf000000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056111_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52168cf5__0))))))));
    vlSelf->wasmetal_core__DOT___060930_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009397_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb37ea0c9__0))))))));
    vlSelf->wasmetal_core__DOT___060919_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5533f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_he49a3989__0))))))))));
    vlSelf->wasmetal_core__DOT___055888_ = ((IData)(vlSelf->wasmetal_core__DOT___009027_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xaaffccff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he49a3989__0))))))));
    vlSelf->wasmetal_core__DOT___056240_ = (1U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009246_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007844_)))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xaaff33fff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009956_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5aef5382__0))))))))));
    vlSelf->wasmetal_core__DOT___056161_ = (1U & (0x50cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aef5382__0)))));
    vlSelf->wasmetal_core__DOT___010042_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           & (IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008549_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008548_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008547_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055457_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055456_)))))))))))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x305U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3b033656__0)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055464_)))))));
    vlSelf->wasmetal_core__DOT___066788_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061171_))));
    vlSelf->wasmetal_core__DOT___024504_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010649_))));
    vlSelf->wasmetal_core__DOT___010032_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab523f16__0))));
    vlSelf->wasmetal_core__DOT___068251_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057030_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057031_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___060982_)))))));
    vlSelf->wasmetal_core__DOT___056052_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008826_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009329_))))))
                                                   : 
                                                  (0x100U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009330_)))))));
    vlSelf->__VdfgTmp_h3b65973b__0 = (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056052_));
    vlSelf->wasmetal_core__DOT___055789_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010069_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x305U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heedd871e__0))))))));
    vlSelf->__VdfgTmp_h30bed265__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010648_));
    vlSelf->wasmetal_core__DOT___055489_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa33114f__0)))));
    vlSelf->wasmetal_core__DOT___061333_ = (1U & (IData)(
                                                         (0xaa00cc00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h584d0366__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h05b3fc84__0))))))));
    vlSelf->__VdfgTmp_he07352b1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013181_));
    vlSelf->wasmetal_core__DOT___055849_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  (0xaaccf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x1111000fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055845_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___008938_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(wasmetal_core__DOT___008941_))));
    vlSelf->__VdfgTmp_h69066ba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055849_));
    vlSelf->__VdfgTmp_h284e2fd7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010651_));
    vlSelf->wasmetal_core__DOT___061304_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009363_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he19f1ef5__0))))))));
    vlSelf->wasmetal_core__DOT___010043_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                ? 
                                                               (0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                            & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85f1be24__0)))) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3068c687__0)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                             & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc229347b__0)))) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))))))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008757_)))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                ? 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008758_))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008756_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055710_))))));
    vlSelf->wasmetal_core__DOT___061330_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061327_))));
    vlSelf->__VdfgTmp_h04c057c0__0 = ((2U & ((0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009711_));
    vlSelf->wasmetal_core__DOT___056003_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009711_))));
    vlSelf->wasmetal_core__DOT___055239_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010035_))));
    vlSelf->wasmetal_core__DOT___060721_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056001_))));
    vlSelf->__VdfgTmp_h30ace780__0 = (((IData)(vlSelf->wasmetal_core__DOT___056001_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___060759_ = (1U & (IData)(
                                                         (0xf00aa00330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009376_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h41d1df16__0))))))));
    vlSelf->wasmetal_core__DOT___060754_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1111f0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060752_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf0f03355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009306_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055717_))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009307_)))))))))))))));
    vlSelf->__VdfgTmp_h672152ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___009307_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009306_));
    if (vlSelf->wasmetal_core__DOT___007847_) {
        if (vlSelf->wasmetal_core__DOT___007844_) {
            vlSelf->wasmetal_core__DOT___056026_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_hc69ce2b6__0)))));
            vlSelf->wasmetal_core__DOT___056021_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_h74811752__0)))));
            vlSelf->wasmetal_core__DOT___056038_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h672152ba__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___056026_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_))));
            vlSelf->wasmetal_core__DOT___056021_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055538_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0))))))))));
            vlSelf->wasmetal_core__DOT___056038_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009308_))));
        }
        wasmetal_core__DOT___056218_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                               ? (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5e3623a6__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009851_))))
                                               : (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9005ae64__0)))));
        vlSelf->wasmetal_core__DOT___056074_ = (1U 
                                                & (0x3000aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009376_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009374_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___056026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009276_)))));
        wasmetal_core__DOT___056218_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009853_)));
        vlSelf->wasmetal_core__DOT___056074_ = (1U 
                                                & (0x100U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009375_))))));
        vlSelf->wasmetal_core__DOT___056021_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009267_)))));
        vlSelf->wasmetal_core__DOT___056038_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009309_)))));
    }
    vlSelf->wasmetal_core__DOT___056353_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056351_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056349_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056178_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056341_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056340_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056179_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))))));
    vlSelf->wasmetal_core__DOT___024507_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056104_))));
    vlSelf->__VdfgTmp_hc7fb8523__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055938_));
    vlSelf->wasmetal_core__DOT___060743_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008975_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x55330f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb80b9598__0))))))))));
    vlSelf->wasmetal_core__DOT___055869_ = ((IData)(vlSelf->wasmetal_core__DOT___008975_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xaaffccfff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb80b9598__0))))))));
    vlSelf->wasmetal_core__DOT___061264_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009473_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xccaaf0f0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha0fb8243__0)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056129_ = ((IData)(vlSelf->wasmetal_core__DOT___009473_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha0fb8243__0))))))));
    vlSelf->wasmetal_core__DOT___009707_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (IData)(
                                                          (0xff55ffccff0fff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009211_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0xf1111U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009861_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9005ae64__0)))))))
                                                : (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009211_))));
    vlSelf->wasmetal_core__DOT___056207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->__VdfgTmp_ha0636656__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056121_));
    vlSelf->wasmetal_core__DOT___024484_ = (1U & (0x10efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b57d846__0))));
    vlSelf->wasmetal_core__DOT___024493_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4cbaee21__0))));
    vlSelf->wasmetal_core__DOT___061076_ = (1U & (0xcf5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009935_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009758_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009267_)))))));
    vlSelf->__VdfgTmp_h0ff5ee52__0 = (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_));
    vlSelf->wasmetal_core__DOT___010021_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x33550f0f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009081_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___008639_)) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h422b1f0e__0))))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055546_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055545_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x305U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h74811752__0)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055555_)))))));
    vlSelf->__VdfgTmp_h885d71fc__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___009952_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x33550f0f00000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 3U) 
                                                                    | (IData)(__VdfgTmp_h6f023739__0))))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056239_ = ((IData)(vlSelf->wasmetal_core__DOT___009952_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6f023739__0))))))));
    vlSelf->wasmetal_core__DOT___056228_ = (1U & (IData)(
                                                         (0x1fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hcb50dc13__0)))));
    vlSelf->wasmetal_core__DOT___056352_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056271_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056269_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___056270_)))))));
    vlSelf->wasmetal_core__DOT___010048_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056271_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___056270_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056269_)))))))));
    vlSelf->wasmetal_core__DOT___067677_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067676_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056009_)))))))));
    vlSelf->wasmetal_core__DOT___010653_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056009_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___024481_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055954_))));
    vlSelf->wasmetal_core__DOT___060986_ = (1U & (0xcf5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009962_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___009716_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009258_)))))));
    vlSelf->wasmetal_core__DOT___056213_ = (1U & ((0xf3faU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xccaaf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xcaU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0))))))))))) 
                                                  & (IData)(
                                                            (0xccffaafff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 3U) 
                                                                    | (((IData)(wasmetal_core__DOT___009716_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0x3aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055481_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009870_)))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___009047_))))))))));
    vlSelf->wasmetal_core__DOT___056138_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055938_))))));
    vlSelf->__VdfgTmp_h33ebc999__0 = (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055964_));
    vlSelf->wasmetal_core__DOT___060962_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009867_))));
    vlSelf->wasmetal_core__DOT___061016_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h8f2e1370__0))));
    vlSelf->wasmetal_core__DOT___009909_ = (1U & (IData)(
                                                         (0x11000000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h8f2e1370__0))))));
    vlSelf->wasmetal_core__DOT___061000_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009050_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___009049_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009047_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009048_))))))))))));
    vlSelf->wasmetal_core__DOT___010053_ = ((IData)(vlSelf->wasmetal_core__DOT___009050_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___009049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009048_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009047_))))))))));
    vlSelf->__VdfgTmp_h356ffba0__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010646_));
    vlSelf->wasmetal_core__DOT___043264_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedda33f4__0))))))));
    vlSelf->wasmetal_core__DOT___068951_ = (1U & (IData)(
                                                         (0xbbbb3030aaff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011683_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___060853_)))))))));
    vlSelf->__VdfgTmp_h798d913c__0 = (((IData)(vlSelf->wasmetal_core__DOT___060853_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->__VdfgTmp_h862c0500__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056107_));
    vlSelf->__VdfgTmp_h9fc94011__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 2U) | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                       ? 
                                                      (0xf0f0cc55U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 4U) 
                                                        | (IData)(__VdfgTmp_h0fbdc802__0)))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___009317_))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056042_)));
    vlSelf->wasmetal_core__DOT___008814_ = (1U & (IData)(
                                                         (0xf0f000033aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h0fbdc802__0))))));
    vlSelf->wasmetal_core__DOT___024472_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011249_))));
    vlSelf->wasmetal_core__DOT___055412_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055410_)))))))));
    vlSelf->wasmetal_core__DOT___061089_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009701_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf5f3f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___009700_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc9a6e3e5__0)))))))))));
    vlSelf->wasmetal_core__DOT___012502_ = ((IData)(vlSelf->wasmetal_core__DOT___009701_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___009700_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc9a6e3e5__0)))))))));
    vlSelf->wasmetal_core__DOT___061102_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h4bae57cc__0))));
    vlSelf->wasmetal_core__DOT___009904_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h4bae57cc__0)))));
    vlSelf->wasmetal_core__DOT___056231_ = (1U & (IData)(
                                                         (0xf0f0f0f0f0f0f02ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8f3860df__0))))))));
    vlSelf->__VdfgTmp_h740b215b__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010068_));
    vlSelf->wasmetal_core__DOT___061071_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009335_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hce268e24__0))))))));
    vlSelf->__VdfgTmp_h78ac443f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009712_));
    vlSelf->wasmetal_core__DOT___067912_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012602_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056026_))))));
    vlSelf->__VdfgTmp_h9b8fed80__0 = (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___010028_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010626_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010625_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010624_)))))))));
    vlSelf->wasmetal_core__DOT___055607_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010626_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010624_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010625_)))))));
    vlSelf->wasmetal_core__DOT___061182_ = (1U & (IData)(
                                                         (0xf050000cc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009915_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h35ac7889__0))))))));
    vlSelf->wasmetal_core__DOT___010054_ = (1U & ((IData)(
                                                          (0xff0fff44ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009412_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009096_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009095_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009094_)))))))))));
    vlSelf->wasmetal_core__DOT___068358_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057295_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___061152_))))));
    vlSelf->wasmetal_core__DOT___055826_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbcde5889__0))));
    vlSelf->wasmetal_core__DOT___061213_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056219_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056218_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056232_ = (1U & (IData)(
                                                         (0x703300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055849_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056219_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___056218_)))))))));
    vlSelf->wasmetal_core__DOT___061218_ = (1U & (IData)(
                                                         (0xaa330000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009358_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h41d7b504__0))))))));
    vlSelf->wasmetal_core__DOT___009898_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056247_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                          ? 
                                                         (0xa3U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h41d7b504__0)))))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___009359_))))));
    vlSelf->wasmetal_core__DOT___056216_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009728_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009727_)
                                                    ? (IData)(
                                                              (0xeee000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                                    << 4U) 
                                                                   | (((IData)(wasmetal_core__DOT___009725_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009724_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h83e89eb3__0)))))))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h83e89eb3__0)))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009727_)
                                                    ? 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                         << 2U) 
                                                        | (((IData)(wasmetal_core__DOT___009725_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009724_)))))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___009726_)))));
    vlSelf->wasmetal_core__DOT___061223_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009946_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33550f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h738ad7cb__0))))))))));
    vlSelf->wasmetal_core__DOT___012954_ = ((IData)(vlSelf->wasmetal_core__DOT___009946_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h738ad7cb__0))))))));
    wasmetal_core__DOT___068805_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061265_))));
    vlSelf->wasmetal_core__DOT___061266_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061265_))));
    vlSelf->wasmetal_core__DOT___070521_ = (1U & (IData)(
                                                         (0x8eafffffffff8eafULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013181_)))))))));
    vlSelf->wasmetal_core__DOT___024477_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010033_))));
    vlSelf->__VdfgTmp_hfe94c053__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012944_));
    vlSelf->wasmetal_core__DOT___024469_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055839_))));
    __VdfgTmp_h40167917__0 = (((IData)(vlSelf->wasmetal_core__DOT___056030_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    __VdfgTmp_h242203a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010623_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010622_));
    vlSelf->wasmetal_core__DOT___055661_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010627_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010622_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010623_)))))));
    vlSelf->wasmetal_core__DOT___061370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009998_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33550f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h6c7838ff__0))))))))));
    vlSelf->wasmetal_core__DOT___056250_ = ((IData)(vlSelf->wasmetal_core__DOT___009998_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6c7838ff__0))))))));
    vlSelf->wasmetal_core__DOT___056708_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009868_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf1710ca9__0)))));
    vlSelf->wasmetal_core__DOT___024509_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010034_))));
    vlSelf->wasmetal_core__DOT___068597_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012054_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012053_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012052_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060930_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010084_)))))))));
    vlSelf->wasmetal_core__DOT___024501_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010647_))));
    vlSelf->__VdfgTmp_h50e83fab__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055888_));
    wasmetal_core__DOT___009896_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056243_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056242_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056241_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056240_))))));
    vlSelf->wasmetal_core__DOT___056752_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056160_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056161_)))));
    wasmetal_core__DOT___056215_ = (1U & (IData)((0xeee00000fff00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056162_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056161_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056160_)))))))));
    vlSelf->wasmetal_core__DOT___067741_ = (1U & (IData)(
                                                         (0x88fff8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012002_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012001_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056014_)))))))));
    vlSelf->wasmetal_core__DOT___060890_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056014_))));
    wasmetal_core__DOT___010654_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___056014_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___024221_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010042_))));
    vlSelf->__VdfgTmp_hd62224af__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010032_)))));
    vlSelf->wasmetal_core__DOT___024466_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055789_))));
    wasmetal_core__DOT___070530_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010646_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010647_)))))));
    vlSelf->__VdfgTmp_hbf1fbd0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___056018_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___010049_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055491_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055489_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055490_)))))))));
    vlSelf->wasmetal_core__DOT___010614_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055491_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055490_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055489_)))))));
    vlSelf->wasmetal_core__DOT___056262_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he07352b1__0)))));
    vlSelf->wasmetal_core__DOT___024470_ = (1U & (0xb00f4ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h69066ba7__0))))));
    vlSelf->wasmetal_core__DOT___055853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0))))));
    vlSelf->wasmetal_core__DOT___043256_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056104_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h284e2fd7__0))))))));
    vlSelf->wasmetal_core__DOT___068438_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013076_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061304_)))))))));
    vlSelf->wasmetal_core__DOT___024498_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056070_))));
    __VdfgTmp_hcca0817d__0 = (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___065433_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057617_)))));
    vlSelf->__VdfgTmp_h71fdadc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010043_));
    vlSelf->wasmetal_core__DOT___055713_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xf4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055712_)))))));
    vlSelf->wasmetal_core__DOT___055721_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010043_)))));
    vlSelf->wasmetal_core__DOT___056135_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056096_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056086_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056063_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->__VdfgTmp_h14375066__0 = (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055239_));
    wasmetal_core__DOT___010657_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___010026_ = (1U & (0x401004abU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056009_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___024486_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___060761_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060759_))));
    wasmetal_core__DOT___056357_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056062_))))));
    vlSelf->__VdfgTmp_h11bce3c4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056074_));
    vlSelf->wasmetal_core__DOT___056075_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->__VdfgTmp_h27adf041__0 = (((IData)(vlSelf->wasmetal_core__DOT___060754_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    wasmetal_core__DOT___008807_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h672152ba__0)))));
    wasmetal_core__DOT___056140_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055869_))));
    vlSelf->__VdfgTmp_hf4167eb1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055869_));
    wasmetal_core__DOT___056354_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056107_))))));
    wasmetal_core__DOT___056212_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2275929a__0))));
    vlSelf->wasmetal_core__DOT___070510_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056129_)))))));
    vlSelf->wasmetal_core__DOT___024511_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056129_))));
    vlSelf->__VdfgTmp_hd684d3d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009707_));
    vlSelf->__VdfgTmp_h4528de02__0 = (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009707_)));
    vlSelf->wasmetal_core__DOT___070533_ = (1U & (IData)(
                                                         (0xbfbf00bfffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010032_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010034_)))))))));
    vlSelf->wasmetal_core__DOT___024475_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0))))));
    vlSelf->wasmetal_core__DOT___067825_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056021_)))))))));
    vlSelf->wasmetal_core__DOT___010656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056021_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->__VdfgTmp_h4a210212__0 = (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010021_));
    vlSelf->wasmetal_core__DOT___055559_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055558_)))))));
    vlSelf->wasmetal_core__DOT___024487_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010653_))));
    vlSelf->wasmetal_core__DOT___067766_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012280_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___060986_))))));
    vlSelf->__VdfgTmp_haf42252b__0 = (((IData)(vlSelf->wasmetal_core__DOT___060986_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___070522_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h33ebc999__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))));
    vlSelf->__VdfgTmp_h6850d65a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010053_));
    vlSelf->wasmetal_core__DOT___043254_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h356ffba0__0))))))));
    vlSelf->wasmetal_core__DOT___070532_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010651_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))));
    vlSelf->wasmetal_core__DOT___060804_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fc94011__0))));
    vlSelf->wasmetal_core__DOT___056044_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9fc94011__0)))));
    __VdfgTmp_hc61624da__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                           << 3U) | 
                                          ((4U & ((0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5cf792c3__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___008814_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___008813_))))));
    vlSelf->__VdfgTmp_hc6176170__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0x305U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5cf792c3__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008813_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___008814_)))));
    wasmetal_core__DOT___056358_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010651_)) 
                                          & (IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___010646_))))))))));
    wasmetal_core__DOT___070531_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010649_)))))));
    vlSelf->__VdfgTmp_h7f725de9__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009904_));
    wasmetal_core__DOT___070517_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___055789_)))));
    __VdfgTmp_h5dfa3f6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         ((8U & ((0x305U 
                                                  >> (IData)(vlSelf->__VdfgTmp_heedd871e__0)) 
                                                 << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___010069_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h740b215b__0)))));
    vlSelf->wasmetal_core__DOT___068304_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068285_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___012440_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061071_)))))));
    wasmetal_core__DOT___070528_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc194321c__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))));
    vlSelf->wasmetal_core__DOT___010063_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3b65973b__0))))))));
    vlSelf->wasmetal_core__DOT___024495_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056057_))));
    vlSelf->wasmetal_core__DOT___010064_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9b8fed80__0))));
    vlSelf->wasmetal_core__DOT___055608_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055606_)))))));
    vlSelf->wasmetal_core__DOT___068744_ = (1U & (IData)(
                                                         (0x88ff8f8fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057257_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057256_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061182_)))))))));
    vlSelf->wasmetal_core__DOT___061183_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061182_))));
    __VdfgTmp_h9dd569ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___013181_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010054_)));
    vlSelf->__VdfgTmp_h26c3fed8__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010054_));
    wasmetal_core__DOT___056362_ = (1U & (0x1000U >> 
                                          ((8U & ((0xd0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055869_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055849_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___007844_)))))) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0xbU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0))))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055826_))))));
    vlSelf->__VdfgTmp_h64128247__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055826_));
    wasmetal_core__DOT___009686_ = (1U & (0x10000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___056232_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056231_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                         | (IData)(
                                                                   (0xee0e0000ff0fff0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009868_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hf1710ca9__0)))))))) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((0xd00U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___011268_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011267_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007844_))))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056228_)))))));
    wasmetal_core__DOT___068410_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061218_))));
    vlSelf->wasmetal_core__DOT___067979_ = (1U & (IData)(
                                                         (0xc0ffeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067960_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061223_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065289_)))))))));
    vlSelf->__VdfgTmp_hb48e4863__0 = (((IData)(vlSelf->wasmetal_core__DOT___061223_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___068806_ = (1U & (IData)(
                                                         (0xff00ee00ff000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___068805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h90d51bf1__0)))))));
    vlSelf->wasmetal_core__DOT___043245_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070521_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7fb8523__0))));
    vlSelf->wasmetal_core__DOT___010061_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe94c053__0))))))));
    vlSelf->wasmetal_core__DOT___010059_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h40167917__0))));
    vlSelf->wasmetal_core__DOT___010023_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010627_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h242203a7__0))))))));
    vlSelf->wasmetal_core__DOT___055662_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055660_)))))));
    vlSelf->wasmetal_core__DOT___068165_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056835_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___061370_))))));
    vlSelf->wasmetal_core__DOT___043257_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010032_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024509_)))));
    vlSelf->wasmetal_core__DOT___070519_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055869_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011249_)))))));
    wasmetal_core__DOT___009687_ = (1U & ((1U >> ((2U 
                                                   & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                        ? 
                                                       (0xc0005U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009872_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___009329_))))))
                                                        : 
                                                       (0x200U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xf0f0ccaaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                                << 2U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h23e0654e__0))))))))))) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___056250_))) 
                                          & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056249_) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & (((IData)(
                                                                  (0xfafcf0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h38f150ef__0))))))) 
                                                          & (IData)(
                                                                    (0xccffaafff0fff0ffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009988_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hcfb95646__0)))))))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))) 
                                             & (IData)(
                                                       (0x8000000000000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___009898_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009897_) 
                                                             << 4U) 
                                                            | (((IData)(wasmetal_core__DOT___009896_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___056239_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012954_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056238_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___056237_))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (((~ (IData)(vlSelf->wasmetal_core__DOT___009911_)) 
                                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT___009910_)) 
                                                                             & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009909_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009908_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009907_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009906_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009905_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009904_)))))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (1U 
                                                                           >> 
                                                                           ((8U 
                                                                             & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                                                << 3U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056104_))))))))))))))));
    vlSelf->__VdfgTmp_h3e52c1ca__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                       << 1U) | (IData)(wasmetal_core__DOT___010654_));
    vlSelf->__VdfgTmp_hee926831__0 = (((IData)(vlSelf->wasmetal_core__DOT___010035_) 
                                       << 5U) | (IData)(vlSelf->__VdfgTmp_hd62224af__0));
    vlSelf->wasmetal_core__DOT___043236_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070530_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30bed265__0))));
    vlSelf->wasmetal_core__DOT___010027_ = (1U & (0x401004abU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056021_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0))))));
    vlSelf->wasmetal_core__DOT___024489_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0))))));
    vlSelf->wasmetal_core__DOT___010013_ = ((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010048_) 
                                               & (IData)(
                                                         (0x1428000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010042_))))))))));
    vlSelf->wasmetal_core__DOT___043197_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024221_)))));
    vlSelf->__VdfgTmp_h4c3f9374__0 = (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033390_));
    __VdfgTmp_h2115d7e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010614_));
    vlSelf->wasmetal_core__DOT___055511_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055510_)))))))));
    vlSelf->wasmetal_core__DOT___043263_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___024477_))));
    wasmetal_core__DOT___070518_ = (1U & (0x8eafffffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055839_)))))));
    vlSelf->wasmetal_core__DOT___055854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055853_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->__VdfgTmp_hcfdcf3c6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 2U) | (IData)(__VdfgTmp_hcca0817d__0));
    vlSelf->wasmetal_core__DOT___056035_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hcca0817d__0))));
    wasmetal_core__DOT___070537_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010058_)))));
    vlSelf->wasmetal_core__DOT___070540_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055839_)))));
    vlSelf->wasmetal_core__DOT___024205_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___024204_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->__VdfgTmp_h3691f72d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055721_)));
    vlSelf->wasmetal_core__DOT___024202_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055789_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___024201_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___127636___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__)) 
                 | (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
    vlSelf->wasmetal_core__DOT___127653___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__)) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
    vlSelf->wasmetal_core__DOT___043250_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0))))));
    wasmetal_core__DOT___070529_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056070_)))))));
    vlSelf->wasmetal_core__DOT___068089_ = (1U & (IData)(
                                                         (0x88fff8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068071_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf400U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056038_)))))))));
    vlSelf->wasmetal_core__DOT___060724_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056038_))));
    __VdfgTmp_had20add3__0 = (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    __VdfgTmp_h2dd5429b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___008808_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___008807_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___008806_))))));
    wasmetal_core__DOT___055722_ = (1U & (IData)((0xfef0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008808_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008806_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___008807_)))))))));
    vlSelf->wasmetal_core__DOT___043261_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf4167eb1__0))))))));
    wasmetal_core__DOT___056217_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056212_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056211_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056210_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056174_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056173_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056172_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0x3faf00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___056170_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009218_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056169_)))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056207_)))))))));
    vlSelf->wasmetal_core__DOT___043240_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070510_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa7da8bd__0))));
    vlSelf->wasmetal_core__DOT___043258_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024511_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h78ee927d__0))))));
    vlSelf->wasmetal_core__DOT___024485_ = (1U & (0x10efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4528de02__0))));
    vlSelf->wasmetal_core__DOT___043239_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070533_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha0636656__0))));
    vlSelf->__VdfgTmp_h78c69d21__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010656_));
    vlSelf->wasmetal_core__DOT___043177_ = (1U & (IData)(
                                                         (0x2220bbb33332fffbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070514_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070513_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))))))))));
    vlSelf->wasmetal_core__DOT___043620_ = (1U & (IData)(
                                                         (0xeeef888cccce0008ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070514_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070513_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))))))))));
    vlSelf->wasmetal_core__DOT___070524_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024487_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h30ace780__0)))))));
    vlSelf->wasmetal_core__DOT___043246_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070522_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33ebc999__0))));
    __VdfgTmp_hc12c3471__0 = (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010054_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h6850d65a__0)))));
    vlSelf->wasmetal_core__DOT___043238_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070532_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h862c0500__0))));
    vlSelf->wasmetal_core__DOT___068114_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056689_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___060804_))))));
    vlSelf->__VdfgTmp_h9d55d8c7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056044_));
    vlSelf->wasmetal_core__DOT___010025_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)
                                                   ? (IData)(
                                                             (0xfef0ULL 
                                                              >> (IData)(__VdfgTmp_hc61624da__0)))
                                                   : (IData)(
                                                             (0xffffffffffff010fULL 
                                                              >> (IData)(__VdfgTmp_hc61624da__0)))));
    vlSelf->wasmetal_core__DOT___011276_ = (1U & (IData)(
                                                         (0xfef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc6176170__0)))));
    wasmetal_core__DOT___056363_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056358_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___056357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056044_)))))))));
    vlSelf->wasmetal_core__DOT___043237_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070531_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6abc2452__0))));
    vlSelf->wasmetal_core__DOT___043255_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7f725de9__0))))))));
    vlSelf->wasmetal_core__DOT___010062_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)
                                                   ? (IData)(
                                                             (0x9990ULL 
                                                              >> (IData)(__VdfgTmp_h5dfa3f6d__0)))
                                                   : (IData)(
                                                             (0x9999999999990009ULL 
                                                              >> (IData)(__VdfgTmp_h5dfa3f6d__0)))));
    vlSelf->wasmetal_core__DOT___043234_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070528_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc194321c__0))));
    wasmetal_core__DOT___010658_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h9dd569ac__0))));
    wasmetal_core__DOT___056139_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___012502_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h9dd569ac__0))));
    vlSelf->wasmetal_core__DOT___070520_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0)))))))));
    vlSelf->wasmetal_core__DOT___043260_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024469_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h64128247__0)))))));
    vlSelf->wasmetal_core__DOT___068414_ = (1U & (IData)(
                                                         (0xff00ee00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___068410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7a970221__0)))))));
    vlSelf->__VdfgTmp_h50ba50d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010023_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010028_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))));
    vlSelf->wasmetal_core__DOT___043243_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070519_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h50e83fab__0))));
    __VdfgTmp_h0d445bfa__0 = (((IData)(wasmetal_core__DOT___009687_) 
                               << 1U) | (IData)(wasmetal_core__DOT___009686_));
    vlSelf->wasmetal_core__DOT___043251_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0))))));
    vlSelf->wasmetal_core__DOT___043174_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_h2115d7e3__0)))))))))));
    vlSelf->wasmetal_core__DOT___043617_ = (1U & (IData)(
                                                         (0xfeeaeaeaaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(__VdfgTmp_h2115d7e3__0)))))))))));
    vlSelf->wasmetal_core__DOT___043242_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070518_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055854_)))));
    wasmetal_core__DOT___055865_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010043_)))));
    wasmetal_core__DOT___070526_ = (1U & (IData)((0x405444ffffffffffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4bU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h40167917__0))))))));
    vlSelf->wasmetal_core__DOT___043252_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4bU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010064_)))));
    wasmetal_core__DOT___070539_ = (1U & (0xe00U >> 
                                          ((8U & ((0xe1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055789_))))));
    wasmetal_core__DOT___070538_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___024202_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0xe1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0))))));
    if (vlSelf->wasmetal_core__DOT___010048_) {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127636___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010338_)));
    } else {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010338_)));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127653___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT___043235_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070529_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11bce3c4__0))));
    vlSelf->__VdfgTmp_h6a2679f3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 2U) | (IData)(__VdfgTmp_had20add3__0));
    vlSelf->wasmetal_core__DOT___010024_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)
                                                   ? (IData)(
                                                             (0xfef0ULL 
                                                              >> (IData)(__VdfgTmp_h2dd5429b__0)))
                                                   : (IData)(
                                                             (0xffffffffffff010fULL 
                                                              >> (IData)(__VdfgTmp_h2dd5429b__0)))));
    wasmetal_core__DOT___055733_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___055722_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055721_))));
    wasmetal_core__DOT___009688_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056217_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056216_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___056215_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                  ? 
                                                                 (0xc05U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xacU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009698_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaf0f0ff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007906_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008642_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008639_)))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___009267_)))))
                                                                  : 
                                                                 (0xc0aU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009758_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___009757_)))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056213_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055363_)))))))));
    vlSelf->wasmetal_core__DOT___043229_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009807_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x10U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)))))))))));
    vlSelf->__VdfgTmp_h2237a749__0 = (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024484_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)))));
    vlSelf->wasmetal_core__DOT___070525_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h78c69d21__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010027_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0))))))));
    vlSelf->wasmetal_core__DOT___043230_ = (1U & (IData)(
                                                         (0xffffffff40ff4040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070524_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010653_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04c057c0__0))))))));
    vlSelf->wasmetal_core__DOT___043262_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)
                                                   ? (IData)(
                                                             (0x900900000000ULL 
                                                              >> (IData)(__VdfgTmp_hc12c3471__0)))
                                                   : (IData)(
                                                             (0x9009000090099009ULL 
                                                              >> (IData)(__VdfgTmp_hc12c3471__0)))));
    vlSelf->wasmetal_core__DOT___043621_ = (1U & (IData)(
                                                         (0xaaffffff80ecc8feULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___055722_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))))))))));
    vlSelf->wasmetal_core__DOT___024259_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___043241_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070517_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h740b215b__0))))));
    vlSelf->wasmetal_core__DOT___043179_ = (1U & (IData)(
                                                         (0xffffffffff101010ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070517_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))))));
    vlSelf->wasmetal_core__DOT___043259_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hef18707b__0))))));
    wasmetal_core__DOT___056364_ = (1U & ((0xf1U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056038_)))) 
                                          & ((0xf1U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___056030_)))) 
                                             & (IData)(
                                                       (0x1000000000000ULL 
                                                        >> 
                                                        (((IData)(wasmetal_core__DOT___010658_) 
                                                          << 5U) 
                                                         | (((IData)(wasmetal_core__DOT___010657_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010656_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)) 
                                                                      << 2U)) 
                                                                  | (((IData)(wasmetal_core__DOT___010654_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010653_)))))))))));
    wasmetal_core__DOT___009689_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056140_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___056139_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056138_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                                  ? 
                                                                 (1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___009711_)))
                                                                  : (IData)(
                                                                            (0xb0bbULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))))));
    vlSelf->wasmetal_core__DOT___043244_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070520_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26c3fed8__0))));
    vlSelf->__VdfgTmp_hc8f8c4ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055865_));
    vlSelf->__VdfgTmp_h10a93ed5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055865_));
    vlSelf->__VdfgTmp_hfadc0d9c__0 = (((IData)(wasmetal_core__DOT___055865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055854_));
    vlSelf->__VdfgTmp_h9415b560__0 = (((IData)(wasmetal_core__DOT___055865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_));
    vlSelf->wasmetal_core__DOT___043232_ = (1U & (0xb0ffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070526_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0))));
    vlSelf->wasmetal_core__DOT___043622_ = (1U & (IData)(
                                                         (0xfffff000fffffeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___070539_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070538_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___070537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))))));
    vlSelf->wasmetal_core__DOT___043663_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070539_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___070538_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___043202_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024201_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070538_))));
    if (vlSelf->wasmetal_core__DOT___024221_) {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010045_)));
    } else {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010045_)));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___010014_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x4bU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043255_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0))))))));
    vlSelf->wasmetal_core__DOT___043233_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056044_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)))))))))));
    vlSelf->wasmetal_core__DOT___043253_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x4bU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0)))))));
    vlSelf->wasmetal_core__DOT___043178_ = (1U & (IData)(
                                                         (0xabaaffff0000abaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010024_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(wasmetal_core__DOT___055722_))))))))))));
    vlSelf->wasmetal_core__DOT___043201_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010025_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010024_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))))));
    vlSelf->wasmetal_core__DOT___024258_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___055733_))));
    vlSelf->wasmetal_core__DOT___055735_ = (1U & (0xfcf5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___055733_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055732_)))))));
    vlSelf->wasmetal_core__DOT___043231_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070525_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78c69d21__0))));
    vlSelf->wasmetal_core__DOT___010015_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___043262_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h64128247__0))))))));
    vlSelf->wasmetal_core__DOT___012496_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___056364_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___056363_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056362_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___056354_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056353_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055239_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x10U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((0xfff1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x305U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heedd871e__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010069_)))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011276_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((1U 
                                                                              >> 
                                                                              ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009711_)))) 
                                                                             & (((IData)(vlSelf->wasmetal_core__DOT___010627_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008809_))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010626_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008809_))
                                                                                 : (IData)(
                                                                                (0xffffffff0001ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010625_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010624_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h242203a7__0))))))))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x10U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0x10U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010614_)))))))))))))))))));
    vlSelf->__VdfgTmp_h1cb679e9__0 = (((IData)(wasmetal_core__DOT___009687_) 
                                       << 4U) | (((IData)(wasmetal_core__DOT___009686_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___009688_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___009689_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0)))))));
    vlSelf->__VdfgTmp_h22919fe9__0 = (((IData)(wasmetal_core__DOT___009689_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009687_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___009686_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___009688_))));
    vlSelf->__VdfgTmp_h238f5c0e__0 = (((IData)(wasmetal_core__DOT___009688_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009689_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h0d445bfa__0)));
    vlSelf->__VdfgTmp_h83b9759e__0 = (((IData)(wasmetal_core__DOT___009689_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009688_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h0d445bfa__0)));
    vlSelf->wasmetal_core__DOT___024206_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8f8c4ae__0)))));
    vlSelf->__VdfgTmp_h27f90c9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___056135_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hdb7f5f3b__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h09d9ebba__0 = ((4U & ((1U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hf2504815__0 = ((4U & ((1U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hf8fd63d3__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010651_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h5c2c85cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_he887753f__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd9969096__0 = (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h7fe84144__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h3971bdc1__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010646_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h373f306d__0 = (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h2f82e844__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hc699f06e__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h86e2747e__0 = (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hb788ecb2__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h03f01150__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h8c718ae9__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056044_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h3300e967__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(__VdfgTmp_had20add3__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hde8b5012__0 = (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd8684912__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(__VdfgTmp_h40167917__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h27272852__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h9b8fed80__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd2c8a10e__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (IData)(wasmetal_core__DOT___010654_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_ha16f0aa3__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h30ace780__0))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->wasmetal_core__DOT___043180_ = (1U & (0xcf5f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070518_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfadc0d9c__0))))));
    vlSelf->wasmetal_core__DOT___043169_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070528_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043167_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070526_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043172_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070531_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043171_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070530_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043170_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070529_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___056122_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056112_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056108_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056105_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056104_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056091_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056023_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010656_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->__VdfgTmp_h5553b859__0 = (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9415b560__0));
    vlSelf->wasmetal_core__DOT___056011_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010653_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055998_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055991_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x10U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
}
